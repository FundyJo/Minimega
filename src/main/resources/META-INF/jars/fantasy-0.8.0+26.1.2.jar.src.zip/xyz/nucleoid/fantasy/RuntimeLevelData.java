/*    */ package xyz.nucleoid.fantasy;
/*    */ 
/*    */ import net.minecraft.world.Difficulty;
/*    */ import net.minecraft.world.level.storage.DerivedLevelData;
/*    */ import net.minecraft.world.level.storage.WorldData;
/*    */ 
/*    */ public final class RuntimeLevelData
/*    */   extends DerivedLevelData
/*    */ {
/*    */   final RuntimeLevelConfig config;
/*    */   
/*    */   public RuntimeLevelData(WorldData worldData, RuntimeLevelConfig config) {
/* 13 */     super(worldData, worldData.overworldData());
/* 14 */     this.config = config;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getGameTime() {
/* 19 */     return this.config.getGameTime();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setGameTime(long time) {
/* 24 */     this.config.setGameTime(time);
/*    */   }
/*    */ 
/*    */   
/*    */   public Difficulty getDifficulty() {
/* 29 */     if (this.config.shouldMirrorOverworldDifficulty()) {
/* 30 */       return super.getDifficulty();
/*    */     }
/* 32 */     return this.config.getDifficulty();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\RuntimeLevelData.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */