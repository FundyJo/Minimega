package xyz.nucleoid.fantasy.util;

import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import org.jetbrains.annotations.Nullable;

public interface ChunkGeneratorSettingsProvider {
  @Nullable
  NoiseGeneratorSettings getSettings();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantas\\util\ChunkGeneratorSettingsProvider.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */