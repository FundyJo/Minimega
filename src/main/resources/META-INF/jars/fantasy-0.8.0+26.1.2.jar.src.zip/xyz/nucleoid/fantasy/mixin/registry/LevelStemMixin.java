/*    */ package xyz.nucleoid.fantasy.mixin.registry;
/*    */ 
/*    */ import net.minecraft.world.level.dimension.LevelStem;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import xyz.nucleoid.fantasy.FantasyDimensionOptions;
/*    */ 
/*    */ @Mixin({LevelStem.class})
/*    */ public class LevelStemMixin
/*    */   implements FantasyDimensionOptions {
/*    */   @Unique
/*    */   private boolean fantasy$save = true;
/*    */   
/*    */   public void fantasy$setSave(boolean value) {
/* 15 */     this.fantasy$save = value;
/*    */   }
/*    */   @Unique
/*    */   private boolean fantasy$saveProperties = true;
/*    */   public boolean fantasy$getSave() {
/* 20 */     return this.fantasy$save;
/*    */   }
/*    */ 
/*    */   
/*    */   public void fantasy$setSaveProperties(boolean value) {
/* 25 */     this.fantasy$saveProperties = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean fantasy$getSaveProperties() {
/* 30 */     return this.fantasy$saveProperties;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\registry\LevelStemMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */