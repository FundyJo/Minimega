/*    */ package xyz.nucleoid.fantasy.mixin.clock;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.server.level.ServerLevel;
/*    */ import net.minecraft.server.players.PlayerList;
/*    */ import net.minecraft.world.clock.ServerClockManager;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ 
/*    */ @Mixin({PlayerList.class})
/*    */ public class PlayerListMixin {
/*    */   @WrapOperation(method = {"sendLevelInfo"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/server/MinecraftServer;clockManager()Lnet/minecraft/world/clock/ServerClockManager;")})
/*    */   private ServerClockManager replaceClockManager(MinecraftServer instance, Operation<ServerClockManager> original, @Local(argsOnly = true) ServerLevel level) {
/* 17 */     return level.clockManager();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\clock\PlayerListMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */