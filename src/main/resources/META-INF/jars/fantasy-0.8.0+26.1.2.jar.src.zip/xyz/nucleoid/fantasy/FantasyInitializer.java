/*    */ package xyz.nucleoid.fantasy;
/*    */ 
/*    */ import net.fabricmc.api.ModInitializer;
/*    */ import net.minecraft.core.Registry;
/*    */ import net.minecraft.core.registries.BuiltInRegistries;
/*    */ import net.minecraft.resources.Identifier;
/*    */ import xyz.nucleoid.fantasy.util.TransientChunkGenerator;
/*    */ import xyz.nucleoid.fantasy.util.VoidChunkGenerator;
/*    */ 
/*    */ public final class FantasyInitializer
/*    */   implements ModInitializer {
/*    */   public void onInitialize() {
/* 13 */     Registry.register(BuiltInRegistries.CHUNK_GENERATOR, Identifier.fromNamespaceAndPath("fantasy", "void"), VoidChunkGenerator.CODEC);
/* 14 */     Registry.register(BuiltInRegistries.CHUNK_GENERATOR, Identifier.fromNamespaceAndPath("fantasy", "transient"), TransientChunkGenerator.CODEC);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\FantasyInitializer.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */