/*    */ package xyz.nucleoid.fantasy.mixin;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import net.minecraft.server.level.ChunkMap;
/*    */ import net.minecraft.world.level.chunk.ChunkGenerator;
/*    */ import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import xyz.nucleoid.fantasy.util.ChunkGeneratorSettingsProvider;
/*    */ 
/*    */ @Mixin({ChunkMap.class})
/*    */ public class ChunkMapMixin
/*    */ {
/*    */   @WrapOperation(method = {"<init>"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/world/level/levelgen/NoiseGeneratorSettings;dummy()Lnet/minecraft/world/level/levelgen/NoiseGeneratorSettings;")})
/*    */   private NoiseGeneratorSettings fantasy$useProvidedChunkGeneratorSettings(Operation<NoiseGeneratorSettings> original, @Local(argsOnly = true) ChunkGenerator chunkGenerator) {
/* 18 */     if (chunkGenerator instanceof ChunkGeneratorSettingsProvider) { ChunkGeneratorSettingsProvider provider = (ChunkGeneratorSettingsProvider)chunkGenerator;
/* 19 */       NoiseGeneratorSettings settings = provider.getSettings();
/* 20 */       if (settings != null) return settings;
/*    */        }
/*    */     
/* 23 */     return (NoiseGeneratorSettings)original.call(new Object[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\ChunkMapMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */