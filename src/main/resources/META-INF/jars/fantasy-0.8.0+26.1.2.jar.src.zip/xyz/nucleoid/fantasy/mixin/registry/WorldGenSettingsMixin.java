/*    */ package xyz.nucleoid.fantasy.mixin.registry;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import java.util.Map;
/*    */ import net.minecraft.resources.ResourceKey;
/*    */ import net.minecraft.world.level.dimension.LevelStem;
/*    */ import net.minecraft.world.level.levelgen.WorldDimensions;
/*    */ import net.minecraft.world.level.levelgen.WorldGenSettings;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyArg;
/*    */ import xyz.nucleoid.fantasy.FantasyDimensionOptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({WorldGenSettings.class})
/*    */ public class WorldGenSettingsMixin
/*    */ {
/*    */   @ModifyArg(method = {"of(Lnet/minecraft/world/level/levelgen/WorldOptions;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/world/level/levelgen/WorldGenSettings;"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/levelgen/WorldGenSettings;<init>(Lnet/minecraft/world/level/levelgen/WorldOptions;Lnet/minecraft/world/level/levelgen/WorldDimensions;)V"), index = 1)
/*    */   private static WorldDimensions fantasy$wrapWorldGenSettings(WorldDimensions original) {
/* 23 */     Map<ResourceKey<LevelStem>, LevelStem> dimensions = original.dimensions();
/* 24 */     Map<ResourceKey<LevelStem>, LevelStem> saveDimensions = Maps.filterEntries(dimensions, entry -> FantasyDimensionOptions.SAVE_PROPERTIES_PREDICATE.test((LevelStem)entry.getValue()));
/*    */     
/* 26 */     return new WorldDimensions(saveDimensions);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\registry\WorldGenSettingsMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */