/*    */ package xyz.nucleoid.fantasy;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.world.level.dimension.LevelStem;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ 
/*    */ @Internal
/*    */ public interface FantasyDimensionOptions {
/*    */   static {
/* 10 */     SAVE_PREDICATE = (e -> ((FantasyDimensionOptions)e).fantasy$getSave());
/* 11 */     SAVE_PROPERTIES_PREDICATE = (e -> ((FantasyDimensionOptions)e).fantasy$getSaveProperties());
/*    */   }
/*    */   
/*    */   public static final Predicate<LevelStem> SAVE_PREDICATE;
/*    */   public static final Predicate<LevelStem> SAVE_PROPERTIES_PREDICATE;
/*    */   
/*    */   boolean fantasy$getSaveProperties();
/*    */   
/*    */   void fantasy$setSaveProperties(boolean paramBoolean);
/*    */   
/*    */   boolean fantasy$getSave();
/*    */   
/*    */   void fantasy$setSave(boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\FantasyDimensionOptions.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */