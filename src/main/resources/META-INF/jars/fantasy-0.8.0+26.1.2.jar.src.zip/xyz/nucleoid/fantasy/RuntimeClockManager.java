/*    */ package xyz.nucleoid.fantasy;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.function.BooleanSupplier;
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.core.Holder;
/*    */ import net.minecraft.network.protocol.Packet;
/*    */ import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.server.level.ServerLevel;
/*    */ import net.minecraft.server.level.ServerPlayer;
/*    */ import net.minecraft.util.Util;
/*    */ import net.minecraft.world.clock.ClockNetworkState;
/*    */ import net.minecraft.world.clock.PackedClockStates;
/*    */ import net.minecraft.world.clock.ServerClockManager;
/*    */ import net.minecraft.world.clock.WorldClock;
/*    */ import xyz.nucleoid.fantasy.mixin.clock.ClockInstanceAccessor;
/*    */ 
/*    */ public class RuntimeClockManager extends ServerClockManager {
/*    */   protected final BooleanSupplier advanceTime;
/*    */   
/*    */   public RuntimeClockManager(PackedClockStates packedClockStates, BooleanSupplier advanceTime) {
/* 23 */     super(packedClockStates);
/* 24 */     this.advanceTime = advanceTime;
/*    */   }
/*    */   protected MinecraftServer server;
/*    */   
/*    */   public void init(MinecraftServer server) {
/* 29 */     super.init(server);
/* 30 */     this.server = server;
/*    */   }
/*    */ 
/*    */   
/*    */   public void tick() {
/* 35 */     if (this.advanceTime.getAsBoolean()) {
/* 36 */       ((ServerClockManagerExtension)this).fantasy$getClocks().values().forEach(ServerClockManager.ClockInstance::tick);
/* 37 */       setDirty();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void modifyClock(Holder<WorldClock> clock, Consumer<? super ServerClockManager.ClockInstance> action) {
/* 43 */     ServerClockManager.ClockInstance instance = getInstance(clock);
/* 44 */     action.accept(instance);
/* 45 */     Map<Holder<WorldClock>, ClockNetworkState> updates = Map.of(clock, packNetworkState(instance, this.server));
/* 46 */     setDirty();
/*    */     
/* 48 */     ClientboundSetTimePacket packet = new ClientboundSetTimePacket(getGameTime(), updates);
/*    */     
/* 50 */     for (ServerLevel level : this.server.getAllLevels()) {
/* 51 */       if (level.clockManager() == this) {
/* 52 */         for (ServerPlayer player : level.players()) {
/* 53 */           player.connection.send((Packet)packet);
/*    */         }
/*    */         
/* 56 */         level.environmentAttributes().invalidateTickCache();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public ClientboundSetTimePacket createFullSyncPacket() {
/* 63 */     return new ClientboundSetTimePacket(getGameTime(), Util.mapValues(((ServerClockManagerExtension)this).fantasy$getClocks(), clock -> packNetworkState(clock, this.server)));
/*    */   }
/*    */   
/*    */   protected ClockNetworkState packNetworkState(ServerClockManager.ClockInstance instance, MinecraftServer server) {
/* 67 */     ClockInstanceAccessor i = (ClockInstanceAccessor)instance;
/* 68 */     boolean paused = (i.isPaused() || !this.advanceTime.getAsBoolean());
/* 69 */     return new ClockNetworkState(i.getTotalTicks(), i.getPartialTick(), paused ? 0.0F : i.getRate());
/*    */   }
/*    */   
/*    */   public void tickFromLevel(RuntimeLevel level) {
/* 73 */     tick();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\RuntimeClockManager.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */