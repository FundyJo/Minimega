package xyz.nucleoid.fantasy.mixin;

import net.minecraft.world.level.gamerules.GameRuleMap;
import net.minecraft.world.level.gamerules.GameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({GameRules.class})
public interface GameRulesAccessor {
  @Accessor
  GameRuleMap getRules();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\GameRulesAccessor.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */