/*    */ package xyz.nucleoid.fantasy.mixin;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import java.util.List;
/*    */ import java.util.function.BooleanSupplier;
/*    */ import net.minecraft.network.protocol.Packet;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.server.level.ServerChunkCache;
/*    */ import net.minecraft.server.level.ServerLevel;
/*    */ import net.minecraft.server.level.ServerPlayer;
/*    */ import net.minecraft.server.players.PlayerList;
/*    */ import net.minecraft.world.clock.ServerClockManager;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import xyz.nucleoid.fantasy.FantasyLevelAccess;
/*    */ import xyz.nucleoid.fantasy.RuntimeLevel;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({ServerLevel.class})
/*    */ public abstract class ServerLevelMixin
/*    */   implements FantasyLevelAccess
/*    */ {
/*    */   @Unique
/*    */   private static final int TICK_TIMEOUT = 300;
/*    */   @Unique
/*    */   private boolean fantasy$tickWhenEmpty = true;
/*    */   @Unique
/*    */   private int fantasy$tickTimeout;
/*    */   
/*    */   @Shadow
/*    */   public abstract List<ServerPlayer> players();
/*    */   
/*    */   @Shadow
/*    */   public abstract ServerChunkCache getChunkSource();
/*    */   
/*    */   public void fantasy$setTickWhenEmpty(boolean tickWhenEmpty) {
/* 44 */     this.fantasy$tickWhenEmpty = tickWhenEmpty;
/*    */   }
/*    */   
/*    */   @Inject(method = {"tick"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void tick(BooleanSupplier shouldKeepTicking, CallbackInfo ci) {
/* 49 */     boolean shouldTick = (this.fantasy$tickWhenEmpty || !isLevelEmpty());
/* 50 */     if (shouldTick) {
/* 51 */       this.fantasy$tickTimeout = 300;
/* 52 */     } else if (this.fantasy$tickTimeout-- <= 0) {
/* 53 */       ci.cancel();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean fantasy$shouldTick() {
/* 59 */     boolean shouldTick = (this.fantasy$tickWhenEmpty || !isLevelEmpty());
/* 60 */     return (shouldTick || this.fantasy$tickTimeout > 0);
/*    */   }
/*    */   
/*    */   @Unique
/*    */   private boolean isLevelEmpty() {
/* 65 */     return (players().isEmpty() && getChunkSource().getLoadedChunksCount() <= 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Redirect(method = {"advanceWeatherCycle"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/server/players/PlayerList;broadcastAll(Lnet/minecraft/network/protocol/Packet;)V"))
/*    */   private void dontSendRainPacketsToAllLevels(PlayerList instance, Packet<?> packet) {
/* 80 */     instance.broadcastAll(packet, getChunkSource().getLevel().dimension());
/*    */   }
/*    */   
/*    */   @WrapOperation(method = {"tick"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/server/MinecraftServer;clockManager()Lnet/minecraft/world/clock/ServerClockManager;")})
/*    */   private ServerClockManager onTickMoveToTimeMarkerWakeUp(MinecraftServer instance, Operation<ServerClockManager> original) {
/* 85 */     ServerLevelMixin serverLevelMixin = this; if (serverLevelMixin instanceof RuntimeLevel) { RuntimeLevel level = (RuntimeLevel)serverLevelMixin;
/* 86 */       return level.clockManager(); }
/*    */     
/* 88 */     return (ServerClockManager)original.call(new Object[] { instance });
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\ServerLevelMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */