package xyz.nucleoid.fantasy;

import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;

public interface Constructor {
  RuntimeLevel createLevel(MinecraftServer paramMinecraftServer, ResourceKey<Level> paramResourceKey, RuntimeLevelConfig paramRuntimeLevelConfig, RuntimeLevel.Style paramStyle);
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\RuntimeLevel$Constructor.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */