/*    */ package xyz.nucleoid.fantasy.mixin;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import net.minecraft.commands.CommandSourceStack;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.server.commands.TimeCommand;
/*    */ import net.minecraft.world.clock.ServerClockManager;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({TimeCommand.class})
/*    */ public class TimeCommandMixin
/*    */ {
/*    */   @WrapOperation(method = {"suggestTimeMarkers", "queryTime", "setTotalTicks", "addTime", "setTimeToTimeMarker", "setPaused", "setRate", "queryTimelineTicks", "queryTimelineRepetitions"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/server/MinecraftServer;clockManager()Lnet/minecraft/world/clock/ServerClockManager;")})
/*    */   private static ServerClockManager useRuntimeClockManager(MinecraftServer instance, Operation<ServerClockManager> original, @Local(argsOnly = true) CommandSourceStack source) {
/* 23 */     return source.getLevel().clockManager();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\TimeCommandMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */