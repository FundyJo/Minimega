/*     */ package xyz.nucleoid.fantasy;
/*     */ 
/*     */ import com.google.common.base.Preconditions;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import java.util.function.Function;
/*     */ import net.fabricmc.fabric.api.util.TriState;
/*     */ import net.minecraft.core.Holder;
/*     */ import net.minecraft.core.registries.Registries;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.world.Difficulty;
/*     */ import net.minecraft.world.clock.ClockState;
/*     */ import net.minecraft.world.clock.PackedClockStates;
/*     */ import net.minecraft.world.clock.ServerClockManager;
/*     */ import net.minecraft.world.clock.WorldClock;
/*     */ import net.minecraft.world.level.chunk.ChunkGenerator;
/*     */ import net.minecraft.world.level.dimension.DimensionType;
/*     */ import net.minecraft.world.level.dimension.LevelStem;
/*     */ import net.minecraft.world.level.gamerules.GameRule;
/*     */ import net.minecraft.world.level.gamerules.GameRules;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import xyz.nucleoid.fantasy.util.GameRuleStore;
/*     */ 
/*     */ 
/*     */ public final class RuntimeLevelConfig
/*     */ {
/*     */   private long seed;
/*     */   private ResourceKey<DimensionType> dimensionTypeKey;
/*     */   private Holder<DimensionType> dimensionType;
/*     */   
/*     */   public RuntimeLevelConfig() {
/*  35 */     this.seed = 0L;
/*  36 */     this.dimensionTypeKey = Fantasy.DEFAULT_DIM_TYPE;
/*     */     
/*  38 */     this.generator = null;
/*  39 */     this.shouldTickTime = false;
/*  40 */     this.difficulty = Difficulty.NORMAL;
/*  41 */     this.gameRules = new GameRuleStore();
/*  42 */     this.mirrorOverworldGameRules = false;
/*  43 */     this.mirrorOverworldDifficulty = false;
/*  44 */     this.mirrorOverworldClocks = false;
/*  45 */     this.levelConstructor = RuntimeLevel::new;
/*  46 */     this.clockManagerConstructor = ((c, s) -> new RuntimeClockManager(c, s));
/*  47 */     this.clockState = new HashMap<>();
/*     */     
/*  49 */     this.gameTime = 0L;
/*  50 */     this.flat = TriState.DEFAULT;
/*     */   }
/*     */   private ChunkGenerator generator; private boolean shouldTickTime; private Difficulty difficulty;
/*     */   private final GameRuleStore gameRules;
/*     */   private boolean mirrorOverworldGameRules;
/*     */   private boolean mirrorOverworldDifficulty;
/*     */   private boolean mirrorOverworldClocks;
/*     */   private RuntimeLevel.Constructor levelConstructor;
/*     */   
/*     */   public RuntimeLevelConfig setSeed(long seed) {
/*  60 */     this.seed = seed;
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private BiFunction<PackedClockStates, BooleanSupplier, RuntimeClockManager> clockManagerConstructor;
/*     */   
/*     */   private final Map<ResourceKey<WorldClock>, ClockState> clockState;
/*     */   private long gameTime;
/*     */   private TriState flat;
/*     */   
/*     */   public RuntimeLevelConfig setLevelConstructor(RuntimeLevel.Constructor constructor) {
/*  72 */     this.levelConstructor = constructor;
/*  73 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setClockManagerConstructor(PackedClockStates clockStates) {
/*  84 */     this.clockManagerConstructor = ((paramPackedClockStates1, s) -> new RuntimeClockManager(clockStates, s));
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setClockManagerConstructor(Function<BooleanSupplier, RuntimeClockManager> clockManagerConstructor) {
/*  96 */     this.clockManagerConstructor = ((paramPackedClockStates, s) -> (RuntimeClockManager)clockManagerConstructor.apply(s));
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setClockManagerConstructor(BiFunction<PackedClockStates, BooleanSupplier, RuntimeClockManager> clockManagerConstructor) {
/* 108 */     this.clockManagerConstructor = clockManagerConstructor;
/* 109 */     return this;
/*     */   }
/*     */   
/*     */   public RuntimeLevelConfig setClockTime(ResourceKey<WorldClock> clock, int time) {
/* 113 */     return setClockTime(clock, new ClockState(time, 0.0F, 1.0F, false));
/*     */   }
/*     */   
/*     */   public RuntimeLevelConfig setClockTime(ResourceKey<WorldClock> clock, int time, float rate) {
/* 117 */     return setClockTime(clock, new ClockState(time, 0.0F, rate, false));
/*     */   }
/*     */   
/*     */   public RuntimeLevelConfig setClockTime(ResourceKey<WorldClock> clock, int time, boolean paused) {
/* 121 */     return setClockTime(clock, new ClockState(time, 0.0F, 1.0F, paused));
/*     */   }
/*     */   
/*     */   public RuntimeLevelConfig setClockTime(ResourceKey<WorldClock> clock, ClockState state) {
/* 125 */     this.clockState.put(clock, state);
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setDimensionType(Holder<DimensionType> dimensionType) {
/* 137 */     this.dimensionType = dimensionType;
/* 138 */     this.dimensionTypeKey = null;
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public RuntimeLevelConfig setDimensionType(DimensionType dimensionType) {
/* 154 */     this.dimensionType = Holder.direct(dimensionType);
/* 155 */     this.dimensionTypeKey = null;
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setDimensionType(ResourceKey<DimensionType> dimensionType) {
/* 167 */     this.dimensionTypeKey = dimensionType;
/* 168 */     this.dimensionType = null;
/* 169 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setGenerator(ChunkGenerator generator) {
/* 180 */     this.generator = generator;
/* 181 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setShouldTickTime(boolean shouldTickTime) {
/* 198 */     this.shouldTickTime = shouldTickTime;
/* 199 */     this.gameRules.set(GameRules.ADVANCE_TIME, Boolean.valueOf(shouldTickTime));
/* 200 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setGameTime(long gameTime) {
/* 211 */     this.gameTime = gameTime;
/* 212 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setDifficulty(Difficulty difficulty) {
/* 223 */     this.difficulty = difficulty;
/* 224 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> RuntimeLevelConfig setGameRule(GameRule<T> key, T value) {
/* 236 */     this.gameRules.set(key, value);
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setMirrorOverworldGameRules(boolean mirror) {
/* 248 */     this.mirrorOverworldGameRules = mirror;
/* 249 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setMirrorOverworldDifficulty(boolean mirror) {
/* 260 */     this.mirrorOverworldDifficulty = mirror;
/* 261 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setMirrorOverworldClocks(boolean mirror) {
/* 272 */     this.mirrorOverworldClocks = mirror;
/* 273 */     return this;
/*     */   }
/*     */   
/*     */   public RuntimeLevelConfig mirrorOverworldGameState() {
/* 277 */     setMirrorOverworldGameRules(true);
/* 278 */     setMirrorOverworldClocks(true);
/* 279 */     setMirrorOverworldDifficulty(true);
/* 280 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setFlat(TriState state) {
/* 291 */     this.flat = state;
/* 292 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelConfig setFlat(boolean state) {
/* 303 */     return setFlat(TriState.of(state));
/*     */   }
/*     */   
/*     */   public long getSeed() {
/* 307 */     return this.seed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LevelStem createDimensionOptions(MinecraftServer server) {
/* 316 */     Holder<DimensionType> dimensionType = resolveDimensionType(server);
/* 317 */     return new LevelStem(dimensionType, this.generator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Holder<DimensionType> resolveDimensionType(MinecraftServer server) {
/* 326 */     Holder<DimensionType> dimensionType = this.dimensionType;
/* 327 */     if (dimensionType == null) {
/* 328 */       dimensionType = server.registryAccess().lookupOrThrow(Registries.DIMENSION_TYPE).get(this.dimensionTypeKey).orElse(null);
/* 329 */       Preconditions.checkNotNull(dimensionType, "invalid dimension type " + String.valueOf(this.dimensionTypeKey));
/*     */     } 
/* 331 */     return dimensionType;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public ChunkGenerator getGenerator() {
/* 336 */     return this.generator;
/*     */   }
/*     */   
/*     */   public RuntimeLevel.Constructor getLevelConstructor() {
/* 340 */     return this.levelConstructor;
/*     */   }
/*     */   
/*     */   public boolean shouldTickTime() {
/* 344 */     return this.shouldTickTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Difficulty getDifficulty() {
/* 355 */     return this.difficulty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GameRuleStore getGameRules() {
/* 366 */     return this.gameRules;
/*     */   }
/*     */   
/*     */   public boolean shouldMirrorOverworldGameRules() {
/* 370 */     return this.mirrorOverworldGameRules;
/*     */   }
/*     */   
/*     */   public boolean shouldMirrorOverworldDifficulty() {
/* 374 */     return this.mirrorOverworldDifficulty;
/*     */   }
/*     */   
/*     */   public boolean shouldMirrorOverworldClocks() {
/* 378 */     return this.mirrorOverworldClocks;
/*     */   }
/*     */   
/*     */   public long getGameTime() {
/* 382 */     return this.gameTime;
/*     */   }
/*     */   
/*     */   public TriState isFlat() {
/* 386 */     return this.flat;
/*     */   }
/*     */   
/*     */   public ServerClockManager getClockManager(MinecraftServer server, GameRules gameRules) {
/* 390 */     if (this.mirrorOverworldClocks) {
/* 391 */       return server.clockManager();
/*     */     }
/* 393 */     PackedClockStates states = PackedClockStates.EMPTY;
/* 394 */     if (!this.clockState.isEmpty()) {
/* 395 */       HashMap<Holder<WorldClock>, ClockState> map = new HashMap<>();
/* 396 */       for (Map.Entry<ResourceKey<WorldClock>, ClockState> entry : this.clockState.entrySet()) {
/* 397 */         map.put(server.registryAccess().getOrThrow(entry.getKey()), entry.getValue());
/*     */       }
/* 399 */       states = new PackedClockStates(map);
/*     */     } 
/*     */     
/* 402 */     RuntimeClockManager t = this.clockManagerConstructor.apply(states, () -> ((Boolean)gameRules.get(GameRules.ADVANCE_TIME)).booleanValue());
/* 403 */     t.init(server);
/*     */     
/* 405 */     return t;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\RuntimeLevelConfig.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */