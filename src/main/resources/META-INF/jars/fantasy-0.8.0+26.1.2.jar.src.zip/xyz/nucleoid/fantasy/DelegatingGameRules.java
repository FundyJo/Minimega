/*    */ package xyz.nucleoid.fantasy;
/*    */ 
/*    */ import com.google.common.collect.Streams;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.world.flag.FeatureFlagSet;
/*    */ import net.minecraft.world.level.gamerules.GameRule;
/*    */ import net.minecraft.world.level.gamerules.GameRuleMap;
/*    */ import net.minecraft.world.level.gamerules.GameRules;
/*    */ import xyz.nucleoid.fantasy.mixin.GameRulesAccessor;
/*    */ 
/*    */ class DelegatingGameRules
/*    */   extends GameRules
/*    */ {
/*    */   private final GameRules parent;
/*    */   private final GameRuleMap rules;
/*    */   
/*    */   public DelegatingGameRules(GameRules parent) {
/* 20 */     super(List.of());
/* 21 */     this.parent = parent;
/* 22 */     this.rules = ((GameRulesAccessor)this).getRules();
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> void set(GameRule<T> gameRule, T value, MinecraftServer server) {
/* 27 */     this.rules.set(gameRule, value);
/* 28 */     if (server != null) {
/* 29 */       server.onGameRuleChanged(gameRule, value);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> T get(GameRule<T> gameRule) {
/* 35 */     T value = (T)this.rules.get(gameRule);
/* 36 */     if (value == null) {
/* 37 */       return (T)this.parent.get(gameRule);
/*    */     }
/* 39 */     return value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<GameRule<?>> availableRules() {
/* 45 */     return Streams.concat(new Stream[] { this.rules.keySet().stream(), this.parent.availableRules() });
/*    */   }
/*    */ 
/*    */   
/*    */   public GameRules copy(FeatureFlagSet enabledFeatures) {
/* 50 */     DelegatingGameRules copy = new DelegatingGameRules(this.parent);
/* 51 */     setAll(this, null);
/* 52 */     return copy;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\DelegatingGameRules.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */