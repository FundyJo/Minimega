package xyz.nucleoid.fantasy.mixin;

import java.util.Map;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.LevelStorageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({MinecraftServer.class})
public interface MinecraftServerAccess {
  @Accessor
  Map<ResourceKey<Level>, ServerLevel> getLevels();
  
  @Accessor
  LevelStorageSource.LevelStorageAccess getStorageSource();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\MinecraftServerAccess.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */