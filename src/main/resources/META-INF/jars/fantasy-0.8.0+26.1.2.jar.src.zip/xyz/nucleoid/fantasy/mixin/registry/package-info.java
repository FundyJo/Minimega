package xyz.nucleoid.fantasy.mixin.registry;

import org.jetbrains.annotations.ApiStatus.Internal;



/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\registry\package-info.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */