/*    */ package xyz.nucleoid.fantasy;
/*    */ 
/*    */ import net.minecraft.resources.ResourceKey;
/*    */ import net.minecraft.server.level.ServerLevel;
/*    */ import net.minecraft.world.level.Level;
/*    */ 
/*    */ public final class RuntimeLevelHandle {
/*    */   private final Fantasy fantasy;
/*    */   private final ServerLevel level;
/*    */   
/*    */   RuntimeLevelHandle(Fantasy fantasy, ServerLevel level) {
/* 12 */     this.fantasy = fantasy;
/* 13 */     this.level = level;
/*    */   }
/*    */   
/*    */   public void setTickWhenEmpty(boolean tickWhenEmpty) {
/* 17 */     ((FantasyLevelAccess)this.level).fantasy$setTickWhenEmpty(tickWhenEmpty);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void delete() {
/* 24 */     this.fantasy.enqueueLevelDeletion(this.level);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void unload() {
/* 31 */     ServerLevel serverLevel = this.level; if (serverLevel instanceof RuntimeLevel) { RuntimeLevel runtimeLevel = (RuntimeLevel)serverLevel; if (runtimeLevel.style == RuntimeLevel.Style.TEMPORARY) {
/* 32 */         this.fantasy.enqueueLevelDeletion(this.level); return;
/*    */       }  }
/* 34 */      this.fantasy.enqueueLevelUnloading(this.level);
/*    */   }
/*    */ 
/*    */   
/*    */   public ServerLevel asLevel() {
/* 39 */     return this.level;
/*    */   }
/*    */   
/*    */   public ResourceKey<Level> getRegistryKey() {
/* 43 */     return this.level.dimension();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\RuntimeLevelHandle.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */