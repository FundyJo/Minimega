/*     */ package xyz.nucleoid.fantasy;
/*     */ 
/*     */ import com.google.common.base.Preconditions;
/*     */ import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
/*     */ import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
/*     */ import net.minecraft.core.registries.Registries;
/*     */ import net.minecraft.resources.Identifier;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.level.ServerLevel;
/*     */ import net.minecraft.server.level.ServerPlayer;
/*     */ import net.minecraft.world.clock.WorldClock;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.dimension.DimensionType;
/*     */ import net.minecraft.world.level.portal.TeleportTransition;
/*     */ import net.minecraft.world.level.storage.LevelData;
/*     */ import net.minecraft.world.level.storage.LevelStorageSource;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.lang3.RandomStringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import xyz.nucleoid.fantasy.mixin.MinecraftServerAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Fantasy
/*     */ {
/*  41 */   public static final Logger LOGGER = LogManager.getLogger(Fantasy.class);
/*     */ 
/*     */   
/*     */   public static final String ID = "fantasy";
/*     */   
/*  46 */   public static final ResourceKey<DimensionType> DEFAULT_DIM_TYPE = ResourceKey.create(Registries.DIMENSION_TYPE, Identifier.fromNamespaceAndPath("fantasy", "default"));
/*  47 */   public static final ResourceKey<WorldClock> DEFAULT_CLOCK = ResourceKey.create(Registries.WORLD_CLOCK, Identifier.fromNamespaceAndPath("fantasy", "default"));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final ResourceKey<DimensionType> DEFAULT_OVERWORLD_DIM_TYPE = ResourceKey.create(Registries.DIMENSION_TYPE, Identifier.fromNamespaceAndPath("fantasy", "default_overworld"));
/*     */   
/*     */   private static Fantasy instance;
/*     */   
/*     */   private final MinecraftServer server;
/*     */   
/*     */   private final MinecraftServerAccess serverAccess;
/*     */   private final RuntimeLevelManager levelManager;
/*  60 */   private final Set<ServerLevel> deletionQueue = (Set<ServerLevel>)new ReferenceOpenHashSet();
/*  61 */   private final Set<ServerLevel> unloadingQueue = (Set<ServerLevel>)new ReferenceOpenHashSet();
/*     */   
/*     */   static {
/*  64 */     ServerTickEvents.START_SERVER_TICK.register(server -> {
/*     */           Fantasy fantasy = get(server);
/*     */           
/*     */           fantasy.tick();
/*     */         });
/*  69 */     ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
/*     */           Fantasy fantasy = get(server);
/*     */           fantasy.onServerStopping();
/*     */         });
/*     */   }
/*     */   
/*     */   private Fantasy(MinecraftServer server) {
/*  76 */     this.server = server;
/*  77 */     this.serverAccess = (MinecraftServerAccess)server;
/*     */     
/*  79 */     this.levelManager = new RuntimeLevelManager(server);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Fantasy get(MinecraftServer server) {
/*  89 */     Preconditions.checkState(server.isSameThread(), "cannot create levels from off-thread!");
/*     */     
/*  91 */     if (instance == null || instance.server != server) {
/*  92 */       instance = new Fantasy(server);
/*     */     }
/*     */     
/*  95 */     return instance;
/*     */   }
/*     */   
/*     */   private void tick() {
/*  99 */     Set<ServerLevel> deletionQueue = this.deletionQueue;
/* 100 */     if (!deletionQueue.isEmpty()) {
/* 101 */       deletionQueue.removeIf(this::tickDeleteLevel);
/*     */     }
/*     */     
/* 104 */     Set<ServerLevel> unloadingQueue = this.unloadingQueue;
/* 105 */     if (!unloadingQueue.isEmpty()) {
/* 106 */       unloadingQueue.removeIf(this::tickUnloadLevel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelHandle openTemporaryLevel(RuntimeLevelConfig config) {
/* 122 */     return openTemporaryLevel(generateTemporaryLevelKey(), config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelHandle openTemporaryLevel(Identifier key, RuntimeLevelConfig config) {
/* 138 */     RuntimeLevel level = addTemporaryLevel(key, config);
/* 139 */     return new RuntimeLevelHandle(this, level);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeLevelHandle getOrOpenPersistentLevel(Identifier key, RuntimeLevelConfig config) {
/* 160 */     ResourceKey<Level> levelKey = ResourceKey.create(Registries.DIMENSION, key);
/*     */     
/* 162 */     ServerLevel level = this.server.getLevel(levelKey);
/* 163 */     if (level == null) {
/* 164 */       level = addPersistentLevel(key, config);
/*     */     } else {
/* 166 */       this.deletionQueue.remove(level);
/* 167 */       this.unloadingQueue.remove(level);
/*     */     } 
/*     */     
/* 170 */     return new RuntimeLevelHandle(this, level);
/*     */   }
/*     */   
/*     */   private RuntimeLevel addPersistentLevel(Identifier key, RuntimeLevelConfig config) {
/* 174 */     ResourceKey<Level> levelKey = ResourceKey.create(Registries.DIMENSION, key);
/* 175 */     return this.levelManager.add(levelKey, config, RuntimeLevel.Style.PERSISTENT);
/*     */   }
/*     */   
/*     */   private RuntimeLevel addTemporaryLevel(Identifier key, RuntimeLevelConfig config) {
/* 179 */     ResourceKey<Level> levelKey = ResourceKey.create(Registries.DIMENSION, key);
/*     */     
/*     */     try {
/* 182 */       LevelStorageSource.LevelStorageAccess session = this.serverAccess.getStorageSource();
/* 183 */       FileUtils.forceDeleteOnExit(session.getDimensionPath(levelKey).toFile());
/* 184 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 187 */     return this.levelManager.add(levelKey, config, RuntimeLevel.Style.TEMPORARY);
/*     */   }
/*     */   
/*     */   void enqueueLevelDeletion(ServerLevel level) {
/* 191 */     this.server.execute(() -> {
/*     */           level.getChunkSource().deactivateTicketsOnClosing();
/*     */           level.noSave = true;
/*     */           kickPlayers(level);
/*     */           this.deletionQueue.add(level);
/*     */         });
/*     */   }
/*     */   
/*     */   void enqueueLevelUnloading(ServerLevel level) {
/* 200 */     this.server.execute(() -> {
/*     */           level.noSave = false;
/*     */           level.getChunkSource().deactivateTicketsOnClosing();
/*     */           level.getChunkSource().tick((), false);
/*     */           kickPlayers(level);
/*     */           this.unloadingQueue.add(level);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean tickDeleteLevel(ServerLevel level) {
/* 211 */     kickPlayers(level);
/* 212 */     this.levelManager.delete(level);
/* 213 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean tickUnloadLevel(ServerLevel level) {
/* 221 */     if (isLevelActive(level) && !(level.getChunkSource()).chunkMap.hasWork()) {
/* 222 */       this.levelManager.unload(level);
/* 223 */       return true;
/*     */     } 
/* 225 */     kickPlayers(level);
/* 226 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void kickPlayers(ServerLevel level) {
/* 231 */     if (level.players().isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 235 */     ServerLevel spawnLevel = this.server.findRespawnDimension();
/* 236 */     LevelData.RespawnData spawnPoint = this.server.getRespawnData();
/*     */     
/* 238 */     List<ServerPlayer> players = new ArrayList<>(level.players());
/*     */     
/* 240 */     for (ServerPlayer player : players) {
/* 241 */       Vec3 pos = player.adjustSpawnLocation(spawnLevel, spawnPoint.pos()).getBottomCenter();
/* 242 */       TeleportTransition target = new TeleportTransition(spawnLevel, pos, Vec3.ZERO, spawnPoint.yaw(), spawnPoint.pitch(), TeleportTransition.DO_NOTHING);
/*     */       
/* 244 */       player.teleport(target);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isLevelActive(ServerLevel level) {
/* 249 */     return (level.players().isEmpty() && level.getChunkSource().getLoadedChunksCount() <= 0);
/*     */   }
/*     */   
/*     */   private void onServerStopping() {
/* 253 */     List<RuntimeLevel> temporaryLevels = collectTemporaryLevels();
/* 254 */     for (RuntimeLevel temporary : temporaryLevels) {
/* 255 */       kickPlayers(temporary);
/* 256 */       this.levelManager.delete(temporary);
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<RuntimeLevel> collectTemporaryLevels() {
/* 261 */     List<RuntimeLevel> temporaryLevels = new ArrayList<>();
/* 262 */     for (ServerLevel level : this.server.getAllLevels()) {
/* 263 */       if (level instanceof RuntimeLevel) { RuntimeLevel runtimeLevel = (RuntimeLevel)level;
/* 264 */         if (runtimeLevel.style == RuntimeLevel.Style.TEMPORARY) {
/* 265 */           temporaryLevels.add(runtimeLevel);
/*     */         } }
/*     */     
/*     */     } 
/* 269 */     return temporaryLevels;
/*     */   }
/*     */   
/*     */   private static Identifier generateTemporaryLevelKey() {
/* 273 */     String key = RandomStringUtils.random(16, "abcdefghijklmnopqrstuvwxyz0123456789");
/* 274 */     return Identifier.fromNamespaceAndPath("fantasy", key);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\Fantasy.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */