/*    */ package xyz.nucleoid.fantasy.util;
/*    */ import it.unimi.dsi.fastutil.objects.Reference2ObjectMap;
/*    */ import it.unimi.dsi.fastutil.objects.Reference2ObjectMaps;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.world.level.gamerules.GameRule;
/*    */ import net.minecraft.world.level.gamerules.GameRules;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public final class GameRuleStore {
/* 10 */   private final Reference2ObjectMap<GameRule<?>, Object> rules = (Reference2ObjectMap<GameRule<?>, Object>)new Reference2ObjectOpenHashMap();
/*    */   
/*    */   public <T> void set(GameRule<T> key, T value) {
/* 13 */     this.rules.put(key, value);
/*    */   }
/*    */   
/*    */   public <T> T get(GameRule<T> key) {
/* 17 */     return (T)this.rules.get(key);
/*    */   }
/*    */   
/*    */   public boolean contains(GameRule<?> key) {
/* 21 */     return this.rules.containsKey(key);
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 25 */     return this.rules.isEmpty();
/*    */   }
/*    */   
/*    */   public void applyTo(GameRules rules, @Nullable MinecraftServer server) {
/* 29 */     Reference2ObjectMaps.fastForEach(this.rules, entry -> rules.set((GameRule)entry.getKey(), entry.getValue(), server));
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantas\\util\GameRuleStore.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */