/*    */ package xyz.nucleoid.fantasy.mixin;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import net.minecraft.network.protocol.Packet;
/*    */ import net.minecraft.resources.ResourceKey;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.server.level.ServerLevel;
/*    */ import net.minecraft.server.players.PlayerList;
/*    */ import net.minecraft.world.clock.ServerClockManager;
/*    */ import net.minecraft.world.level.Level;
/*    */ import net.minecraft.world.level.gamerules.GameRules;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import xyz.nucleoid.fantasy.util.SafeIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({MinecraftServer.class})
/*    */ public abstract class MinecraftServerMixin
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private Map<ResourceKey<Level>, ServerLevel> levels;
/*    */   @Shadow
/*    */   @Final
/*    */   private ServerClockManager clockManager;
/*    */   
/*    */   @Shadow
/*    */   @Deprecated
/*    */   public abstract GameRules getGlobalGameRules();
/*    */   
/*    */   @Redirect(method = {"tickChildren"}, at = @At(value = "INVOKE", target = "Ljava/lang/Iterable;iterator()Ljava/util/Iterator;", ordinal = 0), require = 0)
/*    */   private Iterator<ServerLevel> fantasy$copyBeforeTicking(Iterable<ServerLevel> instance) {
/* 44 */     return (Iterator<ServerLevel>)new SafeIterator((Collection)instance);
/*    */   }
/*    */   
/*    */   @WrapOperation(method = {"onGameRuleChanged"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/server/players/PlayerList;broadcastAll(Lnet/minecraft/network/protocol/Packet;)V")})
/*    */   private void forceGameRunTimeSynchronization(PlayerList instance, Packet<?> packet, Operation<Void> original) {
/* 49 */     for (ServerLevel level : this.levels.values()) {
/* 50 */       if (level.clockManager() == this.clockManager)
/* 51 */         instance.broadcastAll(packet, level.dimension()); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\MinecraftServerMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */