/*    */ package xyz.nucleoid.fantasy.util;
/*    */ 
/*    */ import com.mojang.serialization.MapCodec;
/*    */ import net.minecraft.util.KeyDispatchDataCodec;
/*    */ import net.minecraft.world.level.levelgen.DensityFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements DensityFunction
/*    */ {
/*    */   public double compute(DensityFunction.FunctionContext pos) {
/* 65 */     return 0.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public void fillArray(double[] ds, DensityFunction.ContextProvider arg) {}
/*    */ 
/*    */   
/*    */   public DensityFunction mapAll(DensityFunction.Visitor visitor) {
/* 73 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public double minValue() {
/* 78 */     return 0.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public double maxValue() {
/* 83 */     return 0.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public KeyDispatchDataCodec<? extends DensityFunction> codec() {
/* 88 */     return KeyDispatchDataCodec.of(MapCodec.unit(this));
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantas\\util\VoidChunkGenerator$1.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */