/*    */ package xyz.nucleoid.fantasy.mixin.clock;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import java.util.Map;
/*    */ import net.minecraft.core.Holder;
/*    */ import net.minecraft.network.protocol.Packet;
/*    */ import net.minecraft.server.level.ServerPlayer;
/*    */ import net.minecraft.server.players.PlayerList;
/*    */ import net.minecraft.world.clock.ServerClockManager;
/*    */ import net.minecraft.world.clock.WorldClock;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import xyz.nucleoid.fantasy.ServerClockManagerExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({ServerClockManager.class})
/*    */ public abstract class ServerClockManagerMixin
/*    */   implements ServerClockManagerExtension
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private Map<Holder<WorldClock>, ServerClockManager.ClockInstance> clocks;
/*    */   
/*    */   public Map<Holder<WorldClock>, ServerClockManager.ClockInstance> fantasy$getClocks() {
/* 31 */     return this.clocks;
/*    */   }
/*    */   
/*    */   @WrapOperation(method = {"modifyClock"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/server/players/PlayerList;broadcastAll(Lnet/minecraft/network/protocol/Packet;)V")})
/*    */   private void updateTimeOnlyOverworld(PlayerList instance, Packet<?> packet, Operation<Void> original) {
/* 36 */     for (ServerPlayer player : instance.getPlayers()) {
/* 37 */       if (player.level().clockManager() == this)
/* 38 */         player.connection.send(packet); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\clock\ServerClockManagerMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */