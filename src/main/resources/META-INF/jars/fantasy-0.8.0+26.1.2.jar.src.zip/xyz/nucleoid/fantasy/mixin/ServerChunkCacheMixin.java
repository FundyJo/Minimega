/*    */ package xyz.nucleoid.fantasy.mixin;
/*    */ 
/*    */ import net.minecraft.server.level.ServerChunkCache;
/*    */ import net.minecraft.server.level.ServerLevel;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ import xyz.nucleoid.fantasy.FantasyLevelAccess;
/*    */ 
/*    */ @Mixin({ServerChunkCache.class})
/*    */ public class ServerChunkCacheMixin {
/*    */   @Shadow
/*    */   @Final
/*    */   ServerLevel level;
/*    */   
/*    */   @Inject(method = {"pollTask"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void executeQueuedTasks(CallbackInfoReturnable<Boolean> ci) {
/* 21 */     if (!((FantasyLevelAccess)this.level).fantasy$shouldTick())
/* 22 */       ci.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\ServerChunkCacheMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */