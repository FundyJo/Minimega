/*    */ package xyz.nucleoid.fantasy.util;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ 
/*    */ @Internal
/*    */ public final class SafeIterator<T>
/*    */   implements Iterator<T> {
/*    */   private final Object[] values;
/* 11 */   private int index = 0;
/*    */   
/*    */   public SafeIterator(Collection<T> source) {
/* 14 */     this.values = source.toArray();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 19 */     return (this.values.length > this.index);
/*    */   }
/*    */ 
/*    */   
/*    */   public T next() {
/* 24 */     return (T)this.values[this.index++];
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantas\\util\SafeIterator.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */