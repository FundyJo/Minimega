package xyz.nucleoid.fantasy.mixin.clock;

import net.minecraft.world.clock.ServerClockManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({ServerClockManager.ClockInstance.class})
public interface ClockInstanceAccessor {
  @Accessor
  boolean isPaused();
  
  @Accessor
  long getTotalTicks();
  
  @Accessor
  float getPartialTick();
  
  @Accessor
  float getRate();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\clock\ClockInstanceAccessor.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */