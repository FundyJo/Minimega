/*     */ package xyz.nucleoid.fantasy.util;
/*     */ import com.mojang.datafixers.kinds.App;
/*     */ import com.mojang.datafixers.kinds.Applicative;
/*     */ import com.mojang.datafixers.util.Pair;
/*     */ import com.mojang.serialization.MapCodec;
/*     */ import com.mojang.serialization.codecs.RecordCodecBuilder;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.core.Holder;
/*     */ import net.minecraft.core.HolderLookup;
/*     */ import net.minecraft.core.HolderSet;
/*     */ import net.minecraft.core.Registry;
/*     */ import net.minecraft.core.RegistryAccess;
/*     */ import net.minecraft.core.registries.Registries;
/*     */ import net.minecraft.resources.Identifier;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.level.ServerLevel;
/*     */ import net.minecraft.server.level.WorldGenRegion;
/*     */ import net.minecraft.util.KeyDispatchDataCodec;
/*     */ import net.minecraft.util.random.WeightedList;
/*     */ import net.minecraft.world.entity.MobCategory;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.LevelHeightAccessor;
/*     */ import net.minecraft.world.level.NoiseColumn;
/*     */ import net.minecraft.world.level.StructureManager;
/*     */ import net.minecraft.world.level.WorldGenLevel;
/*     */ import net.minecraft.world.level.biome.Biome;
/*     */ import net.minecraft.world.level.biome.BiomeManager;
/*     */ import net.minecraft.world.level.biome.BiomeSource;
/*     */ import net.minecraft.world.level.biome.Biomes;
/*     */ import net.minecraft.world.level.biome.Climate;
/*     */ import net.minecraft.world.level.biome.FixedBiomeSource;
/*     */ import net.minecraft.world.level.biome.MobSpawnSettings;
/*     */ import net.minecraft.world.level.chunk.ChunkAccess;
/*     */ import net.minecraft.world.level.chunk.ChunkGenerator;
/*     */ import net.minecraft.world.level.chunk.ChunkGeneratorStructureState;
/*     */ import net.minecraft.world.level.levelgen.DensityFunction;
/*     */ import net.minecraft.world.level.levelgen.Heightmap;
/*     */ import net.minecraft.world.level.levelgen.RandomState;
/*     */ import net.minecraft.world.level.levelgen.blending.Blender;
/*     */ import net.minecraft.world.level.levelgen.structure.Structure;
/*     */ import net.minecraft.world.level.levelgen.structure.StructureSet;
/*     */ import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class VoidChunkGenerator extends ChunkGenerator {
/*     */   static {
/*  54 */     CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)Biome.CODEC.stable().fieldOf("biome").forGetter(VoidChunkGenerator::getBiome)).apply((Applicative)instance, instance.stable(VoidChunkGenerator::new)));
/*     */   }
/*     */   
/*     */   public static final MapCodec<VoidChunkGenerator> CODEC;
/*  58 */   private static final NoiseColumn EMPTY_SAMPLE = new NoiseColumn(0, new net.minecraft.world.level.block.state.BlockState[0]);
/*     */   
/*     */   private final Holder<Biome> biome;
/*     */   
/*  62 */   public static final DensityFunction ZERO_DENSITY_FUNCTION = new DensityFunction()
/*     */     {
/*     */       public double compute(DensityFunction.FunctionContext pos) {
/*  65 */         return 0.0D;
/*     */       }
/*     */ 
/*     */       
/*     */       public void fillArray(double[] ds, DensityFunction.ContextProvider arg) {}
/*     */ 
/*     */       
/*     */       public DensityFunction mapAll(DensityFunction.Visitor visitor) {
/*  73 */         return this;
/*     */       }
/*     */ 
/*     */       
/*     */       public double minValue() {
/*  78 */         return 0.0D;
/*     */       }
/*     */ 
/*     */       
/*     */       public double maxValue() {
/*  83 */         return 0.0D;
/*     */       }
/*     */ 
/*     */       
/*     */       public KeyDispatchDataCodec<? extends DensityFunction> codec() {
/*  88 */         return KeyDispatchDataCodec.of(MapCodec.unit(this));
/*     */       }
/*     */     };
/*     */   
/*  92 */   public static final Climate.Sampler EMPTY_SAMPLER = new Climate.Sampler(ZERO_DENSITY_FUNCTION, ZERO_DENSITY_FUNCTION, ZERO_DENSITY_FUNCTION, ZERO_DENSITY_FUNCTION, ZERO_DENSITY_FUNCTION, ZERO_DENSITY_FUNCTION, Collections.emptyList());
/*     */   
/*     */   public VoidChunkGenerator(Holder<Biome> biome) {
/*  95 */     super((BiomeSource)new FixedBiomeSource(biome));
/*  96 */     this.biome = biome;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public VoidChunkGenerator(Supplier<Biome> biome) {
/* 101 */     this(Holder.direct(biome.get()));
/*     */   }
/*     */   
/*     */   public VoidChunkGenerator(Registry<Biome> biomeRegistry) {
/* 105 */     this(biomeRegistry, Biomes.THE_VOID);
/*     */   }
/*     */   
/*     */   public VoidChunkGenerator(Registry<Biome> biomeRegistry, ResourceKey<Biome> biome) {
/* 109 */     this(biomeRegistry.get(biome).orElseThrow());
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidChunkGenerator(MinecraftServer server) {
/* 114 */     this(server.registryAccess().lookupOrThrow(Registries.BIOME), Biomes.THE_VOID);
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidChunkGenerator(MinecraftServer server, Identifier biome) {
/* 119 */     this(server, ResourceKey.create(Registries.BIOME, biome));
/*     */   }
/*     */ 
/*     */   
/*     */   public VoidChunkGenerator(MinecraftServer server, ResourceKey<Biome> biome) {
/* 124 */     this(server.registryAccess().lookupOrThrow(Registries.BIOME), biome);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MapCodec<? extends ChunkGenerator> codec() {
/* 129 */     return (MapCodec)CODEC;
/*     */   }
/*     */   
/*     */   protected Holder<Biome> getBiome() {
/* 133 */     return this.biome;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyCarvers(WorldGenRegion chunkRegion, long seed, RandomState noiseConfig, BiomeManager world, StructureManager structureAccessor, ChunkAccess chunk) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void createReferences(WorldGenLevel world, StructureManager accessor, ChunkAccess chunk) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletableFuture<ChunkAccess> fillFromNoise(Blender blender, RandomState noiseConfig, StructureManager structureAccessor, ChunkAccess chunk) {
/* 147 */     return CompletableFuture.completedFuture(chunk);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSeaLevel() {
/* 152 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMinY() {
/* 157 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBaseHeight(int x, int z, Heightmap.Types heightmap, LevelHeightAccessor world, RandomState noiseConfig) {
/* 162 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor world, RandomState noiseConfig) {
/* 167 */     return EMPTY_SAMPLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDebugScreenInfo(List<String> text, RandomState noiseConfig, BlockPos pos) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyBiomeDecoration(WorldGenLevel world, ChunkAccess chunk, StructureManager structureAccessor) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildSurface(WorldGenRegion region, StructureManager structures, RandomState noiseConfig, ChunkAccess chunk) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void spawnOriginalMobs(WorldGenRegion region) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGenDepth() {
/* 190 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Pair<BlockPos, Holder<Structure>> findNearestMapStructure(ServerLevel world, HolderSet<Structure> structures, BlockPos center, int radius, boolean skipReferencedStructures) {
/* 196 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public WeightedList<MobSpawnSettings.SpawnerData> getMobsAt(Holder<Biome> biome, StructureManager accessor, MobCategory group, BlockPos pos) {
/* 201 */     return WeightedList.of();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void createStructures(RegistryAccess registryManager, ChunkGeneratorStructureState placementCalculator, StructureManager structureAccessor, ChunkAccess chunk, StructureTemplateManager structureTemplateManager, ResourceKey<Level> dimension) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public ChunkGeneratorStructureState createState(HolderLookup<StructureSet> structureSetRegistry, RandomState noiseConfig, long seed) {
/* 211 */     return ChunkGeneratorStructureState.createForFlat(noiseConfig, seed, this.biomeSource, Stream.empty());
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantas\\util\VoidChunkGenerator.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */