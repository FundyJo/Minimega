/*    */ package xyz.nucleoid.fantasy;
/*    */ 
/*    */ import java.util.Map;
/*    */ import net.minecraft.core.Holder;
/*    */ import net.minecraft.world.clock.ServerClockManager;
/*    */ import net.minecraft.world.clock.WorldClock;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ public interface ServerClockManagerExtension
/*    */ {
/*    */   default Map<Holder<WorldClock>, ServerClockManager.ClockInstance> fantasy$getClocks() {
/* 17 */     throw new UnsupportedOperationException("Implemented via Mixin.");
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\ServerClockManagerExtension.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */