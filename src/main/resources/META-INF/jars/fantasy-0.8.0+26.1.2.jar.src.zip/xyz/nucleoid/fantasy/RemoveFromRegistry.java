/*    */ package xyz.nucleoid.fantasy;
/*    */ 
/*    */ import net.minecraft.core.MappedRegistry;
/*    */ import net.minecraft.core.Registry;
/*    */ import net.minecraft.resources.Identifier;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.jetbrains.annotations.ApiStatus.NonExtendable;
/*    */ 
/*    */ @Internal
/*    */ public interface RemoveFromRegistry<T> {
/*    */   static <T> boolean remove(MappedRegistry<T> registry, Identifier key) {
/* 12 */     return ((RemoveFromRegistry)registry).fantasy$remove(key);
/*    */   }
/*    */ 
/*    */   
/*    */   static <T> boolean remove(MappedRegistry<T> registry, T value) {
/* 17 */     return ((RemoveFromRegistry<T>)registry).fantasy$remove(value);
/*    */   }
/*    */ 
/*    */   
/*    */   static <T> RegistryRemoval thaw(Registry<T> registry) {
/* 22 */     RemoveFromRegistry<T> registry1 = (RemoveFromRegistry<T>)registry;
/* 23 */     boolean priorStateOfMatter = registry1.fantasy$isFrozen();
/* 24 */     registry1.fantasy$setFrozen(false);
/* 25 */     return () -> registry1.fantasy$setFrozen(priorStateOfMatter);
/*    */   }
/*    */   
/*    */   boolean fantasy$remove(T paramT);
/*    */   
/*    */   boolean fantasy$remove(Identifier paramIdentifier);
/*    */   
/*    */   void fantasy$setFrozen(boolean paramBoolean);
/*    */   
/*    */   boolean fantasy$isFrozen();
/*    */   
/*    */   @FunctionalInterface
/*    */   @NonExtendable
/*    */   public static interface RegistryRemoval extends AutoCloseable {
/*    */     void close();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\RemoveFromRegistry.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */