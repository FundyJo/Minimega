/*    */ package xyz.nucleoid.fantasy.mixin.registry;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.ModifyReturnValue;
/*    */ import com.mojang.logging.LogUtils;
/*    */ import it.unimi.dsi.fastutil.objects.ObjectList;
/*    */ import it.unimi.dsi.fastutil.objects.Reference2IntMap;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import java.util.stream.Stream;
/*    */ import net.minecraft.core.Holder;
/*    */ import net.minecraft.core.MappedRegistry;
/*    */ import net.minecraft.core.RegistrationInfo;
/*    */ import net.minecraft.core.Registry;
/*    */ import net.minecraft.core.WritableRegistry;
/*    */ import net.minecraft.resources.Identifier;
/*    */ import net.minecraft.resources.ResourceKey;
/*    */ import org.slf4j.Logger;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import xyz.nucleoid.fantasy.RemoveFromRegistry;
/*    */ 
/*    */ @Mixin({MappedRegistry.class})
/*    */ public abstract class MappedRegistryMixin<T> implements RemoveFromRegistry<T>, WritableRegistry<T> {
/*    */   @Unique
/* 28 */   private static final Logger fantasy$LOGGER = LogUtils.getLogger();
/*    */   @Shadow
/*    */   @Final
/*    */   private Map<T, Holder.Reference<T>> byValue; @Shadow
/*    */   @Final
/*    */   private Map<Identifier, Holder.Reference<T>> byLocation;
/*    */   @Shadow
/*    */   @Final
/*    */   private Map<ResourceKey<T>, Holder.Reference<T>> byKey;
/*    */   @Shadow
/*    */   @Final
/*    */   private Map<ResourceKey<T>, RegistrationInfo> registrationInfos;
/*    */   
/* 41 */   public boolean fantasy$remove(T entry) { Holder.Reference<T> registryEntry = this.byValue.get(entry);
/* 42 */     int rawId = this.toId.removeInt(entry);
/* 43 */     if (rawId == -1) {
/* 44 */       return false;
/*    */     }
/*    */     
/*    */     try {
/* 48 */       this.byKey.remove(registryEntry.key());
/* 49 */       this.byLocation.remove(registryEntry.key().identifier());
/* 50 */       this.byValue.remove(entry);
/* 51 */       this.byId.set(rawId, null);
/* 52 */       this.registrationInfos.remove(this.key);
/*    */       
/* 54 */       return true;
/* 55 */     } catch (Throwable e) {
/* 56 */       fantasy$LOGGER.error("Could not remove entry", e);
/* 57 */       return false;
/*    */     }  } @Shadow @Final private ObjectList<Holder.Reference<T>> byId; @Shadow
/*    */   @Final
/*    */   private Reference2IntMap<T> toId; @Shadow
/*    */   @Final
/*    */   private ResourceKey<? extends Registry<T>> key; @Shadow
/* 63 */   private boolean frozen; public boolean fantasy$remove(Identifier key) { Holder.Reference<T> entry = this.byLocation.get(key);
/* 64 */     return (entry != null && entry.isBound() && fantasy$remove((T)entry.value())); }
/*    */ 
/*    */ 
/*    */   
/*    */   public void fantasy$setFrozen(boolean value) {
/* 69 */     this.frozen = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean fantasy$isFrozen() {
/* 74 */     return this.frozen;
/*    */   }
/*    */   
/*    */   @ModifyReturnValue(method = {"listElements"}, at = {@At("RETURN")})
/*    */   public Stream<Holder.Reference<T>> fixEntryStream(Stream<Holder.Reference<T>> original) {
/* 79 */     return original.filter(Objects::nonNull);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\mixin\registry\MappedRegistryMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */