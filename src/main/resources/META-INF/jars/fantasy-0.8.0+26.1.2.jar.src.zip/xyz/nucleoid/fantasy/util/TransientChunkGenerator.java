/*    */ package xyz.nucleoid.fantasy.util;
/*    */ 
/*    */ import com.mojang.datafixers.kinds.App;
/*    */ import com.mojang.datafixers.kinds.Applicative;
/*    */ import com.mojang.serialization.MapCodec;
/*    */ import com.mojang.serialization.codecs.RecordCodecBuilder;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.core.Holder;
/*    */ import net.minecraft.resources.RegistryOps;
/*    */ import net.minecraft.world.level.biome.Biome;
/*    */ import net.minecraft.world.level.biome.BiomeGenerationSettings;
/*    */ import net.minecraft.world.level.biome.BiomeSource;
/*    */ import net.minecraft.world.level.biome.Biomes;
/*    */ import net.minecraft.world.level.chunk.ChunkGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TransientChunkGenerator
/*    */   extends ChunkGenerator
/*    */ {
/*    */   public static final MapCodec<? extends ChunkGenerator> CODEC;
/*    */   
/*    */   static {
/* 25 */     CODEC = RecordCodecBuilder.mapCodec(i -> i.group((App)RegistryOps.retrieveElement(Biomes.THE_VOID)).apply((Applicative)i, VoidChunkGenerator::new));
/*    */   }
/*    */ 
/*    */   
/*    */   public TransientChunkGenerator(BiomeSource biomeSource) {
/* 30 */     super(biomeSource);
/*    */   }
/*    */   
/*    */   public TransientChunkGenerator(BiomeSource biomeSource, Function<Holder<Biome>, BiomeGenerationSettings> generationSettingsGetter) {
/* 34 */     super(biomeSource, generationSettingsGetter);
/*    */   }
/*    */ 
/*    */   
/*    */   protected final MapCodec<? extends ChunkGenerator> codec() {
/* 39 */     return CODEC;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantas\\util\TransientChunkGenerator.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */