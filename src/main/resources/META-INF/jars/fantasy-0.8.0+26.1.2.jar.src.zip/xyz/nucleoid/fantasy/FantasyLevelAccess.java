package xyz.nucleoid.fantasy;

import org.jetbrains.annotations.ApiStatus.Internal;

@Internal
public interface FantasyLevelAccess {
  void fantasy$setTickWhenEmpty(boolean paramBoolean);
  
  boolean fantasy$shouldTick();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\fantasy-0.8.0+26.1.2.jar!\xyz\nucleoid\fantasy\FantasyLevelAccess.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */