/*    */ package com.siemens.ct.exi.core.datatype.charset;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CodePointCharacterSet
/*    */   extends AbstractRestrictedCharacterSet
/*    */ {
/*    */   public CodePointCharacterSet(Set<Integer> codePoints) {
/* 45 */     List<Integer> sortedCodePoints = new ArrayList<>();
/* 46 */     sortedCodePoints.addAll(codePoints);
/* 47 */     Collections.sort(sortedCodePoints);
/*    */ 
/*    */     
/* 50 */     Iterator<Integer> iter = sortedCodePoints.iterator();
/* 51 */     while (iter.hasNext())
/* 52 */       addValue(((Integer)iter.next()).intValue()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\charset\CodePointCharacterSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */