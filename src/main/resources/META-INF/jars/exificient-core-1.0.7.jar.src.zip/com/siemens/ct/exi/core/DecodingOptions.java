/*     */ package com.siemens.ct.exi.core;
/*     */ 
/*     */ import com.siemens.ct.exi.core.exceptions.UnsupportedOption;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DecodingOptions
/*     */ {
/*     */   public static final String IGNORE_SCHEMA_ID = "IGNORE_SCHEMA_ID";
/*     */   public static final int PUSHBACK_BUFFER_SIZE = 512;
/*  51 */   protected Set<String> options = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DecodingOptions createDefault() {
/*  60 */     DecodingOptions ho = new DecodingOptions();
/*  61 */     return ho;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOption(String key) throws UnsupportedOption {
/*  80 */     if (key.equals("IGNORE_SCHEMA_ID")) {
/*  81 */       this.options.add(key);
/*     */     } else {
/*  83 */       throw new UnsupportedOption("DecodingOption '" + key + "' is unknown!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unsetOption(String key) {
/*  97 */     return this.options.remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOptionEnabled(String key) {
/* 108 */     return this.options.contains(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 113 */     if (o instanceof DecodingOptions) {
/* 114 */       DecodingOptions other = (DecodingOptions)o;
/* 115 */       return this.options.equals(other.options);
/*     */     } 
/*     */     
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 123 */     return this.options.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 128 */     return this.options.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\DecodingOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */