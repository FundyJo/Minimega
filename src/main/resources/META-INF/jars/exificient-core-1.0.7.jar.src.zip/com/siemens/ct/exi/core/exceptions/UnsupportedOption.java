/*    */ package com.siemens.ct.exi.core.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedOption
/*    */   extends EXIException
/*    */ {
/*    */   private static final long serialVersionUID = -8859158367056532581L;
/*    */   
/*    */   public UnsupportedOption(String msg) {
/* 41 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\exceptions\UnsupportedOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */