/*    */ package com.siemens.ct.exi.core.types;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.datatype.Datatype;
/*    */ import com.siemens.ct.exi.core.datatype.strings.StringEncoder;
/*    */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*    */ import com.siemens.ct.exi.core.values.Value;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringTypeEncoder
/*    */   extends AbstractTypeEncoder
/*    */ {
/*    */   String lastValidValue;
/*    */   
/*    */   public boolean isValid(Datatype datatype, Value value) {
/* 51 */     this.lastValidValue = value.toString();
/* 52 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeValue(QNameContext qnContext, EncoderChannel valueChannel, StringEncoder stringEncoder) throws IOException {
/* 57 */     stringEncoder.writeValue(qnContext, valueChannel, this.lastValidValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\StringTypeEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */