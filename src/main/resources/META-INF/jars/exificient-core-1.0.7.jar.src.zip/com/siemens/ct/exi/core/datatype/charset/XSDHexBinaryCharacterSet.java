/*    */ package com.siemens.ct.exi.core.datatype.charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XSDHexBinaryCharacterSet
/*    */   extends AbstractRestrictedCharacterSet
/*    */ {
/*    */   public XSDHexBinaryCharacterSet() {
/* 45 */     addValue(9);
/* 46 */     addValue(10);
/* 47 */     addValue(13);
/* 48 */     addValue(32);
/*    */     int i;
/* 50 */     for (i = 48; i <= 57; i++) {
/* 51 */       addValue((char)i);
/*    */     }
/*    */     
/* 54 */     for (i = 65; i <= 70; i++) {
/* 55 */       addValue((char)i);
/*    */     }
/*    */     
/* 58 */     for (i = 97; i <= 102; i++)
/* 59 */       addValue((char)i); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\charset\XSDHexBinaryCharacterSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */