/*    */ package com.siemens.ct.exi.core.datatype.charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XSDDoubleCharacterSet
/*    */   extends AbstractRestrictedCharacterSet
/*    */ {
/*    */   public XSDDoubleCharacterSet() {
/* 45 */     addValue(9);
/* 46 */     addValue(10);
/* 47 */     addValue(13);
/* 48 */     addValue(32);
/*    */     
/* 50 */     addValue(43);
/* 51 */     addValue(45);
/* 52 */     addValue(46);
/*    */     
/* 54 */     for (int i = 48; i <= 57; i++) {
/* 55 */       addValue((char)i);
/*    */     }
/*    */     
/* 58 */     addValue(69);
/* 59 */     addValue(70);
/* 60 */     addValue(73);
/* 61 */     addValue(78);
/* 62 */     addValue(97);
/* 63 */     addValue(101);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\charset\XSDDoubleCharacterSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */