/*     */ package com.siemens.ct.exi.core.util.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QNameUtilities
/*     */ {
/*     */   public static String getLocalPart(String qname) {
/*  51 */     int index = qname.indexOf(':');
/*     */     
/*  53 */     return (index < 0) ? qname : qname.substring(index + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPrefixPart(String qname) {
/*  65 */     int index = qname.indexOf(':');
/*     */     
/*  67 */     return (index >= 0) ? qname.substring(0, index) : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getQualifiedName(String localName, String pfx) {
/*  86 */     pfx = (pfx == null) ? "" : pfx;
/*  87 */     return (pfx.length() == 0) ? localName : (
/*  88 */       pfx + ":" + localName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getClassName(QName qname) {
/*     */     try {
/* 102 */       StringBuilder className = new StringBuilder();
/*     */ 
/*     */       
/* 105 */       StringTokenizer st1 = new StringTokenizer(qname.getNamespaceURI(), "/");
/*     */ 
/*     */       
/* 108 */       st1.nextToken();
/* 109 */       String domain = st1.nextToken();
/*     */       
/* 111 */       StringTokenizer st2 = new StringTokenizer(domain, ".");
/* 112 */       List<String> lDomain = new ArrayList<>();
/* 113 */       while (st2.hasMoreTokens()) {
/* 114 */         lDomain.add(st2.nextToken());
/*     */       }
/* 116 */       assert lDomain.size() >= 2;
/* 117 */       className.append(lDomain.get(lDomain.size() - 1));
/* 118 */       className.append('.');
/* 119 */       className.append(lDomain.get(lDomain.size() - 2));
/*     */       
/* 121 */       while (st1.hasMoreTokens()) {
/* 122 */         className.append('.');
/* 123 */         className.append(st1.nextToken());
/*     */       } 
/*     */       
/* 126 */       className.append('.');
/* 127 */       className.append(qname.getLocalPart());
/*     */       
/* 129 */       return className.toString();
/* 130 */     } catch (Exception e) {
/* 131 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\cor\\util\xml\QNameUtilities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */