/*     */ package com.siemens.ct.exi.core.datatype.strings;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringEncoderImpl
/*     */   extends AbstractStringCoder
/*     */   implements StringEncoder
/*     */ {
/*     */   protected Map<String, ValueContainer> stringValues;
/*     */   
/*     */   public StringEncoderImpl(boolean localValuePartitions) {
/*  50 */     this(localValuePartitions, 60);
/*     */   }
/*     */   
/*     */   public StringEncoderImpl(boolean localValuePartitions, int initialQNameLists) {
/*  54 */     super(localValuePartitions, initialQNameLists);
/*  55 */     this.stringValues = new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeValue(QNameContext context, EncoderChannel valueChannel, String value) throws IOException {
/*  61 */     ValueContainer vc = this.stringValues.get(value);
/*     */     
/*  63 */     if (vc != null) {
/*     */       
/*  65 */       if (this.localValuePartitions && context.equals(vc.context))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  71 */         valueChannel.encodeUnsignedInteger(0);
/*     */         
/*  73 */         int numberBitsLocal = MethodsBag.getCodingLength(getNumberOfStringValues(context));
/*  74 */         valueChannel.encodeNBitUnsignedInteger(vc.localValueID, numberBitsLocal);
/*     */ 
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */         
/*  82 */         valueChannel.encodeUnsignedInteger(1);
/*     */ 
/*     */         
/*  85 */         int numberBitsGlobal = MethodsBag.getCodingLength(this.stringValues
/*  86 */             .size());
/*  87 */         valueChannel.encodeNBitUnsignedInteger(vc.globalValueID, numberBitsGlobal);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  96 */       int L = value.codePointCount(0, value.length());
/*  97 */       valueChannel.encodeUnsignedInteger(L + 2);
/*     */ 
/*     */ 
/*     */       
/* 101 */       if (L > 0) {
/* 102 */         valueChannel.encodeStringOnly(value);
/*     */ 
/*     */ 
/*     */         
/* 106 */         addValue(context, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueContainer getValueContainer(String value) {
/* 113 */     return this.stringValues.get(value);
/*     */   }
/*     */   
/*     */   public int getValueContainerSize() {
/* 117 */     return this.stringValues.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStringHit(String value) throws IOException {
/* 122 */     return (this.stringValues.get(value) != null);
/*     */   }
/*     */   
/*     */   public void addValue(QNameContext qnc, String value) {
/* 126 */     assert !this.stringValues.containsKey(value);
/*     */ 
/*     */     
/* 129 */     ValueContainer vc = new ValueContainer(value, qnc, getNumberOfStringValues(qnc), this.stringValues.size());
/*     */ 
/*     */     
/* 132 */     this.stringValues.put(value, vc);
/*     */ 
/*     */     
/* 135 */     addLocalValue(qnc, new StringValue(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 140 */     super.clear();
/* 141 */     this.stringValues.clear();
/*     */   }
/*     */   
/*     */   public void setSharedStrings(List<String> sharedStrings) {
/* 145 */     for (String s : sharedStrings) {
/* 146 */       addValue((QNameContext)null, s);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ValueContainer
/*     */   {
/*     */     public final String value;
/*     */     public final QNameContext context;
/*     */     public final int localValueID;
/*     */     public final int globalValueID;
/*     */     
/*     */     public ValueContainer(String value, QNameContext context, int localValueID, int globalValueID) {
/* 159 */       this.value = value;
/* 160 */       this.context = context;
/* 161 */       this.localValueID = localValueID;
/* 162 */       this.globalValueID = globalValueID;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 167 */       return "['" + this.value + "', " + this.context + "," + this.localValueID + "," + this.globalValueID + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\strings\StringEncoderImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */