/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchemaInformedDocContent
/*    */   extends AbstractSchemaInformedGrammar
/*    */ {
/*    */   public SchemaInformedDocContent() {}
/*    */   
/*    */   public SchemaInformedDocContent(String label) {
/* 47 */     this();
/* 48 */     setLabel(label);
/*    */   }
/*    */   
/*    */   public GrammarType getGrammarType() {
/* 52 */     return GrammarType.SCHEMA_INFORMED_DOC_CONTENT;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 56 */     return "DocContent" + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\SchemaInformedDocContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */