/*    */ package com.siemens.ct.exi.core.grammars.event;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.datatype.Datatype;
/*    */ import com.siemens.ct.exi.core.types.BuiltIn;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Attribute
/*    */   extends AbstractDatatypeEvent
/*    */ {
/*    */   protected final QName qname;
/*    */   protected final QNameContext qnameContext;
/*    */   
/*    */   public Attribute(QNameContext qnc, Datatype datatype) {
/* 45 */     super(EventType.ATTRIBUTE, datatype);
/* 46 */     this.qnameContext = qnc;
/* 47 */     this.qname = this.qnameContext.getQName();
/*    */   }
/*    */   
/*    */   public Attribute(QNameContext qnc) {
/* 51 */     this(qnc, BuiltIn.getDefaultDatatype());
/*    */   }
/*    */   
/*    */   public QNameContext getQNameContext() {
/* 55 */     return this.qnameContext;
/*    */   }
/*    */   
/*    */   public QName getQName() {
/* 59 */     return this.qname;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 63 */     return super.toString() + "(" + this.qname.toString() + ")";
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 68 */     return this.qname.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 73 */     if (this == obj)
/* 74 */       return true; 
/* 75 */     if (obj instanceof Attribute) {
/* 76 */       Attribute otherAT = (Attribute)obj;
/* 77 */       return this.qname.equals(otherAT.qname);
/*    */     } 
/* 79 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\Attribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */