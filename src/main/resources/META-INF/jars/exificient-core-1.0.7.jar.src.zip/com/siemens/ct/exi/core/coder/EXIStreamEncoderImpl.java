/*    */ package com.siemens.ct.exi.core.coder;
/*    */ 
/*    */ import com.siemens.ct.exi.core.CodingMode;
/*    */ import com.siemens.ct.exi.core.EXIBodyEncoder;
/*    */ import com.siemens.ct.exi.core.EXIFactory;
/*    */ import com.siemens.ct.exi.core.EXIStreamEncoder;
/*    */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*    */ import com.siemens.ct.exi.core.io.channel.BitEncoderChannel;
/*    */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EXIStreamEncoderImpl
/*    */   implements EXIStreamEncoder
/*    */ {
/*    */   protected final EXIHeaderEncoder exiHeader;
/*    */   protected final EXIBodyEncoder exiBody;
/*    */   protected final EXIFactory exiFactory;
/*    */   
/*    */   public EXIStreamEncoderImpl(EXIFactory exiFactory) throws EXIException {
/* 52 */     this.exiFactory = exiFactory;
/* 53 */     this.exiHeader = new EXIHeaderEncoder();
/* 54 */     this.exiBody = exiFactory.createEXIBodyEncoder();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public EXIBodyEncoder encodeHeader(OutputStream os) throws EXIException, IOException {
/* 60 */     BitEncoderChannel headerChannel = new BitEncoderChannel(os);
/* 61 */     this.exiHeader.write(headerChannel, this.exiFactory);
/*    */ 
/*    */     
/* 64 */     if (this.exiFactory.getCodingMode() == CodingMode.BIT_PACKED) {
/*    */       
/* 66 */       this.exiBody.setOutputChannel((EncoderChannel)headerChannel);
/*    */     } else {
/* 68 */       this.exiBody.setOutputStream(os);
/*    */     } 
/* 70 */     return this.exiBody;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIStreamEncoderImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */