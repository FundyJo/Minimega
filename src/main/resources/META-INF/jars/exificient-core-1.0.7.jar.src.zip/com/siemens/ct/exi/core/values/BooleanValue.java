/*     */ package com.siemens.ct.exi.core.values;
/*     */ 
/*     */ import com.siemens.ct.exi.core.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanValue
/*     */   extends AbstractValue
/*     */ {
/*  37 */   public static final BooleanValue BOOLEAN_VALUE_FALSE = new BooleanValue(false);
/*     */   
/*  39 */   public static final BooleanValue BOOLEAN_VALUE_TRUE = new BooleanValue(true);
/*     */   
/*  41 */   public static final BooleanValue BOOLEAN_VALUE_0 = new BooleanValue(0);
/*  42 */   public static final BooleanValue BOOLEAN_VALUE_1 = new BooleanValue(1);
/*  43 */   public static final BooleanValue BOOLEAN_VALUE_2 = new BooleanValue(2);
/*  44 */   public static final BooleanValue BOOLEAN_VALUE_3 = new BooleanValue(3);
/*     */   
/*     */   protected final boolean bool;
/*     */   
/*     */   protected final char[] characters;
/*     */   protected final String sValue;
/*     */   
/*     */   private BooleanValue(boolean bool) {
/*  52 */     super(ValueType.BOOLEAN);
/*  53 */     this.bool = bool;
/*  54 */     if (bool) {
/*  55 */       this.characters = Constants.DECODED_BOOLEAN_TRUE_ARRAY;
/*  56 */       this.sValue = "true";
/*     */     } else {
/*  58 */       this.characters = Constants.DECODED_BOOLEAN_FALSE_ARRAY;
/*  59 */       this.sValue = "false";
/*     */     } 
/*     */   }
/*     */   
/*     */   public static BooleanValue getBooleanValue(boolean bool) {
/*  64 */     return bool ? BOOLEAN_VALUE_TRUE : 
/*  65 */       BOOLEAN_VALUE_FALSE;
/*     */   }
/*     */   
/*     */   private BooleanValue(int boolID) {
/*  69 */     super(ValueType.BOOLEAN);
/*  70 */     switch (boolID) {
/*     */       case 0:
/*  72 */         this.characters = Constants.XSD_BOOLEAN_FALSE_ARRAY;
/*  73 */         this.sValue = "false";
/*  74 */         this.bool = false;
/*     */         return;
/*     */       case 1:
/*  77 */         this.characters = Constants.XSD_BOOLEAN_0_ARRAY;
/*  78 */         this.sValue = "0";
/*  79 */         this.bool = false;
/*     */         return;
/*     */       case 2:
/*  82 */         this.characters = Constants.XSD_BOOLEAN_TRUE_ARRAY;
/*  83 */         this.sValue = "true";
/*  84 */         this.bool = true;
/*     */         return;
/*     */       case 3:
/*  87 */         this.characters = Constants.XSD_BOOLEAN_1_ARRAY;
/*  88 */         this.sValue = "1";
/*  89 */         this.bool = true;
/*     */         return;
/*     */     } 
/*  92 */     throw new RuntimeException("Error while creating boolean pattern facet with boolID==" + boolID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BooleanValue getBooleanValue(int boolID) {
/*     */     BooleanValue bv;
/* 100 */     switch (boolID) {
/*     */       case 0:
/* 102 */         bv = BOOLEAN_VALUE_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 119 */         return bv;case 1: bv = BOOLEAN_VALUE_1; return bv;case 2: bv = BOOLEAN_VALUE_2; return bv;case 3: bv = BOOLEAN_VALUE_3; return bv;
/*     */     } 
/*     */     throw new RuntimeException("Error while creating boolean pattern facet with boolID==" + boolID);
/*     */   } public static BooleanValue parse(String value) {
/* 123 */     value = value.trim();
/* 124 */     if (value.equals("0") || value
/* 125 */       .equals("false"))
/* 126 */       return BOOLEAN_VALUE_FALSE; 
/* 127 */     if (value.equals("1") || value
/* 128 */       .equals("true")) {
/* 129 */       return BOOLEAN_VALUE_TRUE;
/*     */     }
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean toBoolean() {
/* 136 */     return this.bool;
/*     */   }
/*     */   
/*     */   public int getCharactersLength() {
/* 140 */     return this.characters.length;
/*     */   }
/*     */   
/*     */   public char[] getCharacters() {
/* 144 */     return this.characters;
/*     */   }
/*     */ 
/*     */   
/*     */   public void getCharacters(char[] cbuffer, int offset) {
/* 149 */     System.arraycopy(this.characters, 0, cbuffer, offset, this.characters.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 154 */     return this.sValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(char[] cbuffer, int offset) {
/* 159 */     return this.sValue;
/*     */   }
/*     */   
/*     */   private final boolean _equals(BooleanValue o) {
/* 163 */     return (this.bool == o.bool);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 168 */     if (o == null) {
/* 169 */       return false;
/*     */     }
/* 171 */     if (o instanceof BooleanValue) {
/* 172 */       return _equals((BooleanValue)o);
/*     */     }
/* 174 */     BooleanValue bv = parse(o.toString());
/* 175 */     return (bv == null) ? false : _equals(bv);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 181 */     return this.bool ? 1 : 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\BooleanValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */