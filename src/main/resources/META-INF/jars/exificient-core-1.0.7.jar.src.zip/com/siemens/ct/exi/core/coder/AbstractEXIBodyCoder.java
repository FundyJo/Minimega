/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.FidelityOptions;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.context.GrammarContext;
/*     */ import com.siemens.ct.exi.core.context.GrammarUriContext;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.BooleanDatatype;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.exceptions.ErrorHandler;
/*     */ import com.siemens.ct.exi.core.grammars.Grammars;
/*     */ import com.siemens.ct.exi.core.grammars.SchemaInformedGrammars;
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.BuiltInStartTag;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import com.siemens.ct.exi.core.helpers.DefaultErrorHandler;
/*     */ import com.siemens.ct.exi.core.util.xml.QNameUtilities;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEXIBodyCoder
/*     */ {
/*     */   public final EXIFactory exiFactory;
/*     */   protected final Grammars grammar;
/*     */   protected final GrammarContext grammarContext;
/*     */   protected final FidelityOptions fidelityOptions;
/*     */   protected final boolean preservePrefix;
/*     */   protected final boolean preserveLexicalValues;
/*     */   protected ErrorHandler errorHandler;
/*     */   protected final BooleanDatatype booleanDatatype;
/*     */   private ElementContext elementContext;
/*     */   protected ElementContext[] elementContextStack;
/*     */   protected int elementContextStackIndex;
/*     */   public static final int INITIAL_STACK_SIZE = 16;
/*     */   protected Map<QNameContext, StartElement> runtimeGlobalElements;
/*     */   List<RuntimeUriContext> runtimeUris;
/*     */   protected QNameContext xsiTypeContext;
/*     */   protected QNameContext xsiNilContext;
/*     */   protected final int gUris;
/*     */   protected int nextUriID;
/*     */   protected final boolean limitGrammarLearning;
/*     */   protected final int maxBuiltInElementGrammars;
/*     */   protected final int maxBuiltInProductions;
/*     */   protected int learnedProductions;
/*     */   
/*     */   public AbstractEXIBodyCoder(EXIFactory exiFactory) throws EXIException {
/* 108 */     this.exiFactory = exiFactory;
/*     */     
/* 110 */     this.grammar = exiFactory.getGrammars();
/* 111 */     this.grammarContext = this.grammar.getGrammarContext();
/* 112 */     this
/* 113 */       .nextUriID = this.gUris = this.grammarContext.getNumberOfGrammarUriContexts();
/* 114 */     this.fidelityOptions = exiFactory.getFidelityOptions();
/*     */ 
/*     */     
/* 117 */     this
/* 118 */       .preservePrefix = this.fidelityOptions.isFidelityEnabled("PRESERVE_PREFIXES");
/*     */     
/* 120 */     this
/* 121 */       .preserveLexicalValues = this.fidelityOptions.isFidelityEnabled("PRESERVE_LEXICAL_VALUES");
/*     */ 
/*     */     
/* 124 */     this.errorHandler = (ErrorHandler)new DefaultErrorHandler();
/*     */ 
/*     */     
/* 127 */     this.runtimeGlobalElements = new HashMap<>();
/* 128 */     this.runtimeUris = new ArrayList<>();
/* 129 */     for (int i = 0; i < this.gUris; i++) {
/* 130 */       this.runtimeUris.add(new RuntimeUriContext(this.grammarContext
/* 131 */             .getGrammarUriContext(i)));
/*     */     }
/* 133 */     this.elementContextStack = new ElementContext[16];
/*     */ 
/*     */     
/* 136 */     this.booleanDatatype = new BooleanDatatype(null);
/*     */ 
/*     */     
/* 139 */     if (this.grammar.isSchemaInformed()) {
/* 140 */       this
/* 141 */         .maxBuiltInElementGrammars = this.exiFactory.getMaximumNumberOfBuiltInElementGrammars();
/* 142 */       this
/* 143 */         .maxBuiltInProductions = this.exiFactory.getMaximumNumberOfBuiltInProductions();
/* 144 */       this.limitGrammarLearning = (this.maxBuiltInElementGrammars >= 0 || this.maxBuiltInProductions >= 0);
/*     */     } else {
/* 146 */       this.maxBuiltInElementGrammars = -1;
/* 147 */       this.maxBuiltInProductions = -1;
/* 148 */       this.limitGrammarLearning = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected QNameContext getXsiTypeContext() {
/* 153 */     if (this.xsiTypeContext == null) {
/* 154 */       this
/* 155 */         .xsiTypeContext = this.grammarContext.getGrammarUriContext(2).getQNameContext(1);
/*     */     }
/* 157 */     return this.xsiTypeContext;
/*     */   }
/*     */ 
/*     */   
/*     */   protected QNameContext getXsiNilContext() {
/* 162 */     if (this.xsiNilContext == null) {
/* 163 */       this
/* 164 */         .xsiNilContext = this.grammarContext.getGrammarUriContext(2).getQNameContext(0);
/*     */     }
/* 166 */     return this.xsiNilContext;
/*     */   }
/*     */   
/*     */   protected final boolean isBuiltInStartTagGrammarWithAtXsiTypeOnly(Grammar g) {
/* 170 */     boolean ret = false;
/* 171 */     if (g.getNumberOfEvents() == 1) {
/* 172 */       Production p0 = g.getProduction(0);
/* 173 */       Event ev0 = p0.getEvent();
/* 174 */       if (ev0.isEventType(EventType.ATTRIBUTE)) {
/* 175 */         Attribute at = (Attribute)ev0;
/* 176 */         QNameContext qn0 = at.getQNameContext();
/* 177 */         if (qn0.getNamespaceUriID() == 2 && qn0.getLocalNameID() == 1)
/*     */         {
/* 179 */           ret = true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 184 */     return ret;
/*     */   }
/*     */   
/*     */   protected final StartElement getGlobalStartElement(QNameContext qnc) {
/* 188 */     StartElement se = qnc.getGlobalStartElement();
/* 189 */     if (se == null) {
/*     */ 
/*     */       
/* 192 */       se = this.runtimeGlobalElements.get(qnc);
/* 193 */       if (se == null) {
/*     */         
/* 195 */         se = new StartElement(qnc);
/*     */ 
/*     */         
/* 198 */         if (this.grammar.isSchemaInformed() && this.exiFactory
/* 199 */           .isUsingNonEvolvingGrammars()) {
/* 200 */           SchemaInformedGrammars sig = (SchemaInformedGrammars)this.grammar;
/* 201 */           se.setGrammar((Grammar)sig.getSchemaInformedElementFragmentGrammar());
/*     */         } else {
/* 203 */           se.setGrammar((Grammar)new BuiltInStartTag());
/*     */         } 
/* 205 */         this.runtimeGlobalElements.put(qnc, se);
/*     */       } 
/*     */     } 
/*     */     
/* 209 */     return se;
/*     */   }
/*     */   
/*     */   protected final Grammar getCurrentGrammar() {
/* 213 */     return this.elementContext.gr;
/*     */   }
/*     */   
/*     */   protected final void updateCurrentRule(Grammar newCurrentGrammar) {
/* 217 */     this.elementContext.gr = newCurrentGrammar;
/*     */   }
/*     */   
/*     */   protected final ElementContext getElementContext() {
/* 221 */     return this.elementContext;
/*     */   }
/*     */   
/*     */   protected final void updateElementContext(ElementContext elementContext) {
/* 225 */     this.elementContext = elementContext;
/*     */   }
/*     */   
/*     */   public void setErrorHandler(ErrorHandler errorHandler) {
/* 229 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initForEachRun() throws EXIException, IOException {
/* 236 */     this.runtimeGlobalElements.clear();
/* 237 */     for (int i = 0; i < this.nextUriID; i++) {
/* 238 */       ((RuntimeUriContext)this.runtimeUris.get(i)).clear();
/*     */     }
/*     */ 
/*     */     
/* 242 */     this.nextUriID = this.gUris;
/*     */ 
/*     */ 
/*     */     
/* 246 */     Grammar startRule = this.exiFactory.isFragment() ? this.grammar.getFragmentGrammar() : this.grammar.getDocumentGrammar();
/*     */ 
/*     */     
/* 249 */     this.elementContextStackIndex = 0;
/* 250 */     this.elementContextStack[this.elementContextStackIndex] = this.elementContext = new ElementContext(null, startRule);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void declarePrefix(String pfx, String uri) {
/* 255 */     declarePrefix(new NamespaceDeclaration(uri, pfx));
/*     */   }
/*     */   
/*     */   protected final void declarePrefix(NamespaceDeclaration nsDecl) {
/* 259 */     if (this.elementContext.nsDeclarations == null) {
/* 260 */       this.elementContext.nsDeclarations = new ArrayList<>();
/*     */     }
/* 262 */     assert !this.elementContext.nsDeclarations.contains(nsDecl);
/* 263 */     this.elementContext.nsDeclarations.add(nsDecl);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final String getURI(String prefix) {
/* 268 */     for (int i = this.elementContextStackIndex; i > 0; i--) {
/* 269 */       ElementContext ec = this.elementContextStack[i];
/* 270 */       if (ec.nsDeclarations != null) {
/* 271 */         for (int k = 0; k < ec.nsDeclarations.size(); k++) {
/* 272 */           NamespaceDeclaration ns = ec.nsDeclarations.get(k);
/* 273 */           if (ns.prefix.equals(prefix)) {
/* 274 */             return ns.namespaceURI;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 279 */     return (prefix.length() == 0) ? "" : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final String getPrefix(String uri) {
/* 284 */     for (int i = 1; i <= this.elementContextStackIndex; i++) {
/* 285 */       ElementContext ec = this.elementContextStack[i];
/* 286 */       if (ec.nsDeclarations != null) {
/* 287 */         for (int k = 0; k < ec.nsDeclarations.size(); k++) {
/* 288 */           NamespaceDeclaration ns = ec.nsDeclarations.get(k);
/* 289 */           if (ns.namespaceURI.equals(uri)) {
/* 290 */             return ns.prefix;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 295 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void pushElement(Grammar updContextGrammar, StartElement se) {
/* 300 */     this.elementContext.gr = updContextGrammar;
/*     */ 
/*     */     
/* 303 */     if (this.elementContextStack.length == ++this.elementContextStackIndex) {
/* 304 */       ElementContext[] elementContextStackNew = new ElementContext[this.elementContextStack.length << 2];
/* 305 */       System.arraycopy(this.elementContextStack, 0, elementContextStackNew, 0, this.elementContextStack.length);
/*     */       
/* 307 */       this.elementContextStack = elementContextStackNew;
/*     */     } 
/*     */ 
/*     */     
/* 311 */     this.elementContextStack[this.elementContextStackIndex] = this
/* 312 */       .elementContext = new ElementContext(se.getQNameContext(), se.getGrammar());
/*     */   }
/*     */   
/*     */   protected final ElementContext popElement() {
/* 316 */     assert this.elementContextStackIndex > 0;
/*     */     
/* 318 */     ElementContext poppedEC = this.elementContextStack[this.elementContextStackIndex];
/* 319 */     this.elementContextStack[this.elementContextStackIndex--] = null;
/* 320 */     this.elementContext = this.elementContextStack[this.elementContextStackIndex];
/*     */     
/* 322 */     return poppedEC;
/*     */   }
/*     */   
/*     */   protected RuntimeUriContext addUri(String uri) {
/*     */     RuntimeUriContext ruc;
/* 327 */     int uriID = this.nextUriID++;
/* 328 */     if (uriID < this.runtimeUris.size()) {
/*     */       
/* 330 */       ruc = this.runtimeUris.get(uriID);
/*     */       
/* 332 */       ruc.setNamespaceUri(uri);
/*     */     } else {
/*     */       
/* 335 */       ruc = new RuntimeUriContext(uriID, uri);
/* 336 */       this.runtimeUris.add(ruc);
/*     */     } 
/*     */     
/* 339 */     return ruc;
/*     */   }
/*     */   
/*     */   public int getNumberOfUris() {
/* 343 */     return this.nextUriID;
/*     */   }
/*     */   
/*     */   public RuntimeUriContext getUri(String namespaceUri) {
/* 347 */     for (int i = 0; i < this.nextUriID && i < this.runtimeUris.size(); i++) {
/* 348 */       RuntimeUriContext ruc = this.runtimeUris.get(i);
/* 349 */       if (ruc.namespaceUri.equals(namespaceUri)) {
/* 350 */         return ruc;
/*     */       }
/*     */     } 
/*     */     
/* 354 */     return null;
/*     */   }
/*     */   
/*     */   public RuntimeUriContext getUri(int namespaceUriID) {
/* 358 */     assert namespaceUriID >= 0 && namespaceUriID < this.nextUriID;
/* 359 */     return this.runtimeUris.get(namespaceUriID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void throwWarning(String message) {
/* 367 */     this.errorHandler.warning(new EXIException(message + ", options=" + this.exiFactory
/* 368 */           .getFidelityOptions()));
/*     */   }
/*     */ 
/*     */   
/*     */   public final class ElementContext
/*     */   {
/*     */     private String prefix;
/*     */     private String sqname;
/*     */     Grammar gr;
/*     */     List<NamespaceDeclaration> nsDeclarations;
/*     */     private Boolean isXmlSpacePreserve;
/*     */     public final QNameContext qnameContext;
/*     */     
/*     */     public ElementContext(QNameContext qnameContext, Grammar gr) {
/* 382 */       this.qnameContext = qnameContext;
/* 383 */       this.gr = gr;
/*     */     }
/*     */     
/*     */     String getQNameAsString() {
/* 387 */       if (this.sqname == null) {
/* 388 */         if (AbstractEXIBodyCoder.this.preservePrefix) {
/* 389 */           this.sqname = QNameUtilities.getQualifiedName(this.qnameContext
/* 390 */               .getLocalName(), getPrefix());
/*     */         } else {
/* 392 */           this.sqname = this.qnameContext.getDefaultQNameAsString();
/*     */         } 
/*     */       }
/* 395 */       return this.sqname;
/*     */     }
/*     */     
/*     */     void setPrefix(String pfx) {
/* 399 */       this.prefix = pfx;
/*     */     }
/*     */     
/*     */     String getPrefix() {
/* 403 */       return this.prefix;
/*     */     }
/*     */     
/*     */     void setXmlSpacePreserve(Boolean isXmlSpacePreserve) {
/* 407 */       this.isXmlSpacePreserve = isXmlSpacePreserve;
/*     */     }
/*     */     
/*     */     Boolean isXmlSpacePreserve() {
/* 411 */       return this.isXmlSpacePreserve;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final class RuntimeUriContext
/*     */   {
/*     */     final int namespaceUriID;
/*     */     
/*     */     private String namespaceUri;
/*     */     final GrammarUriContext guc;
/*     */     List<QNameContext> qnames;
/*     */     List<String> prefixes;
/*     */     
/*     */     public RuntimeUriContext(int namespaceUriID, String namespaceUri) {
/* 426 */       this(null, namespaceUriID, namespaceUri);
/*     */     }
/*     */     
/*     */     public RuntimeUriContext(GrammarUriContext guc) {
/* 430 */       this(guc, guc.getNamespaceUriID(), guc.getNamespaceUri());
/*     */     }
/*     */ 
/*     */     
/*     */     private RuntimeUriContext(GrammarUriContext guc, int namespaceUriID, String namespaceUri) {
/* 435 */       this.guc = guc;
/* 436 */       this.namespaceUriID = namespaceUriID;
/* 437 */       this.namespaceUri = namespaceUri;
/*     */     }
/*     */     
/*     */     protected void clear() {
/* 441 */       if (this.guc == null) {
/* 442 */         this.namespaceUri = null;
/*     */       }
/*     */       
/* 445 */       if (this.qnames != null && this.qnames.size() > 0) {
/* 446 */         this.qnames.clear();
/*     */       }
/* 448 */       if (AbstractEXIBodyCoder.this.preservePrefix && this.prefixes != null && this.prefixes.size() > 0) {
/* 449 */         this.prefixes.clear();
/*     */       }
/*     */     }
/*     */     
/*     */     public QNameContext getQNameContext(String localName) {
/* 454 */       QNameContext qnc = null;
/* 455 */       if (this.guc != null) {
/* 456 */         qnc = this.guc.getQNameContext(localName);
/*     */       }
/* 458 */       if (qnc == null)
/*     */       {
/* 460 */         if (this.qnames != null && this.qnames.size() != 0) {
/*     */           
/* 462 */           for (int i = this.qnames.size() - 1; i >= 0; i--) {
/* 463 */             qnc = this.qnames.get(i);
/* 464 */             if (qnc.getLocalName().equals(localName)) {
/* 465 */               return qnc;
/*     */             }
/*     */           } 
/* 468 */           qnc = null;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 473 */       return qnc;
/*     */     }
/*     */     
/*     */     public QNameContext getQNameContext(int localNameID) {
/* 477 */       QNameContext qnc = null;
/* 478 */       int sub = 0;
/* 479 */       if (this.guc != null) {
/* 480 */         qnc = this.guc.getQNameContext(localNameID);
/* 481 */         sub = this.guc.getNumberOfQNames();
/*     */       } 
/* 483 */       if (qnc == null) {
/*     */         
/* 485 */         localNameID -= sub;
/* 486 */         assert localNameID >= 0 && localNameID < this.qnames.size();
/* 487 */         qnc = this.qnames.get(localNameID);
/*     */       } 
/*     */       
/* 490 */       return qnc;
/*     */     }
/*     */     
/*     */     public int getNumberOfQNames() {
/* 494 */       int n = 0;
/* 495 */       if (this.guc != null) {
/* 496 */         n = this.guc.getNumberOfQNames();
/*     */       }
/* 498 */       if (this.qnames != null) {
/* 499 */         n += this.qnames.size();
/*     */       }
/* 501 */       return n;
/*     */     }
/*     */     
/*     */     protected QNameContext addQNameContext(String localName) {
/* 505 */       if (this.qnames == null) {
/* 506 */         this.qnames = new ArrayList<>();
/*     */       }
/* 508 */       int localNameID = getNumberOfQNames();
/* 509 */       QName qName = new QName(this.namespaceUri, localName);
/* 510 */       QNameContext qnc = new QNameContext(this.namespaceUriID, localNameID, qName);
/*     */       
/* 512 */       this.qnames.add(qnc);
/*     */       
/* 514 */       return qnc;
/*     */     }
/*     */     
/*     */     public int getNumberOfPrefixes() {
/* 518 */       int pfs = 0;
/* 519 */       if (this.guc != null) {
/* 520 */         pfs = this.guc.getNumberOfPrefixes();
/*     */       }
/*     */       
/* 523 */       if (this.prefixes != null) {
/* 524 */         assert AbstractEXIBodyCoder.this.preservePrefix;
/* 525 */         pfs += this.prefixes.size();
/*     */       } 
/*     */       
/* 528 */       return pfs;
/*     */     }
/*     */     
/*     */     protected void addPrefix(String prefix) {
/* 532 */       assert AbstractEXIBodyCoder.this.preservePrefix;
/*     */       
/* 534 */       if (this.prefixes == null) {
/* 535 */         this.prefixes = new ArrayList<>();
/*     */       }
/* 537 */       this.prefixes.add(prefix);
/*     */     }
/*     */     
/*     */     protected int getPrefixID(String prefix) {
/* 541 */       assert AbstractEXIBodyCoder.this.preservePrefix;
/*     */       
/* 543 */       int id = -1;
/* 544 */       int sub = 0;
/* 545 */       if (this.guc != null) {
/* 546 */         id = this.guc.getPrefixID(prefix);
/* 547 */         sub = this.guc.getNumberOfPrefixes();
/*     */       } 
/* 549 */       if (id == -1 && 
/* 550 */         this.prefixes != null && this.prefixes.size() != 0) {
/* 551 */         for (int i = 0; i < this.prefixes.size(); i++) {
/* 552 */           if (((String)this.prefixes.get(i)).equals(prefix)) {
/* 553 */             return i + sub;
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 559 */       return id;
/*     */     }
/*     */     
/*     */     public String getPrefix(int prefixID) {
/* 563 */       String pfx = null;
/* 564 */       int sub = 0;
/* 565 */       if (this.guc != null) {
/* 566 */         pfx = this.guc.getPrefix(prefixID);
/* 567 */         sub = this.guc.getNumberOfPrefixes();
/*     */       } 
/* 569 */       if (pfx == null) {
/* 570 */         assert AbstractEXIBodyCoder.this.preservePrefix;
/* 571 */         assert this.prefixes != null;
/* 572 */         prefixID -= sub;
/* 573 */         assert prefixID >= 0 && prefixID < this.prefixes.size();
/* 574 */         pfx = this.prefixes.get(prefixID);
/*     */       } 
/*     */       
/* 577 */       return pfx;
/*     */     }
/*     */     
/*     */     public void setNamespaceUri(String namespaceUri) {
/* 581 */       this.namespaceUri = namespaceUri;
/*     */     }
/*     */     
/*     */     public String getNamespaceUri() {
/* 585 */       return this.namespaceUri;
/*     */     }
/*     */     
/*     */     public int getNamespaceUriID() {
/* 589 */       return this.namespaceUriID;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\AbstractEXIBodyCoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */