/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum GrammarType
/*    */ {
/* 35 */   DOCUMENT, FRAGMENT, DOC_END,
/*    */   
/* 37 */   SCHEMA_INFORMED_DOC_CONTENT, SCHEMA_INFORMED_FRAGMENT_CONTENT,
/*    */   
/* 39 */   SCHEMA_INFORMED_FIRST_START_TAG_CONTENT, SCHEMA_INFORMED_START_TAG_CONTENT, SCHEMA_INFORMED_ELEMENT_CONTENT,
/*    */   
/* 41 */   BUILT_IN_DOC_CONTENT, BUILT_IN_FRAGMENT_CONTENT,
/*    */   
/* 43 */   BUILT_IN_START_TAG_CONTENT, BUILT_IN_ELEMENT_CONTENT;
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\GrammarType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */