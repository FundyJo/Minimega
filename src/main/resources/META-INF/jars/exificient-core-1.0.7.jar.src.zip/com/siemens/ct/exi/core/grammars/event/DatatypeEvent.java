package com.siemens.ct.exi.core.grammars.event;

import com.siemens.ct.exi.core.datatype.Datatype;

public interface DatatypeEvent extends Event {
  Datatype getDatatype();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\DatatypeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */