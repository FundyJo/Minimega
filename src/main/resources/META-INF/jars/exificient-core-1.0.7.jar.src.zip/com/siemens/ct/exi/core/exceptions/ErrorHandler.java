package com.siemens.ct.exi.core.exceptions;

public interface ErrorHandler {
  void warning(EXIException paramEXIException);
  
  void error(EXIException paramEXIException);
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\exceptions\ErrorHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */