package com.siemens.ct.exi.core;

import com.siemens.ct.exi.core.datatype.Datatype;
import com.siemens.ct.exi.core.datatype.strings.StringDecoder;
import com.siemens.ct.exi.core.datatype.strings.StringEncoder;
import com.siemens.ct.exi.core.exceptions.EXIException;
import com.siemens.ct.exi.core.grammars.Grammars;
import com.siemens.ct.exi.core.types.TypeDecoder;
import com.siemens.ct.exi.core.types.TypeEncoder;
import java.util.List;
import javax.xml.namespace.QName;

public interface EXIFactory extends Cloneable {
  void setFidelityOptions(FidelityOptions paramFidelityOptions);
  
  FidelityOptions getFidelityOptions();
  
  void setEncodingOptions(EncodingOptions paramEncodingOptions);
  
  EncodingOptions getEncodingOptions();
  
  void setDecodingOptions(DecodingOptions paramDecodingOptions);
  
  DecodingOptions getDecodingOptions();
  
  void setSchemaIdResolver(SchemaIdResolver paramSchemaIdResolver);
  
  SchemaIdResolver getSchemaIdResolver();
  
  void setFragment(boolean paramBoolean);
  
  boolean isFragment();
  
  void setGrammars(Grammars paramGrammars);
  
  Grammars getGrammars();
  
  void setCodingMode(CodingMode paramCodingMode);
  
  CodingMode getCodingMode();
  
  void setBlockSize(int paramInt);
  
  int getBlockSize();
  
  void setValueMaxLength(int paramInt);
  
  int getValueMaxLength();
  
  void setValuePartitionCapacity(int paramInt);
  
  int getValuePartitionCapacity();
  
  void setDatatypeRepresentationMap(QName[] paramArrayOfQName1, QName[] paramArrayOfQName2);
  
  Datatype registerDatatypeRepresentationMapDatatype(QName paramQName, Datatype paramDatatype);
  
  QName[] getDatatypeRepresentationMapTypes();
  
  QName[] getDatatypeRepresentationMapRepresentations();
  
  void setSelfContainedElements(QName[] paramArrayOfQName);
  
  void setSelfContainedElements(QName[] paramArrayOfQName, SelfContainedHandler paramSelfContainedHandler);
  
  boolean isSelfContainedElement(QName paramQName);
  
  SelfContainedHandler getSelfContainedHandler();
  
  void setLocalValuePartitions(boolean paramBoolean);
  
  boolean isLocalValuePartitions();
  
  void setMaximumNumberOfBuiltInElementGrammars(int paramInt);
  
  int getMaximumNumberOfBuiltInElementGrammars();
  
  void setMaximumNumberOfBuiltInProductions(int paramInt);
  
  int getMaximumNumberOfBuiltInProductions();
  
  boolean isGrammarLearningDisabled();
  
  void setSharedStrings(List<String> paramList);
  
  List<String> getSharedStrings();
  
  void setUsingNonEvolvingGrammars(boolean paramBoolean);
  
  boolean isUsingNonEvolvingGrammars();
  
  EXIBodyEncoder createEXIBodyEncoder() throws EXIException;
  
  EXIStreamEncoder createEXIStreamEncoder() throws EXIException;
  
  EXIBodyDecoder createEXIBodyDecoder() throws EXIException;
  
  EXIStreamDecoder createEXIStreamDecoder() throws EXIException;
  
  StringEncoder createStringEncoder();
  
  TypeEncoder createTypeEncoder() throws EXIException;
  
  StringDecoder createStringDecoder();
  
  TypeDecoder createTypeDecoder() throws EXIException;
  
  EXIFactory clone();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\EXIFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */