/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.types.BuiltInType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBinaryDatatype
/*    */   extends AbstractDatatype
/*    */ {
/*    */   public AbstractBinaryDatatype(BuiltInType binaryType, QNameContext schemaType) {
/* 40 */     super(binaryType, schemaType);
/* 41 */     assert binaryType == BuiltInType.BINARY_BASE64 || binaryType == BuiltInType.BINARY_HEX;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\AbstractBinaryDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */