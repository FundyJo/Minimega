/*     */ package com.siemens.ct.exi.core.context;
/*     */ 
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QNameContext
/*     */ {
/*     */   final int namespaceUriID;
/*     */   final int localNameID;
/*     */   final QName qName;
/*     */   final String defaultQNameAsString;
/*     */   final String defaultPrefix;
/*     */   StartElement grammarGlobalElement;
/*     */   Attribute grammarGlobalAttribute;
/*     */   SchemaInformedFirstStartTagGrammar typeGrammar;
/*     */   
/*     */   public QNameContext(int namespaceUriID, int localNameID, QName qName) {
/*  83 */     this.namespaceUriID = namespaceUriID;
/*  84 */     this.localNameID = localNameID;
/*  85 */     this.qName = qName;
/*  86 */     switch (namespaceUriID) {
/*     */       
/*     */       case 0:
/*  89 */         this.defaultPrefix = "";
/*  90 */         this.defaultQNameAsString = this.qName.getLocalPart();
/*     */         return;
/*     */       case 1:
/*  93 */         this.defaultPrefix = "xml";
/*  94 */         this
/*  95 */           .defaultQNameAsString = this.defaultPrefix + ":" + this.qName.getLocalPart();
/*     */         return;
/*     */       case 2:
/*  98 */         this.defaultPrefix = "xsi";
/*  99 */         this
/* 100 */           .defaultQNameAsString = this.defaultPrefix + ":" + this.qName.getLocalPart();
/*     */         return;
/*     */     } 
/* 103 */     this.defaultPrefix = "ns" + namespaceUriID;
/* 104 */     this
/* 105 */       .defaultQNameAsString = this.defaultPrefix + ":" + this.qName.getLocalPart();
/*     */   }
/*     */ 
/*     */   
/*     */   public QName getQName() {
/* 110 */     return this.qName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultQNameAsString() {
/* 135 */     return this.defaultQNameAsString;
/*     */   }
/*     */   
/*     */   public String getDefaultPrefix() {
/* 139 */     return this.defaultPrefix;
/*     */   }
/*     */   
/*     */   public int getLocalNameID() {
/* 143 */     return this.localNameID;
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/* 147 */     return this.qName.getLocalPart();
/*     */   }
/*     */   
/*     */   public void setGlobalStartElement(StartElement grammarGlobalElement) {
/* 151 */     this.grammarGlobalElement = grammarGlobalElement;
/*     */   }
/*     */   
/*     */   public StartElement getGlobalStartElement() {
/* 155 */     return this.grammarGlobalElement;
/*     */   }
/*     */   
/*     */   public void setGlobalAttribute(Attribute grammarGlobalAttribute) {
/* 159 */     this.grammarGlobalAttribute = grammarGlobalAttribute;
/*     */   }
/*     */   
/*     */   public Attribute getGlobalAttribute() {
/* 163 */     return this.grammarGlobalAttribute;
/*     */   }
/*     */   
/*     */   public void setTypeGrammar(SchemaInformedFirstStartTagGrammar typeGrammar) {
/* 167 */     this.typeGrammar = typeGrammar;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaInformedFirstStartTagGrammar getTypeGrammar() {
/* 172 */     return this.typeGrammar;
/*     */   }
/*     */   
/*     */   public int getNamespaceUriID() {
/* 176 */     return this.namespaceUriID;
/*     */   }
/*     */   
/*     */   public String getNamespaceUri() {
/* 180 */     return this.qName.getNamespaceURI();
/*     */   }
/*     */   
/*     */   protected int compareTo(String localName) {
/* 184 */     return getQName().getLocalPart().compareTo(localName);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 188 */     return "{" + this.namespaceUriID + "}" + this.localNameID + "," + 
/* 189 */       getLocalName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean equals(Object o) {
/* 202 */     if (o instanceof QNameContext) {
/* 203 */       QNameContext other = (QNameContext)o;
/* 204 */       return (other.localNameID == this.localNameID && other.namespaceUriID == this.namespaceUriID);
/*     */     } 
/*     */     
/* 207 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 212 */     return this.namespaceUriID ^ this.localNameID;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\context\QNameContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */