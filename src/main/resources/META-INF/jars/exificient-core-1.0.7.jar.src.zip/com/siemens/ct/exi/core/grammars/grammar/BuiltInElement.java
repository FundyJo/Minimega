/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*    */ import com.siemens.ct.exi.core.grammars.event.Event;
/*    */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuiltInElement
/*    */   extends AbstractBuiltInContent
/*    */ {
/*    */   protected BuiltInElement() {
/* 51 */     addProduction(END_ELEMENT, END_RULE);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasEndElement() {
/* 56 */     return true;
/*    */   }
/*    */   
/*    */   public GrammarType getGrammarType() {
/* 60 */     return GrammarType.BUILT_IN_ELEMENT_CONTENT;
/*    */   }
/*    */ 
/*    */   
/*    */   public void learnStartElement(StartElement se) {
/* 65 */     addProduction((Event)se, this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void learnAttribute(Attribute at) {
/* 76 */     throw new IllegalArgumentException("ElementContent Rule cannot learn AT events");
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\BuiltInElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */