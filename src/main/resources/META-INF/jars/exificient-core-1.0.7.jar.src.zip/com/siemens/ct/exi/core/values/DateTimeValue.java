/*      */ package com.siemens.ct.exi.core.values;
/*      */ 
/*      */ import com.siemens.ct.exi.core.exceptions.XMLParsingException;
/*      */ import com.siemens.ct.exi.core.types.DateTimeType;
/*      */ import com.siemens.ct.exi.core.util.MethodsBag;
/*      */ import java.util.Calendar;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DateTimeValue
/*      */   extends AbstractValue
/*      */ {
/*      */   public static final int NUMBER_BITS_MONTHDAY = 9;
/*      */   public static final int NUMBER_BITS_TIME = 17;
/*      */   public static final int NUMBER_BITS_TIMEZONE = 11;
/*      */   public static final int YEAR_OFFSET = 2000;
/*      */   public static final int TIMEZONE_OFFSET_IN_MINUTES = 896;
/*      */   static final int SECONDS_IN_MINUTE = 64;
/*      */   static final int SECONDS_IN_HOUR = 4096;
/*      */   public static final int MONTH_MULTIPLICATOR = 32;
/*      */   public final DateTimeType type;
/*      */   public final int year;
/*      */   public final int monthDay;
/*      */   public final int time;
/*      */   public final boolean presenceFractionalSecs;
/*      */   public final int fractionalSecs;
/*      */   public final boolean presenceTimezone;
/*      */   public final int timezone;
/*      */   public final boolean normalized;
/*      */   protected Calendar cal;
/*      */   protected DateTimeValue normalizedDateTimeValue;
/*   71 */   int sizeFractionalSecs = -1;
/*      */ 
/*      */   
/*      */   public DateTimeValue(DateTimeType type, int year, int monthDay, int time, int fractionalSecs, boolean presenceTimezone, int timezone) {
/*   75 */     this(type, year, monthDay, time, fractionalSecs, presenceTimezone, timezone, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DateTimeValue(DateTimeType type, int year, int monthDay, int time, int fractionalSecs, boolean presenceTimezone, int timezone, boolean normalized) {
/*   82 */     super(ValueType.DATETIME);
/*   83 */     this.type = type;
/*      */ 
/*      */ 
/*      */     
/*   87 */     int hour = time / 4096;
/*   88 */     if (hour == 24) {
/*   89 */       time -= hour * 4096;
/*   90 */       int minute = time / 64;
/*   91 */       time -= minute * 64;
/*      */ 
/*      */       
/*   94 */       monthDay++;
/*   95 */       hour = 0;
/*      */       
/*   97 */       time = (hour * 64 + minute) * 64 + time;
/*      */ 
/*      */ 
/*      */       
/*  101 */       int month = monthDay / 32;
/*  102 */       int day = monthDay - month * 32;
/*      */       
/*  104 */       if (month == 13) {
/*  105 */         year++;
/*  106 */         month = 1;
/*  107 */         day = 1;
/*  108 */         monthDay = month * 32 + day;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  113 */     this.time = time;
/*      */     
/*  115 */     this.year = year;
/*  116 */     this.monthDay = monthDay;
/*  117 */     this.fractionalSecs = fractionalSecs;
/*      */ 
/*      */     
/*  120 */     this.presenceFractionalSecs = (this.fractionalSecs != 0);
/*  121 */     this.presenceTimezone = presenceTimezone;
/*  122 */     this.timezone = timezone;
/*  123 */     this.normalized = normalized;
/*      */   }
/*      */ 
/*      */   
/*      */   public static DateTimeValue parse(String cal, DateTimeType type) {
/*  128 */     cal = cal.trim();
/*      */     
/*  130 */     int sYear = 0;
/*  131 */     int sMonthDay = 0;
/*  132 */     int sTime = 0;
/*  133 */     int sFractionalSecs = 0;
/*      */ 
/*      */ 
/*      */     
/*  137 */     StringBuilder sbCal = new StringBuilder(cal); try {
/*      */       boolean sPresenceTimezone;
/*      */       int sTimezone;
/*  140 */       switch (type) {
/*      */         case gYear:
/*  142 */           sYear = parseYear(sbCal);
/*      */           break;
/*      */         case gYearMonth:
/*  145 */           sYear = parseYear(sbCal);
/*  146 */           checkCharacter(sbCal, '-');
/*  147 */           sMonthDay = parseMonth(sbCal) * 32;
/*      */           break;
/*      */         case date:
/*  150 */           sYear = parseYear(sbCal);
/*  151 */           checkCharacter(sbCal, '-');
/*  152 */           sMonthDay = parseMonthDay(sbCal);
/*      */           break;
/*      */         
/*      */         case dateTime:
/*  156 */           sYear = parseYear(sbCal);
/*  157 */           checkCharacter(sbCal, '-');
/*  158 */           sMonthDay = parseMonthDay(sbCal);
/*  159 */           checkCharacter(sbCal, 'T');
/*      */         
/*      */         case time:
/*  162 */           sTime = parseTime(sbCal);
/*  163 */           if (sbCal.length() > 0 && sbCal.charAt(0) == '.') {
/*  164 */             sbCal.deleteCharAt(0);
/*      */ 
/*      */             
/*  167 */             int digits = countDigits(sbCal);
/*  168 */             sFractionalSecs = Integer.parseInt((new StringBuilder(sbCal
/*  169 */                   .substring(0, digits))).reverse().toString());
/*      */             
/*  171 */             sbCal.delete(0, digits);
/*      */           } 
/*      */           break;
/*      */         case gMonth:
/*  175 */           checkCharacter(sbCal, '-');
/*  176 */           checkCharacter(sbCal, '-');
/*  177 */           sMonthDay = parseMonth(sbCal) * 32;
/*  178 */           if (sbCal.length() > 1 && sbCal.charAt(0) == sbCal.charAt(1) && sbCal
/*  179 */             .charAt(0) == '-') {
/*  180 */             checkCharacter(sbCal, '-');
/*  181 */             checkCharacter(sbCal, '-');
/*      */           } 
/*      */           break;
/*      */         case gMonthDay:
/*  185 */           checkCharacter(sbCal, '-');
/*  186 */           checkCharacter(sbCal, '-');
/*  187 */           sMonthDay = parseMonthDay(sbCal);
/*      */           break;
/*      */         case gDay:
/*  190 */           checkCharacter(sbCal, '-');
/*  191 */           checkCharacter(sbCal, '-');
/*  192 */           checkCharacter(sbCal, '-');
/*  193 */           sMonthDay = parseDay(sbCal);
/*      */           break;
/*      */         default:
/*  196 */           throw new UnsupportedOperationException();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  211 */       if (sbCal.length() == 0) {
/*  212 */         sPresenceTimezone = false;
/*  213 */         sTimezone = 0;
/*  214 */       } else if (sbCal.length() == 1 && sbCal.charAt(0) == 'Z') {
/*  215 */         sbCal.delete(0, 1);
/*  216 */         sPresenceTimezone = true;
/*      */         
/*  218 */         sTimezone = 0;
/*      */       } else {
/*  220 */         int multiplicator; sPresenceTimezone = true;
/*      */         
/*  222 */         if (sbCal.charAt(0) == '+') {
/*  223 */           multiplicator = 1;
/*  224 */         } else if (sbCal.charAt(0) == '-') {
/*  225 */           multiplicator = -1;
/*      */         } else {
/*  227 */           throw new XMLParsingException("Unexpected character while parsing");
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  232 */         int hours = Integer.parseInt(sbCal.substring(1, 3));
/*      */         
/*  234 */         assert sbCal.charAt(3) == ':';
/*      */         
/*  236 */         int minutes = Integer.parseInt(sbCal.substring(4, 6));
/*      */ 
/*      */ 
/*      */         
/*  240 */         sTimezone = multiplicator * (hours * 64 + minutes);
/*      */       } 
/*      */       
/*  243 */       return new DateTimeValue(type, sYear, sMonthDay, sTime, sFractionalSecs, sPresenceTimezone, sTimezone);
/*      */     }
/*  245 */     catch (RuntimeException e) {
/*  246 */       RuntimeException runtimeException1; return null;
/*  247 */     } catch (XMLParsingException e) {
/*  248 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected static int parseYear(StringBuilder sb) {
/*      */     String sYear;
/*      */     int len;
/*  255 */     if (sb.charAt(0) == '-') {
/*  256 */       sYear = sb.substring(0, 5);
/*  257 */       len = 5;
/*      */     } else {
/*  259 */       sYear = sb.substring(0, 4);
/*  260 */       len = 4;
/*      */     } 
/*  262 */     int year = Integer.parseInt(sYear);
/*      */ 
/*      */     
/*  265 */     sb.delete(0, len);
/*      */     
/*  267 */     return year;
/*      */   }
/*      */ 
/*      */   
/*      */   protected static void checkCharacter(StringBuilder sb, char c) throws XMLParsingException {
/*  272 */     if (sb.length() > 0 && sb.charAt(0) == c) {
/*  273 */       sb.delete(0, 1);
/*      */     } else {
/*  275 */       throw new XMLParsingException("Unexpected character while parsing");
/*      */     } 
/*      */   }
/*      */   
/*      */   protected static int parseMonth(StringBuilder sb) {
/*  280 */     int month = Integer.parseInt(sb.substring(0, 2));
/*      */ 
/*      */     
/*  283 */     sb.delete(0, 2);
/*      */     
/*  285 */     return month;
/*      */   }
/*      */   
/*      */   protected static int parseDay(StringBuilder sb) {
/*  289 */     String sDay = sb.substring(0, 2);
/*  290 */     int day = Integer.parseInt(sDay);
/*      */ 
/*      */     
/*  293 */     sb.delete(0, 2);
/*      */     
/*  295 */     return day;
/*      */   }
/*      */ 
/*      */   
/*      */   protected static int parseMonthDay(StringBuilder sb) throws XMLParsingException {
/*  300 */     int month = parseMonth(sb);
/*  301 */     checkCharacter(sb, '-');
/*  302 */     int day = parseDay(sb);
/*      */     
/*  304 */     return month * 32 + day;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static int parseTime(StringBuilder sb) throws XMLParsingException {
/*  310 */     int hour = Integer.parseInt(sb.substring(0, 2));
/*  311 */     sb.delete(0, 2);
/*      */     
/*  313 */     checkCharacter(sb, ':');
/*      */ 
/*      */     
/*  316 */     int minutes = Integer.parseInt(sb.substring(0, 2));
/*  317 */     sb.delete(0, 2);
/*      */     
/*  319 */     checkCharacter(sb, ':');
/*      */ 
/*      */     
/*  322 */     int seconds = Integer.parseInt(sb.substring(0, 2));
/*  323 */     sb.delete(0, 2);
/*      */     
/*  325 */     return (hour * 64 + minutes) * 64 + seconds;
/*      */   }
/*      */   
/*      */   private static int countDigits(StringBuilder sb) {
/*  329 */     int length = sb.length();
/*  330 */     int index = 0;
/*      */     
/*  332 */     while (index < length && isDigit(sb.charAt(index))) {
/*  333 */       index++;
/*      */     }
/*      */     
/*  336 */     return index;
/*      */   }
/*      */   
/*      */   private static boolean isDigit(char c) {
/*  340 */     boolean isDigit = false;
/*      */     
/*  342 */     char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
/*      */     
/*  344 */     int i = 0;
/*  345 */     while (!isDigit && i < digits.length) {
/*  346 */       if (c == digits[i]) {
/*  347 */         isDigit = true;
/*      */       }
/*  349 */       i++;
/*      */     } 
/*      */     
/*  352 */     return isDigit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DateTimeValue parse(Calendar cal, DateTimeType type) {
/*  367 */     int sYear = 0;
/*  368 */     int sMonthDay = 0;
/*  369 */     int sTime = 0;
/*  370 */     int sFractionalSecs = 0;
/*  371 */     boolean sPresenceTimezone = false;
/*      */ 
/*      */     
/*  374 */     switch (type) {
/*      */       case gYear:
/*      */       case gYearMonth:
/*      */       case date:
/*  378 */         sYear = cal.get(1);
/*  379 */         sMonthDay = getMonthDay(cal);
/*      */         break;
/*      */       
/*      */       case dateTime:
/*  383 */         sYear = cal.get(1);
/*  384 */         sMonthDay = getMonthDay(cal);
/*      */       
/*      */       case time:
/*  387 */         sTime = getTime(cal);
/*  388 */         sFractionalSecs = cal.get(14);
/*      */         break;
/*      */       case gMonth:
/*      */       case gMonthDay:
/*      */       case gDay:
/*  393 */         sMonthDay = getMonthDay(cal);
/*      */         break;
/*      */       default:
/*  396 */         throw new UnsupportedOperationException();
/*      */     } 
/*      */     
/*  399 */     int sTimezone = getTimeZoneInMinutesOffset(cal);
/*  400 */     if (sTimezone != 0) {
/*  401 */       sPresenceTimezone = true;
/*      */     }
/*      */     
/*  404 */     return new DateTimeValue(type, sYear, sMonthDay, sTime, sFractionalSecs, sPresenceTimezone, sTimezone);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getMonthDay(Calendar cal) {
/*  417 */     int month = cal.get(2) + 1;
/*  418 */     int day = cal.get(5);
/*  419 */     int monthDay = month * 32 + day;
/*      */     
/*  421 */     return monthDay;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getTime(Calendar cal) {
/*  433 */     int time = cal.get(11);
/*  434 */     time *= 64;
/*  435 */     time += cal.get(12);
/*  436 */     time *= 64;
/*  437 */     time += cal.get(13);
/*  438 */     return time;
/*      */   }
/*      */   
/*      */   public Calendar toCalendar() {
/*  442 */     if (this.cal == null) {
/*  443 */       this.cal = Calendar.getInstance();
/*  444 */       this.cal.clear();
/*      */       
/*  446 */       switch (this.type) {
/*      */         case gYear:
/*  448 */           this.cal.set(1, this.year);
/*      */           break;
/*      */         case gYearMonth:
/*      */         case date:
/*  452 */           this.cal.set(1, this.year);
/*  453 */           setMonthDay(this.monthDay, this.cal);
/*      */           break;
/*      */         
/*      */         case dateTime:
/*  457 */           this.cal.set(1, this.year);
/*  458 */           setMonthDay(this.monthDay, this.cal);
/*  459 */           setTime(this.time, this.cal);
/*  460 */           this.cal.set(14, this.fractionalSecs);
/*      */           break;
/*      */         case gMonth:
/*      */         case gMonthDay:
/*      */         case gDay:
/*  465 */           setMonthDay(this.monthDay, this.cal);
/*      */           break;
/*      */         case time:
/*  468 */           setTime(this.time, this.cal);
/*  469 */           this.cal.set(14, this.fractionalSecs);
/*      */           break;
/*      */         default:
/*  472 */           throw new UnsupportedOperationException();
/*      */       } 
/*  474 */       setTimezone(this.cal, this.timezone);
/*      */     } 
/*  476 */     return this.cal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void setMonthDay(int monthDay, Calendar cal) {
/*  490 */     int month = monthDay / 32;
/*  491 */     cal.set(2, month - 1);
/*  492 */     int day = monthDay - month * 32;
/*  493 */     cal.set(5, day);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void setTime(int time, Calendar cal) {
/*  507 */     int hour = time / 4096;
/*  508 */     time -= hour * 4096;
/*  509 */     int minute = time / 64;
/*  510 */     time -= minute * 64;
/*  511 */     cal.set(11, hour);
/*  512 */     cal.set(12, minute);
/*  513 */     cal.set(13, time);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static int getTimeZoneInMinutesOffset(Calendar cal) {
/*  524 */     return cal.getTimeZone().getRawOffset() / 60000 + 896;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static int getTimeZoneInMillisecs(int minutes) {
/*  536 */     return minutes * 60000;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCharactersLength() {
/*  558 */     if (this.slen == -1) {
/*  559 */       switch (this.type) {
/*      */         case gYear:
/*  561 */           this.slen = (this.year < 0) ? 5 : 4;
/*      */           break;
/*      */         case gYearMonth:
/*  564 */           this.slen = ((this.year < 0) ? 5 : 4) + 3;
/*      */           break;
/*      */         case date:
/*  567 */           this.slen = ((this.year < 0) ? 5 : 4) + 6;
/*      */           break;
/*      */         
/*      */         case dateTime:
/*  571 */           this
/*  572 */             .sizeFractionalSecs = (this.fractionalSecs == 0) ? 0 : (MethodsBag.getStringSize(this.fractionalSecs) + 1);
/*  573 */           this.slen = ((this.year < 0) ? 5 : 4) + 6 + 9 + this.sizeFractionalSecs;
/*      */           break;
/*      */         
/*      */         case gMonth:
/*  577 */           this.slen = 4;
/*      */           break;
/*      */         
/*      */         case gMonthDay:
/*  581 */           this.slen = 7;
/*      */           break;
/*      */         
/*      */         case gDay:
/*  585 */           this.slen = 5;
/*      */           break;
/*      */         
/*      */         case time:
/*  589 */           this
/*  590 */             .sizeFractionalSecs = (this.fractionalSecs == 0) ? 0 : (MethodsBag.getStringSize(this.fractionalSecs) + 1);
/*  591 */           this.slen = 8 + this.sizeFractionalSecs;
/*      */           break;
/*      */         default:
/*  594 */           throw new UnsupportedOperationException();
/*      */       } 
/*      */ 
/*      */       
/*  598 */       if (this.presenceTimezone) {
/*  599 */         this.slen += (this.timezone == 0) ? 1 : 6;
/*      */       }
/*      */     } 
/*      */     
/*  603 */     return this.slen;
/*      */   }
/*      */   
/*      */   public void getCharacters(char[] cbuffer, int offset) {
/*  607 */     switch (this.type) {
/*      */       case gYear:
/*  609 */         offset = appendYear(cbuffer, offset, this.year);
/*      */         break;
/*      */       case gYearMonth:
/*  612 */         offset = appendYear(cbuffer, offset, this.year);
/*  613 */         offset = appendMonth(cbuffer, offset, this.monthDay);
/*      */         break;
/*      */       case date:
/*  616 */         offset = appendYear(cbuffer, offset, this.year);
/*  617 */         offset = appendMonthDay(cbuffer, offset, this.monthDay);
/*      */         break;
/*      */       
/*      */       case dateTime:
/*  621 */         offset = appendYear(cbuffer, offset, this.year);
/*  622 */         offset = appendMonthDay(cbuffer, offset, this.monthDay);
/*  623 */         cbuffer[offset++] = 'T';
/*  624 */         offset = appendTime(cbuffer, offset, this.time);
/*  625 */         assert this.sizeFractionalSecs != -1;
/*  626 */         offset = appendFractionalSeconds(cbuffer, offset, this.fractionalSecs, this.sizeFractionalSecs - 1);
/*      */         break;
/*      */ 
/*      */       
/*      */       case gMonth:
/*  631 */         cbuffer[offset++] = '-';
/*  632 */         offset = appendMonth(cbuffer, offset, this.monthDay);
/*      */         break;
/*      */       
/*      */       case gMonthDay:
/*  636 */         cbuffer[offset++] = '-';
/*  637 */         offset = appendMonthDay(cbuffer, offset, this.monthDay);
/*      */         break;
/*      */       
/*      */       case gDay:
/*  641 */         cbuffer[offset++] = '-';
/*  642 */         cbuffer[offset++] = '-';
/*  643 */         cbuffer[offset++] = '-';
/*  644 */         offset = appendDay(cbuffer, offset, this.monthDay);
/*      */         break;
/*      */       
/*      */       case time:
/*  648 */         offset = appendTime(cbuffer, offset, this.time);
/*  649 */         assert this.sizeFractionalSecs != -1;
/*  650 */         offset = appendFractionalSeconds(cbuffer, offset, this.fractionalSecs, this.sizeFractionalSecs - 1);
/*      */         break;
/*      */       
/*      */       default:
/*  654 */         throw new UnsupportedOperationException();
/*      */     } 
/*      */     
/*  657 */     if (this.presenceTimezone) {
/*  658 */       appendTimezone(cbuffer, offset, this.timezone);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void setTimezone(Calendar cal, int tz) {
/*  665 */     TimeZone tzO = TimeZone.getTimeZone("GMT+00:00");
/*  666 */     tzO.setRawOffset(tz);
/*  667 */     cal.setTimeZone(tzO);
/*      */   }
/*      */   
/*      */   private static int appendTimezone(char[] ca, int index, int tz) {
/*  671 */     if (tz == 0) {
/*      */       
/*  673 */       ca[index++] = 'Z';
/*      */     } else {
/*      */       
/*  676 */       if (tz < 0) {
/*  677 */         ca[index++] = '-';
/*  678 */         tz *= -1;
/*      */       } else {
/*  680 */         ca[index++] = '+';
/*      */       } 
/*      */       
/*  683 */       int hours = tz / 64;
/*  684 */       index = appendTwoDigits(ca, index, hours);
/*      */       
/*  686 */       ca[index++] = ':';
/*      */       
/*  688 */       int minutes = tz - hours * 64;
/*  689 */       index = appendTwoDigits(ca, index, minutes);
/*      */     } 
/*  691 */     return index;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int appendFractionalSeconds(char[] ca, int index, int fracSecs, int sLen) {
/*  696 */     if (fracSecs > 0) {
/*      */       
/*  698 */       ca[index++] = '.';
/*      */       
/*  700 */       index += MethodsBag.itosReverse(fracSecs, index, ca);
/*      */     } 
/*      */     
/*  703 */     return index;
/*      */   }
/*      */   
/*      */   private static int appendTwoDigits(char[] ca, int index, int i) {
/*  707 */     if (i > 9) {
/*  708 */       index += 2;
/*      */     } else {
/*      */       
/*  711 */       ca[index++] = '0';
/*  712 */       index++;
/*      */     } 
/*  714 */     MethodsBag.itos(i, index, ca);
/*      */     
/*  716 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendYear(char[] ca, int index, int year) {
/*  722 */     if (year < 0) {
/*  723 */       ca[index] = '-';
/*  724 */       index++;
/*  725 */       year = -year;
/*      */     } 
/*      */ 
/*      */     
/*  729 */     if (year > 999) {
/*  730 */       index += 4;
/*  731 */     } else if (year > 99) {
/*  732 */       ca[index++] = '0';
/*  733 */       index += 3;
/*  734 */     } else if (year > 9) {
/*  735 */       ca[index++] = '0';
/*  736 */       ca[index++] = '0';
/*  737 */       index += 2;
/*      */     } else {
/*      */       
/*  740 */       ca[index++] = '0';
/*  741 */       ca[index++] = '0';
/*  742 */       ca[index++] = '0';
/*  743 */       index++;
/*      */     } 
/*      */     
/*  746 */     MethodsBag.itos(year, index, ca);
/*      */     
/*  748 */     return index;
/*      */   }
/*      */   
/*      */   private static int appendMonth(char[] ca, int index, int monthDay) {
/*  752 */     int month = monthDay / 32;
/*  753 */     assert monthDay - month * 32 == 0;
/*      */ 
/*      */     
/*  756 */     ca[index++] = '-';
/*      */     
/*  758 */     return appendTwoDigits(ca, index, month);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendMonthDay(char[] ca, int index, int monthDay) {
/*  765 */     int month = monthDay / 32;
/*  766 */     int day = monthDay - month * 32;
/*      */ 
/*      */     
/*  769 */     ca[index++] = '-';
/*  770 */     index = appendTwoDigits(ca, index, month);
/*  771 */     ca[index++] = '-';
/*  772 */     return appendTwoDigits(ca, index, day);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendDay(char[] ca, int index, int day) {
/*  778 */     assert day < 31;
/*  779 */     return appendTwoDigits(ca, index, day);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendTime(char[] ca, int index, int time) {
/*  788 */     int hour = time / 4096;
/*  789 */     time -= hour * 4096;
/*  790 */     int minutes = time / 64;
/*  791 */     int seconds = time - minutes * 64;
/*      */ 
/*      */     
/*  794 */     index = appendTwoDigits(ca, index, hour);
/*  795 */     ca[index++] = ':';
/*  796 */     index = appendTwoDigits(ca, index, minutes);
/*  797 */     ca[index++] = ':';
/*  798 */     index = appendTwoDigits(ca, index, seconds);
/*      */     
/*  800 */     return index;
/*      */   }
/*      */   
/*      */   protected final boolean _equals(DateTimeValue o) {
/*  804 */     boolean ret = true;
/*  805 */     if (this.type == o.type && this.year == o.year && this.monthDay == o.monthDay && this.time == o.time) {
/*      */       
/*  807 */       if (this.presenceFractionalSecs == o.presenceFractionalSecs && 
/*  808 */         this.fractionalSecs != o.fractionalSecs) {
/*  809 */         ret = false;
/*      */       }
/*      */       
/*  812 */       if (ret && this.presenceTimezone == o.presenceTimezone && 
/*  813 */         this.timezone != o.timezone) {
/*  814 */         ret = false;
/*      */       }
/*      */     } else {
/*      */       
/*  818 */       ret = false;
/*      */     } 
/*      */     
/*  821 */     if (ret)
/*      */     {
/*  823 */       return ret;
/*      */     }
/*      */     
/*  826 */     if (!this.normalized || !o.normalized) {
/*      */ 
/*      */ 
/*      */       
/*  830 */       DateTimeValue tn = normalize();
/*  831 */       DateTimeValue on = o.normalize();
/*  832 */       ret = tn._equals(on);
/*      */     } 
/*      */ 
/*      */     
/*  836 */     return ret;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/*  841 */     if (o == null) {
/*  842 */       return false;
/*      */     }
/*  844 */     if (o instanceof DateTimeValue) {
/*  845 */       return _equals((DateTimeValue)o);
/*      */     }
/*  847 */     DateTimeValue dt = parse(o.toString(), this.type);
/*  848 */     return (dt == null) ? false : _equals(dt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  854 */     return this.type.hashCode() ^ this.year ^ this.monthDay ^ this.time ^ (
/*  855 */       this.presenceFractionalSecs ? 1 : 0) ^ this.fractionalSecs ^ (
/*  856 */       this.presenceTimezone ? 1 : 0) ^ this.timezone;
/*      */   }
/*      */   
/*      */   public DateTimeValue normalize() {
/*  860 */     if (this.normalized) {
/*  861 */       return this;
/*      */     }
/*  863 */     if (this.normalizedDateTimeValue == null) {
/*  864 */       this.normalizedDateTimeValue = doNormalize();
/*      */     }
/*      */     
/*  867 */     return this.normalizedDateTimeValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DateTimeValue doNormalize() {
/*  874 */     int tempDays, year = this.year;
/*  875 */     int month = this.monthDay / 32;
/*  876 */     int day = this.monthDay - month * 32;
/*      */     
/*  878 */     int hour = this.time / 4096;
/*  879 */     int time = this.time;
/*  880 */     time -= hour * 4096;
/*  881 */     int minutes = time / 64;
/*  882 */     int seconds = time - minutes * 64;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  896 */     int tzMinutes = 0;
/*  897 */     int tzHours = 0;
/*  898 */     if (this.presenceTimezone && this.timezone != 0) {
/*  899 */       int tz = this.timezone;
/*      */       
/*  901 */       tzHours = tz / 64;
/*      */       
/*  903 */       tzMinutes = tz - tzHours * 64;
/*      */     } 
/*      */     
/*  906 */     int negate = -1;
/*      */ 
/*      */ 
/*      */     
/*  910 */     int temp = minutes + -1 * tzMinutes;
/*  911 */     minutes = modulo(temp, 60);
/*  912 */     int carry = fQuotient(temp, 60);
/*      */ 
/*      */ 
/*      */     
/*  916 */     temp = hour + -1 * tzHours + carry;
/*  917 */     hour = modulo(temp, 24);
/*  918 */     carry = fQuotient(temp, 24);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  923 */     if (day > maximumDayInMonthFor(year, month)) {
/*      */       
/*  925 */       tempDays = maximumDayInMonthFor(year, month);
/*      */     }
/*  927 */     else if (day < 1) {
/*      */       
/*  929 */       tempDays = 1;
/*      */     }
/*      */     else {
/*      */       
/*  933 */       tempDays = day;
/*      */     } 
/*      */     
/*  936 */     day = tempDays + carry;
/*      */     
/*      */     while (true) {
/*  939 */       if (day < 1) {
/*  940 */         day += maximumDayInMonthFor(year, month - 1);
/*  941 */         carry = -1;
/*  942 */       } else if (day > maximumDayInMonthFor(year, month)) {
/*  943 */         day -= maximumDayInMonthFor(year, month);
/*  944 */         carry = 1;
/*      */       } else {
/*      */         break;
/*      */       } 
/*  948 */       temp = month + carry;
/*  949 */       month = modulo(temp, 1, 13);
/*  950 */       year += fQuotient(temp, 1, 13);
/*      */     } 
/*      */ 
/*      */     
/*  954 */     int monthDay = month * 32 + day;
/*  955 */     time = (hour * 64 + minutes) * 64 + seconds;
/*      */ 
/*      */ 
/*      */     
/*  959 */     boolean presenceTimezone = this.presenceTimezone;
/*  960 */     int timezone = 0;
/*      */     
/*  962 */     return new DateTimeValue(this.type, year, monthDay, time, this.fractionalSecs, presenceTimezone, timezone, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int fQuotient(int a, int b) {
/*  972 */     return (int)Math.floor((a / b));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int fQuotient(int temp, int low, int high) {
/*  981 */     return fQuotient(temp - low, high - low);
/*      */   }
/*      */ 
/*      */   
/*      */   protected int modulo(int a, int b) {
/*  986 */     return a - fQuotient(a, b) * b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int modulo(int a, int low, int high) {
/*  995 */     return modulo(a - low, high - low) + low;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int maximumDayInMonthFor(int year, int month) {
/* 1009 */     if (month == 1 || month == 3 || month == 7 || month == 8 || month == 10 || month == 12)
/*      */     {
/* 1011 */       return 31; } 
/* 1012 */     if (month == 4 || month == 6 || month == 9 || month == 11)
/* 1013 */       return 30; 
/* 1014 */     if (month == 2 && (
/* 1015 */       modulo(year, 400) == 0 || (modulo(year, 100) != 0 && 
/* 1016 */       modulo(year, 4) == 0))) {
/* 1017 */       return 29;
/*      */     }
/* 1019 */     return 28;
/*      */   }
/*      */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\DateTimeValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */