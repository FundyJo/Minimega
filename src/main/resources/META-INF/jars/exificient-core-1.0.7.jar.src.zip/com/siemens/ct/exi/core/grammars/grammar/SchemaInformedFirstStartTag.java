/*     */ package com.siemens.ct.exi.core.grammars.grammar;
/*     */ 
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaInformedFirstStartTag
/*     */   extends SchemaInformedStartTag
/*     */   implements SchemaInformedFirstStartTagGrammar, Cloneable
/*     */ {
/*     */   private static final boolean USE_RUNTIME_EMPTY_TYPE = true;
/*     */   protected boolean isTypeCastable = false;
/*     */   protected boolean isNillable = false;
/*     */   protected SchemaInformedFirstStartTagGrammar typeEmpty;
/*  47 */   protected QName typeName = null;
/*     */ 
/*     */   
/*     */   public SchemaInformedFirstStartTag() {}
/*     */ 
/*     */   
/*     */   public SchemaInformedFirstStartTag(SchemaInformedGrammar elementContent2) {
/*  54 */     super(elementContent2);
/*     */   }
/*     */   
/*     */   public GrammarType getGrammarType() {
/*  58 */     return GrammarType.SCHEMA_INFORMED_FIRST_START_TAG_CONTENT;
/*     */   }
/*     */   
/*     */   public SchemaInformedFirstStartTag(SchemaInformedStartTagGrammar startTag) {
/*  62 */     this((SchemaInformedGrammar)startTag.getElementContentGrammar());
/*     */ 
/*     */     
/*  65 */     for (int i = 0; i < startTag.getNumberOfEvents(); i++) {
/*  66 */       Production ei = startTag.getProduction(i);
/*     */       
/*  68 */       Grammar next = ei.getNextGrammar();
/*  69 */       if (next == startTag) {
/*  70 */         next = this;
/*     */       }
/*  72 */       addProduction(ei.getEvent(), next);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setTypeCastable(boolean isTypeCastable) {
/*  77 */     this.isTypeCastable = isTypeCastable;
/*     */   }
/*     */   
/*     */   public boolean isTypeCastable() {
/*  81 */     return this.isTypeCastable;
/*     */   }
/*     */   
/*     */   public void setNillable(boolean isNillable) {
/*  85 */     this.isNillable = isNillable;
/*     */   }
/*     */   
/*     */   public boolean isNillable() {
/*  89 */     return this.isNillable;
/*     */   }
/*     */   
/*     */   public void setTypeEmpty(SchemaInformedFirstStartTagGrammar typeEmpty) {
/*  93 */     this.typeEmpty = typeEmpty;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaInformedFirstStartTagGrammar getTypeEmpty() {
/*  98 */     return (SchemaInformedFirstStartTagGrammar)getTypeEmptyInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 107 */     if (this == obj) {
/* 108 */       return true;
/*     */     }
/* 110 */     if (obj instanceof SchemaInformedFirstStartTag) {
/* 111 */       SchemaInformedFirstStartTag other = (SchemaInformedFirstStartTag)obj;
/* 112 */       if (this.isTypeCastable == other.isTypeCastable && this.isNillable == other.isNillable && super
/*     */         
/* 114 */         .equals(other)) {
/* 115 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     return (this.isTypeCastable ? 1 : 0) ^ (this.isNillable ? 1 : 0) ^ super
/* 125 */       .hashCode();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 129 */     String s = "First";
/*     */     
/* 131 */     if (this.isTypeCastable) {
/* 132 */       s = s + "(xsi:type)";
/*     */     }
/* 134 */     if (this.isNillable) {
/* 135 */       s = s + "(xsi:nil)";
/*     */     }
/*     */     
/* 138 */     return s + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\SchemaInformedFirstStartTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */