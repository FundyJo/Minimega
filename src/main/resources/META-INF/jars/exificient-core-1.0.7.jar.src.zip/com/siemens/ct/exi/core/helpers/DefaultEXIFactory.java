/*     */ package com.siemens.ct.exi.core.helpers;
/*     */ 
/*     */ import com.siemens.ct.exi.core.CodingMode;
/*     */ import com.siemens.ct.exi.core.DecodingOptions;
/*     */ import com.siemens.ct.exi.core.EXIBodyDecoder;
/*     */ import com.siemens.ct.exi.core.EXIBodyEncoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EXIStreamDecoder;
/*     */ import com.siemens.ct.exi.core.EXIStreamEncoder;
/*     */ import com.siemens.ct.exi.core.EncodingOptions;
/*     */ import com.siemens.ct.exi.core.FidelityOptions;
/*     */ import com.siemens.ct.exi.core.SchemaIdResolver;
/*     */ import com.siemens.ct.exi.core.SelfContainedHandler;
/*     */ import com.siemens.ct.exi.core.coder.EXIBodyDecoderInOrder;
/*     */ import com.siemens.ct.exi.core.coder.EXIBodyDecoderInOrderSC;
/*     */ import com.siemens.ct.exi.core.coder.EXIBodyDecoderReordered;
/*     */ import com.siemens.ct.exi.core.coder.EXIBodyEncoderInOrder;
/*     */ import com.siemens.ct.exi.core.coder.EXIBodyEncoderInOrderSC;
/*     */ import com.siemens.ct.exi.core.coder.EXIBodyEncoderReordered;
/*     */ import com.siemens.ct.exi.core.coder.EXIStreamDecoderImpl;
/*     */ import com.siemens.ct.exi.core.coder.EXIStreamEncoderImpl;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.strings.BoundedStringDecoderImpl;
/*     */ import com.siemens.ct.exi.core.datatype.strings.BoundedStringEncoderImpl;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringDecoder;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringDecoderImpl;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringEncoder;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringEncoderImpl;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.exceptions.UnsupportedOption;
/*     */ import com.siemens.ct.exi.core.grammars.Grammars;
/*     */ import com.siemens.ct.exi.core.grammars.SchemaInformedGrammars;
/*     */ import com.siemens.ct.exi.core.grammars.SchemaLessGrammars;
/*     */ import com.siemens.ct.exi.core.types.LexicalTypeDecoder;
/*     */ import com.siemens.ct.exi.core.types.LexicalTypeEncoder;
/*     */ import com.siemens.ct.exi.core.types.StringTypeDecoder;
/*     */ import com.siemens.ct.exi.core.types.StringTypeEncoder;
/*     */ import com.siemens.ct.exi.core.types.TypeDecoder;
/*     */ import com.siemens.ct.exi.core.types.TypeEncoder;
/*     */ import com.siemens.ct.exi.core.types.TypedTypeDecoder;
/*     */ import com.siemens.ct.exi.core.types.TypedTypeEncoder;
/*     */ import com.siemens.ct.exi.core.util.sort.QNameSort;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultEXIFactory
/*     */   implements EXIFactory
/*     */ {
/*     */   protected Grammars grammar;
/*     */   protected boolean isFragment;
/*     */   protected CodingMode codingMode;
/*     */   protected FidelityOptions fidelityOptions;
/*     */   protected EncodingOptions encodingOptions;
/*     */   protected DecodingOptions decodingOptions;
/*     */   protected SchemaIdResolver schemaIdResolver;
/*     */   protected QName[] dtrMapTypes;
/*     */   protected QName[] dtrMapRepresentations;
/*     */   protected Map<QName, Datatype> dtrMapRepresentationsDatatype;
/*     */   protected QName[] scElements;
/*     */   protected SelfContainedHandler scHandler;
/* 106 */   protected int blockSize = 1000000;
/*     */ 
/*     */   
/* 109 */   protected int valueMaxLength = -1;
/*     */ 
/*     */   
/* 112 */   protected int valuePartitionCapacity = -1;
/*     */ 
/*     */   
/*     */   protected boolean localValuePartitions = true;
/*     */ 
/*     */   
/* 118 */   protected int maximumNumberOfBuiltInElementGrammars = -1;
/* 119 */   protected int maximumNumberOfBuiltInProductions = -1;
/*     */ 
/*     */   
/*     */   protected boolean grammarLearningDisabled = false;
/*     */ 
/*     */   
/*     */   protected List<String> sharedStrings;
/*     */   
/*     */   protected boolean isUsingNonEvolvingGrammrs;
/*     */   
/* 129 */   protected static final QNameSort qnameSort = new QNameSort();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void setDefaultValues(EXIFactory factory) {
/* 135 */     factory.setFidelityOptions(FidelityOptions.createDefault());
/* 136 */     factory.setEncodingOptions(EncodingOptions.createDefault());
/* 137 */     factory.setDecodingOptions(DecodingOptions.createDefault());
/* 138 */     factory.setCodingMode(CodingMode.BIT_PACKED);
/* 139 */     factory.setFragment(false);
/* 140 */     factory.setGrammars((Grammars)new SchemaLessGrammars());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static EXIFactory newInstance() {
/* 146 */     EXIFactory factory = new DefaultEXIFactory();
/*     */ 
/*     */     
/* 149 */     setDefaultValues(factory);
/*     */     
/* 151 */     return factory;
/*     */   }
/*     */   
/*     */   public void setFidelityOptions(FidelityOptions fidelityOptions) {
/* 155 */     this.fidelityOptions = fidelityOptions;
/*     */   }
/*     */   
/*     */   public FidelityOptions getFidelityOptions() {
/* 159 */     return this.fidelityOptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncodingOptions(EncodingOptions encodingOptions) {
/* 185 */     this.encodingOptions = encodingOptions;
/*     */   }
/*     */   
/*     */   public EncodingOptions getEncodingOptions() {
/* 189 */     return this.encodingOptions;
/*     */   }
/*     */   
/*     */   public void setDecodingOptions(DecodingOptions decodingOptions) {
/* 193 */     this.decodingOptions = decodingOptions;
/*     */   }
/*     */   
/*     */   public DecodingOptions getDecodingOptions() {
/* 197 */     return this.decodingOptions;
/*     */   }
/*     */   
/*     */   public void setSchemaIdResolver(SchemaIdResolver schemaIdResolver) {
/* 201 */     this.schemaIdResolver = schemaIdResolver;
/*     */   }
/*     */   
/*     */   public SchemaIdResolver getSchemaIdResolver() {
/* 205 */     return this.schemaIdResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDatatypeRepresentationMap(QName[] dtrMapTypes, QName[] dtrMapRepresentations) {
/* 210 */     if (dtrMapTypes == null || dtrMapRepresentations == null || dtrMapTypes.length != dtrMapRepresentations.length || dtrMapTypes.length == 0) {
/*     */ 
/*     */ 
/*     */       
/* 214 */       this.dtrMapTypes = null;
/* 215 */       this.dtrMapRepresentations = null;
/*     */     } else {
/* 217 */       this.dtrMapTypes = dtrMapTypes;
/* 218 */       this.dtrMapRepresentations = dtrMapRepresentations;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Datatype registerDatatypeRepresentationMapDatatype(QName dtrMapRepresentation, Datatype datatype) {
/* 224 */     if (this.dtrMapRepresentationsDatatype == null) {
/* 225 */       this.dtrMapRepresentationsDatatype = new HashMap<>();
/*     */     }
/* 227 */     return this.dtrMapRepresentationsDatatype.put(dtrMapRepresentation, datatype);
/*     */   }
/*     */ 
/*     */   
/*     */   public QName[] getDatatypeRepresentationMapTypes() {
/* 232 */     return this.dtrMapTypes;
/*     */   }
/*     */   
/*     */   public QName[] getDatatypeRepresentationMapRepresentations() {
/* 236 */     return this.dtrMapRepresentations;
/*     */   }
/*     */   
/*     */   public void setSelfContainedElements(QName[] scElements) {
/* 240 */     setSelfContainedElements(scElements, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSelfContainedElements(QName[] scElements, SelfContainedHandler scHandler) {
/* 245 */     this.scElements = scElements;
/* 246 */     this.scHandler = scHandler;
/*     */   }
/*     */   
/*     */   public boolean isSelfContainedElement(QName element) {
/* 250 */     assert element != null;
/* 251 */     String elementNS = element.getNamespaceURI();
/* 252 */     String elementLP = element.getLocalPart();
/* 253 */     if (this.scElements != null && this.scElements.length > 0) {
/* 254 */       for (int i = 0; i < this.scElements.length; i++) {
/* 255 */         QName qname = this.scElements[i];
/* 256 */         assert qname != null;
/* 257 */         if (elementNS.matches(qname.getNamespaceURI()) && elementLP
/* 258 */           .matches(qname.getLocalPart())) {
/* 259 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 266 */     return false;
/*     */   }
/*     */   
/*     */   public SelfContainedHandler getSelfContainedHandler() {
/* 270 */     return this.scHandler;
/*     */   }
/*     */   
/*     */   public void setGrammars(Grammars grammar) {
/* 274 */     assert grammar != null;
/*     */     
/* 276 */     this.grammar = grammar;
/*     */   }
/*     */   
/*     */   public Grammars getGrammars() {
/* 280 */     return this.grammar;
/*     */   }
/*     */   
/*     */   protected boolean isSchemaInformed() {
/* 284 */     return this.grammar.isSchemaInformed();
/*     */   }
/*     */   
/*     */   public void setFragment(boolean isFragment) {
/* 288 */     this.isFragment = isFragment;
/*     */   }
/*     */   
/*     */   public boolean isFragment() {
/* 292 */     return this.isFragment;
/*     */   }
/*     */   
/*     */   public void setCodingMode(CodingMode codingMode) {
/* 296 */     this.codingMode = codingMode;
/*     */   }
/*     */   
/*     */   public CodingMode getCodingMode() {
/* 300 */     return this.codingMode;
/*     */   }
/*     */   
/*     */   public void setBlockSize(int blockSize) {
/* 304 */     if (blockSize < 0) {
/* 305 */       throw new RuntimeException("EXI's blockSize has the be a positive number!");
/*     */     }
/*     */     
/* 308 */     this.blockSize = blockSize;
/*     */   }
/*     */   
/*     */   public int getBlockSize() {
/* 312 */     return this.blockSize;
/*     */   }
/*     */   
/*     */   public void setValueMaxLength(int valueMaxLength) {
/* 316 */     this.valueMaxLength = valueMaxLength;
/*     */   }
/*     */   
/*     */   public int getValueMaxLength() {
/* 320 */     return this.valueMaxLength;
/*     */   }
/*     */   
/*     */   public void setValuePartitionCapacity(int valuePartitionCapacity) {
/* 324 */     this.valuePartitionCapacity = valuePartitionCapacity;
/*     */   }
/*     */   
/*     */   public int getValuePartitionCapacity() {
/* 328 */     return this.valuePartitionCapacity;
/*     */   }
/*     */   
/*     */   public void setLocalValuePartitions(boolean useLocalValuePartitions) {
/* 332 */     this.localValuePartitions = useLocalValuePartitions;
/*     */   }
/*     */   
/*     */   public boolean isLocalValuePartitions() {
/* 336 */     return this.localValuePartitions;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaximumNumberOfBuiltInElementGrammars(int maximumNumberOfBuiltInElementGrammars) {
/* 341 */     if (maximumNumberOfBuiltInElementGrammars >= 0) {
/* 342 */       this.maximumNumberOfBuiltInElementGrammars = maximumNumberOfBuiltInElementGrammars;
/*     */     } else {
/* 344 */       this.maximumNumberOfBuiltInElementGrammars = -1;
/*     */     } 
/* 346 */     checkGrammarLearningDisabled();
/*     */   }
/*     */   
/*     */   public int getMaximumNumberOfBuiltInElementGrammars() {
/* 350 */     return this.maximumNumberOfBuiltInElementGrammars;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaximumNumberOfBuiltInProductions(int maximumNumberOfBuiltInProductions) {
/* 355 */     if (maximumNumberOfBuiltInProductions >= 0) {
/* 356 */       this.maximumNumberOfBuiltInProductions = maximumNumberOfBuiltInProductions;
/*     */     } else {
/* 358 */       this.maximumNumberOfBuiltInProductions = -1;
/*     */     } 
/* 360 */     checkGrammarLearningDisabled();
/*     */   }
/*     */   
/*     */   public int getMaximumNumberOfBuiltInProductions() {
/* 364 */     return this.maximumNumberOfBuiltInProductions;
/*     */   }
/*     */   
/*     */   private void checkGrammarLearningDisabled() {
/* 368 */     if (this.maximumNumberOfBuiltInElementGrammars >= 0 || this.maximumNumberOfBuiltInProductions >= 0) {
/*     */       
/* 370 */       this.grammarLearningDisabled = true;
/*     */     } else {
/* 372 */       this.grammarLearningDisabled = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isGrammarLearningDisabled() {
/* 377 */     return this.grammarLearningDisabled;
/*     */   }
/*     */   
/*     */   public void setSharedStrings(List<String> sharedStrings) {
/* 381 */     this.sharedStrings = sharedStrings;
/*     */   }
/*     */   
/*     */   public List<String> getSharedStrings() {
/* 385 */     return this.sharedStrings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUsingNonEvolvingGrammars(boolean isNonEvolving) {
/* 390 */     this.isUsingNonEvolvingGrammrs = isNonEvolving;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUsingNonEvolvingGrammars() {
/* 395 */     return this.isUsingNonEvolvingGrammrs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doSanityCheck() throws EXIException {
/* 402 */     if (this.fidelityOptions.isFidelityEnabled("SELF_CONTAINED") && (this.codingMode == CodingMode.COMPRESSION || this.codingMode == CodingMode.PRE_COMPRESSION))
/*     */     {
/* 404 */       throw new EXIException("(Pre-)Compression and selfContained elements cannot work together");
/*     */     }
/*     */ 
/*     */     
/* 408 */     if (!this.grammar.isSchemaInformed()) {
/* 409 */       this.maximumNumberOfBuiltInElementGrammars = -1;
/* 410 */       this.maximumNumberOfBuiltInProductions = -1;
/* 411 */       this.grammarLearningDisabled = false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 418 */     if (getEncodingOptions().isOptionEnabled("http://www.w3.org/TR/exi-c14n"))
/*     */     {
/* 420 */       updateFactoryAccordingCanonicalEXI();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EXIBodyEncoder createEXIBodyEncoder() throws EXIException {
/* 481 */     doSanityCheck();
/*     */     
/* 483 */     if (this.codingMode == CodingMode.COMPRESSION || this.codingMode == CodingMode.PRE_COMPRESSION)
/*     */     {
/* 485 */       return (EXIBodyEncoder)new EXIBodyEncoderReordered(this);
/*     */     }
/* 487 */     if (this.fidelityOptions.isFidelityEnabled("SELF_CONTAINED")) {
/* 488 */       return (EXIBodyEncoder)new EXIBodyEncoderInOrderSC(this);
/*     */     }
/* 490 */     return (EXIBodyEncoder)new EXIBodyEncoderInOrder(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EXIStreamEncoder createEXIStreamEncoder() throws EXIException {
/* 496 */     doSanityCheck();
/*     */     
/* 498 */     return (EXIStreamEncoder)new EXIStreamEncoderImpl(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateFactoryAccordingCanonicalEXI() throws UnsupportedOption {
/* 506 */     getEncodingOptions().unsetOption("INCLUDE_COOKIE");
/*     */ 
/*     */     
/* 509 */     if (getCodingMode() == CodingMode.COMPRESSION) {
/* 510 */       setCodingMode(CodingMode.PRE_COMPRESSION);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 515 */     if (this.dtrMapTypes != null && this.dtrMapTypes.length > 0) {
/* 516 */       bubbleSort(this.dtrMapTypes, this.dtrMapRepresentations);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bubbleSort(QName[] dtrMapTypes, QName[] dtrMapRepresentations) {
/* 521 */     boolean swapped = true;
/* 522 */     int j = 0;
/*     */ 
/*     */     
/* 525 */     while (swapped) {
/* 526 */       swapped = false;
/* 527 */       j++;
/* 528 */       for (int i = 0; i < dtrMapTypes.length - j; i++) {
/*     */         
/* 530 */         if (qnameSort.compare(dtrMapTypes[i], dtrMapTypes[i + 1]) > 0) {
/* 531 */           QName tmpType = dtrMapTypes[i];
/* 532 */           dtrMapTypes[i] = dtrMapTypes[i + 1];
/* 533 */           dtrMapTypes[i + 1] = tmpType;
/* 534 */           QName tmpRep = dtrMapRepresentations[i];
/* 535 */           dtrMapRepresentations[i] = dtrMapRepresentations[i + 1];
/* 536 */           dtrMapRepresentations[i + 1] = tmpRep;
/* 537 */           swapped = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EXIBodyDecoder createEXIBodyDecoder() throws EXIException {
/* 548 */     doSanityCheck();
/*     */     
/* 550 */     if (this.codingMode == CodingMode.COMPRESSION || this.codingMode == CodingMode.PRE_COMPRESSION)
/*     */     {
/* 552 */       return (EXIBodyDecoder)new EXIBodyDecoderReordered(this);
/*     */     }
/* 554 */     if (this.fidelityOptions.isFidelityEnabled("SELF_CONTAINED")) {
/* 555 */       return (EXIBodyDecoder)new EXIBodyDecoderInOrderSC(this);
/*     */     }
/* 557 */     return (EXIBodyDecoder)new EXIBodyDecoderInOrder(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EXIStreamDecoder createEXIStreamDecoder() throws EXIException {
/* 563 */     doSanityCheck();
/*     */     
/* 565 */     return (EXIStreamDecoder)new EXIStreamDecoderImpl(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringEncoder createStringEncoder() {
/*     */     StringEncoderImpl stringEncoderImpl;
/* 571 */     if (getValueMaxLength() != -1 || 
/* 572 */       getValuePartitionCapacity() != -1) {
/*     */ 
/*     */       
/* 575 */       BoundedStringEncoderImpl boundedStringEncoderImpl = new BoundedStringEncoderImpl(isLocalValuePartitions(), getValueMaxLength(), getValuePartitionCapacity());
/*     */     } else {
/* 577 */       stringEncoderImpl = new StringEncoderImpl(isLocalValuePartitions());
/*     */     } 
/*     */     
/* 580 */     return (StringEncoder)stringEncoderImpl;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringDecoder createStringDecoder() {
/*     */     StringDecoderImpl stringDecoderImpl;
/* 586 */     if (getValueMaxLength() != -1 || 
/* 587 */       getValuePartitionCapacity() != -1) {
/*     */ 
/*     */       
/* 590 */       BoundedStringDecoderImpl boundedStringDecoderImpl = new BoundedStringDecoderImpl(isLocalValuePartitions(), getValueMaxLength(), getValuePartitionCapacity());
/*     */     } else {
/* 592 */       stringDecoderImpl = new StringDecoderImpl(isLocalValuePartitions());
/*     */     } 
/*     */     
/* 595 */     return (StringDecoder)stringDecoderImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeEncoder createTypeEncoder() throws EXIException {
/*     */     StringTypeEncoder stringTypeEncoder;
/* 602 */     if (isSchemaInformed()) {
/*     */       
/* 604 */       checkDtrMap();
/*     */       
/* 606 */       if (this.fidelityOptions
/* 607 */         .isFidelityEnabled("PRESERVE_LEXICAL_VALUES")) {
/* 608 */         LexicalTypeEncoder lexicalTypeEncoder = new LexicalTypeEncoder(this.dtrMapTypes, this.dtrMapRepresentations, this.dtrMapRepresentationsDatatype);
/*     */       }
/*     */       else {
/*     */         
/* 612 */         boolean doNormalize = getEncodingOptions().isOptionEnabled("UTC_TIME");
/* 613 */         TypedTypeEncoder typedTypeEncoder = new TypedTypeEncoder(this.dtrMapTypes, this.dtrMapRepresentations, this.dtrMapRepresentationsDatatype, doNormalize);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 620 */       stringTypeEncoder = new StringTypeEncoder();
/*     */     } 
/*     */     
/* 623 */     return (TypeEncoder)stringTypeEncoder;
/*     */   }
/*     */   
/*     */   private void checkDtrMap() throws EXIException {
/* 627 */     if (this.dtrMapTypes == null) {
/* 628 */       this.dtrMapRepresentations = null;
/*     */     }
/* 630 */     else if (this.dtrMapRepresentations == null || this.dtrMapTypes.length != this.dtrMapRepresentations.length) {
/*     */       
/* 632 */       throw new EXIException("Number of arguments for DTR map must match.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDecoder createTypeDecoder() throws EXIException {
/*     */     StringTypeDecoder stringTypeDecoder;
/* 642 */     if (isSchemaInformed()) {
/*     */       
/* 644 */       checkDtrMap();
/*     */       
/* 646 */       if (this.fidelityOptions
/* 647 */         .isFidelityEnabled("PRESERVE_LEXICAL_VALUES")) {
/* 648 */         LexicalTypeDecoder lexicalTypeDecoder = new LexicalTypeDecoder(this.dtrMapTypes, this.dtrMapRepresentations, this.dtrMapRepresentationsDatatype);
/*     */       } else {
/*     */         
/* 651 */         TypedTypeDecoder typedTypeDecoder = new TypedTypeDecoder(this.dtrMapTypes, this.dtrMapRepresentations, this.dtrMapRepresentationsDatatype);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 656 */       stringTypeDecoder = new StringTypeDecoder();
/*     */     } 
/*     */     
/* 659 */     return (TypeDecoder)stringTypeDecoder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EXIFactory clone() {
/*     */     try {
/* 666 */       EXIFactory copy = (EXIFactory)super.clone();
/*     */       
/* 668 */       return copy;
/*     */     }
/* 670 */     catch (CloneNotSupportedException e) {
/* 671 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 677 */     if (o instanceof EXIFactory) {
/* 678 */       EXIFactory other = (EXIFactory)o;
/*     */       
/* 680 */       if (!this.fidelityOptions.equals(other.getFidelityOptions())) {
/* 681 */         return false;
/*     */       }
/*     */       
/* 684 */       if (this.isFragment != other.isFragment()) {
/* 685 */         return false;
/*     */       }
/*     */       
/* 688 */       if (!Arrays.equals((Object[])this.dtrMapTypes, (Object[])other
/* 689 */           .getDatatypeRepresentationMapTypes()) || 
/* 690 */         !Arrays.equals((Object[])this.dtrMapRepresentations, (Object[])other
/* 691 */           .getDatatypeRepresentationMapRepresentations())) {
/* 692 */         return false;
/*     */       }
/*     */       
/* 695 */       if (getCodingMode() != other.getCodingMode()) {
/* 696 */         return false;
/*     */       }
/*     */       
/* 699 */       if (getBlockSize() != other.getBlockSize()) {
/* 700 */         return false;
/*     */       }
/*     */       
/* 703 */       if (getValueMaxLength() != other.getValueMaxLength()) {
/* 704 */         return false;
/*     */       }
/*     */       
/* 707 */       if (getValuePartitionCapacity() != other
/* 708 */         .getValuePartitionCapacity()) {
/* 709 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 713 */       return true;
/*     */     } 
/* 715 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 720 */     return this.fidelityOptions.hashCode() ^ (this.isFragment ? 1 : 0) ^ this.codingMode
/* 721 */       .hashCode() ^ this.blockSize ^ this.valueMaxLength ^ this.valuePartitionCapacity;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 727 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 729 */     if (this.grammar.isSchemaInformed()) {
/* 730 */       SchemaInformedGrammars sig = (SchemaInformedGrammars)this.grammar;
/* 731 */       sb.append("[Schema-Informed=" + sig.getSchemaId() + "]");
/*     */     } else {
/* 733 */       sb.append("[Schema-Less]");
/*     */     } 
/*     */     
/* 736 */     sb.append("[" + this.codingMode + "]");
/*     */     
/* 738 */     sb.append(this.fidelityOptions.toString());
/*     */     
/* 740 */     if (isFragment()) {
/* 741 */       sb.append("[Fragment]");
/*     */     }
/*     */     
/* 744 */     if (this.dtrMapTypes != null && this.dtrMapTypes.length > 0) {
/* 745 */       sb.append("[DTR Types="); int i;
/* 746 */       for (i = 0; i < this.dtrMapTypes.length; i++) {
/* 747 */         QName dtrMapType = this.dtrMapTypes[i];
/* 748 */         sb.append(dtrMapType + " ");
/*     */       } 
/* 750 */       sb.append(", Representation=");
/* 751 */       for (i = 0; i < this.dtrMapRepresentations.length; i++) {
/* 752 */         QName dtrMapRepresentation = this.dtrMapRepresentations[i];
/* 753 */         sb.append(dtrMapRepresentation + " ");
/*     */       } 
/* 755 */       sb.append("]");
/*     */     } 
/*     */     
/* 758 */     if (this.scElements != null && this.scElements.length > 0) {
/* 759 */       sb.append("[SCElements=");
/* 760 */       for (int i = 0; i < this.scElements.length; i++) {
/* 761 */         QName scElement = this.scElements[i];
/* 762 */         sb.append(scElement + " ");
/*     */       } 
/* 764 */       sb.append("]");
/*     */     } 
/*     */     
/* 767 */     if (this.blockSize != 1000000) {
/* 768 */       sb.append("[blockSize=" + this.blockSize + "]");
/*     */     }
/* 770 */     if (this.valueMaxLength != -1) {
/* 771 */       sb.append("[valueMaxLength=" + this.valueMaxLength + "]");
/*     */     }
/* 773 */     if (this.valuePartitionCapacity != -1) {
/* 774 */       sb.append("[valuePartitionCapacity=" + this.valuePartitionCapacity + "]");
/*     */     }
/*     */     
/* 777 */     if (!isLocalValuePartitions()) {
/* 778 */       sb.append("[localValuePartitions=" + isLocalValuePartitions() + "]");
/*     */     }
/*     */     
/* 781 */     if (getMaximumNumberOfBuiltInProductions() >= 0) {
/* 782 */       sb.append("[maximumNumberOfBuiltInProductions=" + 
/* 783 */           getMaximumNumberOfBuiltInProductions() + "]");
/*     */     }
/*     */     
/* 786 */     if (getMaximumNumberOfBuiltInElementGrammars() >= 0) {
/* 787 */       sb.append("[maximumNumberOfEvolvingBuiltInElementGrammars=" + 
/* 788 */           getMaximumNumberOfBuiltInElementGrammars() + "]");
/*     */     }
/*     */     
/* 791 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\helpers\DefaultEXIFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */