/*      */ package com.siemens.ct.exi.core.coder;
/*      */ 
/*      */ import com.siemens.ct.exi.core.EXIFactory;
/*      */ import com.siemens.ct.exi.core.FidelityOptions;
/*      */ import com.siemens.ct.exi.core.context.GrammarContext;
/*      */ import com.siemens.ct.exi.core.context.GrammarUriContext;
/*      */ import com.siemens.ct.exi.core.context.QNameContext;
/*      */ import com.siemens.ct.exi.core.datatype.BinaryBase64Datatype;
/*      */ import com.siemens.ct.exi.core.datatype.BinaryHexDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.BooleanDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.Datatype;
/*      */ import com.siemens.ct.exi.core.datatype.DatetimeDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.DecimalDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.FloatDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.IntegerDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.ListDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.NBitUnsignedIntegerDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.StringDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.UnsignedIntegerDatatype;
/*      */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*      */ import com.siemens.ct.exi.core.exceptions.UnsupportedOption;
/*      */ import com.siemens.ct.exi.core.grammars.Grammars;
/*      */ import com.siemens.ct.exi.core.grammars.event.AttributeGeneric;
/*      */ import com.siemens.ct.exi.core.grammars.event.Characters;
/*      */ import com.siemens.ct.exi.core.grammars.event.CharactersGeneric;
/*      */ import com.siemens.ct.exi.core.grammars.event.EndDocument;
/*      */ import com.siemens.ct.exi.core.grammars.event.EndElement;
/*      */ import com.siemens.ct.exi.core.grammars.event.Event;
/*      */ import com.siemens.ct.exi.core.grammars.event.StartDocument;
/*      */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*      */ import com.siemens.ct.exi.core.grammars.event.StartElementGeneric;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.DocEnd;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.Document;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.Fragment;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedDocContent;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedElement;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTag;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFragmentContent;
/*      */ import com.siemens.ct.exi.core.helpers.DefaultEXIFactory;
/*      */ import com.siemens.ct.exi.core.types.DateTimeType;
/*      */ import com.siemens.ct.exi.core.values.IntegerValue;
/*      */ import javax.xml.namespace.QName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractEXIHeader
/*      */ {
/*      */   public static final String HEADER = "header";
/*      */   public static final String LESSCOMMON = "lesscommon";
/*      */   public static final String UNCOMMON = "uncommon";
/*      */   public static final String ALIGNMENT = "alignment";
/*      */   public static final String BYTE = "byte";
/*      */   public static final String PRE_COMPRESS = "pre-compress";
/*      */   public static final String SELF_CONTAINED = "selfContained";
/*      */   public static final String VALUE_MAX_LENGTH = "valueMaxLength";
/*      */   public static final String VALUE_PARTITION_CAPACITY = "valuePartitionCapacity";
/*      */   public static final String DATATYPE_REPRESENTATION_MAP = "datatypeRepresentationMap";
/*      */   public static final String PRESERVE = "preserve";
/*      */   public static final String DTD = "dtd";
/*      */   public static final String PREFIXES = "prefixes";
/*      */   public static final String LEXICAL_VALUES = "lexicalValues";
/*      */   public static final String COMMENTS = "comments";
/*      */   public static final String PIS = "pis";
/*      */   public static final String BLOCK_SIZE = "blockSize";
/*      */   public static final String COMMON = "common";
/*      */   public static final String COMPRESSION = "compression";
/*      */   public static final String FRAGMENT = "fragment";
/*      */   public static final String SCHEMA_ID = "schemaId";
/*      */   public static final String STRICT = "strict";
/*      */   public static final String PROFILE = "p";
/*      */   public static final int NUMBER_OF_DISTINGUISHING_BITS = 2;
/*      */   public static final int DISTINGUISHING_BITS_VALUE = 2;
/*      */   public static final int NUMBER_OF_FORMAT_VERSION_BITS = 4;
/*      */   public static final int FORMAT_VERSION_CONTINUE_VALUE = 15;
/*      */   protected EXIFactory headerFactory;
/*      */   
/*      */   protected EXIFactory getHeaderFactory() throws EXIException {
/*   82 */     if (this.headerFactory == null) {
/*   83 */       this.headerFactory = DefaultEXIFactory.newInstance();
/*   84 */       this.headerFactory.setGrammars(new EXIOptionsHeaderGrammars());
/*   85 */       this.headerFactory.setFidelityOptions(FidelityOptions.createStrict());
/*      */     } 
/*      */     
/*   88 */     return this.headerFactory;
/*      */   }
/*      */   
/*      */   static class EXIOptionsHeaderGrammars
/*      */     implements Grammars
/*      */   {
/*   94 */     final String ns0 = "";
/*   95 */     final QNameContext[] grammarQNames0 = new QNameContext[0];
/*   96 */     final String[] grammarPrefixes0 = new String[] { "" };
/*   97 */     final GrammarUriContext guc0 = new GrammarUriContext(0, "", this.grammarQNames0, this.grammarPrefixes0);
/*      */ 
/*      */     
/*  100 */     final String ns1 = "http://www.w3.org/XML/1998/namespace";
/*  101 */     final QNameContext qnc0 = new QNameContext(1, 0, new QName("http://www.w3.org/XML/1998/namespace", "base"));
/*  102 */     final QNameContext qnc1 = new QNameContext(1, 1, new QName("http://www.w3.org/XML/1998/namespace", "id"));
/*  103 */     final QNameContext qnc2 = new QNameContext(1, 2, new QName("http://www.w3.org/XML/1998/namespace", "lang"));
/*  104 */     final QNameContext qnc3 = new QNameContext(1, 3, new QName("http://www.w3.org/XML/1998/namespace", "space"));
/*      */     
/*  106 */     final QNameContext[] grammarQNames1 = new QNameContext[] { this.qnc0, this.qnc1, this.qnc2, this.qnc3 };
/*  107 */     final String[] grammarPrefixes1 = new String[] { "xml" };
/*  108 */     final GrammarUriContext guc1 = new GrammarUriContext(1, "http://www.w3.org/XML/1998/namespace", this.grammarQNames1, this.grammarPrefixes1);
/*      */ 
/*      */     
/*  111 */     final String ns2 = "http://www.w3.org/2001/XMLSchema-instance";
/*  112 */     final QNameContext qnc4 = new QNameContext(2, 0, new QName("http://www.w3.org/2001/XMLSchema-instance", "nil"));
/*  113 */     final QNameContext qnc5 = new QNameContext(2, 1, new QName("http://www.w3.org/2001/XMLSchema-instance", "type"));
/*  114 */     final QNameContext[] grammarQNames2 = new QNameContext[] { this.qnc4, this.qnc5 };
/*  115 */     final String[] grammarPrefixes2 = new String[] { "xsi" };
/*  116 */     final GrammarUriContext guc2 = new GrammarUriContext(2, "http://www.w3.org/2001/XMLSchema-instance", this.grammarQNames2, this.grammarPrefixes2);
/*      */ 
/*      */     
/*  119 */     final String ns3 = "http://www.w3.org/2001/XMLSchema";
/*  120 */     final QNameContext qnc6 = new QNameContext(3, 0, new QName("http://www.w3.org/2001/XMLSchema", "ENTITIES"));
/*      */     
/*  122 */     final QNameContext qnc7 = new QNameContext(3, 1, new QName("http://www.w3.org/2001/XMLSchema", "ENTITY"));
/*      */     
/*  124 */     final QNameContext qnc8 = new QNameContext(3, 2, new QName("http://www.w3.org/2001/XMLSchema", "ID"));
/*  125 */     final QNameContext qnc9 = new QNameContext(3, 3, new QName("http://www.w3.org/2001/XMLSchema", "IDREF"));
/*      */     
/*  127 */     final QNameContext qnc10 = new QNameContext(3, 4, new QName("http://www.w3.org/2001/XMLSchema", "IDREFS"));
/*      */     
/*  129 */     final QNameContext qnc11 = new QNameContext(3, 5, new QName("http://www.w3.org/2001/XMLSchema", "NCName"));
/*      */     
/*  131 */     final QNameContext qnc12 = new QNameContext(3, 6, new QName("http://www.w3.org/2001/XMLSchema", "NMTOKEN"));
/*      */     
/*  133 */     final QNameContext qnc13 = new QNameContext(3, 7, new QName("http://www.w3.org/2001/XMLSchema", "NMTOKENS"));
/*      */     
/*  135 */     final QNameContext qnc14 = new QNameContext(3, 8, new QName("http://www.w3.org/2001/XMLSchema", "NOTATION"));
/*      */     
/*  137 */     final QNameContext qnc15 = new QNameContext(3, 9, new QName("http://www.w3.org/2001/XMLSchema", "Name"));
/*      */     
/*  139 */     final QNameContext qnc16 = new QNameContext(3, 10, new QName("http://www.w3.org/2001/XMLSchema", "QName"));
/*      */     
/*  141 */     final QNameContext qnc17 = new QNameContext(3, 11, new QName("http://www.w3.org/2001/XMLSchema", "anySimpleType"));
/*      */     
/*  143 */     final QNameContext qnc18 = new QNameContext(3, 12, new QName("http://www.w3.org/2001/XMLSchema", "anyType"));
/*      */     
/*  145 */     final QNameContext qnc19 = new QNameContext(3, 13, new QName("http://www.w3.org/2001/XMLSchema", "anyURI"));
/*      */     
/*  147 */     final QNameContext qnc20 = new QNameContext(3, 14, new QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
/*      */     
/*  149 */     final QNameContext qnc21 = new QNameContext(3, 15, new QName("http://www.w3.org/2001/XMLSchema", "boolean"));
/*      */     
/*  151 */     final QNameContext qnc22 = new QNameContext(3, 16, new QName("http://www.w3.org/2001/XMLSchema", "byte"));
/*      */     
/*  153 */     final QNameContext qnc23 = new QNameContext(3, 17, new QName("http://www.w3.org/2001/XMLSchema", "date"));
/*      */     
/*  155 */     final QNameContext qnc24 = new QNameContext(3, 18, new QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
/*      */     
/*  157 */     final QNameContext qnc25 = new QNameContext(3, 19, new QName("http://www.w3.org/2001/XMLSchema", "decimal"));
/*      */     
/*  159 */     final QNameContext qnc26 = new QNameContext(3, 20, new QName("http://www.w3.org/2001/XMLSchema", "double"));
/*      */     
/*  161 */     final QNameContext qnc27 = new QNameContext(3, 21, new QName("http://www.w3.org/2001/XMLSchema", "duration"));
/*      */     
/*  163 */     final QNameContext qnc28 = new QNameContext(3, 22, new QName("http://www.w3.org/2001/XMLSchema", "float"));
/*      */     
/*  165 */     final QNameContext qnc29 = new QNameContext(3, 23, new QName("http://www.w3.org/2001/XMLSchema", "gDay"));
/*      */     
/*  167 */     final QNameContext qnc30 = new QNameContext(3, 24, new QName("http://www.w3.org/2001/XMLSchema", "gMonth"));
/*      */     
/*  169 */     final QNameContext qnc31 = new QNameContext(3, 25, new QName("http://www.w3.org/2001/XMLSchema", "gMonthDay"));
/*      */     
/*  171 */     final QNameContext qnc32 = new QNameContext(3, 26, new QName("http://www.w3.org/2001/XMLSchema", "gYear"));
/*      */     
/*  173 */     final QNameContext qnc33 = new QNameContext(3, 27, new QName("http://www.w3.org/2001/XMLSchema", "gYearMonth"));
/*      */     
/*  175 */     final QNameContext qnc34 = new QNameContext(3, 28, new QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
/*      */     
/*  177 */     final QNameContext qnc35 = new QNameContext(3, 29, new QName("http://www.w3.org/2001/XMLSchema", "int"));
/*      */     
/*  179 */     final QNameContext qnc36 = new QNameContext(3, 30, new QName("http://www.w3.org/2001/XMLSchema", "integer"));
/*      */     
/*  181 */     final QNameContext qnc37 = new QNameContext(3, 31, new QName("http://www.w3.org/2001/XMLSchema", "language"));
/*      */     
/*  183 */     final QNameContext qnc38 = new QNameContext(3, 32, new QName("http://www.w3.org/2001/XMLSchema", "long"));
/*      */     
/*  185 */     final QNameContext qnc39 = new QNameContext(3, 33, new QName("http://www.w3.org/2001/XMLSchema", "negativeInteger"));
/*      */     
/*  187 */     final QNameContext qnc40 = new QNameContext(3, 34, new QName("http://www.w3.org/2001/XMLSchema", "nonNegativeInteger"));
/*      */     
/*  189 */     final QNameContext qnc41 = new QNameContext(3, 35, new QName("http://www.w3.org/2001/XMLSchema", "nonPositiveInteger"));
/*      */     
/*  191 */     final QNameContext qnc42 = new QNameContext(3, 36, new QName("http://www.w3.org/2001/XMLSchema", "normalizedString"));
/*      */     
/*  193 */     final QNameContext qnc43 = new QNameContext(3, 37, new QName("http://www.w3.org/2001/XMLSchema", "positiveInteger"));
/*      */     
/*  195 */     final QNameContext qnc44 = new QNameContext(3, 38, new QName("http://www.w3.org/2001/XMLSchema", "short"));
/*      */     
/*  197 */     final QNameContext qnc45 = new QNameContext(3, 39, new QName("http://www.w3.org/2001/XMLSchema", "string"));
/*      */     
/*  199 */     final QNameContext qnc46 = new QNameContext(3, 40, new QName("http://www.w3.org/2001/XMLSchema", "time"));
/*      */     
/*  201 */     final QNameContext qnc47 = new QNameContext(3, 41, new QName("http://www.w3.org/2001/XMLSchema", "token"));
/*      */     
/*  203 */     final QNameContext qnc48 = new QNameContext(3, 42, new QName("http://www.w3.org/2001/XMLSchema", "unsignedByte"));
/*      */     
/*  205 */     final QNameContext qnc49 = new QNameContext(3, 43, new QName("http://www.w3.org/2001/XMLSchema", "unsignedInt"));
/*      */     
/*  207 */     final QNameContext qnc50 = new QNameContext(3, 44, new QName("http://www.w3.org/2001/XMLSchema", "unsignedLong"));
/*      */     
/*  209 */     final QNameContext qnc51 = new QNameContext(3, 45, new QName("http://www.w3.org/2001/XMLSchema", "unsignedShort"));
/*      */     
/*  211 */     final QNameContext[] grammarQNames3 = new QNameContext[] { this.qnc6, this.qnc7, this.qnc8, this.qnc9, this.qnc10, this.qnc11, this.qnc12, this.qnc13, this.qnc14, this.qnc15, this.qnc16, this.qnc17, this.qnc18, this.qnc19, this.qnc20, this.qnc21, this.qnc22, this.qnc23, this.qnc24, this.qnc25, this.qnc26, this.qnc27, this.qnc28, this.qnc29, this.qnc30, this.qnc31, this.qnc32, this.qnc33, this.qnc34, this.qnc35, this.qnc36, this.qnc37, this.qnc38, this.qnc39, this.qnc40, this.qnc41, this.qnc42, this.qnc43, this.qnc44, this.qnc45, this.qnc46, this.qnc47, this.qnc48, this.qnc49, this.qnc50, this.qnc51 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  217 */     final String[] grammarPrefixes3 = new String[0];
/*  218 */     final GrammarUriContext guc3 = new GrammarUriContext(3, "http://www.w3.org/2001/XMLSchema", this.grammarQNames3, this.grammarPrefixes3);
/*      */ 
/*      */     
/*  221 */     final String ns4 = "http://www.w3.org/2009/exi";
/*  222 */     final QNameContext qnc52 = new QNameContext(4, 0, new QName("http://www.w3.org/2009/exi", "alignment"));
/*      */     
/*  224 */     final QNameContext qnc53 = new QNameContext(4, 1, new QName("http://www.w3.org/2009/exi", "base64Binary"));
/*      */     
/*  226 */     final QNameContext qnc54 = new QNameContext(4, 2, new QName("http://www.w3.org/2009/exi", "blockSize"));
/*      */     
/*  228 */     final QNameContext qnc55 = new QNameContext(4, 3, new QName("http://www.w3.org/2009/exi", "boolean"));
/*      */     
/*  230 */     final QNameContext qnc56 = new QNameContext(4, 4, new QName("http://www.w3.org/2009/exi", "byte"));
/*      */     
/*  232 */     final QNameContext qnc57 = new QNameContext(4, 5, new QName("http://www.w3.org/2009/exi", "comments"));
/*      */     
/*  234 */     final QNameContext qnc58 = new QNameContext(4, 6, new QName("http://www.w3.org/2009/exi", "common"));
/*      */     
/*  236 */     final QNameContext qnc59 = new QNameContext(4, 7, new QName("http://www.w3.org/2009/exi", "compression"));
/*      */     
/*  238 */     final QNameContext qnc60 = new QNameContext(4, 8, new QName("http://www.w3.org/2009/exi", "datatypeRepresentationMap"));
/*      */     
/*  240 */     final QNameContext qnc61 = new QNameContext(4, 9, new QName("http://www.w3.org/2009/exi", "date"));
/*      */     
/*  242 */     final QNameContext qnc62 = new QNameContext(4, 10, new QName("http://www.w3.org/2009/exi", "dateTime"));
/*      */     
/*  244 */     final QNameContext qnc63 = new QNameContext(4, 11, new QName("http://www.w3.org/2009/exi", "decimal"));
/*      */     
/*  246 */     final QNameContext qnc64 = new QNameContext(4, 12, new QName("http://www.w3.org/2009/exi", "double"));
/*      */     
/*  248 */     final QNameContext qnc65 = new QNameContext(4, 13, new QName("http://www.w3.org/2009/exi", "dtd"));
/*      */     
/*  250 */     final QNameContext qnc66 = new QNameContext(4, 14, new QName("http://www.w3.org/2009/exi", "fragment"));
/*      */     
/*  252 */     final QNameContext qnc67 = new QNameContext(4, 15, new QName("http://www.w3.org/2009/exi", "gDay"));
/*      */     
/*  254 */     final QNameContext qnc68 = new QNameContext(4, 16, new QName("http://www.w3.org/2009/exi", "gMonth"));
/*      */     
/*  256 */     final QNameContext qnc69 = new QNameContext(4, 17, new QName("http://www.w3.org/2009/exi", "gMonthDay"));
/*      */     
/*  258 */     final QNameContext qnc70 = new QNameContext(4, 18, new QName("http://www.w3.org/2009/exi", "gYear"));
/*      */     
/*  260 */     final QNameContext qnc71 = new QNameContext(4, 19, new QName("http://www.w3.org/2009/exi", "gYearMonth"));
/*      */     
/*  262 */     final QNameContext qnc72 = new QNameContext(4, 20, new QName("http://www.w3.org/2009/exi", "header"));
/*      */     
/*  264 */     final QNameContext qnc73 = new QNameContext(4, 21, new QName("http://www.w3.org/2009/exi", "hexBinary"));
/*      */     
/*  266 */     final QNameContext qnc74 = new QNameContext(4, 22, new QName("http://www.w3.org/2009/exi", "ieeeBinary32"));
/*      */     
/*  268 */     final QNameContext qnc75 = new QNameContext(4, 23, new QName("http://www.w3.org/2009/exi", "ieeeBinary64"));
/*      */     
/*  270 */     final QNameContext qnc76 = new QNameContext(4, 24, new QName("http://www.w3.org/2009/exi", "integer"));
/*      */     
/*  272 */     final QNameContext qnc77 = new QNameContext(4, 25, new QName("http://www.w3.org/2009/exi", "lesscommon"));
/*      */     
/*  274 */     final QNameContext qnc78 = new QNameContext(4, 26, new QName("http://www.w3.org/2009/exi", "lexicalValues"));
/*      */     
/*  276 */     final QNameContext qnc79 = new QNameContext(4, 27, new QName("http://www.w3.org/2009/exi", "pis"));
/*      */     
/*  278 */     final QNameContext qnc80 = new QNameContext(4, 28, new QName("http://www.w3.org/2009/exi", "pre-compress"));
/*      */     
/*  280 */     final QNameContext qnc81 = new QNameContext(4, 29, new QName("http://www.w3.org/2009/exi", "prefixes"));
/*      */     
/*  282 */     final QNameContext qnc82 = new QNameContext(4, 30, new QName("http://www.w3.org/2009/exi", "preserve"));
/*      */     
/*  284 */     final QNameContext qnc83 = new QNameContext(4, 31, new QName("http://www.w3.org/2009/exi", "schemaId"));
/*      */     
/*  286 */     final QNameContext qnc84 = new QNameContext(4, 32, new QName("http://www.w3.org/2009/exi", "selfContained"));
/*      */     
/*  288 */     final QNameContext qnc85 = new QNameContext(4, 33, new QName("http://www.w3.org/2009/exi", "strict"));
/*      */     
/*  290 */     final QNameContext qnc86 = new QNameContext(4, 34, new QName("http://www.w3.org/2009/exi", "string"));
/*      */     
/*  292 */     final QNameContext qnc87 = new QNameContext(4, 35, new QName("http://www.w3.org/2009/exi", "time"));
/*      */     
/*  294 */     final QNameContext qnc88 = new QNameContext(4, 36, new QName("http://www.w3.org/2009/exi", "uncommon"));
/*      */     
/*  296 */     final QNameContext qnc89 = new QNameContext(4, 37, new QName("http://www.w3.org/2009/exi", "valueMaxLength"));
/*      */     
/*  298 */     final QNameContext qnc90 = new QNameContext(4, 38, new QName("http://www.w3.org/2009/exi", "valuePartitionCapacity"));
/*      */     
/*  300 */     final QNameContext[] grammarQNames4 = new QNameContext[] { this.qnc52, this.qnc53, this.qnc54, this.qnc55, this.qnc56, this.qnc57, this.qnc58, this.qnc59, this.qnc60, this.qnc61, this.qnc62, this.qnc63, this.qnc64, this.qnc65, this.qnc66, this.qnc67, this.qnc68, this.qnc69, this.qnc70, this.qnc71, this.qnc72, this.qnc73, this.qnc74, this.qnc75, this.qnc76, this.qnc77, this.qnc78, this.qnc79, this.qnc80, this.qnc81, this.qnc82, this.qnc83, this.qnc84, this.qnc85, this.qnc86, this.qnc87, this.qnc88, this.qnc89, this.qnc90 };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  305 */     final String[] grammarPrefixes4 = new String[0];
/*  306 */     final GrammarUriContext guc4 = new GrammarUriContext(4, "http://www.w3.org/2009/exi", this.grammarQNames4, this.grammarPrefixes4);
/*      */ 
/*      */     
/*  309 */     final GrammarUriContext[] grammarUriContexts = new GrammarUriContext[] { this.guc0, this.guc1, this.guc2, this.guc3, this.guc4 };
/*      */     
/*  311 */     final GrammarContext gc = new GrammarContext(this.grammarUriContexts, 91);
/*      */ 
/*      */ 
/*      */     
/*  315 */     Document g0 = new Document();
/*  316 */     SchemaInformedDocContent g1 = new SchemaInformedDocContent();
/*  317 */     SchemaInformedFirstStartTag g2 = new SchemaInformedFirstStartTag();
/*  318 */     SchemaInformedFirstStartTag g3 = new SchemaInformedFirstStartTag();
/*  319 */     SchemaInformedFirstStartTag g4 = new SchemaInformedFirstStartTag();
/*  320 */     SchemaInformedFirstStartTag g5 = new SchemaInformedFirstStartTag();
/*  321 */     SchemaInformedFirstStartTag g6 = new SchemaInformedFirstStartTag();
/*  322 */     SchemaInformedElement g7 = new SchemaInformedElement();
/*  323 */     SchemaInformedElement g8 = new SchemaInformedElement();
/*  324 */     SchemaInformedElement g9 = new SchemaInformedElement();
/*  325 */     SchemaInformedElement g10 = new SchemaInformedElement();
/*  326 */     SchemaInformedElement g11 = new SchemaInformedElement();
/*  327 */     SchemaInformedFirstStartTag g12 = new SchemaInformedFirstStartTag();
/*  328 */     SchemaInformedElement g13 = new SchemaInformedElement();
/*  329 */     SchemaInformedElement g14 = new SchemaInformedElement();
/*  330 */     SchemaInformedElement g15 = new SchemaInformedElement();
/*  331 */     SchemaInformedFirstStartTag g16 = new SchemaInformedFirstStartTag();
/*  332 */     SchemaInformedElement g17 = new SchemaInformedElement();
/*  333 */     SchemaInformedElement g18 = new SchemaInformedElement();
/*  334 */     SchemaInformedElement g19 = new SchemaInformedElement();
/*  335 */     SchemaInformedElement g20 = new SchemaInformedElement();
/*  336 */     SchemaInformedFirstStartTag g21 = new SchemaInformedFirstStartTag();
/*  337 */     SchemaInformedElement g22 = new SchemaInformedElement();
/*  338 */     SchemaInformedElement g23 = new SchemaInformedElement();
/*  339 */     SchemaInformedElement g24 = new SchemaInformedElement();
/*  340 */     SchemaInformedElement g25 = new SchemaInformedElement();
/*  341 */     SchemaInformedElement g26 = new SchemaInformedElement();
/*  342 */     SchemaInformedElement g27 = new SchemaInformedElement();
/*  343 */     SchemaInformedElement g28 = new SchemaInformedElement();
/*  344 */     SchemaInformedElement g29 = new SchemaInformedElement();
/*  345 */     SchemaInformedFirstStartTag g30 = new SchemaInformedFirstStartTag();
/*  346 */     SchemaInformedElement g31 = new SchemaInformedElement();
/*  347 */     SchemaInformedElement g32 = new SchemaInformedElement();
/*  348 */     SchemaInformedFirstStartTag g33 = new SchemaInformedFirstStartTag();
/*  349 */     SchemaInformedElement g34 = new SchemaInformedElement();
/*  350 */     SchemaInformedElement g35 = new SchemaInformedElement();
/*  351 */     SchemaInformedElement g36 = new SchemaInformedElement();
/*  352 */     SchemaInformedElement g37 = new SchemaInformedElement();
/*  353 */     DocEnd g38 = new DocEnd();
/*  354 */     Fragment g39 = new Fragment();
/*  355 */     SchemaInformedFragmentContent g40 = new SchemaInformedFragmentContent();
/*  356 */     SchemaInformedFirstStartTag g41 = new SchemaInformedFirstStartTag();
/*  357 */     SchemaInformedElement g42 = new SchemaInformedElement();
/*  358 */     SchemaInformedFirstStartTag g43 = new SchemaInformedFirstStartTag();
/*  359 */     SchemaInformedFirstStartTag g44 = new SchemaInformedFirstStartTag();
/*  360 */     SchemaInformedElement g45 = new SchemaInformedElement();
/*  361 */     SchemaInformedFirstStartTag g46 = new SchemaInformedFirstStartTag();
/*  362 */     SchemaInformedElement g47 = new SchemaInformedElement();
/*  363 */     SchemaInformedFirstStartTag g48 = new SchemaInformedFirstStartTag();
/*  364 */     SchemaInformedElement g49 = new SchemaInformedElement();
/*  365 */     SchemaInformedFirstStartTag g50 = new SchemaInformedFirstStartTag();
/*  366 */     SchemaInformedElement g51 = new SchemaInformedElement();
/*  367 */     SchemaInformedFirstStartTag g52 = new SchemaInformedFirstStartTag();
/*  368 */     SchemaInformedElement g53 = new SchemaInformedElement();
/*  369 */     SchemaInformedFirstStartTag g54 = new SchemaInformedFirstStartTag();
/*  370 */     SchemaInformedElement g55 = new SchemaInformedElement();
/*  371 */     SchemaInformedFirstStartTag g56 = new SchemaInformedFirstStartTag();
/*  372 */     SchemaInformedElement g57 = new SchemaInformedElement();
/*  373 */     SchemaInformedFirstStartTag g58 = new SchemaInformedFirstStartTag();
/*  374 */     SchemaInformedElement g59 = new SchemaInformedElement();
/*  375 */     SchemaInformedFirstStartTag g60 = new SchemaInformedFirstStartTag();
/*  376 */     SchemaInformedElement g61 = new SchemaInformedElement();
/*  377 */     SchemaInformedFirstStartTag g62 = new SchemaInformedFirstStartTag();
/*  378 */     SchemaInformedElement g63 = new SchemaInformedElement();
/*  379 */     SchemaInformedFirstStartTag g64 = new SchemaInformedFirstStartTag();
/*  380 */     SchemaInformedElement g65 = new SchemaInformedElement();
/*  381 */     SchemaInformedFirstStartTag g66 = new SchemaInformedFirstStartTag();
/*  382 */     SchemaInformedElement g67 = new SchemaInformedElement();
/*  383 */     SchemaInformedFirstStartTag g68 = new SchemaInformedFirstStartTag();
/*  384 */     SchemaInformedElement g69 = new SchemaInformedElement();
/*  385 */     SchemaInformedFirstStartTag g70 = new SchemaInformedFirstStartTag();
/*  386 */     SchemaInformedElement g71 = new SchemaInformedElement();
/*  387 */     SchemaInformedFirstStartTag g72 = new SchemaInformedFirstStartTag();
/*  388 */     SchemaInformedElement g73 = new SchemaInformedElement();
/*  389 */     SchemaInformedFirstStartTag g74 = new SchemaInformedFirstStartTag();
/*  390 */     SchemaInformedElement g75 = new SchemaInformedElement();
/*  391 */     SchemaInformedFirstStartTag g76 = new SchemaInformedFirstStartTag();
/*  392 */     SchemaInformedElement g77 = new SchemaInformedElement();
/*      */ 
/*      */     
/*  395 */     StartElement globalSE72 = new StartElement(this.qnc72, (Grammar)this.g2);
/*      */ 
/*      */     
/*  398 */     protected String schemaId = "http://www.w3.org/2009/exi";
/*      */ 
/*      */ 
/*      */     
/*      */     public EXIOptionsHeaderGrammars() {
/*  403 */       this.qnc72.setGlobalStartElement(this.globalSE72);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  410 */       this.qnc6.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g41);
/*  411 */       this.qnc7.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  412 */       this.qnc8.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  413 */       this.qnc9.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  414 */       this.qnc10.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g41);
/*  415 */       this.qnc11.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  416 */       this.qnc12.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  417 */       this.qnc13.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g41);
/*  418 */       this.qnc14.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  419 */       this.qnc15.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  420 */       this.qnc16.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  421 */       this.qnc17.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  422 */       this.qnc18.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g44);
/*  423 */       this.qnc19.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  424 */       this.qnc20.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g46);
/*  425 */       this.qnc21.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g48);
/*  426 */       this.qnc22.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g50);
/*  427 */       this.qnc23.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g52);
/*  428 */       this.qnc24.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g54);
/*  429 */       this.qnc25.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g56);
/*  430 */       this.qnc26.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g58);
/*  431 */       this.qnc27.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  432 */       this.qnc28.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g58);
/*  433 */       this.qnc29.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g60);
/*  434 */       this.qnc30.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g62);
/*  435 */       this.qnc31.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g64);
/*  436 */       this.qnc32.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g66);
/*  437 */       this.qnc33.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g68);
/*  438 */       this.qnc34.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g70);
/*  439 */       this.qnc35.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g72);
/*  440 */       this.qnc36.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g72);
/*  441 */       this.qnc37.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  442 */       this.qnc38.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g72);
/*  443 */       this.qnc39.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g72);
/*  444 */       this.qnc40.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g12);
/*  445 */       this.qnc41.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g72);
/*  446 */       this.qnc42.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  447 */       this.qnc43.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g12);
/*  448 */       this.qnc44.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g72);
/*  449 */       this.qnc45.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  450 */       this.qnc46.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g74);
/*  451 */       this.qnc47.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  452 */       this.qnc48.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g76);
/*  453 */       this.qnc49.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g12);
/*  454 */       this.qnc50.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g12);
/*  455 */       this.qnc51.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g12);
/*  456 */       this.qnc53.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g46);
/*  457 */       this.qnc55.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g48);
/*  458 */       this.qnc61.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g52);
/*  459 */       this.qnc62.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g54);
/*  460 */       this.qnc63.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g56);
/*  461 */       this.qnc64.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g58);
/*  462 */       this.qnc67.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g60);
/*  463 */       this.qnc68.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g62);
/*  464 */       this.qnc69.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g64);
/*  465 */       this.qnc70.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g66);
/*  466 */       this.qnc71.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g68);
/*  467 */       this.qnc73.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g70);
/*  468 */       this.qnc74.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g58);
/*  469 */       this.qnc75.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g58);
/*  470 */       this.qnc76.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g72);
/*  471 */       this.qnc86.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g43);
/*  472 */       this.qnc87.setTypeGrammar((SchemaInformedFirstStartTagGrammar)this.g74);
/*      */ 
/*      */ 
/*      */       
/*  476 */       this.g0.addProduction((Event)new StartDocument(), (Grammar)this.g1);
/*      */ 
/*      */       
/*  479 */       this.g1.addProduction((Event)this.globalSE72, (Grammar)this.g38);
/*  480 */       this.g1.addProduction((Event)new StartElementGeneric(), (Grammar)this.g38);
/*      */ 
/*      */       
/*  483 */       this.g2.addProduction((Event)new StartElement(this.qnc77, (Grammar)this.g3), (Grammar)this.g29);
/*      */ 
/*      */       
/*  486 */       this.g2.addProduction((Event)new StartElement(this.qnc58, (Grammar)this.g30), (Grammar)this.g36);
/*      */ 
/*      */       
/*  489 */       this.g2.addProduction((Event)new StartElement(this.qnc85, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  492 */       this.g2.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  494 */       this.g3.addProduction((Event)new StartElement(this.qnc88, (Grammar)this.g4), (Grammar)this.g20);
/*      */ 
/*      */       
/*  497 */       this.g3.addProduction((Event)new StartElement(this.qnc82, (Grammar)this.g21), (Grammar)this.g27);
/*      */ 
/*      */       
/*  500 */       this.g3.addProduction((Event)new StartElement(this.qnc54, (Grammar)this.g12), (Grammar)this.g8);
/*      */ 
/*      */       
/*  503 */       this.g3.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  505 */       this.g4.addProduction((Event)new StartElement(this.qnc52, (Grammar)this.g5), (Grammar)this.g10);
/*      */ 
/*      */       
/*  508 */       this.g4.addProduction((Event)new StartElement(this.qnc84, (Grammar)this.g6), (Grammar)this.g11);
/*      */ 
/*      */       
/*  511 */       this.g4.addProduction((Event)new StartElement(this.qnc89, (Grammar)this.g12), (Grammar)this.g14);
/*      */ 
/*      */       
/*  514 */       this.g4.addProduction((Event)new StartElement(this.qnc90, (Grammar)this.g12), (Grammar)this.g15);
/*      */ 
/*      */       
/*  517 */       this.g4.addProduction((Event)new StartElement(this.qnc60, (Grammar)this.g16), (Grammar)this.g15);
/*      */ 
/*      */       
/*  520 */       this.g4.addProduction((Event)new StartElementGeneric(), (Grammar)this.g19);
/*      */ 
/*      */       
/*  523 */       this.g4.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  525 */       this.g5.addProduction((Event)new StartElement(this.qnc56, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  528 */       this.g5.addProduction((Event)new StartElement(this.qnc80, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  531 */       this.g6.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  533 */       this.g8.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  535 */       this.g9.addProduction((Event)new StartElement(this.qnc56, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  538 */       this.g9.addProduction((Event)new StartElement(this.qnc80, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  541 */       this.g10.addProduction((Event)new StartElement(this.qnc84, (Grammar)this.g6), (Grammar)this.g11);
/*      */ 
/*      */       
/*  544 */       this.g10.addProduction((Event)new StartElement(this.qnc89, (Grammar)this.g12), (Grammar)this.g14);
/*      */ 
/*      */       
/*  547 */       this.g10.addProduction((Event)new StartElement(this.qnc90, (Grammar)this.g12), (Grammar)this.g15);
/*      */ 
/*      */       
/*  550 */       this.g10.addProduction((Event)new StartElement(this.qnc60, (Grammar)this.g16), (Grammar)this.g15);
/*      */ 
/*      */       
/*  553 */       this.g10.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  555 */       this.g11.addProduction((Event)new StartElement(this.qnc89, (Grammar)this.g12), (Grammar)this.g14);
/*      */ 
/*      */       
/*  558 */       this.g11.addProduction((Event)new StartElement(this.qnc90, (Grammar)this.g12), (Grammar)this.g15);
/*      */ 
/*      */       
/*  561 */       this.g11.addProduction((Event)new StartElement(this.qnc60, (Grammar)this.g16), (Grammar)this.g15);
/*      */ 
/*      */       
/*  564 */       this.g11.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  566 */       this.g12.addProduction((Event)new Characters((Datatype)new UnsignedIntegerDatatype(this.qnc49)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  570 */       this.g13.addProduction((Event)new Characters((Datatype)new UnsignedIntegerDatatype(this.qnc49)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  574 */       this.g14.addProduction((Event)new StartElement(this.qnc90, (Grammar)this.g12), (Grammar)this.g15);
/*      */ 
/*      */       
/*  577 */       this.g14.addProduction((Event)new StartElement(this.qnc60, (Grammar)this.g16), (Grammar)this.g15);
/*      */ 
/*      */       
/*  580 */       this.g14.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  582 */       this.g15.addProduction((Event)new StartElement(this.qnc60, (Grammar)this.g16), (Grammar)this.g15);
/*      */ 
/*      */       
/*  585 */       this.g15.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  587 */       this.g16.addProduction((Event)new StartElementGeneric(), (Grammar)this.g17);
/*      */ 
/*      */       
/*  590 */       this.g17.addProduction((Event)new StartElementGeneric(), (Grammar)this.g8);
/*      */ 
/*      */       
/*  593 */       this.g18.addProduction((Event)new StartElementGeneric(), (Grammar)this.g17);
/*      */ 
/*      */       
/*  596 */       this.g19.addProduction((Event)new StartElement(this.qnc52, (Grammar)this.g5), (Grammar)this.g10);
/*      */ 
/*      */       
/*  599 */       this.g19.addProduction((Event)new StartElement(this.qnc84, (Grammar)this.g6), (Grammar)this.g11);
/*      */ 
/*      */       
/*  602 */       this.g19.addProduction((Event)new StartElement(this.qnc89, (Grammar)this.g12), (Grammar)this.g14);
/*      */ 
/*      */       
/*  605 */       this.g19.addProduction((Event)new StartElement(this.qnc90, (Grammar)this.g12), (Grammar)this.g15);
/*      */ 
/*      */       
/*  608 */       this.g19.addProduction((Event)new StartElement(this.qnc60, (Grammar)this.g16), (Grammar)this.g15);
/*      */ 
/*      */       
/*  611 */       this.g19.addProduction((Event)new StartElementGeneric(), (Grammar)this.g19);
/*      */ 
/*      */       
/*  614 */       this.g19.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  616 */       this.g20.addProduction((Event)new StartElement(this.qnc82, (Grammar)this.g21), (Grammar)this.g27);
/*      */ 
/*      */       
/*  619 */       this.g20.addProduction((Event)new StartElement(this.qnc54, (Grammar)this.g12), (Grammar)this.g8);
/*      */ 
/*      */       
/*  622 */       this.g20.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  624 */       this.g21.addProduction((Event)new StartElement(this.qnc65, (Grammar)this.g6), (Grammar)this.g22);
/*      */ 
/*      */       
/*  627 */       this.g21.addProduction((Event)new StartElement(this.qnc81, (Grammar)this.g6), (Grammar)this.g23);
/*      */ 
/*      */       
/*  630 */       this.g21.addProduction((Event)new StartElement(this.qnc78, (Grammar)this.g6), (Grammar)this.g24);
/*      */ 
/*      */       
/*  633 */       this.g21.addProduction((Event)new StartElement(this.qnc57, (Grammar)this.g6), (Grammar)this.g25);
/*      */ 
/*      */       
/*  636 */       this.g21.addProduction((Event)new StartElement(this.qnc79, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  639 */       this.g21.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  641 */       this.g22.addProduction((Event)new StartElement(this.qnc81, (Grammar)this.g6), (Grammar)this.g23);
/*      */ 
/*      */       
/*  644 */       this.g22.addProduction((Event)new StartElement(this.qnc78, (Grammar)this.g6), (Grammar)this.g24);
/*      */ 
/*      */       
/*  647 */       this.g22.addProduction((Event)new StartElement(this.qnc57, (Grammar)this.g6), (Grammar)this.g25);
/*      */ 
/*      */       
/*  650 */       this.g22.addProduction((Event)new StartElement(this.qnc79, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  653 */       this.g22.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  655 */       this.g23.addProduction((Event)new StartElement(this.qnc78, (Grammar)this.g6), (Grammar)this.g24);
/*      */ 
/*      */       
/*  658 */       this.g23.addProduction((Event)new StartElement(this.qnc57, (Grammar)this.g6), (Grammar)this.g25);
/*      */ 
/*      */       
/*  661 */       this.g23.addProduction((Event)new StartElement(this.qnc79, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  664 */       this.g23.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  666 */       this.g24.addProduction((Event)new StartElement(this.qnc57, (Grammar)this.g6), (Grammar)this.g25);
/*      */ 
/*      */       
/*  669 */       this.g24.addProduction((Event)new StartElement(this.qnc79, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  672 */       this.g24.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  674 */       this.g25.addProduction((Event)new StartElement(this.qnc79, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  677 */       this.g25.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  679 */       this.g26.addProduction((Event)new StartElement(this.qnc65, (Grammar)this.g6), (Grammar)this.g22);
/*      */ 
/*      */       
/*  682 */       this.g26.addProduction((Event)new StartElement(this.qnc81, (Grammar)this.g6), (Grammar)this.g23);
/*      */ 
/*      */       
/*  685 */       this.g26.addProduction((Event)new StartElement(this.qnc78, (Grammar)this.g6), (Grammar)this.g24);
/*      */ 
/*      */       
/*  688 */       this.g26.addProduction((Event)new StartElement(this.qnc57, (Grammar)this.g6), (Grammar)this.g25);
/*      */ 
/*      */       
/*  691 */       this.g26.addProduction((Event)new StartElement(this.qnc79, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  694 */       this.g26.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  696 */       this.g27.addProduction((Event)new StartElement(this.qnc54, (Grammar)this.g12), (Grammar)this.g8);
/*      */ 
/*      */       
/*  699 */       this.g27.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  701 */       this.g28.addProduction((Event)new StartElement(this.qnc88, (Grammar)this.g4), (Grammar)this.g20);
/*      */ 
/*      */       
/*  704 */       this.g28.addProduction((Event)new StartElement(this.qnc82, (Grammar)this.g21), (Grammar)this.g27);
/*      */ 
/*      */       
/*  707 */       this.g28.addProduction((Event)new StartElement(this.qnc54, (Grammar)this.g12), (Grammar)this.g8);
/*      */ 
/*      */       
/*  710 */       this.g28.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  712 */       this.g29.addProduction((Event)new StartElement(this.qnc58, (Grammar)this.g30), (Grammar)this.g36);
/*      */ 
/*      */       
/*  715 */       this.g29.addProduction((Event)new StartElement(this.qnc85, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  718 */       this.g29.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  720 */       this.g30.addProduction((Event)new StartElement(this.qnc59, (Grammar)this.g6), (Grammar)this.g31);
/*      */ 
/*      */       
/*  723 */       this.g30.addProduction((Event)new StartElement(this.qnc66, (Grammar)this.g6), (Grammar)this.g32);
/*      */ 
/*      */       
/*  726 */       this.g30.addProduction((Event)new StartElement(this.qnc83, (Grammar)this.g33), (Grammar)this.g8);
/*      */ 
/*      */       
/*  729 */       this.g30.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  731 */       this.g31.addProduction((Event)new StartElement(this.qnc66, (Grammar)this.g6), (Grammar)this.g32);
/*      */ 
/*      */       
/*  734 */       this.g31.addProduction((Event)new StartElement(this.qnc83, (Grammar)this.g33), (Grammar)this.g8);
/*      */ 
/*      */       
/*  737 */       this.g31.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  739 */       this.g32.addProduction((Event)new StartElement(this.qnc83, (Grammar)this.g33), (Grammar)this.g8);
/*      */ 
/*      */       
/*  742 */       this.g32.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  744 */       this.g33.addProduction((Event)new Characters((Datatype)new StringDatatype(this.qnc45)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  748 */       this.g34.addProduction((Event)new Characters((Datatype)new StringDatatype(this.qnc45)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  752 */       this.g35.addProduction((Event)new StartElement(this.qnc59, (Grammar)this.g6), (Grammar)this.g31);
/*      */ 
/*      */       
/*  755 */       this.g35.addProduction((Event)new StartElement(this.qnc66, (Grammar)this.g6), (Grammar)this.g32);
/*      */ 
/*      */       
/*  758 */       this.g35.addProduction((Event)new StartElement(this.qnc83, (Grammar)this.g33), (Grammar)this.g8);
/*      */ 
/*      */       
/*  761 */       this.g35.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  763 */       this.g36.addProduction((Event)new StartElement(this.qnc85, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  766 */       this.g36.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  768 */       this.g37.addProduction((Event)new StartElement(this.qnc77, (Grammar)this.g3), (Grammar)this.g29);
/*      */ 
/*      */       
/*  771 */       this.g37.addProduction((Event)new StartElement(this.qnc58, (Grammar)this.g30), (Grammar)this.g36);
/*      */ 
/*      */       
/*  774 */       this.g37.addProduction((Event)new StartElement(this.qnc85, (Grammar)this.g6), (Grammar)this.g8);
/*      */ 
/*      */       
/*  777 */       this.g37.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  779 */       this.g38.addProduction((Event)new EndDocument(), (Grammar)this.g7);
/*      */ 
/*      */       
/*  782 */       this.g39.addProduction((Event)new StartDocument(), (Grammar)this.g40);
/*      */ 
/*      */       
/*  785 */       this.g40.addProduction((Event)new StartElement(this.qnc52, (Grammar)this.g5), (Grammar)this.g40);
/*      */ 
/*      */       
/*  788 */       this.g40.addProduction((Event)new StartElement(this.qnc54, (Grammar)this.g12), (Grammar)this.g40);
/*      */ 
/*      */       
/*  791 */       this.g40.addProduction((Event)new StartElement(this.qnc56, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  794 */       this.g40.addProduction((Event)new StartElement(this.qnc57, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  797 */       this.g40.addProduction((Event)new StartElement(this.qnc58, (Grammar)this.g30), (Grammar)this.g40);
/*      */ 
/*      */       
/*  800 */       this.g40.addProduction((Event)new StartElement(this.qnc59, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  803 */       this.g40.addProduction((Event)new StartElement(this.qnc60, (Grammar)this.g16), (Grammar)this.g40);
/*      */ 
/*      */       
/*  806 */       this.g40.addProduction((Event)new StartElement(this.qnc65, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  809 */       this.g40.addProduction((Event)new StartElement(this.qnc66, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  812 */       this.g40.addProduction((Event)this.globalSE72, (Grammar)this.g40);
/*  813 */       this.g40.addProduction((Event)new StartElement(this.qnc77, (Grammar)this.g3), (Grammar)this.g40);
/*      */ 
/*      */       
/*  816 */       this.g40.addProduction((Event)new StartElement(this.qnc78, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  819 */       this.g40.addProduction((Event)new StartElement(this.qnc79, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  822 */       this.g40.addProduction((Event)new StartElement(this.qnc80, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  825 */       this.g40.addProduction((Event)new StartElement(this.qnc81, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  828 */       this.g40.addProduction((Event)new StartElement(this.qnc82, (Grammar)this.g21), (Grammar)this.g40);
/*      */ 
/*      */       
/*  831 */       this.g40.addProduction((Event)new StartElement(this.qnc83, (Grammar)this.g33), (Grammar)this.g40);
/*      */ 
/*      */       
/*  834 */       this.g40.addProduction((Event)new StartElement(this.qnc84, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  837 */       this.g40.addProduction((Event)new StartElement(this.qnc85, (Grammar)this.g6), (Grammar)this.g40);
/*      */ 
/*      */       
/*  840 */       this.g40.addProduction((Event)new StartElement(this.qnc88, (Grammar)this.g4), (Grammar)this.g40);
/*      */ 
/*      */       
/*  843 */       this.g40.addProduction((Event)new StartElement(this.qnc89, (Grammar)this.g12), (Grammar)this.g40);
/*      */ 
/*      */       
/*  846 */       this.g40.addProduction((Event)new StartElement(this.qnc90, (Grammar)this.g12), (Grammar)this.g40);
/*      */ 
/*      */       
/*  849 */       this.g40.addProduction((Event)new StartElementGeneric(), (Grammar)this.g40);
/*      */ 
/*      */       
/*  852 */       this.g40.addProduction((Event)new EndDocument(), (Grammar)this.g7);
/*      */ 
/*      */       
/*  855 */       this.g41.addProduction((Event)new Characters((Datatype)new ListDatatype((Datatype)new StringDatatype(this.qnc7), this.qnc6)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  860 */       this.g42.addProduction((Event)new Characters((Datatype)new ListDatatype((Datatype)new StringDatatype(this.qnc7), this.qnc6)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  865 */       this.g43.addProduction((Event)new Characters((Datatype)new StringDatatype(this.qnc7)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  869 */       this.g44.addProduction((Event)new AttributeGeneric(), (Grammar)this.g44);
/*      */ 
/*      */       
/*  872 */       this.g44.addProduction((Event)new StartElementGeneric(), (Grammar)this.g45);
/*      */ 
/*      */       
/*  875 */       this.g44.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  877 */       this.g44.addProduction((Event)new CharactersGeneric(), (Grammar)this.g45);
/*      */ 
/*      */       
/*  880 */       this.g45.addProduction((Event)new StartElementGeneric(), (Grammar)this.g45);
/*      */ 
/*      */       
/*  883 */       this.g45.addProduction((Event)new EndElement(), (Grammar)this.g7);
/*      */       
/*  885 */       this.g45.addProduction((Event)new CharactersGeneric(), (Grammar)this.g45);
/*      */ 
/*      */       
/*  888 */       this.g46.addProduction((Event)new Characters((Datatype)new BinaryBase64Datatype(this.qnc20)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  892 */       this.g47.addProduction((Event)new Characters((Datatype)new BinaryBase64Datatype(this.qnc20)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  896 */       this.g48.addProduction((Event)new Characters((Datatype)new BooleanDatatype(this.qnc21)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  900 */       this.g49.addProduction((Event)new Characters((Datatype)new BooleanDatatype(this.qnc21)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  904 */       this.g50.addProduction((Event)new Characters((Datatype)new NBitUnsignedIntegerDatatype(
/*      */ 
/*      */ 
/*      */               
/*  908 */               IntegerValue.valueOf(-128), 
/*      */               
/*  910 */               IntegerValue.valueOf(127), this.qnc22)), (Grammar)this.g8);
/*  911 */       this.g51.addProduction((Event)new Characters((Datatype)new NBitUnsignedIntegerDatatype(
/*      */ 
/*      */ 
/*      */               
/*  915 */               IntegerValue.valueOf(-128), 
/*      */               
/*  917 */               IntegerValue.valueOf(127), this.qnc22)), (Grammar)this.g8);
/*  918 */       this.g52.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.date, this.qnc23)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  923 */       this.g53.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.date, this.qnc23)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  928 */       this.g54.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.dateTime, this.qnc24)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  933 */       this.g55.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.dateTime, this.qnc24)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  938 */       this.g56.addProduction((Event)new Characters((Datatype)new DecimalDatatype(this.qnc25)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  942 */       this.g57.addProduction((Event)new Characters((Datatype)new DecimalDatatype(this.qnc25)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  946 */       this.g58.addProduction((Event)new Characters((Datatype)new FloatDatatype(this.qnc26)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  950 */       this.g59.addProduction((Event)new Characters((Datatype)new FloatDatatype(this.qnc26)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/*  954 */       this.g60.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gDay, this.qnc29)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  959 */       this.g61.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gDay, this.qnc29)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  964 */       this.g62.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gMonth, this.qnc30)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  969 */       this.g63.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gMonth, this.qnc30)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  974 */       this.g64.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gMonthDay, this.qnc31)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  979 */       this.g65.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gMonthDay, this.qnc31)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  984 */       this.g66.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gYear, this.qnc32)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  989 */       this.g67.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gYear, this.qnc32)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  994 */       this.g68.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gYearMonth, this.qnc33)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  999 */       this.g69.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.gYearMonth, this.qnc33)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1004 */       this.g70.addProduction((Event)new Characters((Datatype)new BinaryHexDatatype(this.qnc34)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/* 1008 */       this.g71.addProduction((Event)new Characters((Datatype)new BinaryHexDatatype(this.qnc34)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/* 1012 */       this.g72.addProduction((Event)new Characters((Datatype)new IntegerDatatype(this.qnc35)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/* 1016 */       this.g73.addProduction((Event)new Characters((Datatype)new IntegerDatatype(this.qnc35)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/* 1020 */       this.g74.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.time, this.qnc46)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1025 */       this.g75.addProduction((Event)new Characters((Datatype)new DatetimeDatatype(DateTimeType.time, this.qnc46)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1030 */       this.g76.addProduction((Event)new Characters((Datatype)new NBitUnsignedIntegerDatatype(
/*      */ 
/*      */ 
/*      */               
/* 1034 */               IntegerValue.valueOf(0), 
/*      */               
/* 1036 */               IntegerValue.valueOf(255), this.qnc48)), (Grammar)this.g8);
/* 1037 */       this.g77.addProduction((Event)new Characters((Datatype)new NBitUnsignedIntegerDatatype(
/*      */ 
/*      */ 
/*      */               
/* 1041 */               IntegerValue.valueOf(0), 
/*      */               
/* 1043 */               IntegerValue.valueOf(255), this.qnc48)), (Grammar)this.g8);
/*      */ 
/*      */ 
/*      */       
/* 1047 */       this.g2.setElementContentGrammar((Grammar)this.g37);
/* 1048 */       this.g3.setElementContentGrammar((Grammar)this.g28);
/* 1049 */       this.g4.setElementContentGrammar((Grammar)this.g19);
/* 1050 */       this.g5.setElementContentGrammar((Grammar)this.g9);
/* 1051 */       this.g6.setElementContentGrammar((Grammar)this.g8);
/* 1052 */       this.g12.setElementContentGrammar((Grammar)this.g13);
/* 1053 */       this.g16.setElementContentGrammar((Grammar)this.g18);
/* 1054 */       this.g21.setElementContentGrammar((Grammar)this.g26);
/* 1055 */       this.g30.setElementContentGrammar((Grammar)this.g35);
/* 1056 */       this.g33.setElementContentGrammar((Grammar)this.g34);
/* 1057 */       this.g33.setNillable(true);
/* 1058 */       this.g41.setElementContentGrammar((Grammar)this.g42);
/* 1059 */       this.g43.setElementContentGrammar((Grammar)this.g34);
/* 1060 */       this.g44.setElementContentGrammar((Grammar)this.g45);
/* 1061 */       this.g46.setElementContentGrammar((Grammar)this.g47);
/* 1062 */       this.g48.setElementContentGrammar((Grammar)this.g49);
/* 1063 */       this.g50.setElementContentGrammar((Grammar)this.g51);
/* 1064 */       this.g52.setElementContentGrammar((Grammar)this.g53);
/* 1065 */       this.g54.setElementContentGrammar((Grammar)this.g55);
/* 1066 */       this.g56.setElementContentGrammar((Grammar)this.g57);
/* 1067 */       this.g58.setElementContentGrammar((Grammar)this.g59);
/* 1068 */       this.g60.setElementContentGrammar((Grammar)this.g61);
/* 1069 */       this.g62.setElementContentGrammar((Grammar)this.g63);
/* 1070 */       this.g64.setElementContentGrammar((Grammar)this.g65);
/* 1071 */       this.g66.setElementContentGrammar((Grammar)this.g67);
/* 1072 */       this.g68.setElementContentGrammar((Grammar)this.g69);
/* 1073 */       this.g70.setElementContentGrammar((Grammar)this.g71);
/* 1074 */       this.g72.setElementContentGrammar((Grammar)this.g73);
/* 1075 */       this.g74.setElementContentGrammar((Grammar)this.g75);
/* 1076 */       this.g76.setElementContentGrammar((Grammar)this.g77);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSchemaInformed() {
/* 1082 */       return true;
/*      */     }
/*      */     
/*      */     public String getSchemaId() {
/* 1086 */       return this.schemaId;
/*      */     }
/*      */     
/*      */     public void setSchemaId(String schemaId) throws UnsupportedOption {
/* 1090 */       this.schemaId = schemaId;
/*      */     }
/*      */     
/*      */     public boolean isBuiltInXMLSchemaTypesOnly() {
/* 1094 */       return false;
/*      */     }
/*      */     
/*      */     public Grammar getDocumentGrammar() {
/* 1098 */       return (Grammar)this.g0;
/*      */     }
/*      */     
/*      */     public Grammar getFragmentGrammar() {
/* 1102 */       return (Grammar)this.g39;
/*      */     }
/*      */     
/*      */     public GrammarContext getGrammarContext() {
/* 1106 */       return this.gc;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\AbstractEXIHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */