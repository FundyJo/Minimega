/*     */ package com.siemens.ct.exi.core.types;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.DatetimeDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.EnumDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.EnumerationDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.ExtendedStringDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.ListDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.NBitUnsignedIntegerDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.RestrictedCharacterSetDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringCoder;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringDecoder;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.io.channel.DecoderChannel;
/*     */ import com.siemens.ct.exi.core.values.BinaryBase64Value;
/*     */ import com.siemens.ct.exi.core.values.BinaryHexValue;
/*     */ import com.siemens.ct.exi.core.values.BooleanValue;
/*     */ import com.siemens.ct.exi.core.values.IntegerValue;
/*     */ import com.siemens.ct.exi.core.values.ListValue;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypedTypeDecoder
/*     */   extends AbstractTypeDecoder
/*     */ {
/*     */   public TypedTypeDecoder() throws EXIException {
/*  62 */     this((QName[])null, (QName[])null, (Map<QName, Datatype>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedTypeDecoder(QName[] dtrMapTypes, QName[] dtrMapRepresentations, Map<QName, Datatype> dtrMapRepresentationsDatatype) throws EXIException {
/*  68 */     super(dtrMapTypes, dtrMapRepresentations, dtrMapRepresentationsDatatype); } public Value readValue(Datatype datatype, QNameContext qnContext, DecoderChannel valueChannel, StringDecoder stringDecoder) throws IOException { int booleanID; NBitUnsignedIntegerDatatype nbitDT; IntegerValue iv; DatetimeDatatype dtDT; RestrictedCharacterSetDatatype rcsDT; ExtendedStringDatatype esDT; EnumerationDatatype enumDT; int index;
/*     */     ListDatatype lDT;
/*     */     Datatype listDatatype;
/*     */     int len;
/*     */     Value[] values;
/*     */     int l;
/*  74 */     if (this.dtrMapInUse) {
/*  75 */       datatype = getDtrDatatype(datatype);
/*     */     }
/*     */     
/*  78 */     switch (datatype.getBuiltInType()) {
/*     */       case BINARY_BASE64:
/*  80 */         return (Value)new BinaryBase64Value(valueChannel.decodeBinary());
/*     */       case BINARY_HEX:
/*  82 */         return (Value)new BinaryHexValue(valueChannel.decodeBinary());
/*     */       case BOOLEAN:
/*  84 */         return (Value)valueChannel.decodeBooleanValue();
/*     */       case BOOLEAN_FACET:
/*  86 */         booleanID = valueChannel.decodeNBitUnsignedInteger(2);
/*  87 */         return (Value)BooleanValue.getBooleanValue(booleanID);
/*     */       case DECIMAL:
/*  89 */         return (Value)valueChannel.decodeDecimalValue();
/*     */       case FLOAT:
/*  91 */         return (Value)valueChannel.decodeFloatValue();
/*     */       case NBIT_UNSIGNED_INTEGER:
/*  93 */         nbitDT = (NBitUnsignedIntegerDatatype)datatype;
/*     */         
/*  95 */         iv = valueChannel.decodeNBitUnsignedIntegerValue(nbitDT.getNumberOfBits());
/*  96 */         return (Value)iv.add(nbitDT.getLowerBound());
/*     */       case UNSIGNED_INTEGER:
/*  98 */         return (Value)valueChannel.decodeUnsignedIntegerValue();
/*     */       case INTEGER:
/* 100 */         return (Value)valueChannel.decodeIntegerValue();
/*     */       case DATETIME:
/* 102 */         dtDT = (DatetimeDatatype)datatype;
/* 103 */         return (Value)valueChannel.decodeDateTimeValue(dtDT.getDatetimeType());
/*     */       case STRING:
/* 105 */         return (Value)stringDecoder.readValue(qnContext, valueChannel);
/*     */       case RCS_STRING:
/* 107 */         rcsDT = (RestrictedCharacterSetDatatype)datatype;
/* 108 */         return readRCSValue(rcsDT, qnContext, valueChannel, stringDecoder);
/*     */       case EXTENDED_STRING:
/* 110 */         esDT = (ExtendedStringDatatype)datatype;
/* 111 */         return (Value)readExtendedString(esDT, qnContext, valueChannel, stringDecoder);
/*     */       
/*     */       case ENUMERATION:
/* 114 */         enumDT = (EnumerationDatatype)datatype;
/* 115 */         index = valueChannel.decodeNBitUnsignedInteger(enumDT
/* 116 */             .getCodingLength());
/* 117 */         assert index >= 0 && index < enumDT.getEnumerationSize();
/* 118 */         return enumDT.getEnumValue(index);
/*     */       case LIST:
/* 120 */         lDT = (ListDatatype)datatype;
/* 121 */         listDatatype = lDT.getListDatatype();
/*     */         
/* 123 */         len = valueChannel.decodeUnsignedInteger();
/* 124 */         values = new Value[len];
/* 125 */         for (l = 0; l < len; l++) {
/* 126 */           values[l] = readValue(listDatatype, qnContext, valueChannel, stringDecoder);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 131 */         return (Value)new ListValue(values, listDatatype);
/*     */ 
/*     */ 
/*     */       
/*     */       case QNAME:
/* 136 */         throw new IOException("QName is not an allowed as EXI datatype");
/*     */     } 
/*     */     
/* 139 */     return null; }
/*     */ 
/*     */   
/*     */   protected StringValue readExtendedString(ExtendedStringDatatype esDT, QNameContext context, DecoderChannel valueChannel, StringDecoder stringDecoder) throws IOException {
/*     */     int index;
/*     */     Value v;
/*     */     int L;
/* 146 */     EnumDatatype grammarStrings = esDT.getGrammarStrings();
/*     */     
/* 148 */     StringValue value = null;
/*     */     
/* 150 */     int i = valueChannel.decodeUnsignedInteger();
/*     */     
/* 152 */     switch (i) {
/*     */       
/*     */       case 0:
/* 155 */         if (stringDecoder.isLocalValuePartitions()) {
/* 156 */           value = stringDecoder.readValueLocalHit(context, valueChannel); break;
/*     */         } 
/* 158 */         throw new IOException("EXI stream contains local-value hit even though profile options indicate otherwise.");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 164 */         value = stringDecoder.readValueGlobalHit(valueChannel);
/*     */         break;
/*     */       
/*     */       case 2:
/* 168 */         index = valueChannel.decodeNBitUnsignedInteger(grammarStrings
/* 169 */             .getCodingLength());
/* 170 */         assert index >= 0 && index < grammarStrings.getEnumerationSize();
/* 171 */         v = grammarStrings.getEnumValue(index);
/*     */ 
/*     */ 
/*     */         
/* 175 */         if (v instanceof StringValue) {
/* 176 */           value = (StringValue)v; break;
/*     */         } 
/* 178 */         value = new StringValue(v.toString());
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/* 183 */         throw new IOException("ExtendedString, no support for <shared string>");
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 188 */         throw new IOException("ExtendedString, no support for <split string>");
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 193 */         throw new IOException("ExtendedString, no support for <undefined>");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 199 */         L = i - 6;
/*     */ 
/*     */ 
/*     */         
/* 203 */         if (L > 0) {
/* 204 */           value = new StringValue(valueChannel.decodeStringOnly(L));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 210 */           stringDecoder.addValue(context, value); break;
/*     */         } 
/* 212 */         value = StringCoder.EMPTY_STRING_VALUE;
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 217 */     assert value != null;
/* 218 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\TypedTypeDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */