/*     */ package com.siemens.ct.exi.core.io.compression;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ import java.util.zip.ZipException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIInflaterInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   protected Inflater inf;
/*     */   protected byte[] buf;
/*     */   protected int len;
/*     */   private boolean closed = false;
/*     */   private boolean reachEOF = false;
/*     */   boolean usesDefaultInflater;
/*     */   private byte[] singleByteBuf;
/*     */   private byte[] b;
/*     */   
/*     */   private void ensureOpen() throws IOException {
/*  71 */     if (this.closed) {
/*  72 */       throw new IOException("Stream closed");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EXIInflaterInputStream(PushbackInputStream in, Inflater inf, int size) {
/*  90 */     super(in);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     this.usesDefaultInflater = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     this.singleByteBuf = new byte[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     this.b = new byte[512];
/*     */     if (in == null || inf == null)
/*     */       throw new NullPointerException(); 
/*     */     if (size <= 0)
/*     */       throw new IllegalArgumentException("buffer size <= 0"); 
/*     */     this.inf = inf;
/*     */     this.buf = new byte[size];
/*     */   } public void pushbackAndReset() throws IOException { while (!this.inf.finished() && this.in.available() > 0)
/*     */       read(); 
/*     */     int rem = this.inf.getRemaining();
/*     */     if (rem > 0)
/*     */       ((PushbackInputStream)this.in).unread(this.buf, this.len - rem, rem); 
/*     */     this.inf.reset(); } public int read() throws IOException { ensureOpen();
/*     */     return (read(this.singleByteBuf, 0, 1) == -1) ? -1 : (this.singleByteBuf[0] & 0xFF); }
/* 239 */   public long skip(long n) throws IOException { if (n < 0L) {
/* 240 */       throw new IllegalArgumentException("negative skip length");
/*     */     }
/* 242 */     ensureOpen();
/* 243 */     int max = (int)Math.min(n, 2147483647L);
/* 244 */     int total = 0;
/* 245 */     while (total < max) {
/* 246 */       int len = max - total;
/* 247 */       if (len > this.b.length) {
/* 248 */         len = this.b.length;
/*     */       }
/* 250 */       len = read(this.b, 0, len);
/* 251 */       if (len == -1) {
/* 252 */         this.reachEOF = true;
/*     */         break;
/*     */       } 
/* 255 */       total += len;
/*     */     } 
/* 257 */     return total; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 268 */     if (!this.closed) {
/* 269 */       if (this.usesDefaultInflater)
/* 270 */         this.inf.end(); 
/* 271 */       this.in.close();
/* 272 */       this.closed = true;
/*     */     } 
/*     */   }
/*     */   public int read(byte[] b, int off, int len) throws IOException { ensureOpen(); if ((off | len | off + len | b.length - off + len) < 0)
/*     */       throw new IndexOutOfBoundsException();  if (len == 0)
/*     */       return 0;  try { int n; while ((n = this.inf.inflate(b, off, len)) == 0) { if (this.inf.finished() || this.inf.needsDictionary()) { this.reachEOF = true; return -1; }
/*     */          if (this.inf.needsInput())
/*     */           fill();  }
/*     */        return n; }
/*     */     catch (DataFormatException e) { String s = e.getMessage(); throw new ZipException((s != null) ? s : "Invalid ZLIB data format"); }
/*     */      } public int available() throws IOException { ensureOpen(); if (this.reachEOF)
/* 283 */       return 0;  return 1; } protected void fill() throws IOException { ensureOpen();
/* 284 */     this.len = this.in.read(this.buf, 0, this.buf.length);
/* 285 */     if (this.len == -1) {
/* 286 */       throw new EOFException("Unexpected end of ZLIB input stream");
/*     */     }
/* 288 */     this.inf.setInput(this.buf, 0, this.len); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 302 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void mark(int readlimit) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void reset() throws IOException {
/* 334 */     throw new IOException("mark/reset not supported");
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\compression\EXIInflaterInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */