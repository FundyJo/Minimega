/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DatatypeID
/*    */ {
/* 35 */   exi_base64Binary,
/*    */   
/* 37 */   exi_hexBinary,
/*    */   
/* 39 */   exi_boolean,
/*    */   
/* 41 */   exi_dateTime,
/*    */   
/* 43 */   exi_time,
/*    */   
/* 45 */   exi_date,
/*    */   
/* 47 */   exi_gYearMonth,
/*    */   
/* 49 */   exi_gYear,
/*    */   
/* 51 */   exi_gMonthDay,
/*    */   
/* 53 */   exi_gDay,
/*    */   
/* 55 */   exi_gMonth,
/*    */   
/* 57 */   exi_decimal,
/*    */   
/* 59 */   exi_double,
/*    */   
/* 61 */   exi_integer,
/*    */   
/* 63 */   exi_string,
/*    */   
/* 65 */   exi_estring;
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\DatatypeID.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */