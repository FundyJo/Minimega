/*    */ package com.siemens.ct.exi.core.grammars.event;
/*    */ 
/*    */ import com.siemens.ct.exi.core.datatype.Datatype;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Characters
/*    */   extends AbstractDatatypeEvent
/*    */ {
/*    */   public Characters(Datatype datatype) {
/* 39 */     super(EventType.CHARACTERS, datatype);
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 43 */     if (super.equals(o)) {
/*    */       
/* 45 */       Characters ch = (Characters)o;
/*    */ 
/*    */       
/* 48 */       return this.datatype.getBuiltInType().equals(ch
/* 49 */           .getDatatype().getBuiltInType());
/*    */     } 
/* 51 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\Characters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */