/*     */ package com.siemens.ct.exi.core.values;
/*     */ 
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DecimalValue
/*     */   extends AbstractValue
/*     */ {
/*     */   protected final boolean negative;
/*     */   protected final IntegerValue integral;
/*     */   protected final IntegerValue revFractional;
/*     */   protected BigDecimal bd;
/*     */   protected StringBuilder sbHelper;
/*     */   
/*     */   public DecimalValue(boolean negative, IntegerValue integral, IntegerValue revFractional) {
/*  50 */     super(ValueType.DECIMAL);
/*     */     
/*  52 */     if (negative && IntegerValue.ZERO.equals(integral) && IntegerValue.ZERO
/*  53 */       .equals(revFractional)) {
/*  54 */       negative = false;
/*     */     }
/*  56 */     this.negative = negative;
/*  57 */     this.integral = integral;
/*  58 */     this.revFractional = revFractional;
/*     */   }
/*     */   
/*     */   public boolean isNegative() {
/*  62 */     return this.negative;
/*     */   }
/*     */   
/*     */   public IntegerValue getIntegral() {
/*  66 */     return this.integral;
/*     */   }
/*     */   
/*     */   public IntegerValue getRevFractional() {
/*  70 */     return this.revFractional;
/*     */   }
/*     */ 
/*     */   
/*     */   public static DecimalValue parse(BigDecimal decimal) {
/*  75 */     boolean negative = (decimal.signum() == -1);
/*  76 */     if (negative) {
/*  77 */       decimal = decimal.negate();
/*     */     }
/*     */ 
/*     */     
/*  81 */     BigDecimal fractional = decimal.remainder(BigDecimal.ONE);
/*     */ 
/*     */     
/*  84 */     IntegerValue revFractional = IntegerValue.parse(reverseString(fractional.toPlainString().substring(2)));
/*     */ 
/*     */     
/*  87 */     IntegerValue integral = IntegerValue.valueOf(decimal.subtract(fractional)
/*  88 */         .toBigInteger());
/*     */     
/*  90 */     return new DecimalValue(negative, integral, revFractional);
/*     */   }
/*     */ 
/*     */   
/*     */   public static DecimalValue parse(String decimal) {
/*     */     try {
/*     */       IntegerValue sIntegral, sRevFractional;
/*  97 */       decimal = decimal.trim();
/*     */       
/*  99 */       boolean sNegative = false;
/*     */       
/* 101 */       if (decimal.charAt(0) == '-') {
/* 102 */         sNegative = true;
/* 103 */         decimal = decimal.substring(1);
/* 104 */       } else if (decimal.charAt(0) == '+') {
/*     */         
/* 106 */         decimal = decimal.substring(1);
/*     */       } 
/*     */ 
/*     */       
/* 110 */       int decPoint = decimal.indexOf('.');
/*     */       
/* 112 */       if (decPoint == -1) {
/*     */         
/* 114 */         sIntegral = IntegerValue.parse(decimal);
/*     */         
/* 116 */         sRevFractional = IntegerValue.ZERO;
/*     */       }
/* 118 */       else if (decPoint == 0) {
/*     */         
/* 120 */         sIntegral = IntegerValue.ZERO;
/* 121 */         sRevFractional = IntegerValue.parse((new StringBuilder(decimal
/* 122 */               .substring(decPoint + 1, decimal.length()))).reverse()
/* 123 */             .toString());
/*     */       } else {
/* 125 */         sIntegral = IntegerValue.parse(decimal.substring(0, decPoint));
/* 126 */         sRevFractional = IntegerValue.parse(reverseString(decimal
/* 127 */               .substring(decPoint + 1, decimal.length())));
/*     */       } 
/* 129 */       if (sIntegral == null || sRevFractional == null) {
/* 130 */         return null;
/*     */       }
/* 132 */       return new DecimalValue(sNegative, sIntegral, sRevFractional);
/*     */     }
/* 134 */     catch (Exception e) {
/* 135 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String reverseString(String s) {
/* 141 */     return (new StringBuilder(s)).reverse().toString();
/*     */   }
/*     */   
/*     */   public BigDecimal toBigDecimal() {
/* 145 */     if (this.bd == null) {
/* 146 */       char[] characters = new char[getCharactersLength()];
/* 147 */       getCharacters(characters, 0);
/* 148 */       this.bd = new BigDecimal(characters);
/*     */     } 
/* 150 */     return this.bd;
/*     */   }
/*     */   
/*     */   public int getCharactersLength() {
/* 154 */     if (this.slen == -1)
/*     */     {
/* 156 */       this
/* 157 */         .slen = (this.negative ? 1 : 0) + this.integral.getCharactersLength() + 1 + this.revFractional.getCharactersLength();
/*     */     }
/* 159 */     return this.slen;
/*     */   }
/*     */   
/*     */   public void getCharacters(char[] cbuffer, int offset) {
/*     */     int len;
/* 164 */     if (this.negative) {
/* 165 */       cbuffer[offset++] = '-';
/*     */     }
/*     */     
/* 168 */     this.integral.getCharacters(cbuffer, offset);
/* 169 */     offset += this.integral.getCharactersLength();
/*     */     
/* 171 */     cbuffer[offset++] = '.';
/*     */     
/* 173 */     switch (this.revFractional.getIntegerValueType()) {
/*     */       case INT:
/* 175 */         MethodsBag.itosReverse(this.revFractional.ival, offset, cbuffer);
/*     */         return;
/*     */       case LONG:
/* 178 */         MethodsBag.itosReverse(this.revFractional.lval, offset, cbuffer);
/*     */         return;
/*     */       
/*     */       case BIG:
/* 182 */         if (this.sbHelper == null) {
/* 183 */           this.sbHelper = new StringBuilder(this.revFractional.bval.toString());
/*     */         } else {
/* 185 */           this.sbHelper.setLength(0);
/* 186 */           this.sbHelper.append(this.revFractional.bval.toString());
/*     */         } 
/* 188 */         this.sbHelper = this.sbHelper.reverse();
/*     */         
/* 190 */         len = this.sbHelper.length();
/* 191 */         this.sbHelper.getChars(0, len, cbuffer, offset);
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 196 */     throw new RuntimeException("Unknown Int Type: " + this.revFractional.valueType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean _equals(DecimalValue o) {
/* 204 */     return (this.negative == o.negative && this.integral.equals(o.integral) && this.revFractional
/* 205 */       .equals(o.revFractional));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 210 */     if (o == null) {
/* 211 */       return false;
/*     */     }
/* 213 */     if (o instanceof DecimalValue) {
/* 214 */       return _equals((DecimalValue)o);
/*     */     }
/* 216 */     DecimalValue dv = parse(o.toString());
/* 217 */     return (dv == null) ? false : _equals(dv);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 223 */     return (this.negative ? 1 : 0) ^ this.integral.hashCode() ^ this.revFractional
/* 224 */       .hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\DecimalValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */