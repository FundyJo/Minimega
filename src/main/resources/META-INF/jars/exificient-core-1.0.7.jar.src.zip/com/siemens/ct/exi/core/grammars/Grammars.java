package com.siemens.ct.exi.core.grammars;

import com.siemens.ct.exi.core.context.GrammarContext;
import com.siemens.ct.exi.core.exceptions.UnsupportedOption;
import com.siemens.ct.exi.core.grammars.grammar.Grammar;

public interface Grammars {
  boolean isSchemaInformed();
  
  String getSchemaId();
  
  void setSchemaId(String paramString) throws UnsupportedOption;
  
  boolean isBuiltInXMLSchemaTypesOnly();
  
  Grammar getDocumentGrammar();
  
  Grammar getFragmentGrammar();
  
  GrammarContext getGrammarContext();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\Grammars.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */