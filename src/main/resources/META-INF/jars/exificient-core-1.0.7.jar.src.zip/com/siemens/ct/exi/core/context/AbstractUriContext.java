/*    */ package com.siemens.ct.exi.core.context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractUriContext
/*    */   implements UriContext
/*    */ {
/*    */   final int namespaceUriID;
/*    */   final String namespaceUri;
/*    */   
/*    */   public AbstractUriContext(int namespaceUriID, String namespaceUri) {
/* 40 */     this.namespaceUriID = namespaceUriID;
/* 41 */     this.namespaceUri = namespaceUri;
/*    */   }
/*    */   
/*    */   public final int getNamespaceUriID() {
/* 45 */     return this.namespaceUriID;
/*    */   }
/*    */   
/*    */   public final String getNamespaceUri() {
/* 49 */     return this.namespaceUri;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 54 */     if (o instanceof AbstractUriContext) {
/* 55 */       return (((AbstractUriContext)o).namespaceUriID == this.namespaceUriID);
/*    */     }
/* 57 */     return false;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 61 */     return this.namespaceUriID + "," + this.namespaceUri;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\context\AbstractUriContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */