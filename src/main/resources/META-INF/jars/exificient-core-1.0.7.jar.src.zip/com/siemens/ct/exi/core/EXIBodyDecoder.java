package com.siemens.ct.exi.core;

import com.siemens.ct.exi.core.container.DocType;
import com.siemens.ct.exi.core.container.NamespaceDeclaration;
import com.siemens.ct.exi.core.container.ProcessingInstruction;
import com.siemens.ct.exi.core.context.QNameContext;
import com.siemens.ct.exi.core.exceptions.EXIException;
import com.siemens.ct.exi.core.grammars.event.EventType;
import com.siemens.ct.exi.core.io.channel.DecoderChannel;
import com.siemens.ct.exi.core.values.Value;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public interface EXIBodyDecoder {
  void setInputStream(InputStream paramInputStream) throws EXIException, IOException;
  
  void setInputChannel(DecoderChannel paramDecoderChannel) throws EXIException, IOException;
  
  void updateInputStream(InputStream paramInputStream) throws EXIException, IOException;
  
  void updateInputChannel(DecoderChannel paramDecoderChannel) throws EXIException, IOException;
  
  EventType next() throws EXIException, IOException;
  
  void decodeStartDocument() throws EXIException, IOException;
  
  void decodeEndDocument() throws EXIException, IOException;
  
  QNameContext decodeStartElement() throws EXIException, IOException;
  
  String getElementPrefix();
  
  String getElementQNameAsString();
  
  void decodeStartSelfContainedFragment() throws EXIException, IOException;
  
  QNameContext decodeEndElement() throws EXIException, IOException;
  
  QNameContext decodeAttributeXsiNil() throws EXIException, IOException;
  
  QNameContext decodeAttributeXsiType() throws EXIException, IOException;
  
  QNameContext decodeAttribute() throws EXIException, IOException;
  
  String getAttributePrefix();
  
  String getAttributeQNameAsString();
  
  Value getAttributeValue();
  
  NamespaceDeclaration decodeNamespaceDeclaration() throws EXIException, IOException;
  
  List<NamespaceDeclaration> getDeclaredPrefixDeclarations();
  
  Value decodeCharacters() throws EXIException, IOException;
  
  DocType decodeDocType() throws EXIException, IOException;
  
  char[] decodeEntityReference() throws EXIException, IOException;
  
  char[] decodeComment() throws EXIException, IOException;
  
  ProcessingInstruction decodeProcessingInstruction() throws EXIException, IOException;
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\EXIBodyDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */