/*     */ package com.siemens.ct.exi.core.values;
/*     */ 
/*     */ import com.siemens.ct.exi.core.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatValue
/*     */   extends AbstractValue
/*     */ {
/*     */   protected final IntegerValue mantissa;
/*     */   protected final IntegerValue exponent;
/*  43 */   protected int slenMantissa = -1;
/*     */ 
/*     */   
/*  46 */   public static IntegerValue FLOAT_SPECIAL_VALUES = IntegerValue.valueOf(-16384);
/*     */   
/*  48 */   public static IntegerValue FLOAT_NEGATIVE_INFINITY = IntegerValue.valueOf(-1);
/*     */   
/*  50 */   public static IntegerValue FLOAT_POSITIVE_INFINITY = IntegerValue.valueOf(1);
/*  51 */   public static IntegerValue FLOAT_NaN = IntegerValue.ZERO;
/*     */   
/*     */   protected Double f;
/*     */   
/*     */   public FloatValue(IntegerValue mantissa, IntegerValue exponent) {
/*  56 */     super(ValueType.FLOAT);
/*     */ 
/*     */     
/*  59 */     if (IntegerValue.ZERO.equals(mantissa)) {
/*     */ 
/*     */ 
/*     */       
/*  63 */       if (!FLOAT_SPECIAL_VALUES.equals(exponent)) {
/*  64 */         exponent = IntegerValue.ZERO;
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  69 */       long lm = mantissa.longValue();
/*  70 */       long le = exponent.longValue();
/*  71 */       boolean modified = false;
/*  72 */       while (lm % 10L == 0L) {
/*     */         
/*  74 */         lm /= 10L;
/*  75 */         le++;
/*  76 */         modified = true;
/*     */       } 
/*  78 */       if (modified) {
/*  79 */         mantissa = IntegerValue.valueOf(lm);
/*  80 */         exponent = IntegerValue.valueOf(le);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  86 */     if (FLOAT_SPECIAL_VALUES.equals(exponent) && 
/*  87 */       !FLOAT_NEGATIVE_INFINITY.equals(mantissa) && 
/*  88 */       !FLOAT_POSITIVE_INFINITY.equals(mantissa)) {
/*  89 */       mantissa = FLOAT_NaN;
/*     */     }
/*     */     
/*  92 */     this.mantissa = mantissa;
/*  93 */     this.exponent = exponent;
/*     */   }
/*     */   
/*     */   public FloatValue(long mantissa, long exponent) {
/*  97 */     this(IntegerValue.valueOf(mantissa), IntegerValue.valueOf(exponent));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerValue getMantissa() {
/* 106 */     return this.mantissa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerValue getExponent() {
/* 115 */     return this.exponent;
/*     */   }
/*     */   
/*     */   public static FloatValue parse(String value) {
/*     */     try {
/*     */       long sMantissa, sExponent;
/* 121 */       value = value.trim();
/* 122 */       if (value.length() == 0)
/* 123 */         return null; 
/* 124 */       if (value.equals("INF")) {
/* 125 */         sMantissa = 1L;
/* 126 */         sExponent = -16384L;
/* 127 */       } else if (value.equals("-INF")) {
/* 128 */         sMantissa = -1L;
/* 129 */         sExponent = -16384L;
/* 130 */       } else if (value.equals("NaN")) {
/* 131 */         sMantissa = 0L;
/* 132 */         sExponent = -16384L;
/*     */       }
/*     */       else {
/*     */         
/* 136 */         int indexE = value.indexOf('E');
/* 137 */         if (indexE == -1) {
/* 138 */           indexE = value.indexOf('e');
/*     */         }
/*     */ 
/*     */         
/* 142 */         char[] chars = value.toCharArray();
/*     */         
/*     */         char c;
/* 145 */         boolean negative = ((c = chars[0]) == '-');
/*     */         
/* 147 */         int lenMantissa = (indexE == -1) ? chars.length : indexE;
/* 148 */         int startMantissa = (negative || c == '+') ? 1 : 0;
/*     */         
/* 150 */         boolean decPoint = false;
/* 151 */         int decimalDigits = 0;
/* 152 */         sMantissa = 0L;
/* 153 */         sExponent = 0L;
/*     */ 
/*     */         
/* 156 */         if (lenMantissa == 0) {
/* 157 */           return null;
/*     */         }
/*     */ 
/*     */         
/* 161 */         for (int i = startMantissa; i < lenMantissa; i++) {
/* 162 */           c = chars[i];
/* 163 */           switch (c) {
/*     */             case '0':
/*     */             case '1':
/*     */             case '2':
/*     */             case '3':
/*     */             case '4':
/*     */             case '5':
/*     */             case '6':
/*     */             case '7':
/*     */             case '8':
/*     */             case '9':
/* 174 */               sMantissa = 10L * sMantissa + (c - 48);
/* 175 */               if (decPoint) {
/* 176 */                 decimalDigits++;
/*     */               }
/*     */               break;
/*     */             case '.':
/* 180 */               if (decPoint)
/*     */               {
/* 182 */                 return null;
/*     */               }
/* 184 */               decPoint = true;
/*     */               break;
/*     */             default:
/* 187 */               return null;
/*     */           } 
/*     */ 
/*     */         
/*     */         } 
/* 192 */         if (sMantissa < 0L) {
/* 193 */           if (negative) {
/* 194 */             if (sMantissa != Long.MIN_VALUE) {
/* 195 */               return null;
/*     */             }
/*     */           } else {
/* 198 */             return null;
/*     */           } 
/*     */         }
/*     */         
/* 202 */         if (negative) {
/* 203 */           sMantissa = -1L * sMantissa;
/*     */         }
/*     */ 
/*     */         
/* 207 */         boolean negativeExp = false;
/* 208 */         if (indexE != -1) {
/* 209 */           for (int j = indexE + 1; j < chars.length; j++) {
/* 210 */             c = chars[j];
/* 211 */             switch (c) {
/*     */               case '0':
/* 213 */                 sExponent = 10L * sExponent;
/*     */                 break;
/*     */               case '1':
/*     */               case '2':
/*     */               case '3':
/*     */               case '4':
/*     */               case '5':
/*     */               case '6':
/*     */               case '7':
/*     */               case '8':
/*     */               case '9':
/* 224 */                 sExponent = 10L * sExponent + (c - 48);
/*     */                 break;
/*     */               case '-':
/* 227 */                 if (negativeExp)
/*     */                 {
/* 229 */                   return null;
/*     */                 }
/* 231 */                 negativeExp = true;
/*     */                 break;
/*     */               case '+':
/*     */                 break;
/*     */               default:
/* 236 */                 return null;
/*     */             } 
/*     */           
/*     */           } 
/*     */         }
/* 241 */         sExponent = negativeExp ? (-1L * sExponent) : sExponent;
/* 242 */         sExponent -= decimalDigits;
/*     */ 
/*     */         
/* 245 */         if (sMantissa < Long.MIN_VALUE || sMantissa > Long.MAX_VALUE || sExponent < -16383L || sExponent > 16383L)
/*     */         {
/*     */ 
/*     */           
/* 249 */           return null;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 256 */       return new FloatValue(sMantissa, sExponent);
/* 257 */     } catch (Exception e) {
/*     */       
/* 259 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static FloatValue parse(float f) {
/*     */     int sMantissa;
/*     */     int sExponent;
/* 266 */     if (Float.isInfinite(f) || Float.isNaN(f)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 271 */       if (Float.isNaN(f)) {
/* 272 */         sMantissa = 0;
/* 273 */       } else if (f < 0.0F) {
/* 274 */         sMantissa = -1;
/*     */       } else {
/* 276 */         sMantissa = 1;
/*     */       } 
/*     */       
/* 279 */       sExponent = -16384;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 285 */       sExponent = 0;
/* 286 */       while (f - (int)f != 0.0F) {
/* 287 */         f *= 10.0F;
/* 288 */         sExponent--;
/*     */       } 
/* 290 */       sMantissa = (int)f;
/*     */     } 
/* 292 */     return new FloatValue(sMantissa, sExponent);
/*     */   }
/*     */   
/*     */   public static FloatValue parse(double d) {
/*     */     long sMantissa;
/*     */     long sExponent;
/* 298 */     if (Double.isInfinite(d) || Double.isNaN(d)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 303 */       if (Double.isNaN(d)) {
/* 304 */         sMantissa = 0L;
/* 305 */       } else if (d < 0.0D) {
/* 306 */         sMantissa = -1L;
/*     */       } else {
/* 308 */         sMantissa = 1L;
/*     */       } 
/*     */       
/* 311 */       sExponent = -16384L;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 317 */       sExponent = 0L;
/* 318 */       while (d - (long)d != 0.0D) {
/* 319 */         d *= 10.0D;
/* 320 */         sExponent--;
/*     */       } 
/* 322 */       sMantissa = (long)d;
/*     */     } 
/* 324 */     return new FloatValue(sMantissa, sExponent);
/*     */   }
/*     */   
/*     */   public Float toFloat() {
/* 328 */     if (this.f == null) {
/* 329 */       toDouble();
/*     */     }
/* 331 */     return Float.valueOf(this.f.floatValue());
/*     */   }
/*     */   
/*     */   public Double toDouble() {
/* 335 */     if (this.f == null) {
/* 336 */       if (this.exponent.equals(FLOAT_SPECIAL_VALUES)) {
/* 337 */         if (this.mantissa.equals(FLOAT_NEGATIVE_INFINITY)) {
/* 338 */           this.f = Double.valueOf(Double.NEGATIVE_INFINITY);
/* 339 */         } else if (this.mantissa.equals(FLOAT_POSITIVE_INFINITY)) {
/* 340 */           this.f = Double.valueOf(Double.POSITIVE_INFINITY);
/*     */         } else {
/* 342 */           this.f = Double.valueOf(Double.NaN);
/*     */         } 
/*     */       } else {
/*     */         
/* 346 */         long lMantissa = this.mantissa.longValue();
/* 347 */         long lExponent = this.exponent.longValue();
/*     */         
/* 349 */         this.f = Double.valueOf(lMantissa * Math.pow(10.0D, lExponent));
/*     */       } 
/*     */     }
/* 352 */     return this.f;
/*     */   }
/*     */   
/*     */   public int getCharactersLength() {
/* 356 */     if (this.slen == -1) {
/* 357 */       if (this.exponent.equals(FLOAT_SPECIAL_VALUES)) {
/* 358 */         if (this.mantissa.equals(FLOAT_NEGATIVE_INFINITY)) {
/* 359 */           this.slen = Constants.FLOAT_MINUS_INFINITY_CHARARRAY.length;
/* 360 */         } else if (this.mantissa.equals(FLOAT_POSITIVE_INFINITY)) {
/* 361 */           this.slen = Constants.FLOAT_INFINITY_CHARARRAY.length;
/*     */         } else {
/* 363 */           assert this.mantissa.equals(FLOAT_NaN);
/* 364 */           this.slen = Constants.FLOAT_NOT_A_NUMBER_CHARARRAY.length;
/*     */         } 
/*     */       } else {
/*     */         
/* 368 */         this.slenMantissa = this.mantissa.getCharactersLength();
/* 369 */         this.slen = this.slenMantissa + 1 + this.exponent.getCharactersLength();
/*     */       } 
/*     */     }
/* 372 */     return this.slen;
/*     */   }
/*     */   
/*     */   public void getCharacters(char[] cbuffer, int offset) {
/* 376 */     if (this.exponent.equals(FLOAT_SPECIAL_VALUES)) {
/*     */       char[] a2copy;
/* 378 */       if (this.mantissa.equals(FLOAT_NEGATIVE_INFINITY)) {
/*     */         
/* 380 */         a2copy = Constants.FLOAT_MINUS_INFINITY_CHARARRAY;
/* 381 */       } else if (this.mantissa.equals(FLOAT_POSITIVE_INFINITY)) {
/*     */         
/* 383 */         a2copy = Constants.FLOAT_INFINITY_CHARARRAY;
/*     */       } else {
/* 385 */         assert this.mantissa.equals(FLOAT_NaN);
/*     */         
/* 387 */         a2copy = Constants.FLOAT_NOT_A_NUMBER_CHARARRAY;
/*     */       } 
/* 389 */       System.arraycopy(a2copy, 0, cbuffer, offset, a2copy.length);
/*     */     } else {
/* 391 */       this.mantissa.getCharacters(cbuffer, offset);
/* 392 */       offset += this.slenMantissa;
/* 393 */       cbuffer[offset++] = 'E';
/* 394 */       this.exponent.getCharacters(cbuffer, offset);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 401 */     if (this.exponent.equals(FLOAT_SPECIAL_VALUES)) {
/* 402 */       if (this.mantissa.equals(FLOAT_NEGATIVE_INFINITY))
/* 403 */         return "-INF"; 
/* 404 */       if (this.mantissa.equals(FLOAT_POSITIVE_INFINITY)) {
/* 405 */         return "INF";
/*     */       }
/* 407 */       assert this.mantissa.equals(FLOAT_NaN);
/* 408 */       return "NaN";
/*     */     } 
/*     */     
/* 411 */     char[] cbuffer = new char[getCharactersLength()];
/* 412 */     getCharacters(cbuffer, 0);
/* 413 */     return new String(cbuffer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(char[] cbuffer, int offset) {
/* 419 */     if (this.exponent.equals(FLOAT_SPECIAL_VALUES)) {
/* 420 */       if (this.mantissa.equals(FLOAT_NEGATIVE_INFINITY))
/* 421 */         return "-INF"; 
/* 422 */       if (this.mantissa.equals(FLOAT_POSITIVE_INFINITY)) {
/* 423 */         return "INF";
/*     */       }
/* 425 */       assert this.mantissa.equals(FLOAT_NaN);
/* 426 */       return "NaN";
/*     */     } 
/*     */     
/* 429 */     return super.toString(cbuffer, offset);
/*     */   }
/*     */ 
/*     */   
/*     */   static long multiply(long a, long b) throws ArithmeticException {
/* 434 */     long result = a * b;
/*     */     
/* 436 */     if (a != 0L && result / a != b)
/*     */     {
/* 438 */       throw new ArithmeticException("Overflow");
/*     */     }
/*     */     
/* 441 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final boolean _equals(FloatValue o) {
/* 446 */     if (this.mantissa == o.mantissa && this.exponent == o.exponent) {
/* 447 */       return true;
/*     */     }
/* 449 */     if (this.mantissa.equals(o.mantissa) && this.exponent
/* 450 */       .equals(o.exponent)) {
/* 451 */       return true;
/*     */     }
/* 453 */     long tExponent = this.exponent.longValue();
/* 454 */     long oExponent = o.exponent.longValue();
/* 455 */     long tMantissa = this.mantissa.longValue();
/* 456 */     long oMantissa = o.mantissa.longValue();
/*     */     
/*     */     try {
/* 459 */       if (tExponent > oExponent) {
/*     */         
/* 461 */         long diff = tExponent - oExponent;
/* 462 */         for (int i = 0; i < diff; i++)
/*     */         {
/* 464 */           tMantissa = multiply(tMantissa, 10L);
/*     */         }
/*     */       } else {
/*     */         
/* 468 */         long diff = oExponent - tExponent;
/* 469 */         for (int i = 0; i < diff; i++)
/*     */         {
/* 471 */           oMantissa = multiply(oMantissa, 10L);
/*     */         }
/*     */       } 
/* 474 */       return (tMantissa == oMantissa);
/* 475 */     } catch (ArithmeticException e) {
/*     */       
/* 477 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 486 */     if (o == null) {
/* 487 */       return false;
/*     */     }
/* 489 */     if (o instanceof FloatValue) {
/* 490 */       return _equals((FloatValue)o);
/*     */     }
/* 492 */     FloatValue fv = parse(o.toString());
/* 493 */     return (fv == null) ? false : _equals(fv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 502 */     return this.mantissa.hashCode() ^ this.exponent.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\FloatValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */