/*    */ package com.siemens.ct.exi.core.grammars.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractEvent
/*    */   implements Event
/*    */ {
/*    */   protected final EventType eventType;
/*    */   
/*    */   public AbstractEvent(EventType eventType) {
/* 38 */     this.eventType = eventType;
/*    */   }
/*    */   
/*    */   public final EventType getEventType() {
/* 42 */     return this.eventType;
/*    */   }
/*    */   
/*    */   public boolean isEventType(EventType type) {
/* 46 */     return (type == this.eventType);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 50 */     return this.eventType.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 55 */     return this.eventType.ordinal();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 59 */     if (this == obj)
/* 60 */       return true; 
/* 61 */     if (obj instanceof AbstractEvent) {
/* 62 */       return (this.eventType == ((AbstractEvent)obj).eventType);
/*    */     }
/*    */     
/* 65 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\AbstractEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */