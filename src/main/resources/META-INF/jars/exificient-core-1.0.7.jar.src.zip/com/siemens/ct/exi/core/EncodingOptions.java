/*     */ package com.siemens.ct.exi.core;
/*     */ 
/*     */ import com.siemens.ct.exi.core.exceptions.UnsupportedOption;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncodingOptions
/*     */ {
/*     */   public static final String INCLUDE_COOKIE = "INCLUDE_COOKIE";
/*     */   public static final String INCLUDE_OPTIONS = "INCLUDE_OPTIONS";
/*     */   public static final String INCLUDE_SCHEMA_ID = "INCLUDE_SCHEMA_ID";
/*     */   public static final String RETAIN_ENTITY_REFERENCE = "KEEP_ENTITY_REFERENCES_UNRESOLVED";
/*     */   public static final String INCLUDE_XSI_SCHEMALOCATION = "INCLUDE_XSI_SCHEMALOCATION";
/*     */   public static final String INCLUDE_INSIGNIFICANT_XSI_NIL = "INCLUDE_INSIGNIFICANT_XSI_NIL";
/*     */   public static final String INCLUDE_PROFILE_VALUES = "INCLUDE_PROFILE_VALUES";
/*     */   public static final String UTC_TIME = "UTC_TIME";
/*     */   public static final String CANONICAL_EXI = "http://www.w3.org/TR/exi-c14n";
/*     */   public static final String DEFLATE_COMPRESSION_VALUE = "DEFLATE_COMPRESSION_VALUE";
/*  96 */   protected Map<String, Object> options = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EncodingOptions createDefault() {
/* 106 */     EncodingOptions ho = new EncodingOptions();
/* 107 */     return ho;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOption(String key) throws UnsupportedOption {
/* 126 */     setOption(key, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOption(String key, Object value) throws UnsupportedOption {
/* 147 */     if (key.equals("INCLUDE_COOKIE")) {
/* 148 */       this.options.put(key, null);
/* 149 */     } else if (key.equals("INCLUDE_OPTIONS")) {
/* 150 */       this.options.put(key, null);
/* 151 */     } else if (key.equals("INCLUDE_SCHEMA_ID")) {
/* 152 */       this.options.put(key, null);
/* 153 */     } else if (key.equals("KEEP_ENTITY_REFERENCES_UNRESOLVED")) {
/* 154 */       this.options.put(key, null);
/* 155 */     } else if (key.equals("INCLUDE_XSI_SCHEMALOCATION")) {
/* 156 */       this.options.put(key, null);
/* 157 */     } else if (key.equals("INCLUDE_INSIGNIFICANT_XSI_NIL")) {
/* 158 */       this.options.put(key, null);
/* 159 */     } else if (key.equals("INCLUDE_PROFILE_VALUES")) {
/* 160 */       this.options.put(key, null);
/* 161 */     } else if (key.equals("http://www.w3.org/TR/exi-c14n")) {
/* 162 */       this.options.put(key, null);
/*     */ 
/*     */ 
/*     */       
/* 166 */       setOption("INCLUDE_OPTIONS");
/* 167 */     } else if (key.equals("UTC_TIME")) {
/* 168 */       this.options.put(key, null);
/* 169 */     } else if (key.equals("DEFLATE_COMPRESSION_VALUE")) {
/* 170 */       if (value != null && value instanceof Integer) {
/* 171 */         this.options.put(key, value);
/*     */       } else {
/* 173 */         throw new UnsupportedOption("EncodingOption '" + key + "' requires value of type Integer");
/*     */       } 
/*     */     } else {
/*     */       
/* 177 */       throw new UnsupportedOption("EncodingOption '" + key + "' is unknown!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean unsetOption(String key) {
/* 192 */     boolean b = this.options.containsKey(key);
/* 193 */     this.options.remove(key);
/* 194 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOptionEnabled(String key) {
/* 205 */     return this.options.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getOptionValue(String key) {
/* 216 */     return this.options.get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 221 */     if (o instanceof EncodingOptions) {
/* 222 */       EncodingOptions other = (EncodingOptions)o;
/* 223 */       return this.options.equals(other.options);
/*     */     } 
/*     */     
/* 226 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 231 */     return this.options.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 236 */     return this.options.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\EncodingOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */