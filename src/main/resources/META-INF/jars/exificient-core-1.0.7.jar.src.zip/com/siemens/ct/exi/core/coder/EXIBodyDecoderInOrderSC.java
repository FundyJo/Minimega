/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.container.DocType;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.container.ProcessingInstruction;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIBodyDecoderInOrderSC
/*     */   extends EXIBodyDecoderInOrder
/*     */ {
/*     */   protected EXIBodyDecoderInOrderSC scDecoder;
/*     */   
/*     */   public EXIBodyDecoderInOrderSC(EXIFactory exiFactory) throws EXIException {
/*  53 */     super(exiFactory);
/*  54 */     assert this.fidelityOptions.isFidelityEnabled("SELF_CONTAINED");
/*     */   }
/*     */ 
/*     */   
/*     */   public void initForEachRun() throws EXIException, IOException {
/*  59 */     super.initForEachRun();
/*     */ 
/*     */     
/*  62 */     this.scDecoder = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void skipSCElement(long skip) throws IOException {
/*  67 */     assert this.nextEventType == EventType.SELF_CONTAINED;
/*  68 */     this.channel.align();
/*  69 */     for (int i = 0; i < skip; i++) {
/*  70 */       this.channel.decode();
/*     */     }
/*  72 */     popElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EventType next() throws EXIException, IOException {
/*  78 */     if (this.scDecoder == null) {
/*  79 */       return super.next();
/*     */     }
/*  81 */     EventType et = this.scDecoder.next();
/*  82 */     if (et == EventType.END_DOCUMENT) {
/*  83 */       this.scDecoder.decodeEndDocument();
/*     */ 
/*     */       
/*  86 */       this.channel.align();
/*     */       
/*  88 */       this.scDecoder = null;
/*  89 */       popElement();
/*  90 */       et = super.next();
/*     */     } 
/*     */     
/*  93 */     return et;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeStartDocument() throws EXIException {
/*  99 */     if (this.scDecoder == null) {
/* 100 */       super.decodeStartDocument();
/*     */     } else {
/* 102 */       this.scDecoder.decodeStartDocument();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void decodeEndDocument() throws EXIException, IOException {
/* 108 */     if (this.scDecoder == null) {
/* 109 */       super.decodeEndDocument();
/*     */     } else {
/* 111 */       throw new RuntimeException("[EXI] SC not closed properly?");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public QNameContext decodeStartElement() throws EXIException, IOException {
/* 117 */     if (this.scDecoder == null) {
/* 118 */       return super.decodeStartElement();
/*     */     }
/* 120 */     return this.scDecoder.decodeStartElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeStartSelfContainedFragment() throws EXIException, IOException {
/* 127 */     if (this.scDecoder == null) {
/*     */       
/* 129 */       EXIFactory scEXIFactory = this.exiFactory.clone();
/*     */       
/* 131 */       scEXIFactory.setFragment(true);
/* 132 */       this
/* 133 */         .scDecoder = (EXIBodyDecoderInOrderSC)scEXIFactory.createEXIBodyDecoder();
/* 134 */       this.scDecoder.channel = this.channel;
/* 135 */       this.scDecoder.setErrorHandler(this.errorHandler);
/* 136 */       this.scDecoder.initForEachRun();
/*     */ 
/*     */ 
/*     */       
/* 140 */       this.channel.align();
/*     */ 
/*     */ 
/*     */       
/* 144 */       this.scDecoder.decodeStartDocument();
/*     */       
/* 146 */       EventType et = next();
/* 147 */       switch (et) {
/*     */         case START_ELEMENT:
/*     */         case START_ELEMENT_NS:
/*     */         case START_ELEMENT_GENERIC:
/*     */         case START_ELEMENT_GENERIC_UNDECLARED:
/* 152 */           this.scDecoder.decodeStartElement();
/*     */           return;
/*     */       } 
/* 155 */       throw new RuntimeException("[EXI] Unsupported EventType " + et + " in SelfContained Element");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 160 */     this.scDecoder.decodeStartSelfContainedFragment();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QNameContext decodeEndElement() throws EXIException, IOException {
/* 166 */     if (this.scDecoder == null) {
/* 167 */       return super.decodeEndElement();
/*     */     }
/* 169 */     return this.scDecoder.decodeEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getElementPrefix() {
/* 175 */     return (this.scDecoder == null) ? super.getElementPrefix() : 
/* 176 */       this.scDecoder.getElementPrefix();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementQNameAsString() {
/* 181 */     return (this.scDecoder == null) ? super.getElementQNameAsString() : 
/* 182 */       this.scDecoder.getElementQNameAsString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QNameContext decodeAttributeXsiNil() throws EXIException, IOException {
/* 188 */     if (this.scDecoder == null) {
/* 189 */       return super.decodeAttributeXsiNil();
/*     */     }
/* 191 */     return this.scDecoder.decodeAttributeXsiNil();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QNameContext decodeAttributeXsiType() throws EXIException, IOException {
/* 198 */     if (this.scDecoder == null) {
/* 199 */       return super.decodeAttributeXsiType();
/*     */     }
/* 201 */     return this.scDecoder.decodeAttributeXsiType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QNameContext decodeAttribute() throws EXIException, IOException {
/* 207 */     if (this.scDecoder == null) {
/* 208 */       return super.decodeAttribute();
/*     */     }
/* 210 */     return this.scDecoder.decodeAttribute();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttributePrefix() {
/* 216 */     return (this.scDecoder == null) ? super.getAttributePrefix() : 
/* 217 */       this.scDecoder.getAttributePrefix();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttributeQNameAsString() {
/* 222 */     return (this.scDecoder == null) ? super.getAttributeQNameAsString() : 
/* 223 */       this.scDecoder.getAttributeQNameAsString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Value getAttributeValue() {
/* 228 */     return (this.scDecoder == null) ? super.getAttributeValue() : 
/* 229 */       this.scDecoder.getAttributeValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<NamespaceDeclaration> getDeclaredPrefixDeclarations() {
/* 234 */     if (this.scDecoder == null) {
/* 235 */       return super.getDeclaredPrefixDeclarations();
/*     */     }
/* 237 */     return this.scDecoder.getDeclaredPrefixDeclarations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceDeclaration decodeNamespaceDeclaration() throws EXIException, IOException {
/* 244 */     if (this.scDecoder == null) {
/* 245 */       return super.decodeNamespaceDeclaration();
/*     */     }
/* 247 */     return this.scDecoder.decodeNamespaceDeclaration();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Value decodeCharacters() throws EXIException, IOException {
/* 253 */     if (this.scDecoder == null) {
/* 254 */       return super.decodeCharacters();
/*     */     }
/* 256 */     return this.scDecoder.decodeCharacters();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DocType decodeDocType() throws EXIException, IOException {
/* 262 */     if (this.scDecoder == null) {
/* 263 */       return super.decodeDocType();
/*     */     }
/* 265 */     return this.scDecoder.decodeDocType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] decodeEntityReference() throws EXIException, IOException {
/* 271 */     if (this.scDecoder == null) {
/* 272 */       return super.decodeEntityReference();
/*     */     }
/* 274 */     return this.scDecoder.decodeEntityReference();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] decodeComment() throws EXIException, IOException {
/* 280 */     if (this.scDecoder == null) {
/* 281 */       return super.decodeComment();
/*     */     }
/* 283 */     return this.scDecoder.decodeComment();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProcessingInstruction decodeProcessingInstruction() throws EXIException, IOException {
/* 290 */     if (this.scDecoder == null) {
/* 291 */       return super.decodeProcessingInstruction();
/*     */     }
/* 293 */     return this.scDecoder.decodeProcessingInstruction();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIBodyDecoderInOrderSC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */