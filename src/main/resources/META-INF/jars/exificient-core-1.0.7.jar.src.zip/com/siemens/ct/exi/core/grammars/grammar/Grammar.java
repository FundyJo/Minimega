package com.siemens.ct.exi.core.grammars.grammar;

import com.siemens.ct.exi.core.grammars.event.Attribute;
import com.siemens.ct.exi.core.grammars.event.Event;
import com.siemens.ct.exi.core.grammars.event.EventType;
import com.siemens.ct.exi.core.grammars.event.StartElement;
import com.siemens.ct.exi.core.grammars.production.Production;

public interface Grammar {
  boolean isSchemaInformed();
  
  boolean hasEndElement();
  
  GrammarType getGrammarType();
  
  int getNumberOfEvents();
  
  void addProduction(Event paramEvent, Grammar paramGrammar);
  
  void learnStartElement(StartElement paramStartElement);
  
  void learnEndElement();
  
  void learnAttribute(Attribute paramAttribute);
  
  void learnCharacters();
  
  void stopLearning();
  
  int learningStopped();
  
  Grammar getElementContentGrammar();
  
  Production getProduction(EventType paramEventType);
  
  Production getStartElementProduction(String paramString1, String paramString2);
  
  Production getStartElementNSProduction(String paramString);
  
  Production getAttributeProduction(String paramString1, String paramString2);
  
  Production getAttributeNSProduction(String paramString);
  
  Production getProduction(int paramInt);
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\Grammar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */