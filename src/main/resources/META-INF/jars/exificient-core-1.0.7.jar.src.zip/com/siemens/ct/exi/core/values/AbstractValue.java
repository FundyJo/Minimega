/*    */ package com.siemens.ct.exi.core.values;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractValue
/*    */   implements Value
/*    */ {
/* 35 */   protected int slen = -1;
/*    */   
/*    */   protected final ValueType valueType;
/*    */   
/*    */   public AbstractValue(ValueType valueType) {
/* 40 */     this.valueType = valueType;
/*    */   }
/*    */   
/*    */   public final ValueType getValueType() {
/* 44 */     return this.valueType;
/*    */   }
/*    */   
/*    */   public char[] getCharacters() {
/* 48 */     char[] dst = new char[getCharactersLength()];
/* 49 */     getCharacters(dst, 0);
/* 50 */     return dst;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 55 */     return new String(getCharacters());
/*    */   }
/*    */   
/*    */   public String toString(char[] cbuffer, int offset) {
/* 59 */     getCharacters(cbuffer, offset);
/* 60 */     return new String(cbuffer, offset, getCharactersLength());
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\AbstractValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */