package com.siemens.ct.exi.core;

import com.siemens.ct.exi.core.exceptions.EXIException;
import java.io.IOException;
import java.io.InputStream;

public interface EXIStreamDecoder {
  EXIBodyDecoder getBodyOnlyDecoder(InputStream paramInputStream) throws EXIException, IOException;
  
  EXIBodyDecoder decodeHeader(InputStream paramInputStream) throws EXIException, IOException;
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\EXIStreamDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */