/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.types.BuiltInType;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtendedStringDatatype
/*    */   extends AbstractDatatype
/*    */ {
/*    */   protected String lastValue;
/*    */   protected List<String> sharedStrings;
/*    */   protected EnumDatatype grammarStrings;
/*    */   
/*    */   public ExtendedStringDatatype(QNameContext schemaType) {
/* 47 */     this(schemaType, WhiteSpace.preserve);
/*    */   }
/*    */   
/*    */   public ExtendedStringDatatype(QNameContext schemaType, WhiteSpace whiteSpace) {
/* 51 */     super(BuiltInType.EXTENDED_STRING, schemaType);
/*    */ 
/*    */     
/* 54 */     this.whiteSpace = whiteSpace;
/*    */   }
/*    */   
/*    */   public void setSharedStrings(List<String> sharedStrings) {
/* 58 */     this.sharedStrings = sharedStrings;
/*    */   }
/*    */   
/*    */   public void setGrammarStrings(EnumDatatype grammarStrings) {
/* 62 */     this.grammarStrings = grammarStrings;
/*    */   }
/*    */   
/*    */   public EnumDatatype getGrammarStrings() {
/* 66 */     return this.grammarStrings;
/*    */   }
/*    */   
/*    */   public DatatypeID getDatatypeID() {
/* 70 */     return DatatypeID.exi_estring;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\ExtendedStringDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */