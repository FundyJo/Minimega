/*    */ package com.siemens.ct.exi.core.grammars.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartElementNS
/*    */   extends AbstractEvent
/*    */ {
/*    */   protected final String namespaceUri;
/*    */   protected final int namespaceUriID;
/*    */   
/*    */   public StartElementNS(int namespaceUriID, String namespaceUri) {
/* 39 */     super(EventType.START_ELEMENT_NS);
/* 40 */     this.namespaceUriID = namespaceUriID;
/* 41 */     this.namespaceUri = namespaceUri;
/*    */   }
/*    */   
/*    */   public String getNamespaceURI() {
/* 45 */     return this.namespaceUri;
/*    */   }
/*    */   
/*    */   public int getNamespaceUriID() {
/* 49 */     return this.namespaceUriID;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 53 */     return super.toString() + "(" + getNamespaceURI() + ":*)";
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 58 */     return getNamespaceURI().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 63 */     if (this == obj)
/* 64 */       return true; 
/* 65 */     if (obj instanceof StartElementNS) {
/* 66 */       StartElementNS otherSE = (StartElementNS)obj;
/* 67 */       return getNamespaceURI().equals(otherSE.getNamespaceURI());
/*    */     } 
/* 69 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\StartElementNS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */