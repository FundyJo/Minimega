/*    */ package com.siemens.ct.exi.core.util.sort;
/*    */ 
/*    */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*    */ import java.util.Comparator;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeSort
/*    */   implements Comparator<Attribute>
/*    */ {
/*    */   public int compare(Attribute a1, Attribute a2) {
/* 43 */     QName q1 = a1.getQName();
/* 44 */     QName q2 = a2.getQName();
/* 45 */     return QNameSort.compare(q1.getNamespaceURI(), q1.getLocalPart(), q2
/* 46 */         .getNamespaceURI(), q2.getLocalPart());
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\cor\\util\sort\AttributeSort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */