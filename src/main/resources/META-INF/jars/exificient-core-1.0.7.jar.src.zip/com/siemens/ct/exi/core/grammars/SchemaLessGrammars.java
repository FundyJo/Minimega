/*     */ package com.siemens.ct.exi.core.grammars;
/*     */ 
/*     */ import com.siemens.ct.exi.core.Constants;
/*     */ import com.siemens.ct.exi.core.context.GrammarContext;
/*     */ import com.siemens.ct.exi.core.context.GrammarUriContext;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.exceptions.UnsupportedOption;
/*     */ import com.siemens.ct.exi.core.grammars.event.EndDocument;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartDocument;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.BuiltInDocContent;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.BuiltInFragmentContent;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.DocEnd;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Document;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Fragment;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaLessGrammars
/*     */   extends AbstractGrammars
/*     */ {
/*     */   private static final GrammarContext SCHEMA_LESS_GRAMMAR_CONTEXT;
/*     */   
/*     */   static {
/*  52 */     GrammarUriContext[] grammarUriContextsX = new GrammarUriContext[3];
/*  53 */     int qNameID = 0;
/*     */ 
/*     */     
/*  56 */     int namespaceUriID = 0;
/*  57 */     QNameContext[] grammarQNames0 = new QNameContext[Constants.LOCAL_NAMES_EMPTY.length];
/*  58 */     grammarUriContextsX[namespaceUriID] = new GrammarUriContext(namespaceUriID, "", grammarQNames0, Constants.PREFIXES_EMPTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     namespaceUriID = 1;
/*  65 */     QNameContext[] grammarQNames1 = new QNameContext[Constants.LOCAL_NAMES_XML.length]; int i;
/*  66 */     for (i = 0; i < grammarQNames1.length; i++) {
/*  67 */       grammarQNames1[i] = new QNameContext(namespaceUriID, i, new QName("http://www.w3.org/XML/1998/namespace", Constants.LOCAL_NAMES_XML[i]));
/*     */ 
/*     */       
/*  70 */       qNameID++;
/*     */     } 
/*  72 */     grammarUriContextsX[namespaceUriID] = new GrammarUriContext(namespaceUriID, "http://www.w3.org/XML/1998/namespace", grammarQNames1, Constants.PREFIXES_XML);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     namespaceUriID = 2;
/*  79 */     QNameContext[] grammarQNames2 = new QNameContext[Constants.LOCAL_NAMES_XSI.length];
/*  80 */     for (i = 0; i < grammarQNames2.length; i++) {
/*  81 */       grammarQNames2[i] = new QNameContext(namespaceUriID, i, new QName("http://www.w3.org/2001/XMLSchema-instance", Constants.LOCAL_NAMES_XSI[i]));
/*     */ 
/*     */       
/*  84 */       qNameID++;
/*     */     } 
/*  86 */     grammarUriContextsX[namespaceUriID] = new GrammarUriContext(namespaceUriID, "http://www.w3.org/2001/XMLSchema-instance", grammarQNames2, Constants.PREFIXES_XSI);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     SCHEMA_LESS_GRAMMAR_CONTEXT = new GrammarContext(grammarUriContextsX, qNameID);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaLessGrammars() {
/*  97 */     super(false, SCHEMA_LESS_GRAMMAR_CONTEXT);
/*  98 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   private void init() {
/* 103 */     DocEnd builtInDocEndGrammar = new DocEnd("DocEnd");
/* 104 */     builtInDocEndGrammar.addTerminalProduction((Event)new EndDocument());
/*     */     
/* 106 */     BuiltInDocContent builtInDocContent = new BuiltInDocContent((Grammar)builtInDocEndGrammar, "DocContent");
/*     */ 
/*     */     
/* 109 */     this.documentGrammar = (Grammar)new Document("Document");
/* 110 */     this.documentGrammar.addProduction((Event)new StartDocument(), (Grammar)builtInDocContent);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isBuiltInXMLSchemaTypesOnly() {
/* 115 */     return false;
/*     */   }
/*     */   
/*     */   public final String getSchemaId() {
/* 119 */     return null;
/*     */   }
/*     */   
/*     */   public void setSchemaId(String schemaId) throws UnsupportedOption {
/* 123 */     if (schemaId != null) {
/* 124 */       throw new UnsupportedOption("Schema-less grammars do have schemaId == null associated with it.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Grammar getFragmentGrammar() {
/* 137 */     BuiltInFragmentContent builtInFragmentContent = new BuiltInFragmentContent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     this.fragmentGrammar = (Grammar)new Fragment("Fragment");
/* 143 */     this.fragmentGrammar.addProduction((Event)new StartDocument(), (Grammar)builtInFragmentContent);
/*     */ 
/*     */     
/* 146 */     return this.fragmentGrammar;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\SchemaLessGrammars.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */