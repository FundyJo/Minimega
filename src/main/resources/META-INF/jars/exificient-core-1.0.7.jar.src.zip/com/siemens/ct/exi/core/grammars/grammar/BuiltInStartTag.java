/*     */ package com.siemens.ct.exi.core.grammars.grammar;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BuiltInStartTag
/*     */   extends AbstractBuiltInContent
/*     */ {
/*     */   protected BuiltInElement elementContent;
/*     */   protected boolean learnedEE = false;
/*     */   protected boolean learnedXsiType = false;
/*     */   
/*     */   public BuiltInStartTag() {
/*  59 */     this.elementContent = new BuiltInElement();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasEndElement() {
/*  64 */     return this.learnedEE;
/*     */   }
/*     */   
/*     */   public GrammarType getGrammarType() {
/*  68 */     return GrammarType.BUILT_IN_START_TAG_CONTENT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Grammar getElementContentGrammar() {
/*  74 */     return this.elementContent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void learnStartElement(StartElement se) {
/*  81 */     addProduction((Event)se, getElementContentGrammar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void learnEndElement() {
/*  90 */     if (!this.learnedEE) {
/*  91 */       addTerminalProduction(END_ELEMENT);
/*  92 */       this.learnedEE = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void learnAttribute(Attribute at) {
/*  99 */     QNameContext qnc = at.getQNameContext();
/* 100 */     if (qnc.getNamespaceUriID() == 2 && qnc.getLocalNameID() == 1) {
/* 101 */       if (!this.learnedXsiType) {
/* 102 */         addProduction((Event)at, this);
/* 103 */         this.learnedXsiType = true;
/*     */       } 
/*     */     } else {
/* 106 */       addProduction((Event)at, this);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\BuiltInStartTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */