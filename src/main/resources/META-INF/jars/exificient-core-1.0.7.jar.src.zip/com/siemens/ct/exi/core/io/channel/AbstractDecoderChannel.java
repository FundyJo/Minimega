/*     */ package com.siemens.ct.exi.core.io.channel;
/*     */ 
/*     */ import com.siemens.ct.exi.core.types.DateTimeType;
/*     */ import com.siemens.ct.exi.core.values.BooleanValue;
/*     */ import com.siemens.ct.exi.core.values.DateTimeValue;
/*     */ import com.siemens.ct.exi.core.values.DecimalValue;
/*     */ import com.siemens.ct.exi.core.values.FloatValue;
/*     */ import com.siemens.ct.exi.core.values.IntegerValue;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDecoderChannel
/*     */   implements DecoderChannel
/*     */ {
/*  46 */   private final int[] maskedOctets = new int[9];
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MAX_OCTETS_FOR_LONG = 9;
/*     */ 
/*     */   
/*     */   protected StringBuilder sbHelper;
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanValue decodeBooleanValue() throws IOException {
/*  58 */     return decodeBoolean() ? BooleanValue.BOOLEAN_VALUE_TRUE : 
/*  59 */       BooleanValue.BOOLEAN_VALUE_FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] decodeString() throws IOException {
/*  68 */     return decodeStringOnly(decodeUnsignedInteger());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] decodeStringOnly(int length) throws IOException {
/*  82 */     char[] ca = new char[length];
/*     */     
/*  84 */     for (int i = 0; i < length; i++) {
/*  85 */       int codePoint = decodeUnsignedInteger();
/*  86 */       if (Character.isSupplementaryCodePoint(codePoint))
/*     */       {
/*     */         
/*  89 */         return decodeStringOnlySupplementaryCodePoints(ca, length, i, codePoint);
/*     */       }
/*     */       
/*  92 */       ca[i] = (char)codePoint;
/*     */     } 
/*     */ 
/*     */     
/*  96 */     return ca;
/*     */   }
/*     */ 
/*     */   
/*     */   private char[] decodeStringOnlySupplementaryCodePoints(char[] ca, int length, int i, int codePoint) throws IOException {
/* 101 */     assert Character.isSupplementaryCodePoint(codePoint);
/* 102 */     if (this.sbHelper == null) {
/* 103 */       this.sbHelper = new StringBuilder(length + 10);
/*     */     } else {
/* 105 */       this.sbHelper.setLength(0);
/*     */     } 
/*     */     
/* 108 */     this.sbHelper.append(ca, 0, i);
/* 109 */     this.sbHelper.appendCodePoint(codePoint);
/* 110 */     for (int k = i + 1; k < length; k++) {
/* 111 */       this.sbHelper.appendCodePoint(decodeUnsignedInteger());
/*     */     }
/*     */     
/* 114 */     int len = this.sbHelper.length();
/* 115 */     char[] dst = new char[len];
/* 116 */     this.sbHelper.getChars(0, len, dst, 0);
/*     */     
/* 118 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int decodeUnsignedInteger() throws IOException {
/* 131 */     int result = decode();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (result >= 128) {
/* 137 */       int b; result &= 0x7F;
/* 138 */       int mShift = 7;
/*     */ 
/*     */ 
/*     */       
/*     */       do {
/* 143 */         b = decode();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 148 */         result += (b & 0x7F) << mShift;
/*     */         
/* 150 */         mShift += 7;
/*     */       
/*     */       }
/* 153 */       while (b >= 128);
/*     */     } 
/*     */     
/* 156 */     return result;
/*     */   }
/*     */   protected long decodeUnsignedLong() throws IOException {
/*     */     int b;
/* 160 */     long lResult = 0L;
/* 161 */     int mShift = 0;
/*     */ 
/*     */     
/*     */     do {
/* 165 */       b = decode();
/* 166 */       lResult += (b & 0x7F) << mShift;
/* 167 */       mShift += 7;
/* 168 */     } while (b >>> 7 == 1);
/*     */     
/* 170 */     return lResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int decodeInteger() throws IOException {
/* 184 */     if (decodeBoolean())
/*     */     {
/*     */       
/* 187 */       return -(decodeUnsignedInteger() + 1);
/*     */     }
/*     */     
/* 190 */     return decodeUnsignedInteger();
/*     */   }
/*     */ 
/*     */   
/*     */   protected long decodeLong() throws IOException {
/* 195 */     if (decodeBoolean())
/*     */     {
/*     */       
/* 198 */       return -(decodeUnsignedLong() + 1L);
/*     */     }
/*     */     
/* 201 */     return decodeUnsignedLong();
/*     */   }
/*     */ 
/*     */   
/*     */   public IntegerValue decodeIntegerValue() throws IOException {
/* 206 */     return decodeUnsignedIntegerValue(decodeBoolean());
/*     */   }
/*     */   
/*     */   public IntegerValue decodeUnsignedIntegerValue() throws IOException {
/* 210 */     return decodeUnsignedIntegerValue(false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final IntegerValue decodeUnsignedIntegerValue(boolean negative) throws IOException {
/*     */     int b;
/* 216 */     for (int i = 0; i < 9; i++) {
/*     */       
/* 218 */       b = decode();
/*     */ 
/*     */       
/* 221 */       if (b < 128) {
/*     */         int iResult, k;
/* 223 */         switch (i) {
/*     */           
/*     */           case 0:
/* 226 */             return IntegerValue.valueOf(negative ? -(b + 1) : b);
/*     */           
/*     */           case 1:
/*     */           case 2:
/*     */           case 3:
/* 231 */             this.maskedOctets[i] = b;
/*     */             
/* 233 */             iResult = 0;
/* 234 */             for (k = i; k >= 0; k--) {
/* 235 */               iResult = iResult << 7 | this.maskedOctets[k];
/*     */             }
/*     */ 
/*     */             
/* 239 */             return IntegerValue.valueOf(negative ? -(iResult + 1) : 
/* 240 */                 iResult);
/*     */         } 
/*     */         
/* 243 */         this.maskedOctets[i] = b;
/*     */         
/* 245 */         long lResult = 0L;
/* 246 */         for (int m = i; m >= 0; m--) {
/* 247 */           lResult = lResult << 7L | this.maskedOctets[m];
/*     */         }
/*     */ 
/*     */         
/* 251 */         return IntegerValue.valueOf(negative ? -(lResult + 1L) : 
/* 252 */             lResult);
/*     */       } 
/*     */ 
/*     */       
/* 256 */       this.maskedOctets[i] = b & 0x7F;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 261 */     BigInteger bResult = BigInteger.ZERO;
/* 262 */     BigInteger multiplier = BigInteger.ONE;
/*     */     
/* 264 */     for (int j = 0; j < 9; j++) {
/* 265 */       bResult = bResult.add(multiplier.multiply(
/* 266 */             BigInteger.valueOf(this.maskedOctets[j])));
/* 267 */       multiplier = multiplier.shiftLeft(7);
/*     */     } 
/*     */ 
/*     */     
/*     */     do {
/* 272 */       b = decode();
/*     */       
/* 274 */       bResult = bResult.add(multiplier.multiply(
/* 275 */             BigInteger.valueOf((b & 0x7F))));
/*     */       
/* 277 */       multiplier = multiplier.shiftLeft(7);
/*     */     
/*     */     }
/* 280 */     while (b > 127);
/*     */ 
/*     */ 
/*     */     
/* 284 */     if (negative) {
/* 285 */       bResult = bResult.add(BigInteger.ONE).negate();
/*     */     }
/*     */     
/* 288 */     return IntegerValue.valueOf(bResult);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerValue decodeNBitUnsignedIntegerValue(int n) throws IOException {
/* 296 */     return IntegerValue.valueOf(decodeNBitUnsignedInteger(n));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecimalValue decodeDecimalValue() throws IOException {
/* 308 */     boolean negative = decodeBoolean();
/*     */     
/* 310 */     IntegerValue integral = decodeUnsignedIntegerValue(false);
/* 311 */     IntegerValue revFractional = decodeUnsignedIntegerValue(false);
/*     */     
/* 313 */     return new DecimalValue(negative, integral, revFractional);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatValue decodeFloatValue() throws IOException {
/* 322 */     return new FloatValue(decodeIntegerValue(), decodeIntegerValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTimeValue decodeDateTimeValue(DateTimeType type) throws IOException {
/*     */     boolean presenceFractionalSecs;
/* 331 */     int year = 0, monthDay = 0, time = 0, fractionalSecs = 0;
/*     */     
/* 333 */     switch (type) {
/*     */       case gYear:
/* 335 */         year = decodeInteger() + 2000;
/*     */         break;
/*     */       case gYearMonth:
/*     */       case date:
/* 339 */         year = decodeInteger() + 2000;
/* 340 */         monthDay = decodeNBitUnsignedInteger(9);
/*     */         break;
/*     */       
/*     */       case dateTime:
/* 344 */         year = decodeInteger() + 2000;
/* 345 */         monthDay = decodeNBitUnsignedInteger(9);
/*     */ 
/*     */       
/*     */       case time:
/* 349 */         time = decodeNBitUnsignedInteger(17);
/* 350 */         presenceFractionalSecs = decodeBoolean();
/*     */         
/* 352 */         fractionalSecs = presenceFractionalSecs ? decodeUnsignedInteger() : 0;
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case gMonth:
/*     */       case gMonthDay:
/*     */       case gDay:
/* 360 */         monthDay = decodeNBitUnsignedInteger(9);
/*     */         break;
/*     */       default:
/* 363 */         throw new UnsupportedOperationException();
/*     */     } 
/*     */     
/* 366 */     boolean presenceTimezone = decodeBoolean();
/*     */ 
/*     */     
/* 369 */     int timeZone = presenceTimezone ? (decodeNBitUnsignedInteger(11) - 896) : 0;
/*     */     
/* 371 */     return new DateTimeValue(type, year, monthDay, time, fractionalSecs, presenceTimezone, timeZone);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\channel\AbstractDecoderChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */