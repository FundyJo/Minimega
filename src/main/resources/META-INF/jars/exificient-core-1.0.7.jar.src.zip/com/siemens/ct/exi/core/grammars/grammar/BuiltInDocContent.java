/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ import com.siemens.ct.exi.core.grammars.event.Event;
/*    */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuiltInDocContent
/*    */   extends AbstractBuiltInGrammar
/*    */ {
/*    */   protected Grammar docEnd;
/*    */   
/*    */   public BuiltInDocContent(Grammar docEnd) {
/* 49 */     this.docEnd = docEnd;
/*    */     
/* 51 */     addProduction(START_ELEMENT_GENERIC, docEnd);
/*    */   }
/*    */   
/*    */   public BuiltInDocContent(Grammar docEnd, String label) {
/* 55 */     this(docEnd);
/* 56 */     setLabel(label);
/*    */   }
/*    */   
/*    */   public GrammarType getGrammarType() {
/* 60 */     return GrammarType.BUILT_IN_DOC_CONTENT;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void addProduction(Event event, Grammar grammar) {
/* 65 */     if (!event.isEventType(EventType.START_ELEMENT_GENERIC) || 
/* 66 */       getNumberOfEvents() > 0) {
/* 67 */       throw new RuntimeException("Mis-use of BuiltInDocContent grammar");
/*    */     }
/* 69 */     super.addProduction(event, grammar);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\BuiltInDocContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */