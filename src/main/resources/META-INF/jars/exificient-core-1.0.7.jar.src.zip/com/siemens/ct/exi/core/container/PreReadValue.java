/*    */ package com.siemens.ct.exi.core.container;
/*    */ 
/*    */ import com.siemens.ct.exi.core.values.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreReadValue
/*    */ {
/*    */   protected Value[] contentValues;
/*    */   protected int index;
/*    */   
/*    */   public PreReadValue(Value[] contentValues) {
/* 41 */     setValues(contentValues);
/*    */   }
/*    */   
/*    */   protected void setValues(Value[] contentValues) {
/* 45 */     this.contentValues = contentValues;
/* 46 */     this.index = 0;
/*    */   }
/*    */   
/*    */   public Value[] getValues() {
/* 50 */     return this.contentValues;
/*    */   }
/*    */   
/*    */   public Value getNextContantValue() {
/* 54 */     return this.contentValues[this.index++];
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\container\PreReadValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */