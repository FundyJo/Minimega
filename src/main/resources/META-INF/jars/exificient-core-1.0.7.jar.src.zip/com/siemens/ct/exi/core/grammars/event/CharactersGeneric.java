/*    */ package com.siemens.ct.exi.core.grammars.event;
/*    */ 
/*    */ import com.siemens.ct.exi.core.types.BuiltIn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharactersGeneric
/*    */   extends AbstractDatatypeEvent
/*    */ {
/*    */   public CharactersGeneric() {
/* 38 */     super(EventType.CHARACTERS_GENERIC, BuiltIn.getDefaultDatatype());
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\CharactersGeneric.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */