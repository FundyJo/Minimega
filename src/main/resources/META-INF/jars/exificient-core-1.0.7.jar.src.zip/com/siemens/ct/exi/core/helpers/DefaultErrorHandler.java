package com.siemens.ct.exi.core.helpers;

import com.siemens.ct.exi.core.exceptions.EXIException;
import com.siemens.ct.exi.core.exceptions.ErrorHandler;

public class DefaultErrorHandler implements ErrorHandler {
  public void error(EXIException exception) {}
  
  public void warning(EXIException exception) {}
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\helpers\DefaultErrorHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */