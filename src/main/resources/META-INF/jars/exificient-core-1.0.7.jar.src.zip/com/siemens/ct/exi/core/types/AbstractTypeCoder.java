/*     */ package com.siemens.ct.exi.core.types;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.BinaryBase64Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.BinaryHexDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.BooleanDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.DatatypeID;
/*     */ import com.siemens.ct.exi.core.datatype.DatetimeDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.DecimalDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.ExtendedStringDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.FloatDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.IntegerDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.ListDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.StringDatatype;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.util.xml.QNameUtilities;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTypeCoder
/*     */   implements TypeCoder
/*     */ {
/*     */   protected final QName[] dtrMapTypes;
/*     */   protected final QName[] dtrMapRepresentations;
/*     */   protected final Map<QName, Datatype> dtrMapRepresentationsDatatype;
/*     */   protected Map<QName, Datatype> dtrMap;
/*     */   protected final boolean dtrMapInUse;
/*     */   
/*     */   public AbstractTypeCoder() throws EXIException {
/*  65 */     this(null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractTypeCoder(QName[] dtrMapTypes, QName[] dtrMapRepresentations, Map<QName, Datatype> dtrMapRepresentationsDatatype) throws EXIException {
/*  72 */     this.dtrMapTypes = dtrMapTypes;
/*  73 */     this.dtrMapRepresentations = dtrMapRepresentations;
/*  74 */     this.dtrMapRepresentationsDatatype = dtrMapRepresentationsDatatype;
/*     */     
/*  76 */     if (dtrMapTypes == null) {
/*  77 */       this.dtrMapInUse = false;
/*     */     } else {
/*  79 */       this.dtrMapInUse = true;
/*     */       
/*  81 */       this.dtrMap = new HashMap<>();
/*  82 */       assert dtrMapTypes.length == dtrMapRepresentations.length;
/*  83 */       initDtrMaps();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initDtrMaps() throws EXIException {
/*  88 */     assert this.dtrMapInUse;
/*     */ 
/*     */     
/*  91 */     this.dtrMap.put(BuiltIn.XSD_BASE64BINARY, 
/*     */         
/*  93 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "base64Binary"));
/*     */     
/*  95 */     this.dtrMap.put(BuiltIn.XSD_HEXBINARY, 
/*     */         
/*  97 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "hexBinary"));
/*     */ 
/*     */     
/* 100 */     this.dtrMap.put(BuiltIn.XSD_BOOLEAN, 
/*     */         
/* 102 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "boolean"));
/*     */ 
/*     */     
/* 105 */     this.dtrMap.put(BuiltIn.XSD_DATETIME, 
/*     */         
/* 107 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "dateTime"));
/*     */     
/* 109 */     this.dtrMap.put(BuiltIn.XSD_TIME, 
/*     */         
/* 111 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "time"));
/*     */     
/* 113 */     this.dtrMap.put(BuiltIn.XSD_DATE, 
/*     */         
/* 115 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "date"));
/*     */     
/* 117 */     this.dtrMap.put(BuiltIn.XSD_GYEARMONTH, 
/*     */         
/* 119 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "gYearMonth"));
/*     */     
/* 121 */     this.dtrMap.put(BuiltIn.XSD_GYEAR, 
/*     */         
/* 123 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "gYear"));
/*     */     
/* 125 */     this.dtrMap.put(BuiltIn.XSD_GMONTHDAY, 
/*     */         
/* 127 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "gMonthDay"));
/*     */     
/* 129 */     this.dtrMap.put(BuiltIn.XSD_GDAY, 
/*     */         
/* 131 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "gDay"));
/*     */     
/* 133 */     this.dtrMap.put(BuiltIn.XSD_GMONTH, 
/*     */         
/* 135 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "gMonth"));
/*     */ 
/*     */     
/* 138 */     this.dtrMap.put(BuiltIn.XSD_DECIMAL, 
/*     */         
/* 140 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "decimal"));
/*     */ 
/*     */     
/* 143 */     this.dtrMap.put(BuiltIn.XSD_FLOAT, 
/*     */         
/* 145 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "double"));
/*     */     
/* 147 */     this.dtrMap.put(BuiltIn.XSD_DOUBLE, 
/*     */         
/* 149 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "double"));
/*     */ 
/*     */     
/* 152 */     this.dtrMap.put(BuiltIn.XSD_INTEGER, 
/*     */         
/* 154 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "integer"));
/*     */ 
/*     */     
/* 157 */     this.dtrMap.put(BuiltIn.XSD_STRING, 
/*     */         
/* 159 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "string"));
/*     */     
/* 161 */     this.dtrMap.put(BuiltIn.XSD_ANY_SIMPLE_TYPE, 
/*     */         
/* 163 */         getDatatypeRepresentation("http://www.w3.org/2009/exi", "string"));
/*     */ 
/*     */ 
/*     */     
/* 167 */     for (int i = 0; i < this.dtrMapTypes.length; i++) {
/* 168 */       QName dtrMapRepr = this.dtrMapRepresentations[i];
/* 169 */       Datatype representation = getDatatypeRepresentation(dtrMapRepr
/* 170 */           .getNamespaceURI(), dtrMapRepr.getLocalPart());
/* 171 */       QName type = this.dtrMapTypes[i];
/* 172 */       this.dtrMap.put(type, representation);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Datatype getDtrDatatype(Datatype datatype) {
/* 177 */     assert this.dtrMapInUse;
/*     */     
/* 179 */     Datatype dtrDatatype = null;
/* 180 */     if (datatype.equals(BuiltIn.getDefaultDatatype())) {
/*     */ 
/*     */       
/* 183 */       dtrDatatype = datatype;
/*     */     } else {
/*     */       
/* 186 */       QName schemaType = datatype.getSchemaType().getQName();
/*     */ 
/*     */       
/* 189 */       if (dtrDatatype == null && datatype
/* 190 */         .getBuiltInType() == BuiltInType.STRING && ((StringDatatype)datatype)
/* 191 */         .isDerivedByUnion())
/*     */       {
/* 193 */         if (this.dtrMap.containsKey(schemaType)) {
/*     */           
/* 195 */           dtrDatatype = this.dtrMap.get(schemaType);
/*     */         } else {
/* 197 */           Datatype baseDatatype = datatype.getBaseDatatype();
/*     */           
/* 199 */           QName schemBaseType = baseDatatype.getSchemaType().getQName();
/* 200 */           if (baseDatatype.getBuiltInType() == BuiltInType.STRING && ((StringDatatype)baseDatatype)
/*     */             
/* 202 */             .isDerivedByUnion() && this.dtrMap
/* 203 */             .containsKey(schemBaseType)) {
/* 204 */             dtrDatatype = this.dtrMap.get(schemBaseType);
/*     */           } else {
/* 206 */             dtrDatatype = datatype;
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 223 */       if (dtrDatatype == null && datatype
/* 224 */         .getBuiltInType() == BuiltInType.LIST) {
/* 225 */         ListDatatype ldt = (ListDatatype)datatype;
/* 226 */         if (this.dtrMap.containsKey(schemaType)) {
/*     */           
/* 228 */           dtrDatatype = this.dtrMap.get(schemaType);
/* 229 */         } else if (this.dtrMap.containsKey(ldt.getListDatatype()
/* 230 */             .getSchemaType().getQName())) {
/* 231 */           Datatype dt = this.dtrMap.get(ldt.getListDatatype()
/* 232 */               .getSchemaType().getQName());
/* 233 */           ListDatatype listDatatype = new ListDatatype(dt, datatype.getSchemaType());
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 239 */           Datatype baseDatatype = datatype.getBaseDatatype();
/*     */           
/* 241 */           QName schemBaseType = baseDatatype.getSchemaType().getQName();
/* 242 */           if (baseDatatype.getBuiltInType() == BuiltInType.LIST && this.dtrMap
/* 243 */             .containsKey(schemBaseType)) {
/* 244 */             dtrDatatype = this.dtrMap.get(schemBaseType);
/*     */           } else {
/* 246 */             dtrDatatype = datatype;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 273 */       if (dtrDatatype == null && datatype
/* 274 */         .getBuiltInType() == BuiltInType.ENUMERATION)
/*     */       {
/* 276 */         if (this.dtrMap.containsKey(schemaType)) {
/*     */           
/* 278 */           dtrDatatype = this.dtrMap.get(schemaType);
/*     */         } else {
/* 280 */           Datatype baseDatatype = datatype.getBaseDatatype();
/*     */           
/* 282 */           QName schemBaseType = baseDatatype.getSchemaType().getQName();
/* 283 */           if (baseDatatype.getBuiltInType() == BuiltInType.ENUMERATION && this.dtrMap
/* 284 */             .containsKey(schemBaseType)) {
/* 285 */             dtrDatatype = this.dtrMap.get(schemBaseType);
/*     */           } else {
/* 287 */             dtrDatatype = datatype;
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 318 */       if (dtrDatatype == null) {
/*     */ 
/*     */         
/* 321 */         dtrDatatype = this.dtrMap.get(schemaType);
/*     */         
/* 323 */         if (dtrDatatype == null)
/*     */         {
/*     */           
/* 326 */           dtrDatatype = updateDtrDatatype(datatype);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 338 */         if (dtrDatatype.getDatatypeID() == DatatypeID.exi_estring && datatype
/* 339 */           .getGrammarEnumeration() != null) {
/*     */           
/* 341 */           ExtendedStringDatatype esdt = (ExtendedStringDatatype)dtrDatatype;
/* 342 */           esdt.setGrammarStrings(datatype.getGrammarEnumeration());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 365 */     return dtrDatatype;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Datatype updateDtrDatatype(Datatype datatype) {
/* 371 */     assert this.dtrMapInUse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 400 */     Datatype baseDatatype = datatype.getBaseDatatype();
/*     */ 
/*     */ 
/*     */     
/* 404 */     QNameContext simpleBaseType = baseDatatype.getSchemaType();
/*     */     
/* 406 */     Datatype dtrDatatype = this.dtrMap.get(simpleBaseType.getQName());
/*     */     
/* 408 */     if (dtrDatatype == null)
/*     */     {
/*     */       
/* 411 */       dtrDatatype = updateDtrDatatype(baseDatatype);
/*     */     }
/*     */ 
/*     */     
/* 415 */     if ((dtrDatatype.getBuiltInType() == BuiltInType.INTEGER || dtrDatatype
/* 416 */       .getBuiltInType() == BuiltInType.UNSIGNED_INTEGER) && (datatype
/* 417 */       .getBuiltInType() == BuiltInType.NBIT_UNSIGNED_INTEGER || datatype
/* 418 */       .getBuiltInType() == BuiltInType.UNSIGNED_INTEGER)) {
/* 419 */       dtrDatatype = datatype;
/*     */     }
/*     */ 
/*     */     
/* 423 */     this.dtrMap.put(datatype.getSchemaType().getQName(), dtrDatatype);
/*     */     
/* 425 */     return dtrDatatype;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Datatype getDatatypeRepresentation(String reprUri, String reprLocalPart) throws EXIException {
/* 430 */     assert this.dtrMapInUse;
/*     */ 
/*     */     
/*     */     try {
/* 434 */       Datatype datatype = null;
/* 435 */       if ("http://www.w3.org/2009/exi".equals(reprUri)) {
/*     */ 
/*     */         
/* 438 */         if ("base64Binary".equals(reprLocalPart)) {
/* 439 */           BinaryBase64Datatype binaryBase64Datatype = new BinaryBase64Datatype(null);
/* 440 */         } else if ("hexBinary".equals(reprLocalPart)) {
/* 441 */           BinaryHexDatatype binaryHexDatatype = new BinaryHexDatatype(null);
/* 442 */         } else if ("boolean".equals(reprLocalPart)) {
/* 443 */           BooleanDatatype booleanDatatype = new BooleanDatatype(null);
/* 444 */         } else if ("dateTime".equals(reprLocalPart)) {
/* 445 */           DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.dateTime, null);
/* 446 */         } else if ("time".equals(reprLocalPart)) {
/* 447 */           DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.time, null);
/* 448 */         } else if ("date".equals(reprLocalPart)) {
/* 449 */           DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.date, null);
/* 450 */         } else if ("gYearMonth".equals(reprLocalPart)) {
/* 451 */           DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gYearMonth, null);
/*     */         }
/* 453 */         else if ("gYear".equals(reprLocalPart)) {
/* 454 */           DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gYear, null);
/* 455 */         } else if ("gMonthDay".equals(reprLocalPart)) {
/* 456 */           DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gMonthDay, null);
/*     */         }
/* 458 */         else if ("gDay".equals(reprLocalPart)) {
/* 459 */           DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gDay, null);
/* 460 */         } else if ("gMonth".equals(reprLocalPart)) {
/* 461 */           DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gMonth, null);
/* 462 */         } else if ("decimal".equals(reprLocalPart)) {
/* 463 */           DecimalDatatype decimalDatatype = new DecimalDatatype(null);
/* 464 */         } else if ("double".equals(reprLocalPart)) {
/* 465 */           FloatDatatype floatDatatype = new FloatDatatype(null);
/* 466 */         } else if ("integer".equals(reprLocalPart)) {
/* 467 */           IntegerDatatype integerDatatype = new IntegerDatatype(null);
/* 468 */         } else if ("string".equals(reprLocalPart)) {
/* 469 */           StringDatatype stringDatatype = new StringDatatype(null);
/* 470 */         } else if ("estring".equals(reprLocalPart)) {
/* 471 */           ExtendedStringDatatype extendedStringDatatype = new ExtendedStringDatatype(null);
/*     */         } else {
/* 473 */           throw new EXIException("[EXI] Unsupported datatype representation: {" + reprUri + "}" + reprLocalPart);
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 479 */         QName qn = new QName(reprUri, reprLocalPart);
/* 480 */         if (this.dtrMapRepresentationsDatatype != null) {
/* 481 */           datatype = this.dtrMapRepresentationsDatatype.get(qn);
/*     */         }
/* 483 */         if (datatype == null) {
/*     */           
/* 485 */           String className = QNameUtilities.getClassName(qn);
/*     */           
/* 487 */           Class<?> c = Class.forName(className);
/* 488 */           Object o = c.newInstance();
/* 489 */           if (o instanceof Datatype) {
/* 490 */             datatype = (Datatype)o;
/*     */           } else {
/* 492 */             throw new Exception("[EXI] no Datatype instance");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 497 */       return datatype;
/* 498 */     } catch (Exception e) {
/* 499 */       throw new EXIException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\AbstractTypeCoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */