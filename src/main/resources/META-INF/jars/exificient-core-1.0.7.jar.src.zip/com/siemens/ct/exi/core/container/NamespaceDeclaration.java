/*    */ package com.siemens.ct.exi.core.container;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamespaceDeclaration
/*    */ {
/*    */   public final String namespaceURI;
/*    */   public final String prefix;
/*    */   
/*    */   public NamespaceDeclaration(String namespaceURI, String prefix) {
/* 38 */     this.namespaceURI = namespaceURI;
/* 39 */     this.prefix = prefix;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 44 */     if (o instanceof NamespaceDeclaration) {
/* 45 */       NamespaceDeclaration other = (NamespaceDeclaration)o;
/* 46 */       return (this.namespaceURI.equals(other.namespaceURI) && this.prefix
/* 47 */         .equals(other.prefix));
/*    */     } 
/* 49 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 54 */     return this.namespaceURI.hashCode() ^ this.prefix.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\container\NamespaceDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */