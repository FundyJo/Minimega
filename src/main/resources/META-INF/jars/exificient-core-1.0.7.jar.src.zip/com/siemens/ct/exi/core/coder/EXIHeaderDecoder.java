/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.CodingMode;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.SchemaIdResolver;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.exceptions.UnsupportedOption;
/*     */ import com.siemens.ct.exi.core.grammars.Grammars;
/*     */ import com.siemens.ct.exi.core.grammars.SchemaLessGrammars;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.helpers.DefaultEXIFactory;
/*     */ import com.siemens.ct.exi.core.io.channel.BitDecoderChannel;
/*     */ import com.siemens.ct.exi.core.io.channel.DecoderChannel;
/*     */ import com.siemens.ct.exi.core.values.BooleanValue;
/*     */ import com.siemens.ct.exi.core.values.DecimalValue;
/*     */ import com.siemens.ct.exi.core.values.IntegerValue;
/*     */ import com.siemens.ct.exi.core.values.IntegerValueType;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import com.siemens.ct.exi.core.values.ValueType;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIHeaderDecoder
/*     */   extends AbstractEXIHeader
/*     */ {
/*     */   protected QNameContext lastSE;
/*     */   protected boolean dtrSection;
/*  71 */   protected List<QName> dtrMapTypes = new ArrayList<>();
/*  72 */   protected List<QName> dtrMapRepresentations = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clear() {
/*  78 */     this.lastSE = null;
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.dtrSection = false;
/*  83 */     this.dtrMapTypes.clear();
/*  84 */     this.dtrMapRepresentations.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EXIFactory parse(BitDecoderChannel headerChannel, EXIFactory noOptionsFactory) throws EXIException {
/*     */     try {
/*  91 */       if (headerChannel.lookAhead() == 36) {
/*  92 */         int h0 = headerChannel.decode();
/*  93 */         int h1 = headerChannel.decode();
/*  94 */         int h2 = headerChannel.decode();
/*  95 */         int h3 = headerChannel.decode();
/*  96 */         if (h0 != 36 || h1 != 69 || h2 != 88 || h3 != 73) {
/*  97 */           throw new EXIException("No valid EXI Cookie ($EXI)");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 103 */       if (headerChannel
/* 104 */         .decodeNBitUnsignedInteger(2) != 2) {
/* 105 */         throw new EXIException("No valid EXI document according distinguishing bits");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 110 */       boolean presenceOptions = headerChannel.decodeBoolean();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 120 */       boolean previewVersion = headerChannel.decodeBoolean();
/* 121 */       assert !previewVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 132 */       int version = 0;
/*     */       
/*     */       while (true) {
/* 135 */         int value = headerChannel.decodeNBitUnsignedInteger(4);
/* 136 */         version += value;
/* 137 */         if (value != 15)
/* 138 */         { EXIFactory exiFactory; assert version == 0;
/*     */ 
/*     */ 
/*     */           
/* 142 */           if (presenceOptions) {
/*     */             
/* 144 */             exiFactory = readEXIOptions((DecoderChannel)headerChannel, noOptionsFactory);
/*     */           } else {
/* 146 */             exiFactory = noOptionsFactory;
/*     */           } 
/*     */ 
/*     */           
/* 150 */           CodingMode codingMode = exiFactory.getCodingMode();
/* 151 */           if (codingMode != CodingMode.BIT_PACKED) {
/* 152 */             headerChannel.align();
/*     */           }
/*     */           
/* 155 */           return exiFactory; } 
/*     */       } 
/* 157 */     } catch (IOException e) {
/* 158 */       throw new EXIException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EXIFactory readEXIOptions(DecoderChannel decoderChannel, EXIFactory noOptionsFactory) throws EXIException, IOException {
/* 166 */     EXIBodyDecoderInOrder decoder = (EXIBodyDecoderInOrder)getHeaderFactory().createEXIBodyDecoder();
/* 167 */     decoder.setInputChannel(decoderChannel);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     EXIFactory exiOptionsFactory = DefaultEXIFactory.newInstance();
/*     */     
/* 177 */     exiOptionsFactory.setSchemaIdResolver(noOptionsFactory
/* 178 */         .getSchemaIdResolver());
/* 179 */     exiOptionsFactory.setDecodingOptions(noOptionsFactory
/* 180 */         .getDecodingOptions());
/*     */     
/* 182 */     exiOptionsFactory.setGrammars(noOptionsFactory.getGrammars());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     clear();
/*     */     
/*     */     EventType eventType;
/* 195 */     while ((eventType = decoder.next()) != null) {
/*     */       
/* 197 */       switch (eventType) {
/*     */         case START_DOCUMENT:
/* 199 */           decoder.decodeStartDocument();
/*     */           continue;
/*     */         case END_DOCUMENT:
/* 202 */           decoder.decodeEndDocument();
/*     */           continue;
/*     */         case ATTRIBUTE_XSI_NIL:
/* 205 */           decoder.decodeAttributeXsiNil();
/* 206 */           handleXsiNil(decoder.getAttributeValue(), exiOptionsFactory);
/*     */           continue;
/*     */         case ATTRIBUTE_XSI_TYPE:
/* 209 */           decoder.decodeAttributeXsiType();
/*     */           continue;
/*     */         case ATTRIBUTE:
/*     */         case ATTRIBUTE_NS:
/*     */         case ATTRIBUTE_GENERIC:
/*     */         case ATTRIBUTE_GENERIC_UNDECLARED:
/*     */         case ATTRIBUTE_INVALID_VALUE:
/*     */         case ATTRIBUTE_ANY_INVALID_VALUE:
/* 217 */           decoder.decodeAttribute();
/*     */           continue;
/*     */         case NAMESPACE_DECLARATION:
/* 220 */           decoder.decodeNamespaceDeclaration();
/*     */           continue;
/*     */         case START_ELEMENT:
/*     */         case START_ELEMENT_NS:
/*     */         case START_ELEMENT_GENERIC:
/*     */         case START_ELEMENT_GENERIC_UNDECLARED:
/* 226 */           handleStartElement(decoder.decodeStartElement(), exiOptionsFactory);
/*     */           continue;
/*     */         
/*     */         case END_ELEMENT:
/*     */         case END_ELEMENT_UNDECLARED:
/* 231 */           handleEndElement(decoder.decodeEndElement(), exiOptionsFactory);
/*     */           continue;
/*     */         case CHARACTERS:
/*     */         case CHARACTERS_GENERIC:
/*     */         case CHARACTERS_GENERIC_UNDECLARED:
/* 236 */           handleCharacters(decoder.decodeCharacters(), exiOptionsFactory);
/*     */           continue;
/*     */       } 
/* 239 */       throw new RuntimeException("Unexpected EXI Event in Header '" + eventType + "' ");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 245 */     if (this.dtrMapTypes.size() == this.dtrMapTypes.size() && this.dtrMapTypes.size() > 0) {
/* 246 */       QName[] dtrMapTypesA = new QName[this.dtrMapTypes.size()];
/* 247 */       dtrMapTypesA = this.dtrMapTypes.<QName>toArray(dtrMapTypesA);
/*     */       
/* 249 */       QName[] dtrMapRepresentationsA = new QName[this.dtrMapRepresentations.size()];
/*     */       
/* 251 */       dtrMapRepresentationsA = this.dtrMapRepresentations.<QName>toArray(dtrMapRepresentationsA);
/* 252 */       exiOptionsFactory.setDatatypeRepresentationMap(dtrMapTypesA, dtrMapRepresentationsA);
/*     */     } 
/*     */ 
/*     */     
/* 256 */     return exiOptionsFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleStartElement(QNameContext se, EXIFactory f) throws UnsupportedOption {
/* 262 */     if (this.dtrSection) {
/* 263 */       if (this.dtrMapTypes.size() == this.dtrMapRepresentations.size()) {
/*     */         
/* 265 */         this.dtrMapTypes.add(se.getQName());
/*     */       } else {
/*     */         
/* 268 */         this.dtrMapRepresentations.add(se.getQName());
/*     */       } 
/* 270 */     } else if ("http://www.w3.org/2009/exi".equals(se.getNamespaceUri())) {
/* 271 */       String localName = se.getLocalName();
/*     */       
/* 273 */       if ("byte".equals(localName)) {
/* 274 */         f.setCodingMode(CodingMode.BYTE_PACKED);
/* 275 */       } else if ("pre-compress".equals(localName)) {
/* 276 */         f.setCodingMode(CodingMode.PRE_COMPRESSION);
/* 277 */       } else if ("selfContained".equals(localName)) {
/* 278 */         f.getFidelityOptions().setFidelity("SELF_CONTAINED", true);
/*     */       }
/* 280 */       else if ("datatypeRepresentationMap".equals(localName)) {
/* 281 */         this.dtrSection = true;
/* 282 */       } else if ("dtd".equals(localName)) {
/* 283 */         f.getFidelityOptions().setFidelity("PRESERVE_DTDS", true);
/*     */       }
/* 285 */       else if ("prefixes".equals(localName)) {
/* 286 */         f.getFidelityOptions().setFidelity("PRESERVE_PREFIXES", true);
/*     */       }
/* 288 */       else if ("lexicalValues".equals(localName)) {
/* 289 */         f.getFidelityOptions().setFidelity("PRESERVE_LEXICAL_VALUES", true);
/*     */       }
/* 291 */       else if ("comments".equals(localName)) {
/* 292 */         f.getFidelityOptions().setFidelity("PRESERVE_COMMENTS", true);
/*     */       }
/* 294 */       else if ("pis".equals(localName)) {
/* 295 */         f.getFidelityOptions().setFidelity("PRESERVE_PIS", true);
/*     */       }
/* 297 */       else if ("compression".equals(localName)) {
/* 298 */         f.setCodingMode(CodingMode.COMPRESSION);
/* 299 */       } else if ("fragment".equals(localName)) {
/* 300 */         f.setFragment(true);
/* 301 */       } else if ("strict".equals(localName)) {
/* 302 */         f.getFidelityOptions().setFidelity("STRICT", true);
/*     */       }
/* 304 */       else if ("p".equals(localName)) {
/*     */       
/*     */       } 
/*     */     } 
/*     */     
/* 309 */     this.lastSE = se;
/*     */   }
/*     */   
/*     */   protected void handleEndElement(QNameContext ee, EXIFactory f) {
/* 313 */     if ("http://www.w3.org/2009/exi".equals(ee.getNamespaceUri())) {
/* 314 */       String localName = ee.getLocalName();
/*     */       
/* 316 */       if ("datatypeRepresentationMap".equals(localName)) {
/* 317 */         this.dtrSection = false;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleCharacters(Value value, EXIFactory f) throws EXIException {
/* 328 */     String localName = this.lastSE.getLocalName();
/*     */     
/* 330 */     if ("valueMaxLength".equals(localName)) {
/* 331 */       if (value instanceof IntegerValue) {
/* 332 */         IntegerValue iv = (IntegerValue)value;
/* 333 */         f.setValueMaxLength(iv.intValue());
/*     */       } else {
/* 335 */         throw new EXIException("[EXI-Header] Failure while processing " + localName);
/*     */       }
/*     */     
/* 338 */     } else if ("valuePartitionCapacity".equals(localName)) {
/* 339 */       if (value instanceof IntegerValue) {
/* 340 */         IntegerValue iv = (IntegerValue)value;
/* 341 */         if (iv.getIntegerValueType() == IntegerValueType.INT) {
/* 342 */           f.setValuePartitionCapacity(iv.intValue());
/*     */         } else {
/* 344 */           throw new EXIException("[EXI-Header] ValuePartitionCapacity other than int not supported: " + iv);
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 350 */         throw new EXIException("[EXI-Header] Failure while processing " + localName);
/*     */       }
/*     */     
/* 353 */     } else if ("blockSize".equals(localName)) {
/* 354 */       if (value instanceof IntegerValue) {
/* 355 */         IntegerValue iv = (IntegerValue)value;
/* 356 */         if (iv.getIntegerValueType() == IntegerValueType.INT) {
/* 357 */           f.setBlockSize(iv.intValue());
/*     */         } else {
/* 359 */           throw new EXIException("[EXI-Header] BlockSize other than int not supported: " + iv);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 364 */         throw new EXIException("[EXI-Header] Failure while processing " + localName);
/*     */       }
/*     */     
/* 367 */     } else if ("schemaId".equals(localName)) {
/* 368 */       if (!f.getDecodingOptions().isOptionEnabled("IGNORE_SCHEMA_ID"))
/*     */       {
/*     */ 
/*     */         
/* 372 */         String schemaId = value.toString();
/*     */         
/* 374 */         assert schemaId != null;
/* 375 */         SchemaIdResolver sir = f.getSchemaIdResolver();
/* 376 */         if (sir != null) {
/* 377 */           f.setGrammars(sir.resolveSchemaId(schemaId));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 409 */           throw new EXIException("EXI Header povides schemaId '" + schemaId + "'. No schemaIdResolver set!");
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 414 */     } else if ("p".equals(localName)) {
/*     */       
/* 416 */       if (value.getValueType() == ValueType.DECIMAL) {
/* 417 */         DecimalValue dv = (DecimalValue)value;
/* 418 */         f.setLocalValuePartitions(dv.isNegative());
/* 419 */         assert dv.getIntegral().getIntegerValueType() == IntegerValueType.INT;
/* 420 */         f.setMaximumNumberOfBuiltInElementGrammars(dv.getIntegral()
/* 421 */             .intValue() - 1);
/* 422 */         assert dv.getRevFractional().getIntegerValueType() == IntegerValueType.INT;
/* 423 */         f.setMaximumNumberOfBuiltInProductions(dv.getRevFractional()
/* 424 */             .intValue() - 1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void handleXsiNil(Value value, EXIFactory f) throws EXIException {
/* 430 */     String localName = this.lastSE.getLocalName();
/*     */     
/* 432 */     if ("schemaId".equals(localName))
/* 433 */       if (value instanceof BooleanValue) {
/* 434 */         BooleanValue bv = (BooleanValue)value;
/* 435 */         if (bv.toBoolean())
/*     */         {
/* 437 */           f.setGrammars((Grammars)new SchemaLessGrammars());
/*     */         }
/*     */       } else {
/* 440 */         throw new EXIException("[EXI-Header] Failure while processing " + localName);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIHeaderDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */