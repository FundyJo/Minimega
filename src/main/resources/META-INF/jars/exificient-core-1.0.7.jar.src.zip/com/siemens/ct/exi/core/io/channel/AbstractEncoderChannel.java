/*     */ package com.siemens.ct.exi.core.io.channel;
/*     */ 
/*     */ import com.siemens.ct.exi.core.types.DateTimeType;
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import com.siemens.ct.exi.core.values.DateTimeValue;
/*     */ import com.siemens.ct.exi.core.values.FloatValue;
/*     */ import com.siemens.ct.exi.core.values.IntegerValue;
/*     */ import com.siemens.ct.exi.core.values.IntegerValueType;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEncoderChannel
/*     */   implements EncoderChannel
/*     */ {
/*     */   public void encodeBinary(byte[] b) throws IOException {
/*  47 */     encodeUnsignedInteger(b.length);
/*  48 */     encode(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeString(String s) throws IOException {
/*  57 */     int lenChars = s.length();
/*  58 */     int lenCharacters = s.codePointCount(0, lenChars);
/*  59 */     encodeUnsignedInteger(lenCharacters);
/*  60 */     encodeStringOnly(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeStringOnly(String s) throws IOException {
/*  67 */     int lenChars = s.length();
/*  68 */     for (int i = 0; i < lenChars; i++) {
/*  69 */       char ch = s.charAt(i);
/*     */ 
/*     */       
/*  72 */       if (Character.isHighSurrogate(ch)) {
/*     */         
/*  74 */         encodeUnsignedInteger(s.codePointAt(i++));
/*     */       } else {
/*  76 */         encodeUnsignedInteger(ch);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeInteger(int n) throws IOException {
/*  89 */     if (n < 0) {
/*  90 */       encodeBoolean(true);
/*     */ 
/*     */       
/*  93 */       encodeUnsignedInteger(-n - 1);
/*     */     } else {
/*  95 */       encodeBoolean(false);
/*  96 */       encodeUnsignedInteger(n);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void encodeLong(long l) throws IOException {
/* 102 */     if (l < 0L) {
/* 103 */       encodeBoolean(true);
/* 104 */       encodeUnsignedLong(-l - 1L);
/*     */     } else {
/* 106 */       encodeBoolean(false);
/* 107 */       encodeUnsignedLong(l);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void encodeBigInteger(BigInteger bi) throws IOException {
/* 112 */     if (bi.signum() < 0) {
/* 113 */       encodeBoolean(true);
/* 114 */       encodeUnsignedBigInteger(bi.negate().subtract(BigInteger.ONE));
/*     */     } else {
/* 116 */       encodeBoolean(false);
/* 117 */       encodeUnsignedBigInteger(bi);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void encodeIntegerValue(IntegerValue iv) throws IOException {
/* 122 */     switch (iv.getIntegerValueType()) {
/*     */       case gYear:
/* 124 */         encodeInteger(iv.intValue());
/*     */         return;
/*     */       case gYearMonth:
/* 127 */         encodeLong(iv.longValue());
/*     */         return;
/*     */       case date:
/* 130 */         encodeBigInteger(iv.bigIntegerValue());
/*     */         return;
/*     */     } 
/* 133 */     throw new IOException("Unexpcted EXI integer value type " + iv
/* 134 */         .getValueType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeUnsignedInteger(int n) throws IOException {
/* 145 */     if (n < 0) {
/* 146 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/* 149 */     if (n < 128) {
/*     */       
/* 151 */       encode(n);
/*     */     } else {
/* 153 */       int n7BitBlocks = MethodsBag.numberOf7BitBlocksToRepresent(n);
/*     */       
/* 155 */       switch (n7BitBlocks) {
/*     */         case 5:
/* 157 */           encode(0x80 | n);
/* 158 */           n >>>= 7;
/*     */         case 4:
/* 160 */           encode(0x80 | n);
/* 161 */           n >>>= 7;
/*     */         case 3:
/* 163 */           encode(0x80 | n);
/* 164 */           n >>>= 7;
/*     */         case 2:
/* 166 */           encode(0x80 | n);
/* 167 */           n >>>= 7;
/*     */         
/*     */         case 1:
/* 170 */           encode(0x0 | n);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   protected void encodeUnsignedLong(long l) throws IOException {
/* 176 */     if (l < 0L) {
/* 177 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/* 180 */     int lastEncode = (int)l;
/* 181 */     l >>>= 7L;
/*     */     
/* 183 */     while (l != 0L) {
/* 184 */       encode(lastEncode | 0x80);
/* 185 */       lastEncode = (int)l;
/* 186 */       l >>>= 7L;
/*     */     } 
/*     */     
/* 189 */     encode(lastEncode);
/*     */   }
/*     */   
/*     */   protected void encodeUnsignedBigInteger(BigInteger bi) throws IOException {
/* 193 */     if (bi.signum() < 0) {
/* 194 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 199 */     int m = bi.bitLength() % 7;
/* 200 */     int nbytes = bi.bitLength() / 7 + ((m > 0) ? 1 : 0);
/*     */     
/* 202 */     while (--nbytes > 0) {
/*     */       
/* 204 */       encode(0x80 | bi.intValue());
/* 205 */       bi = bi.shiftRight(7);
/*     */     } 
/*     */ 
/*     */     
/* 209 */     encode(0x0 | bi.intValue());
/*     */   }
/*     */   
/*     */   public void encodeUnsignedIntegerValue(IntegerValue iv) throws IOException {
/* 213 */     switch (iv.getIntegerValueType()) {
/*     */       case gYear:
/* 215 */         encodeUnsignedInteger(iv.intValue());
/*     */         return;
/*     */       case gYearMonth:
/* 218 */         encodeUnsignedLong(iv.longValue());
/*     */         return;
/*     */       case date:
/* 221 */         encodeUnsignedBigInteger(iv.bigIntegerValue());
/*     */         return;
/*     */     } 
/* 224 */     throw new IOException("Unexpcted EXI integer value type " + iv
/* 225 */         .getValueType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeDecimal(boolean negative, IntegerValue integral, IntegerValue reverseFraction) throws IOException, RuntimeException {
/* 241 */     encodeBoolean(negative);
/* 242 */     encodeUnsignedIntegerValue(integral);
/* 243 */     encodeUnsignedIntegerValue(reverseFraction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeFloat(FloatValue fv) throws IOException {
/* 253 */     encodeIntegerValue(fv.getMantissa());
/* 254 */     encodeIntegerValue(fv.getExponent());
/*     */   }
/*     */   
/*     */   public void encodeDateTime(DateTimeValue datetime) throws IOException {
/* 258 */     switch (datetime.type) {
/*     */       case gYear:
/* 260 */         encodeInteger(datetime.year - 2000);
/*     */         break;
/*     */       case gYearMonth:
/*     */       case date:
/* 264 */         encodeInteger(datetime.year - 2000);
/* 265 */         encodeNBitUnsignedInteger(datetime.monthDay, 9);
/*     */         break;
/*     */ 
/*     */       
/*     */       case dateTime:
/* 270 */         encodeInteger(datetime.year - 2000);
/* 271 */         encodeNBitUnsignedInteger(datetime.monthDay, 9);
/*     */ 
/*     */       
/*     */       case time:
/* 275 */         encodeNBitUnsignedInteger(datetime.time, 17);
/*     */         
/* 277 */         if (datetime.presenceFractionalSecs) {
/* 278 */           encodeBoolean(true);
/* 279 */           encodeUnsignedInteger(datetime.fractionalSecs); break;
/*     */         } 
/* 281 */         encodeBoolean(false);
/*     */         break;
/*     */       
/*     */       case gMonth:
/*     */       case gMonthDay:
/*     */       case gDay:
/* 287 */         encodeNBitUnsignedInteger(datetime.monthDay, 9);
/*     */         break;
/*     */       
/*     */       default:
/* 291 */         throw new UnsupportedOperationException();
/*     */     } 
/*     */     
/* 294 */     if (datetime.presenceTimezone) {
/* 295 */       encodeBoolean(true);
/* 296 */       encodeNBitUnsignedInteger(datetime.timezone + 896, 11);
/*     */     }
/*     */     else {
/*     */       
/* 300 */       encodeBoolean(false);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\channel\AbstractEncoderChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */