/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.datatype.charset.RestrictedCharacterSet;
/*    */ import com.siemens.ct.exi.core.types.BuiltInType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RestrictedCharacterSetDatatype
/*    */   extends AbstractDatatype
/*    */ {
/*    */   protected RestrictedCharacterSet rcs;
/*    */   
/*    */   public RestrictedCharacterSetDatatype(RestrictedCharacterSet rcs, QNameContext schemaType) {
/* 44 */     this(rcs, schemaType, WhiteSpace.preserve);
/*    */   }
/*    */ 
/*    */   
/*    */   public RestrictedCharacterSetDatatype(RestrictedCharacterSet rcs, QNameContext schemaType, WhiteSpace whiteSpace) {
/* 49 */     super(BuiltInType.RCS_STRING, schemaType);
/* 50 */     this.rcs = rcs;
/* 51 */     this.whiteSpace = whiteSpace;
/*    */   }
/*    */   
/*    */   public RestrictedCharacterSet getRestrictedCharacterSet() {
/* 55 */     return this.rcs;
/*    */   }
/*    */   
/*    */   public DatatypeID getDatatypeID() {
/* 59 */     return DatatypeID.exi_string;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 64 */     if (super.equals(o) && o instanceof RestrictedCharacterSetDatatype) {
/* 65 */       RestrictedCharacterSetDatatype r = (RestrictedCharacterSetDatatype)o;
/* 66 */       return this.rcs.equals(r.rcs);
/*    */     } 
/* 68 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\RestrictedCharacterSetDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */