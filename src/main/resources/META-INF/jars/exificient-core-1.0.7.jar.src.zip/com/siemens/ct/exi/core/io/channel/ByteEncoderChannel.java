/*     */ package com.siemens.ct.exi.core.io.channel;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ByteEncoderChannel
/*     */   extends AbstractEncoderChannel
/*     */   implements EncoderChannel
/*     */ {
/*     */   private final OutputStream os;
/*     */   protected int len;
/*     */   
/*     */   public ByteEncoderChannel(OutputStream os) {
/*  49 */     this.os = os;
/*  50 */     this.len = 0;
/*     */   }
/*     */   
/*     */   public OutputStream getOutputStream() {
/*  54 */     return this.os;
/*     */   }
/*     */   
/*     */   public int getLength() {
/*  58 */     return this.len;
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/*  62 */     this.os.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void align() throws IOException {}
/*     */ 
/*     */   
/*     */   public void encode(int b) throws IOException {
/*  70 */     this.os.write(b);
/*  71 */     this.len++;
/*     */   }
/*     */   
/*     */   public void encode(byte[] b, int off, int len) throws IOException {
/*  75 */     this.os.write(b, off, len);
/*  76 */     this.len += len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBoolean(boolean b) throws IOException, IllegalArgumentException {
/*  85 */     encode(b ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeNBitUnsignedInteger(int b, int n) throws IOException {
/*  94 */     if (b < 0 || n < 0) {
/*  95 */       throw new IllegalArgumentException("Negative value as unsigned integer!");
/*     */     }
/*     */     
/*  98 */     assert b >= 0;
/*  99 */     assert n >= 0;
/*     */     
/* 101 */     if (n != 0)
/*     */     {
/* 103 */       if (n < 9) {
/*     */         
/* 105 */         encode(b & 0xFF);
/* 106 */       } else if (n < 17) {
/*     */         
/* 108 */         encode(b & 0xFF);
/* 109 */         encode((b & 0xFF00) >> 8);
/* 110 */       } else if (n < 25) {
/*     */         
/* 112 */         encode(b & 0xFF);
/* 113 */         encode((b & 0xFF00) >> 8);
/* 114 */         encode((b & 0xFF0000) >> 16);
/* 115 */       } else if (n < 33) {
/*     */         
/* 117 */         encode(b & 0xFF);
/* 118 */         encode((b & 0xFF00) >> 8);
/* 119 */         encode((b & 0xFF0000) >> 16);
/* 120 */         encode((b & 0xFF000000) >> 24);
/*     */       } else {
/* 122 */         throw new RuntimeException("Currently not more than 4 Bytes allowed for NBitUnsignedInteger!");
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\channel\ByteEncoderChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */