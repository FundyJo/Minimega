package com.siemens.ct.exi.core.datatype;

import com.siemens.ct.exi.core.context.QNameContext;
import com.siemens.ct.exi.core.types.BuiltInType;

public interface Datatype {
  BuiltInType getBuiltInType();
  
  QNameContext getSchemaType();
  
  Datatype getBaseDatatype();
  
  void setBaseDatatype(Datatype paramDatatype);
  
  void setGrammarEnumeration(EnumDatatype paramEnumDatatype);
  
  EnumDatatype getGrammarEnumeration();
  
  WhiteSpace getWhiteSpace();
  
  DatatypeID getDatatypeID();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\Datatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */