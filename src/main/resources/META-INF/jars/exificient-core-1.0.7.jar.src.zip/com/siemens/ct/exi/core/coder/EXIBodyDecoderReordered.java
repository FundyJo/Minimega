/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.CodingMode;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.container.DocType;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.container.PreReadValue;
/*     */ import com.siemens.ct.exi.core.container.ProcessingInstruction;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringDecoder;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.io.channel.ByteDecoderChannel;
/*     */ import com.siemens.ct.exi.core.io.channel.DecoderChannel;
/*     */ import com.siemens.ct.exi.core.io.compression.EXIInflaterInputStream;
/*     */ import com.siemens.ct.exi.core.types.BuiltIn;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.zip.Inflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIBodyDecoderReordered
/*     */   extends AbstractEXIBodyDecoder
/*     */ {
/*     */   protected List<EventType> eventTypes;
/*     */   protected int eventTypeIndex;
/*     */   protected List<AbstractEXIBodyCoder.ElementContext> elementEntries;
/*     */   protected int elementEntryIndex;
/*     */   protected List<QNameEntry> qnameEntries;
/*     */   protected int qnameEntryIndex;
/*     */   protected List<DocType> docTypeEntries;
/*     */   protected int docTypeEntryIndex;
/*     */   protected List<char[]> entityReferences;
/*     */   protected int entityReferenceIndex;
/*     */   protected List<char[]> comments;
/*     */   protected int commentIndex;
/*     */   protected List<NamespaceDeclaration> nsEntries;
/*     */   protected int nsEntryIndex;
/*     */   protected List<ProcessingInstruction> processingEntries;
/*     */   protected int processingEntryIndex;
/*     */   protected int blockValues;
/*     */   boolean stillNoEndOfDocument = true;
/*     */   AbstractEXIBodyCoder.ElementContext lastBlockElementContext;
/*     */   protected CodingMode codingMode;
/*     */   AbstractEXIBodyCoder.ElementContext currElementEntry;
/*     */   protected Map<QNameContext, PreReadValue> contentValues;
/*     */   protected List<Value> xsiValues;
/*     */   protected int xsiValueIndex;
/*     */   protected List<String> xsiPrefixes;
/*     */   protected int xsiPrefixIndex;
/*     */   protected Inflater inflater;
/*     */   protected Map<QNameContext, List<Datatype>> channelDatatypes;
/*     */   protected Map<QNameContext, PreReadValue> preReadValues;
/*     */   protected boolean firstChannel;
/*     */   protected InputStream is;
/*     */   EXIInflaterInputStream inflaterInputStream;
/*     */   
/*     */   public EXIBodyDecoderReordered(EXIFactory exiFactory) throws EXIException {
/* 127 */     super(exiFactory);
/*     */ 
/*     */     
/* 130 */     this.eventTypes = new ArrayList<>();
/*     */     
/* 132 */     this.elementEntries = new ArrayList<>();
/*     */     
/* 134 */     this.qnameEntries = new ArrayList<>();
/*     */     
/* 136 */     this.docTypeEntries = new ArrayList<>();
/* 137 */     this.entityReferences = (List)new ArrayList<>();
/* 138 */     this.comments = (List)new ArrayList<>();
/* 139 */     this.nsEntries = new ArrayList<>();
/* 140 */     this.processingEntries = new ArrayList<>();
/*     */     
/* 142 */     this.preReadValues = new HashMap<>();
/*     */ 
/*     */     
/* 145 */     this.channelDatatypes = new LinkedHashMap<>();
/*     */ 
/*     */     
/* 148 */     this.contentValues = new HashMap<>();
/*     */     
/* 150 */     this.xsiValues = new ArrayList<>();
/* 151 */     this.xsiPrefixes = new ArrayList<>();
/*     */     
/* 153 */     this.codingMode = exiFactory.getCodingMode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initForEachRun() throws EXIException, IOException {
/* 159 */     super.initForEachRun();
/*     */ 
/*     */     
/* 162 */     this.nextEvent = null;
/* 163 */     this.nextEventType = EventType.START_DOCUMENT;
/*     */ 
/*     */     
/* 166 */     this.elementEntries.clear();
/* 167 */     this.elementEntryIndex = 0;
/*     */     
/* 169 */     this.qnameEntries.clear();
/* 170 */     this.qnameEntryIndex = 0;
/*     */ 
/*     */     
/* 173 */     this.docTypeEntries.clear();
/* 174 */     this.docTypeEntryIndex = 0;
/* 175 */     this.entityReferences.clear();
/* 176 */     this.entityReferenceIndex = 0;
/* 177 */     this.comments.clear();
/* 178 */     this.commentIndex = 0;
/* 179 */     this.nsEntries.clear();
/* 180 */     this.nsEntryIndex = 0;
/* 181 */     this.processingEntries.clear();
/* 182 */     this.processingEntryIndex = 0;
/*     */     
/* 184 */     this.stillNoEndOfDocument = true;
/* 185 */     this.lastBlockElementContext = null;
/*     */     
/* 187 */     this.channelDatatypes.clear();
/*     */ 
/*     */     
/* 190 */     initBlock();
/*     */ 
/*     */ 
/*     */     
/* 194 */     preReadBlockStructure();
/* 195 */     preReadBlockContent();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBlock() {
/* 200 */     this.blockValues = 0;
/*     */ 
/*     */     
/* 203 */     this.eventTypes.clear();
/* 204 */     this.eventTypeIndex = 0;
/*     */ 
/*     */ 
/*     */     
/* 208 */     initCompressionBlock();
/*     */ 
/*     */     
/* 211 */     this.contentValues.clear();
/* 212 */     this.xsiValues.clear();
/* 213 */     this.xsiValueIndex = 0;
/* 214 */     this.xsiPrefixes.clear();
/* 215 */     this.xsiPrefixIndex = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initCompressionBlock() {
/* 220 */     this.channelDatatypes.clear();
/*     */     
/* 222 */     this.preReadValues.clear();
/*     */   }
/*     */   
/*     */   protected void addDatatype(QNameContext qnc, Datatype d) {
/* 226 */     List<Datatype> ds = this.channelDatatypes.get(qnc);
/* 227 */     if (ds == null) {
/*     */       
/* 229 */       ds = new ArrayList<>();
/*     */       
/* 231 */       this.channelDatatypes.put(qnc, ds);
/*     */     } 
/* 233 */     ds.add(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInputStream(InputStream is) throws EXIException, IOException {
/* 238 */     updateInputStream(is);
/*     */     
/* 240 */     initForEachRun();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateInputStream(InputStream is) throws EXIException, IOException {
/* 247 */     this.is = is;
/* 248 */     if (!(this.is instanceof PushbackInputStream)) {
/* 249 */       this.is = new PushbackInputStream(is, 512);
/*     */     }
/*     */     
/* 252 */     this.inflaterInputStream = null;
/*     */     
/* 254 */     this.firstChannel = true;
/* 255 */     this.inflater = new Inflater(true);
/* 256 */     this.channel = getNextChannel();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInputChannel(DecoderChannel channel) throws EXIException, IOException {
/* 261 */     throw new RuntimeException("[EXI] Reorderd EXI Body decoder needs to be set via setInputStream(...)");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateInputChannel(DecoderChannel decoderChannel) throws EXIException, IOException {
/* 267 */     throw new RuntimeException("[EXI] Reorderd EXI Body decoder needs to be set via updateInputStream(...)");
/*     */   }
/*     */ 
/*     */   
/*     */   private void readjustInputStream(InputStream is) throws IOException {
/* 272 */     assert this.codingMode == CodingMode.COMPRESSION;
/* 273 */     if (this.inflaterInputStream != null)
/*     */     {
/*     */       
/* 276 */       this.inflaterInputStream.pushbackAndReset();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public DecoderChannel getNextChannel() throws IOException {
/* 282 */     if (this.codingMode == CodingMode.COMPRESSION) {
/*     */       
/* 284 */       readjustInputStream(this.is);
/*     */       
/* 286 */       this.inflaterInputStream = new EXIInflaterInputStream((PushbackInputStream)this.is, this.inflater, 512);
/*     */ 
/*     */       
/* 289 */       return (DecoderChannel)new ByteDecoderChannel((InputStream)this.inflaterInputStream);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 294 */     assert this.codingMode == CodingMode.PRE_COMPRESSION;
/* 295 */     if (this.firstChannel) {
/*     */       
/* 297 */       this.channel = (DecoderChannel)new ByteDecoderChannel(this.is);
/* 298 */       this.firstChannel = false;
/*     */     } 
/*     */     
/* 301 */     return this.channel;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateAttributeToXsiType() throws EXIException, IOException {
/* 306 */     this.eventTypes.set(this.eventTypes.size() - 1, EventType.ATTRIBUTE_XSI_TYPE);
/*     */     
/* 308 */     decodeAttributeXsiTypeStructure();
/* 309 */     this.xsiValues.add(this.attributeValue);
/*     */     
/* 311 */     this.xsiPrefixes.add(this.attributePrefix);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleSpecialAttributeCases() throws EXIException, IOException {
/* 316 */     if (getXsiTypeContext().equals(this.attributeQNameContext)) {
/*     */       
/* 318 */       updateAttributeToXsiType();
/* 319 */     } else if (getXsiNilContext().equals(this.attributeQNameContext) && 
/* 320 */       getCurrentGrammar().isSchemaInformed()) {
/*     */       
/* 322 */       this.eventTypes.set(this.eventTypes.size() - 1, EventType.ATTRIBUTE_XSI_NIL);
/*     */       
/* 324 */       decodeAttributeXsiNilStructure();
/* 325 */       this.xsiValues.add(this.attributeValue);
/*     */       
/* 327 */       this.xsiPrefixes.add(this.attributePrefix);
/*     */     } else {
/*     */       
/* 330 */       Datatype dt = BuiltIn.getDefaultDatatype();
/*     */       
/* 332 */       if (getCurrentGrammar().isSchemaInformed() && this.attributeQNameContext
/* 333 */         .getGlobalAttribute() != null) {
/* 334 */         dt = this.attributeQNameContext.getGlobalAttribute().getDatatype();
/*     */       }
/*     */       
/* 337 */       addQNameEntry(new QNameEntry(this.attributeQNameContext, this.attributePrefix));
/* 338 */       incrementValues(this.attributeQNameContext, dt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void preReadBlockStructure() throws EXIException, IOException {
/* 344 */     boolean stillBlockReadable = true;
/* 345 */     boolean deferredStartElement = false;
/*     */     
/* 347 */     if (this.lastBlockElementContext != null) {
/* 348 */       updateElementContext(this.lastBlockElementContext);
/*     */     }
/*     */     
/* 351 */     while (this.stillNoEndOfDocument && stillBlockReadable) {
/*     */       Datatype dtAT; QNameContext qnc;
/* 353 */       if (deferredStartElement) {
/* 354 */         switch (this.nextEventType) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case ATTRIBUTE:
/*     */           case ATTRIBUTE_INVALID_VALUE:
/*     */           case ATTRIBUTE_ANY_INVALID_VALUE:
/*     */           case ATTRIBUTE_GENERIC:
/*     */           case ATTRIBUTE_NS:
/*     */           case ATTRIBUTE_GENERIC_UNDECLARED:
/*     */           case START_ELEMENT:
/*     */           case START_ELEMENT_NS:
/*     */           case START_ELEMENT_GENERIC:
/*     */           case START_ELEMENT_GENERIC_UNDECLARED:
/*     */           case END_ELEMENT:
/*     */           case END_ELEMENT_UNDECLARED:
/*     */           case CHARACTERS:
/*     */           case CHARACTERS_GENERIC:
/*     */           case CHARACTERS_GENERIC_UNDECLARED:
/*     */           case DOC_TYPE:
/*     */           case ENTITY_REFERENCE:
/*     */           case COMMENT:
/*     */           case PROCESSING_INSTRUCTION:
/* 378 */             this.elementEntries.add(getElementContext());
/* 379 */             deferredStartElement = false;
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 386 */       this.eventTypes.add(this.nextEventType);
/*     */       
/* 388 */       switch (this.nextEventType) {
/*     */         case START_DOCUMENT:
/* 390 */           decodeStartDocumentStructure();
/*     */           break;
/*     */         case START_ELEMENT:
/* 393 */           decodeStartElementStructure();
/* 394 */           deferredStartElement = true;
/*     */           break;
/*     */         case START_ELEMENT_NS:
/* 397 */           decodeStartElementNSStructure();
/* 398 */           deferredStartElement = true;
/*     */           break;
/*     */         case START_ELEMENT_GENERIC:
/* 401 */           decodeStartElementGenericStructure();
/* 402 */           deferredStartElement = true;
/*     */           break;
/*     */         case START_ELEMENT_GENERIC_UNDECLARED:
/* 405 */           decodeStartElementGenericUndeclaredStructure();
/* 406 */           deferredStartElement = true;
/*     */           break;
/*     */         case NAMESPACE_DECLARATION:
/* 409 */           this.nsEntries.add(decodeNamespaceDeclarationStructure());
/*     */           break;
/*     */         case ATTRIBUTE_XSI_TYPE:
/* 412 */           decodeAttributeXsiTypeStructure();
/* 413 */           this.xsiPrefixes.add(this.attributePrefix);
/* 414 */           this.xsiValues.add(this.attributeValue);
/*     */           break;
/*     */         case ATTRIBUTE_XSI_NIL:
/* 417 */           decodeAttributeXsiNilStructure();
/* 418 */           this.xsiPrefixes.add(this.attributePrefix);
/* 419 */           this.xsiValues.add(this.attributeValue);
/*     */           break;
/*     */         case ATTRIBUTE:
/* 422 */           dtAT = decodeAttributeStructure();
/* 423 */           if (getXsiTypeContext().equals(this.attributeQNameContext)) {
/* 424 */             updateAttributeToXsiType(); break;
/*     */           } 
/* 426 */           addQNameEntry(new QNameEntry(this.attributeQNameContext, this.attributePrefix));
/*     */           
/* 428 */           incrementValues(this.attributeQNameContext, dtAT);
/*     */           break;
/*     */         
/*     */         case ATTRIBUTE_INVALID_VALUE:
/* 432 */           decodeAttributeStructure();
/* 433 */           addQNameEntry(new QNameEntry(this.attributeQNameContext, this.attributePrefix));
/*     */           
/* 435 */           incrementValues(this.attributeQNameContext, 
/* 436 */               BuiltIn.getDefaultDatatype());
/*     */           break;
/*     */         case ATTRIBUTE_ANY_INVALID_VALUE:
/* 439 */           decodeAttributeAnyInvalidValueStructure();
/* 440 */           addQNameEntry(new QNameEntry(this.attributeQNameContext, this.attributePrefix));
/*     */           
/* 442 */           incrementValues(this.attributeQNameContext, 
/* 443 */               BuiltIn.getDefaultDatatype());
/*     */           break;
/*     */         case ATTRIBUTE_NS:
/* 446 */           decodeAttributeNSStructure();
/*     */           
/* 448 */           handleSpecialAttributeCases();
/*     */           break;
/*     */         case ATTRIBUTE_GENERIC:
/* 451 */           decodeAttributeGenericStructure();
/*     */           
/* 453 */           handleSpecialAttributeCases();
/*     */           break;
/*     */         case ATTRIBUTE_GENERIC_UNDECLARED:
/* 456 */           decodeAttributeGenericUndeclaredStructure();
/*     */           
/* 458 */           handleSpecialAttributeCases();
/*     */           break;
/*     */         case CHARACTERS:
/* 461 */           qnc = (getElementContext()).qnameContext;
/* 462 */           incrementValues(qnc, decodeCharactersStructure());
/* 463 */           addQNameEntry(new QNameEntry(qnc, null));
/*     */           break;
/*     */         case CHARACTERS_GENERIC:
/* 466 */           decodeCharactersGenericStructure();
/* 467 */           qnc = (getElementContext()).qnameContext;
/* 468 */           incrementValues(qnc, BuiltIn.getDefaultDatatype());
/* 469 */           addQNameEntry(new QNameEntry(qnc, null));
/*     */           break;
/*     */         case CHARACTERS_GENERIC_UNDECLARED:
/* 472 */           decodeCharactersGenericUndeclaredStructure();
/* 473 */           qnc = (getElementContext()).qnameContext;
/* 474 */           incrementValues(qnc, BuiltIn.getDefaultDatatype());
/* 475 */           addQNameEntry(new QNameEntry(qnc, null));
/*     */           break;
/*     */         case END_ELEMENT:
/* 478 */           decodeEndElementStructure();
/* 479 */           this.elementEntries.add(getElementContext());
/*     */           break;
/*     */         case END_ELEMENT_UNDECLARED:
/* 482 */           decodeEndElementUndeclaredStructure();
/* 483 */           this.elementEntries.add(getElementContext());
/*     */           break;
/*     */         case END_DOCUMENT:
/* 486 */           decodeEndDocumentStructure();
/* 487 */           this.stillNoEndOfDocument = false;
/*     */           continue;
/*     */         case DOC_TYPE:
/* 490 */           this.docTypeEntries.add(decodeDocTypeStructure());
/*     */           break;
/*     */         case ENTITY_REFERENCE:
/* 493 */           this.entityReferences.add(decodeEntityReferenceStructure());
/*     */           break;
/*     */         case COMMENT:
/* 496 */           this.comments.add(decodeCommentStructure());
/*     */           break;
/*     */         case PROCESSING_INSTRUCTION:
/* 499 */           this.processingEntries.add(decodeProcessingInstructionStructure());
/*     */           break;
/*     */         default:
/* 502 */           throw new RuntimeException("Unknown Event " + this.nextEventType);
/*     */       } 
/*     */ 
/*     */       
/* 506 */       if (this.blockValues == this.exiFactory.getBlockSize()) {
/*     */         
/* 508 */         stillBlockReadable = false;
/*     */         
/* 510 */         this.lastBlockElementContext = getElementContext();
/*     */ 
/*     */         
/* 513 */         assert !deferredStartElement;
/*     */         continue;
/*     */       } 
/* 516 */       decodeEventCode();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 523 */     updateElementContext(this.lastBlockElementContext);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void preReadBlockContent() throws EXIException {
/*     */     try {
/* 529 */       Iterator<QNameContext> iterCh = this.channelDatatypes.keySet().iterator();
/*     */       
/* 531 */       if (this.blockValues <= 100) {
/*     */ 
/*     */         
/* 534 */         while (iterCh.hasNext()) {
/* 535 */           QNameContext o = iterCh.next();
/* 536 */           List<Datatype> lds = this.channelDatatypes.get(o);
/* 537 */           Value[] contentValues = readValues(lds, o, this.channel, this.stringDecoder);
/*     */           
/* 539 */           PreReadValue prv = new PreReadValue(contentValues);
/* 540 */           this.preReadValues.put(o, prv);
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 546 */         DecoderChannel bdcLessEqual100 = null;
/*     */         
/* 548 */         while (iterCh.hasNext()) {
/* 549 */           QNameContext o = iterCh.next();
/* 550 */           List<Datatype> lds = this.channelDatatypes.get(o);
/* 551 */           if (lds.size() <= 100) {
/* 552 */             if (bdcLessEqual100 == null) {
/* 553 */               bdcLessEqual100 = getNextChannel();
/*     */             }
/* 555 */             Value[] contentValues = readValues(lds, o, bdcLessEqual100, this.stringDecoder);
/*     */             
/* 557 */             PreReadValue prv = new PreReadValue(contentValues);
/* 558 */             this.preReadValues.put(o, prv);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 563 */         iterCh = this.channelDatatypes.keySet().iterator();
/* 564 */         while (iterCh.hasNext()) {
/* 565 */           QNameContext o = iterCh.next();
/* 566 */           List<Datatype> lds = this.channelDatatypes.get(o);
/* 567 */           if (lds.size() > 100) {
/* 568 */             DecoderChannel bdcGreater100 = getNextChannel();
/* 569 */             Value[] contentValues = readValues(lds, o, bdcGreater100, this.stringDecoder);
/*     */             
/* 571 */             PreReadValue prv = new PreReadValue(contentValues);
/* 572 */             this.preReadValues.put(o, prv);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 577 */     } catch (IOException e) {
/* 578 */       throw new EXIException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Value[] readValues(List<Datatype> lds, QNameContext o, DecoderChannel valueChannel, StringDecoder stringDecoder) throws IOException {
/* 585 */     Value[] contentValues = new Value[lds.size()];
/* 586 */     for (int i = 0; i < lds.size(); i++) {
/* 587 */       contentValues[i] = this.typeDecoder.readValue(lds.get(i), o, valueChannel, stringDecoder);
/*     */     }
/*     */ 
/*     */     
/* 591 */     return contentValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setContentValues(DecoderChannel bdc, QNameContext channelContext, int occs, List<Datatype> datatypes) throws IOException {
/* 598 */     assert datatypes.size() == occs;
/* 599 */     Value[] decodedValues = new Value[occs];
/*     */     
/* 601 */     for (int k = 0; k < occs; k++) {
/* 602 */       Datatype dt = datatypes.get(k);
/* 603 */       decodedValues[k] = this.typeDecoder.readValue(dt, channelContext, bdc, this.stringDecoder);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 608 */     this.contentValues.put(channelContext, new PreReadValue(decodedValues));
/*     */   }
/*     */   
/*     */   private final void setupNewBlock() throws IOException, EXIException {
/* 612 */     initBlock();
/*     */     
/* 614 */     this.channel = getNextChannel();
/*     */ 
/*     */     
/* 617 */     decodeEventCode();
/*     */     
/* 619 */     preReadBlockStructure();
/* 620 */     preReadBlockContent();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Value getNextContentValue(QNameContext qname) throws EXIException, IOException {
/* 626 */     this.blockValues--;
/*     */     
/* 628 */     Value v = ((PreReadValue)this.preReadValues.get(qname)).getNextContantValue();
/*     */     
/* 630 */     return v;
/*     */   }
/*     */   
/*     */   public EventType next() throws EXIException, IOException {
/* 634 */     if (this.stillNoEndOfDocument && this.blockValues == 0)
/*     */     {
/* 636 */       setupNewBlock();
/*     */     }
/*     */     
/* 639 */     if (this.stillNoEndOfDocument || this.eventTypes.size() > this.eventTypeIndex) {
/* 640 */       return this.eventTypes.get(this.eventTypeIndex++);
/*     */     }
/* 642 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void incrementValues(QNameContext valueContext, Datatype datatype) {
/* 648 */     this.blockValues++;
/*     */     
/* 650 */     addDatatype(valueContext, datatype);
/*     */   }
/*     */ 
/*     */   
/*     */   public void decodeStartDocument() {}
/*     */   
/*     */   protected final AbstractEXIBodyCoder.ElementContext setNextElemementEntry() {
/* 657 */     return this.currElementEntry = this.elementEntries.get(this.elementEntryIndex++);
/*     */   }
/*     */   
/*     */   public QNameContext decodeStartElement() throws IOException, EXIException {
/* 661 */     return (setNextElemementEntry()).qnameContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public QNameContext decodeEndElement() throws EXIException {
/* 666 */     QNameContext eeBefore = this.currElementEntry.qnameContext;
/*     */     
/* 668 */     setNextElemementEntry();
/*     */     
/* 670 */     return eeBefore;
/*     */   }
/*     */   
/*     */   public List<NamespaceDeclaration> getDeclaredPrefixDeclarations() {
/* 674 */     return this.currElementEntry.nsDeclarations;
/*     */   }
/*     */   
/*     */   public String getElementPrefix() {
/* 678 */     return this.currElementEntry.getPrefix();
/*     */   }
/*     */   
/*     */   public String getElementQNameAsString() {
/* 682 */     return this.currElementEntry.getQNameAsString();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamespaceDeclaration decodeNamespaceDeclaration() throws EXIException {
/* 687 */     return this.nsEntries.get(this.nsEntryIndex++);
/*     */   }
/*     */ 
/*     */   
/*     */   public QNameContext decodeAttributeXsiNil() throws EXIException, IOException {
/* 692 */     this.attributeQNameContext = getXsiNilContext();
/* 693 */     this.attributePrefix = this.xsiPrefixes.get(this.xsiPrefixIndex++);
/* 694 */     this.attributeValue = this.xsiValues.get(this.xsiValueIndex++);
/* 695 */     return this.attributeQNameContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public QNameContext decodeAttributeXsiType() throws EXIException, IOException {
/* 700 */     this.attributeQNameContext = getXsiTypeContext();
/* 701 */     this.attributePrefix = this.xsiPrefixes.get(this.xsiPrefixIndex++);
/* 702 */     this.attributeValue = this.xsiValues.get(this.xsiValueIndex++);
/*     */     
/* 704 */     return this.attributeQNameContext;
/*     */   }
/*     */   
/*     */   protected final void addQNameEntry(QNameEntry qne) {
/* 708 */     this.qnameEntries.add(qne);
/*     */   }
/*     */   
/*     */   protected final QNameEntry getNextQNameEntry() {
/* 712 */     return this.qnameEntries.get(this.qnameEntryIndex++);
/*     */   }
/*     */   
/*     */   public QNameContext decodeAttribute() throws EXIException, IOException {
/* 716 */     QNameEntry at = getNextQNameEntry();
/*     */     
/* 718 */     this.attributeQNameContext = at.qnContext;
/* 719 */     this.attributePrefix = at.prefix;
/* 720 */     this.attributeValue = getNextContentValue(this.attributeQNameContext);
/*     */     
/* 722 */     return this.attributeQNameContext;
/*     */   }
/*     */   
/*     */   public Value decodeCharacters() throws EXIException, IOException {
/* 726 */     QNameEntry ch = getNextQNameEntry();
/* 727 */     Value chVal = getNextContentValue(ch.qnContext);
/* 728 */     return chVal;
/*     */   }
/*     */   
/*     */   public Value decodeCharactersGeneric() throws EXIException, IOException {
/* 732 */     return decodeCharacters();
/*     */   }
/*     */ 
/*     */   
/*     */   public Value decodeCharactersGenericUndeclared() throws EXIException, IOException {
/* 737 */     return decodeCharacters();
/*     */   }
/*     */   
/*     */   public void decodeEndDocument() throws EXIException {
/* 741 */     if (this.codingMode == CodingMode.COMPRESSION) {
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */         
/* 747 */         readjustInputStream(this.is);
/* 748 */       } catch (IOException e) {
/* 749 */         throw new EXIException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public DocType decodeDocType() throws EXIException {
/* 755 */     return this.docTypeEntries.get(this.docTypeEntryIndex++);
/*     */   }
/*     */   
/*     */   public char[] decodeEntityReference() throws EXIException {
/* 759 */     return this.entityReferences.get(this.entityReferenceIndex++);
/*     */   }
/*     */   
/*     */   public char[] decodeComment() throws EXIException {
/* 763 */     return this.comments.get(this.commentIndex++);
/*     */   }
/*     */ 
/*     */   
/*     */   public ProcessingInstruction decodeProcessingInstruction() throws EXIException {
/* 768 */     return this.processingEntries.get(this.processingEntryIndex++);
/*     */   }
/*     */   
/*     */   static class EndElementEntry {
/*     */     final AbstractEXIBodyCoder.ElementContext before;
/*     */     final AbstractEXIBodyCoder.ElementContext after;
/*     */     
/*     */     public EndElementEntry(AbstractEXIBodyCoder.ElementContext before, AbstractEXIBodyCoder.ElementContext after) {
/* 776 */       this.before = before;
/* 777 */       this.after = after;
/*     */     }
/*     */   }
/*     */   
/*     */   static class QNameEntry {
/*     */     final QNameContext qnContext;
/*     */     final String prefix;
/*     */     
/*     */     public QNameEntry(QNameContext qnContext, String prefix) {
/* 786 */       this.qnContext = qnContext;
/* 787 */       this.prefix = prefix;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIBodyDecoderReordered.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */