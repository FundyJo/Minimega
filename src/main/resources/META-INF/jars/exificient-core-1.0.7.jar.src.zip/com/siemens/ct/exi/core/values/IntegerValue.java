/*     */ package com.siemens.ct.exi.core.values;
/*     */ 
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegerValue
/*     */   extends AbstractValue
/*     */   implements Comparable<IntegerValue>
/*     */ {
/*  40 */   public static final IntegerValue ZERO = new IntegerValue(0);
/*     */ 
/*     */   
/*  43 */   public static final BigInteger INTEGER_MIN_VALUE = BigInteger.valueOf(-2147483648L);
/*     */   
/*  45 */   public static final BigInteger INTEGER_MAX_VALUE = BigInteger.valueOf(2147483647L);
/*     */ 
/*     */   
/*  48 */   public static final BigInteger LONG_MIN_VALUE = BigInteger.valueOf(Long.MIN_VALUE);
/*     */   
/*  50 */   public static final BigInteger LONG_MAX_VALUE = BigInteger.valueOf(Long.MAX_VALUE);
/*     */   
/*     */   protected final int ival;
/*     */   
/*     */   protected final long lval;
/*     */   protected final BigInteger bval;
/*     */   protected final IntegerValueType iValType;
/*     */   
/*     */   private IntegerValue(int ival) {
/*  59 */     super(ValueType.INTEGER);
/*     */     
/*  61 */     this.ival = ival;
/*  62 */     this.iValType = IntegerValueType.INT;
/*     */     
/*  64 */     this.lval = 0L;
/*  65 */     this.bval = null;
/*     */   }
/*     */   
/*     */   public IntegerValueType getIntegerValueType() {
/*  69 */     return this.iValType;
/*     */   }
/*     */   
/*     */   private IntegerValue(long lval) {
/*  73 */     super(ValueType.INTEGER);
/*     */     
/*  75 */     this.ival = 0;
/*  76 */     this.iValType = IntegerValueType.LONG;
/*     */     
/*  78 */     this.lval = lval;
/*  79 */     this.bval = null;
/*     */   }
/*     */   
/*     */   private IntegerValue(BigInteger bval) {
/*  83 */     super(ValueType.INTEGER);
/*     */     
/*  85 */     this.bval = bval;
/*  86 */     this.iValType = IntegerValueType.BIG;
/*     */     
/*  88 */     this.ival = 0;
/*  89 */     this.lval = 0L;
/*     */   }
/*     */   
/*     */   public int intValue() {
/*  93 */     switch (this.iValType) {
/*     */       case INT:
/*  95 */         return this.ival;
/*     */       case LONG:
/*  97 */         return (int)this.lval;
/*     */       case BIG:
/*  99 */         return this.bval.intValue();
/*     */     } 
/* 101 */     throw new RuntimeException("Unsupported Integer Type " + this.valueType);
/*     */   }
/*     */ 
/*     */   
/*     */   public long longValue() {
/* 106 */     switch (this.iValType) {
/*     */       case INT:
/* 108 */         return this.ival;
/*     */       case LONG:
/* 110 */         return this.lval;
/*     */       case BIG:
/* 112 */         return this.bval.longValue();
/*     */     } 
/* 114 */     throw new RuntimeException("Unsupported Integer Type " + this.valueType);
/*     */   }
/*     */ 
/*     */   
/*     */   public BigInteger bigIntegerValue() {
/* 119 */     switch (this.iValType) {
/*     */       case INT:
/* 121 */         return BigInteger.valueOf(this.ival);
/*     */       case LONG:
/* 123 */         return BigInteger.valueOf(this.lval);
/*     */       case BIG:
/* 125 */         return this.bval;
/*     */     } 
/* 127 */     throw new RuntimeException("Unsupported Integer Type " + this.valueType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPositive() {
/* 132 */     switch (this.iValType) {
/*     */       case INT:
/* 134 */         return (this.ival >= 0);
/*     */       case LONG:
/* 136 */         return (this.lval >= 0L);
/*     */       case BIG:
/* 138 */         return (this.bval.signum() != -1);
/*     */     } 
/* 140 */     return false;
/*     */   }
/*     */   
/*     */   public IntegerValue add(IntegerValue val) {
/*     */     IntegerValue iv;
/* 145 */     if (val._equals(ZERO)) {
/* 146 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 151 */     switch (this.iValType) {
/*     */       case INT:
/* 153 */         switch (val.iValType)
/*     */         { case INT:
/* 155 */             iv = new IntegerValue(this.ival + val.ival);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 208 */             return iv;case LONG: iv = valueOf(this.ival + val.lval); return iv;case BIG: iv = valueOf(BigInteger.valueOf(this.ival).add(val.bval)); return iv; }  iv = null; return iv;case LONG: switch (val.iValType) { case INT: iv = new IntegerValue(this.lval + val.ival); return iv;case LONG: iv = valueOf(this.lval + val.lval); return iv;case BIG: iv = valueOf(BigInteger.valueOf(this.lval).add(val.bval)); return iv; }  iv = null; return iv;case BIG: switch (val.iValType) { case INT: iv = new IntegerValue(this.bval.add(BigInteger.valueOf(val.ival))); return iv;case LONG: iv = valueOf(this.bval.add(BigInteger.valueOf(val.lval))); return iv;case BIG: iv = valueOf(this.bval.add(val.bval)); return iv; }  iv = null; return iv;
/*     */     } 
/*     */     throw new RuntimeException("Unsupported Integer Type " + this.valueType); } public IntegerValue subtract(IntegerValue val) {
/*     */     IntegerValue iv;
/* 212 */     if (val._equals(ZERO)) {
/* 213 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 218 */     switch (this.iValType) {
/*     */       case INT:
/* 220 */         switch (val.iValType)
/*     */         { case INT:
/* 222 */             iv = new IntegerValue(this.ival - val.ival);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 274 */             return iv;case LONG: iv = valueOf(this.ival - val.lval); return iv;case BIG: iv = valueOf(BigInteger.valueOf(this.ival).subtract(val.bval)); return iv; }  iv = null; return iv;case LONG: switch (val.iValType) { case INT: iv = new IntegerValue(this.lval - val.ival); return iv;case LONG: iv = valueOf(this.lval - val.lval); return iv;case BIG: iv = valueOf(BigInteger.valueOf(this.lval).subtract(val.bval)); return iv; }  iv = null; return iv;case BIG: switch (val.iValType) { case INT: iv = new IntegerValue(this.bval.subtract(BigInteger.valueOf(val.ival))); return iv;case LONG: iv = valueOf(this.bval.subtract(BigInteger.valueOf(val.lval))); return iv;case BIG: iv = valueOf(this.bval.subtract(val.bval)); return iv; }  iv = null; return iv;
/*     */     } 
/*     */     throw new RuntimeException("Unsupported Integer Type " + this.valueType);
/*     */   } public static IntegerValue valueOf(int ival) {
/* 278 */     return new IntegerValue(ival);
/*     */   }
/*     */ 
/*     */   
/*     */   public static IntegerValue valueOf(long lval) {
/* 283 */     if (lval < -2147483648L || lval > 2147483647L) {
/* 284 */       return new IntegerValue(lval);
/*     */     }
/* 286 */     return new IntegerValue((int)lval);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntegerValue valueOf(BigInteger bval) {
/* 292 */     if (bval.compareTo(INTEGER_MIN_VALUE) == -1 || bval
/* 293 */       .compareTo(INTEGER_MAX_VALUE) == 1) {
/*     */       
/* 295 */       if (bval.compareTo(LONG_MIN_VALUE) == -1 || bval
/* 296 */         .compareTo(LONG_MAX_VALUE) == 1) {
/* 297 */         return new IntegerValue(bval);
/*     */       }
/* 299 */       return new IntegerValue(bval.longValue());
/*     */     } 
/*     */     
/* 302 */     return new IntegerValue(bval.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getAdjustedValue(String value) {
/* 308 */     value = value.trim();
/*     */     
/* 310 */     if (value.length() > 0 && value.charAt(0) == '+') {
/* 311 */       value = value.substring(1);
/*     */     }
/* 313 */     return value;
/*     */   }
/*     */   
/*     */   public static IntegerValue parse(String value) {
/*     */     try {
/* 318 */       value = getAdjustedValue(value);
/* 319 */       int len = value.length();
/*     */ 
/*     */ 
/*     */       
/* 323 */       if (len > 0) {
/* 324 */         if (value.charAt(0) == '-') {
/*     */           
/* 326 */           if (len < 11)
/*     */           {
/* 328 */             return new IntegerValue(Integer.parseInt(value)); } 
/* 329 */           if (len < 20)
/*     */           {
/* 331 */             return new IntegerValue(Long.parseLong(value));
/*     */           }
/*     */           
/* 334 */           return new IntegerValue(new BigInteger(value));
/*     */         } 
/*     */ 
/*     */         
/* 338 */         if (len < 10)
/*     */         {
/* 340 */           return new IntegerValue(Integer.parseInt(value)); } 
/* 341 */         if (len < 19)
/*     */         {
/* 343 */           return new IntegerValue(Long.parseLong(value));
/*     */         }
/*     */         
/* 346 */         return new IntegerValue(new BigInteger(value));
/*     */       } 
/*     */ 
/*     */       
/* 350 */       return null;
/*     */     }
/* 352 */     catch (NumberFormatException e) {
/* 353 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getCharactersLength() {
/* 358 */     if (this.slen == -1)
/* 359 */     { switch (this.iValType)
/*     */       { case INT:
/* 361 */           if (this.ival == Integer.MIN_VALUE) {
/* 362 */             this.slen = MethodsBag.INTEGER_MIN_VALUE_CHARARRAY.length;
/*     */           } else {
/* 364 */             this.slen = MethodsBag.getStringSize(this.ival);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 382 */           return this.slen;case LONG: if (this.lval == Long.MIN_VALUE) { this.slen = MethodsBag.LONG_MIN_VALUE_CHARARRAY.length; } else { this.slen = MethodsBag.getStringSize(this.lval); }  return this.slen;case BIG: this.slen = this.bval.toString().length(); return this.slen; }  this.slen = -1; }  return this.slen;
/*     */   }
/*     */   public void getCharacters(char[] cbuffer, int offset) {
/*     */     String src;
/* 386 */     switch (this.iValType) {
/*     */       case INT:
/* 388 */         if (this.ival == Integer.MIN_VALUE) {
/*     */           
/* 390 */           System.arraycopy(MethodsBag.INTEGER_MIN_VALUE_CHARARRAY, 0, cbuffer, offset, MethodsBag.INTEGER_MIN_VALUE_CHARARRAY.length);
/*     */           
/*     */           break;
/*     */         } 
/* 394 */         assert cbuffer.length >= getCharactersLength();
/* 395 */         MethodsBag.itos(this.ival, offset + getCharactersLength(), cbuffer);
/*     */         break;
/*     */       
/*     */       case LONG:
/* 399 */         if (this.lval == Long.MIN_VALUE) {
/*     */           
/* 401 */           System.arraycopy(MethodsBag.LONG_MIN_VALUE_CHARARRAY, 0, cbuffer, offset, MethodsBag.LONG_MIN_VALUE_CHARARRAY.length);
/*     */           
/*     */           break;
/*     */         } 
/* 405 */         assert cbuffer.length >= getCharactersLength();
/* 406 */         MethodsBag.itos(this.lval, offset + getCharactersLength(), cbuffer);
/*     */         break;
/*     */       
/*     */       case BIG:
/* 410 */         src = this.bval.toString();
/* 411 */         src.getChars(0, src.length(), cbuffer, 0);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean _equals(IntegerValue o) {
/* 419 */     switch (this.iValType) {
/*     */       case INT:
/* 421 */         return (o.iValType == IntegerValueType.INT && this.ival == o.ival);
/*     */       case LONG:
/* 423 */         return (o.iValType == IntegerValueType.LONG && this.lval == o.lval);
/*     */       case BIG:
/* 425 */         return (o.iValType == IntegerValueType.BIG && this.bval
/* 426 */           .equals(o.bval));
/*     */     } 
/* 428 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 434 */     if (o == null) {
/* 435 */       return false;
/*     */     }
/* 437 */     if (o instanceof IntegerValue) {
/* 438 */       return _equals((IntegerValue)o);
/*     */     }
/* 440 */     IntegerValue iv = parse(o.toString());
/* 441 */     return (iv == null) ? false : _equals(iv);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 447 */     int hc = 0;
/* 448 */     switch (this.iValType) {
/*     */       case INT:
/* 450 */         hc = this.ival;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 462 */         return hc;case LONG: hc = (int)(this.lval ^ this.lval >>> 32L); return hc;case BIG: hc = this.bval.hashCode(); return hc;
/*     */     } 
/*     */     throw new RuntimeException("Unsupported Integer Type " + this.valueType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(IntegerValue o) {
/* 470 */     switch (this.iValType) {
/*     */       case INT:
/* 472 */         switch (o.iValType) {
/*     */           case INT:
/* 474 */             if (this.ival == o.ival)
/* 475 */               return 0; 
/* 476 */             if (this.ival < o.ival) {
/* 477 */               return -1;
/*     */             }
/* 479 */             return 1;
/*     */           
/*     */           case LONG:
/*     */           case BIG:
/* 483 */             return -1;
/*     */         } 
/* 485 */         return -2;
/*     */       
/*     */       case LONG:
/* 488 */         switch (o.iValType) {
/*     */           case INT:
/* 490 */             return 1;
/*     */           case LONG:
/* 492 */             if (this.lval == o.lval)
/* 493 */               return 0; 
/* 494 */             if (this.lval < o.lval) {
/* 495 */               return -1;
/*     */             }
/* 497 */             return 1;
/*     */           
/*     */           case BIG:
/* 500 */             return -1;
/*     */         } 
/* 502 */         return -2;
/*     */       
/*     */       case BIG:
/* 505 */         switch (o.iValType) {
/*     */           case INT:
/*     */           case LONG:
/* 508 */             return 1;
/*     */           case BIG:
/* 510 */             return this.bval.compareTo(o.bval);
/*     */         } 
/* 512 */         return -2;
/*     */     } 
/*     */     
/* 515 */     return -2;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\IntegerValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */