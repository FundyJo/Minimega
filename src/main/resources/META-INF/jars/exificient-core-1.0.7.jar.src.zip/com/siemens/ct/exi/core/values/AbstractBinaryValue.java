/*    */ package com.siemens.ct.exi.core.values;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBinaryValue
/*    */   extends AbstractValue
/*    */ {
/*    */   protected final byte[] bytes;
/*    */   
/*    */   public AbstractBinaryValue(ValueType valueType, byte[] bytes) {
/* 38 */     super(valueType);
/* 39 */     this.bytes = bytes;
/*    */   }
/*    */   
/*    */   public byte[] toBytes() {
/* 43 */     return this.bytes;
/*    */   }
/*    */   
/*    */   protected final boolean _equals(byte[] oBytes) {
/* 47 */     if (this.bytes.length == oBytes.length) {
/* 48 */       for (int i = 0; i < this.bytes.length; i++) {
/* 49 */         if (this.bytes[i] != oBytes[i]) {
/* 50 */           return false;
/*    */         }
/*    */       } 
/* 53 */       return true;
/*    */     } 
/* 55 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\AbstractBinaryValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */