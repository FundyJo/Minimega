/*     */ package com.siemens.ct.exi.core.types;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.StringDatatype;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BuiltIn
/*     */ {
/*  45 */   public static final QName XSD_BASE64BINARY = new QName("http://www.w3.org/2001/XMLSchema", "base64Binary");
/*     */   
/*  47 */   public static final QName XSD_HEXBINARY = new QName("http://www.w3.org/2001/XMLSchema", "hexBinary");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final QName XSD_BOOLEAN = new QName("http://www.w3.org/2001/XMLSchema", "boolean");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final QName XSD_DATETIME = new QName("http://www.w3.org/2001/XMLSchema", "dateTime");
/*     */   
/*  59 */   public static final QName XSD_TIME = new QName("http://www.w3.org/2001/XMLSchema", "time");
/*     */   
/*  61 */   public static final QName XSD_DATE = new QName("http://www.w3.org/2001/XMLSchema", "date");
/*     */   
/*  63 */   public static final QName XSD_GYEARMONTH = new QName("http://www.w3.org/2001/XMLSchema", "gYearMonth");
/*     */   
/*  65 */   public static final QName XSD_GYEAR = new QName("http://www.w3.org/2001/XMLSchema", "gYear");
/*     */   
/*  67 */   public static final QName XSD_GMONTHDAY = new QName("http://www.w3.org/2001/XMLSchema", "gMonthDay");
/*     */   
/*  69 */   public static final QName XSD_GDAY = new QName("http://www.w3.org/2001/XMLSchema", "gDay");
/*     */   
/*  71 */   public static final QName XSD_GMONTH = new QName("http://www.w3.org/2001/XMLSchema", "gMonth");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public static final QName XSD_DECIMAL = new QName("http://www.w3.org/2001/XMLSchema", "decimal");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public static final QName XSD_FLOAT = new QName("http://www.w3.org/2001/XMLSchema", "float");
/*     */   
/*  84 */   public static final QName XSD_DOUBLE = new QName("http://www.w3.org/2001/XMLSchema", "double");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public static final QName XSD_INTEGER = new QName("http://www.w3.org/2001/XMLSchema", "integer");
/*     */   
/*  91 */   public static final QName XSD_NON_NEGATIVE_INTEGER = new QName("http://www.w3.org/2001/XMLSchema", "nonNegativeInteger");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public static final QName XSD_STRING = new QName("http://www.w3.org/2001/XMLSchema", "string");
/*     */ 
/*     */   
/*  99 */   public static final QName XSD_ANY_SIMPLE_TYPE = new QName("http://www.w3.org/2001/XMLSchema", "anySimpleType");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public static final QName XSD_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "QName");
/*     */   
/* 107 */   public static final QName XSD_NOTATION = new QName("http://www.w3.org/2001/XMLSchema", "Notation");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static final QName DEFAULT_VALUE_NAME = XSD_STRING;
/*     */   
/* 115 */   private static final Datatype DEFAULT_DATATYPE = (Datatype)new StringDatatype(new QNameContext(-1, -1, new QName("")));
/*     */ 
/*     */   
/*     */   public static Datatype getDefaultDatatype() {
/* 119 */     return DEFAULT_DATATYPE;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\BuiltIn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */