/*    */ package com.siemens.ct.exi.core.datatype.charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XSDBase64CharacterSet
/*    */   extends AbstractRestrictedCharacterSet
/*    */ {
/*    */   public XSDBase64CharacterSet() {
/* 45 */     addValue(9);
/* 46 */     addValue(10);
/* 47 */     addValue(13);
/* 48 */     addValue(32);
/*    */     
/* 50 */     addValue(43);
/* 51 */     addValue(47);
/*    */     int i;
/* 53 */     for (i = 48; i <= 57; i++) {
/* 54 */       addValue((char)i);
/*    */     }
/*    */     
/* 57 */     addValue(61);
/*    */     
/* 59 */     for (i = 65; i <= 90; i++) {
/* 60 */       addValue((char)i);
/*    */     }
/*    */     
/* 63 */     for (i = 97; i <= 122; i++)
/* 64 */       addValue((char)i); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\charset\XSDBase64CharacterSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */