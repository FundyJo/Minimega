/*    */ package com.siemens.ct.exi.core.grammars.production;
/*    */ 
/*    */ import com.siemens.ct.exi.core.grammars.event.Event;
/*    */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchemaInformedProduction
/*    */   extends AbstractProduction
/*    */ {
/*    */   public SchemaInformedProduction(Grammar next, Event event, int eventCode) {
/* 39 */     super(next, event, eventCode);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getEventCode() {
/* 44 */     return this.eventCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\production\SchemaInformedProduction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */