/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.CodingMode;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.container.DocType;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.container.ProcessingInstruction;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.io.channel.BitDecoderChannel;
/*     */ import com.siemens.ct.exi.core.io.channel.ByteDecoderChannel;
/*     */ import com.siemens.ct.exi.core.io.channel.DecoderChannel;
/*     */ import com.siemens.ct.exi.core.types.BuiltIn;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIBodyDecoderInOrder
/*     */   extends AbstractEXIBodyDecoder
/*     */ {
/*     */   public EXIBodyDecoderInOrder(EXIFactory exiFactory) throws EXIException {
/*  56 */     super(exiFactory);
/*     */   }
/*     */   
/*     */   public void setInputStream(InputStream is) throws EXIException, IOException {
/*  60 */     updateInputStream(is);
/*     */     
/*  62 */     initForEachRun();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInputChannel(DecoderChannel decoderChannel) throws EXIException, IOException {
/*  67 */     updateInputChannel(decoderChannel);
/*     */     
/*  69 */     initForEachRun();
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateInputStream(InputStream is) throws EXIException, IOException {
/*  74 */     CodingMode codingMode = this.exiFactory.getCodingMode();
/*     */ 
/*     */     
/*  77 */     if (codingMode == CodingMode.BIT_PACKED) {
/*     */       
/*  79 */       updateInputChannel((DecoderChannel)new BitDecoderChannel(is));
/*     */     } else {
/*  81 */       assert codingMode == CodingMode.BYTE_PACKED;
/*     */       
/*  83 */       updateInputChannel((DecoderChannel)new ByteDecoderChannel(is));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateInputChannel(DecoderChannel decoderChannel) throws EXIException, IOException {
/*  89 */     this.channel = decoderChannel;
/*     */   }
/*     */   
/*     */   public DecoderChannel getChannel() {
/*  93 */     return this.channel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initForEachRun() throws EXIException, IOException {
/*  98 */     super.initForEachRun();
/*     */     
/* 100 */     this.nextEvent = null;
/* 101 */     this.nextEventType = EventType.START_DOCUMENT;
/*     */   }
/*     */   
/*     */   public EventType next() throws EXIException, IOException {
/* 105 */     return (this.nextEventType == EventType.END_DOCUMENT) ? null : 
/* 106 */       decodeEventCode();
/*     */   }
/*     */   
/*     */   public void decodeStartDocument() throws EXIException {
/* 110 */     decodeStartDocumentStructure();
/*     */   }
/*     */   
/*     */   public void decodeEndDocument() throws EXIException, IOException {
/* 114 */     decodeEndDocumentStructure();
/*     */   }
/*     */   
/*     */   public QNameContext decodeStartElement() throws EXIException, IOException {
/* 118 */     switch (this.nextEventType) {
/*     */       case START_ELEMENT:
/* 120 */         return decodeStartElementStructure();
/*     */       
/*     */       case START_ELEMENT_NS:
/* 123 */         return decodeStartElementNSStructure();
/*     */       
/*     */       case START_ELEMENT_GENERIC:
/* 126 */         return decodeStartElementGenericStructure();
/*     */       
/*     */       case START_ELEMENT_GENERIC_UNDECLARED:
/* 129 */         return decodeStartElementGenericUndeclaredStructure();
/*     */     } 
/*     */     
/* 132 */     throw new EXIException("Invalid decode state: " + this.nextEventType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QNameContext decodeEndElement() throws EXIException, IOException {
/*     */     AbstractEXIBodyCoder.ElementContext ec;
/* 139 */     switch (this.nextEventType) {
/*     */       case END_ELEMENT:
/* 141 */         ec = decodeEndElementStructure();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 150 */         return ec.qnameContext;case END_ELEMENT_UNDECLARED: ec = decodeEndElementUndeclaredStructure(); return ec.qnameContext;
/*     */     } 
/*     */     throw new EXIException("Invalid decode state: " + this.nextEventType);
/*     */   } public List<NamespaceDeclaration> getDeclaredPrefixDeclarations() {
/* 154 */     return (getElementContext()).nsDeclarations;
/*     */   }
/*     */   
/*     */   public String getElementPrefix() {
/* 158 */     return getElementContext().getPrefix();
/*     */   }
/*     */   
/*     */   public String getElementQNameAsString() {
/* 162 */     return getElementContext().getQNameAsString();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamespaceDeclaration decodeNamespaceDeclaration() throws EXIException, IOException {
/* 167 */     return decodeNamespaceDeclarationStructure();
/*     */   }
/*     */ 
/*     */   
/*     */   public QNameContext decodeAttributeXsiNil() throws EXIException, IOException {
/* 172 */     assert this.nextEventType == EventType.ATTRIBUTE_XSI_NIL;
/* 173 */     decodeAttributeXsiNilStructure();
/*     */ 
/*     */     
/* 176 */     return this.attributeQNameContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public QNameContext decodeAttributeXsiType() throws EXIException, IOException {
/* 181 */     assert this.nextEventType == EventType.ATTRIBUTE_XSI_TYPE;
/* 182 */     decodeAttributeXsiTypeStructure();
/*     */     
/* 184 */     return this.attributeQNameContext;
/*     */   }
/*     */   
/*     */   protected void readAttributeContent(Datatype dt) throws IOException {
/* 188 */     this.attributeValue = this.typeDecoder.readValue(dt, this.attributeQNameContext, this.channel, this.stringDecoder);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void readAttributeContent() throws IOException, EXIException {
/* 193 */     if (this.attributeQNameContext.getNamespaceUriID() == getXsiTypeContext()
/* 194 */       .getNamespaceUriID()) {
/* 195 */       int localNameID = this.attributeQNameContext.getLocalNameID();
/* 196 */       if (localNameID == getXsiTypeContext().getLocalNameID()) {
/* 197 */         decodeAttributeXsiTypeStructure();
/* 198 */       } else if (localNameID == getXsiTypeContext().getLocalNameID() && 
/* 199 */         getCurrentGrammar().isSchemaInformed()) {
/* 200 */         decodeAttributeXsiNilStructure();
/*     */       } else {
/* 202 */         readAttributeContent(BuiltIn.getDefaultDatatype());
/*     */       } 
/*     */     } else {
/*     */       
/* 206 */       Datatype dt = BuiltIn.getDefaultDatatype();
/*     */       
/* 208 */       if (getCurrentGrammar().isSchemaInformed() && this.attributeQNameContext
/* 209 */         .getGlobalAttribute() != null) {
/* 210 */         dt = this.attributeQNameContext.getGlobalAttribute().getDatatype();
/*     */       }
/*     */       
/* 213 */       readAttributeContent(dt);
/*     */     } 
/*     */   }
/*     */   public QNameContext decodeAttribute() throws EXIException, IOException {
/*     */     Datatype dt;
/* 218 */     switch (this.nextEventType) {
/*     */       case ATTRIBUTE:
/* 220 */         dt = decodeAttributeStructure();
/* 221 */         if (this.attributeQNameContext.equals(getXsiTypeContext())) {
/* 222 */           decodeAttributeXsiTypeStructure();
/*     */         } else {
/* 224 */           readAttributeContent(dt);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 253 */         return this.attributeQNameContext;case ATTRIBUTE_NS: decodeAttributeNSStructure(); readAttributeContent(); return this.attributeQNameContext;case ATTRIBUTE_GENERIC: decodeAttributeGenericStructure(); readAttributeContent(); return this.attributeQNameContext;case ATTRIBUTE_GENERIC_UNDECLARED: decodeAttributeGenericUndeclaredStructure(); readAttributeContent(); return this.attributeQNameContext;case ATTRIBUTE_INVALID_VALUE: decodeAttributeStructure(); readAttributeContent(BuiltIn.getDefaultDatatype()); return this.attributeQNameContext;case ATTRIBUTE_ANY_INVALID_VALUE: decodeAttributeAnyInvalidValueStructure(); readAttributeContent(BuiltIn.getDefaultDatatype()); return this.attributeQNameContext;
/*     */     } 
/*     */     throw new EXIException("Invalid decode state: " + this.nextEventType);
/*     */   } public Value decodeCharacters() throws EXIException, IOException {
/*     */     Datatype dt;
/* 258 */     switch (this.nextEventType) {
/*     */       case CHARACTERS:
/* 260 */         dt = decodeCharactersStructure();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 276 */         return this.typeDecoder.readValue(dt, (getElementContext()).qnameContext, this.channel, this.stringDecoder);case CHARACTERS_GENERIC: decodeCharactersGenericStructure(); dt = BuiltIn.getDefaultDatatype(); return this.typeDecoder.readValue(dt, (getElementContext()).qnameContext, this.channel, this.stringDecoder);case CHARACTERS_GENERIC_UNDECLARED: decodeCharactersGenericUndeclaredStructure(); dt = BuiltIn.getDefaultDatatype(); return this.typeDecoder.readValue(dt, (getElementContext()).qnameContext, this.channel, this.stringDecoder);
/*     */     } 
/*     */     throw new EXIException("Invalid decode state: " + this.nextEventType);
/*     */   }
/*     */   public char[] decodeEntityReference() throws EXIException, IOException {
/* 281 */     return decodeEntityReferenceStructure();
/*     */   }
/*     */   
/*     */   public char[] decodeComment() throws EXIException, IOException {
/* 285 */     return decodeCommentStructure();
/*     */   }
/*     */ 
/*     */   
/*     */   public ProcessingInstruction decodeProcessingInstruction() throws EXIException, IOException {
/* 290 */     return decodeProcessingInstructionStructure();
/*     */   }
/*     */   
/*     */   public DocType decodeDocType() throws EXIException, IOException {
/* 294 */     return decodeDocTypeStructure();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIBodyDecoderInOrder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */