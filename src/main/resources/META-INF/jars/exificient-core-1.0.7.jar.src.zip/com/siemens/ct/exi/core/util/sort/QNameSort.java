/*    */ package com.siemens.ct.exi.core.util.sort;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QNameSort
/*    */   implements Comparator<QName>
/*    */ {
/*    */   public int compare(QName q1, QName q2) {
/* 45 */     return compare(q1.getNamespaceURI(), q1.getLocalPart(), q2
/* 46 */         .getNamespaceURI(), q2.getLocalPart());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int compare(String ns1, String ln1, String ns2, String ln2) {
/* 64 */     if (ns1 == null) {
/* 65 */       ns1 = "";
/*    */     }
/* 67 */     if (ns2 == null) {
/* 68 */       ns2 = "";
/*    */     }
/* 70 */     int cLocalPart = ln1.compareTo(ln2);
/* 71 */     return (cLocalPart == 0) ? ns1.compareTo(ns2) : cLocalPart;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\cor\\util\sort\QNameSort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */