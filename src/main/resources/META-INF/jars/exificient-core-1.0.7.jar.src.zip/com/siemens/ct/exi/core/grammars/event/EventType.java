/*     */ package com.siemens.ct.exi.core.grammars.event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum EventType
/*     */ {
/*  63 */   START_DOCUMENT,
/*     */ 
/*     */ 
/*     */   
/*  67 */   ATTRIBUTE_XSI_TYPE,
/*  68 */   ATTRIBUTE_XSI_NIL,
/*     */ 
/*     */ 
/*     */   
/*  72 */   ATTRIBUTE,
/*  73 */   ATTRIBUTE_NS,
/*  74 */   ATTRIBUTE_GENERIC,
/*  75 */   ATTRIBUTE_INVALID_VALUE,
/*  76 */   ATTRIBUTE_ANY_INVALID_VALUE,
/*  77 */   ATTRIBUTE_GENERIC_UNDECLARED,
/*     */ 
/*     */ 
/*     */   
/*  81 */   START_ELEMENT,
/*  82 */   START_ELEMENT_NS,
/*  83 */   START_ELEMENT_GENERIC,
/*  84 */   START_ELEMENT_GENERIC_UNDECLARED,
/*     */ 
/*     */ 
/*     */   
/*  88 */   END_ELEMENT,
/*  89 */   END_ELEMENT_UNDECLARED,
/*     */ 
/*     */ 
/*     */   
/*  93 */   CHARACTERS,
/*  94 */   CHARACTERS_GENERIC,
/*  95 */   CHARACTERS_GENERIC_UNDECLARED,
/*     */ 
/*     */ 
/*     */   
/*  99 */   END_DOCUMENT,
/*     */ 
/*     */ 
/*     */   
/* 103 */   DOC_TYPE,
/* 104 */   NAMESPACE_DECLARATION,
/* 105 */   SELF_CONTAINED,
/* 106 */   ENTITY_REFERENCE,
/* 107 */   COMMENT,
/* 108 */   PROCESSING_INSTRUCTION;
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\EventType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */