/*     */ package com.siemens.ct.exi.core.io.channel;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteDecoderChannel
/*     */   extends AbstractDecoderChannel
/*     */   implements DecoderChannel
/*     */ {
/*     */   protected InputStream is;
/*     */   
/*     */   public ByteDecoderChannel(InputStream istream) {
/*  43 */     this.is = istream;
/*     */   }
/*     */   
/*     */   public InputStream getInputStream() {
/*  47 */     return this.is;
/*     */   }
/*     */   
/*     */   public int decode() throws IOException {
/*  51 */     int b = this.is.read();
/*  52 */     if (b == -1) {
/*  53 */       throw new EOFException("Premature EOS found while reading data.");
/*     */     }
/*  55 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public void align() throws IOException {}
/*     */   
/*     */   public void skip(long n) throws IOException {
/*  62 */     while (n != 0L) {
/*  63 */       n -= this.is.skip(n);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int decodeNBitUnsignedInteger(int n) throws IOException {
/*  72 */     assert n >= 0;
/*     */     
/*  74 */     int bitsRead = 0;
/*  75 */     int result = 0;
/*     */     
/*  77 */     while (bitsRead < n) {
/*     */       
/*  79 */       result += decode() << bitsRead;
/*  80 */       bitsRead += 8;
/*     */     } 
/*  82 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean decodeBoolean() throws IOException {
/*  90 */     return !(decode() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decodeBinary() throws IOException {
/*  97 */     int length = decodeUnsignedInteger();
/*  98 */     byte[] result = new byte[length];
/*     */     
/* 100 */     int readBytes = 0;
/* 101 */     while (readBytes < length) {
/* 102 */       int len = this.is.read(result, readBytes, length - readBytes);
/* 103 */       if (len == -1) {
/* 104 */         throw new EOFException("Premature EOS found while reading data.");
/*     */       }
/*     */       
/* 107 */       readBytes += len;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\channel\ByteDecoderChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */