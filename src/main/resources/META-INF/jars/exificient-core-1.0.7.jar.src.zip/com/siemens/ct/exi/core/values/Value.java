package com.siemens.ct.exi.core.values;

public interface Value {
  ValueType getValueType();
  
  char[] getCharacters();
  
  void getCharacters(char[] paramArrayOfchar, int paramInt);
  
  int getCharactersLength();
  
  String toString(char[] paramArrayOfchar, int paramInt);
  
  String toString();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\Value.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */