/*     */ package com.siemens.ct.exi.core.datatype;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.types.BuiltInType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDatatype
/*     */   implements Datatype
/*     */ {
/*     */   protected final BuiltInType builtInType;
/*     */   protected final QNameContext schemaType;
/*     */   protected Datatype baseDatatype;
/*     */   protected EnumDatatype grammarEnumeration;
/*     */   protected WhiteSpace whiteSpace;
/*     */   
/*     */   public AbstractDatatype() {
/*  54 */     this(null, null);
/*     */   }
/*     */   
/*     */   public AbstractDatatype(BuiltInType builtInType, QNameContext schemaType) {
/*  58 */     this.builtInType = builtInType;
/*  59 */     this.schemaType = schemaType;
/*     */ 
/*     */     
/*  62 */     this.whiteSpace = WhiteSpace.collapse;
/*     */   }
/*     */   
/*     */   public BuiltInType getBuiltInType() {
/*  66 */     return this.builtInType;
/*     */   }
/*     */   
/*     */   public QNameContext getSchemaType() {
/*  70 */     return this.schemaType;
/*     */   }
/*     */   
/*     */   public Datatype getBaseDatatype() {
/*  74 */     return this.baseDatatype;
/*     */   }
/*     */   
/*     */   public void setBaseDatatype(Datatype baseDatatype) {
/*  78 */     this.baseDatatype = baseDatatype;
/*     */   }
/*     */   
/*     */   public void setGrammarEnumeration(EnumDatatype grammarEnumeration) {
/*  82 */     this.grammarEnumeration = grammarEnumeration;
/*     */   }
/*     */   
/*     */   public EnumDatatype getGrammarEnumeration() {
/*  86 */     return this.grammarEnumeration;
/*     */   }
/*     */   
/*     */   public WhiteSpace getWhiteSpace() {
/*  90 */     return this.whiteSpace;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/*  94 */     if (o instanceof Datatype && 
/*  95 */       this.builtInType == ((Datatype)o).getBuiltInType()) {
/*  96 */       if (this.schemaType == null) {
/*  97 */         return (((Datatype)o).getSchemaType() == null);
/*     */       }
/*  99 */       return this.schemaType.equals(((Datatype)o).getSchemaType());
/*     */     } 
/*     */ 
/*     */     
/* 103 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 107 */     return this.builtInType.ordinal();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 111 */     return this.builtInType.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\AbstractDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */