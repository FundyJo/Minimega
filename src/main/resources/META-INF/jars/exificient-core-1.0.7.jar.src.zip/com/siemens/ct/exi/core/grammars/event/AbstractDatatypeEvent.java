/*    */ package com.siemens.ct.exi.core.grammars.event;
/*    */ 
/*    */ import com.siemens.ct.exi.core.datatype.Datatype;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDatatypeEvent
/*    */   extends AbstractEvent
/*    */   implements DatatypeEvent
/*    */ {
/*    */   protected final Datatype datatype;
/*    */   
/*    */   public AbstractDatatypeEvent(EventType eventType, Datatype datatype) {
/* 41 */     super(eventType);
/* 42 */     this.datatype = datatype;
/*    */   }
/*    */   
/*    */   public Datatype getDatatype() {
/* 46 */     return this.datatype;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 51 */     return super.toString() + "[" + this.datatype + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\AbstractDatatypeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */