/*    */ package com.siemens.ct.exi.core.coder;
/*    */ 
/*    */ import com.siemens.ct.exi.core.CodingMode;
/*    */ import com.siemens.ct.exi.core.EXIFactory;
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*    */ import com.siemens.ct.exi.core.io.channel.BitEncoderChannel;
/*    */ import com.siemens.ct.exi.core.io.channel.ByteEncoderChannel;
/*    */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EXIBodyEncoderInOrder
/*    */   extends AbstractEXIBodyEncoder
/*    */ {
/*    */   public EXIBodyEncoderInOrder(EXIFactory exiFactory) throws EXIException {
/* 48 */     super(exiFactory);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOutputStream(OutputStream os) throws EXIException, IOException {
/* 54 */     CodingMode codingMode = this.exiFactory.getCodingMode();
/*    */ 
/*    */     
/* 57 */     if (codingMode == CodingMode.BIT_PACKED) {
/*    */       
/* 59 */       setOutputChannel((EncoderChannel)new BitEncoderChannel(os));
/*    */     } else {
/* 61 */       assert codingMode == CodingMode.BYTE_PACKED;
/*    */       
/* 63 */       setOutputChannel((EncoderChannel)new ByteEncoderChannel(os));
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setOutputChannel(EncoderChannel encoderChannel) {
/* 68 */     this.channel = encoderChannel;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void writeValue(QNameContext valueContext) throws IOException {
/* 73 */     this.typeEncoder.writeValue(valueContext, this.channel, this.stringEncoder);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIBodyEncoderInOrder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */