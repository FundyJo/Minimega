/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum WhiteSpace
/*    */ {
/* 38 */   preserve,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   replace,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   collapse;
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\WhiteSpace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */