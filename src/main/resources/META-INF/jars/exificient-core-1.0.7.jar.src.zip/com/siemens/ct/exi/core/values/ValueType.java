/*    */ package com.siemens.ct.exi.core.values;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ValueType
/*    */ {
/* 36 */   BINARY_BASE64, BINARY_HEX,
/*    */   
/* 38 */   BOOLEAN,
/*    */   
/* 40 */   DECIMAL,
/*    */   
/* 42 */   FLOAT,
/*    */   
/* 44 */   INTEGER,
/*    */   
/* 46 */   DATETIME,
/*    */   
/* 48 */   STRING,
/*    */   
/* 50 */   LIST,
/*    */   
/* 52 */   QNAME;
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\ValueType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */