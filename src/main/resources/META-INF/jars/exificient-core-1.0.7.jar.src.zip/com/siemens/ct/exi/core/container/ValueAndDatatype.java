/*    */ package com.siemens.ct.exi.core.container;
/*    */ 
/*    */ import com.siemens.ct.exi.core.datatype.Datatype;
/*    */ import com.siemens.ct.exi.core.values.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValueAndDatatype
/*    */ {
/*    */   public final Value value;
/*    */   public final Datatype datatype;
/*    */   
/*    */   public ValueAndDatatype(Value value, Datatype datatype) {
/* 34 */     this.value = value;
/* 35 */     this.datatype = datatype;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 40 */     return "\"" + this.value + "\" AS " + this.datatype;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\container\ValueAndDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */