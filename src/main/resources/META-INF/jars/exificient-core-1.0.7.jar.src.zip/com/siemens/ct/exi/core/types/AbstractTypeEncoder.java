/*     */ package com.siemens.ct.exi.core.types;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.RestrictedCharacterSetDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.charset.RestrictedCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringEncoder;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTypeEncoder
/*     */   extends AbstractTypeCoder
/*     */   implements TypeEncoder
/*     */ {
/*     */   public AbstractTypeEncoder() throws EXIException {
/*  51 */     this(null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractTypeEncoder(QName[] dtrMapTypes, QName[] dtrMapRepresentations, Map<QName, Datatype> dtrMapRepresentationsDatatype) throws EXIException {
/*  58 */     super(dtrMapTypes, dtrMapRepresentations, dtrMapRepresentationsDatatype);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeRCSValue(RestrictedCharacterSetDatatype rcsDT, QNameContext qnContext, EncoderChannel valueChannel, StringEncoder stringEncoder, String lastValidValue) throws IOException {
/*  65 */     if (stringEncoder.isStringHit(lastValidValue)) {
/*  66 */       stringEncoder.writeValue(qnContext, valueChannel, lastValidValue);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  72 */       int L = lastValidValue.length();
/*     */       
/*  74 */       valueChannel.encodeUnsignedInteger(L + 2);
/*     */       
/*  76 */       RestrictedCharacterSet rcs = rcsDT.getRestrictedCharacterSet();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  81 */       if (L > 0) {
/*     */         
/*  83 */         int numberOfBits = rcs.getCodingLength();
/*     */         
/*  85 */         for (int i = 0; i < L; i++) {
/*  86 */           int codePoint = lastValidValue.codePointAt(i);
/*  87 */           int code = rcs.getCode(codePoint);
/*  88 */           if (code == -1) {
/*     */             
/*  90 */             valueChannel.encodeNBitUnsignedInteger(rcs.size(), numberOfBits);
/*     */ 
/*     */             
/*  93 */             valueChannel.encodeUnsignedInteger(codePoint);
/*     */           } else {
/*  95 */             valueChannel.encodeNBitUnsignedInteger(code, numberOfBits);
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 103 */         stringEncoder.addValue(qnContext, lastValidValue);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\AbstractTypeEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */