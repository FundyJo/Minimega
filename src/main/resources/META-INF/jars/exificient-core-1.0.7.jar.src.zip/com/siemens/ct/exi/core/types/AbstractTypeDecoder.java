/*     */ package com.siemens.ct.exi.core.types;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.RestrictedCharacterSetDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.charset.RestrictedCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringCoder;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringDecoder;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.io.channel.DecoderChannel;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTypeDecoder
/*     */   extends AbstractTypeCoder
/*     */   implements TypeDecoder
/*     */ {
/*     */   public AbstractTypeDecoder() throws EXIException {
/*  53 */     this(null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractTypeDecoder(QName[] dtrMapTypes, QName[] dtrMapRepresentations, Map<QName, Datatype> dtrMapRepresentationsDatatype) throws EXIException {
/*  60 */     super(dtrMapTypes, dtrMapRepresentations, dtrMapRepresentationsDatatype);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Value readRCSValue(RestrictedCharacterSetDatatype rcsDT, QNameContext qnContext, DecoderChannel valueChannel, StringDecoder stringDecoder) throws IOException {
/*     */     StringValue value;
/*  69 */     RestrictedCharacterSet rcs = rcsDT.getRestrictedCharacterSet();
/*     */ 
/*     */ 
/*     */     
/*  73 */     int i = valueChannel.decodeUnsignedInteger();
/*     */     
/*  75 */     if (i == 0) {
/*     */       
/*  77 */       value = stringDecoder.readValueLocalHit(qnContext, valueChannel);
/*  78 */     } else if (i == 1) {
/*     */       
/*  80 */       value = stringDecoder.readValueGlobalHit(valueChannel);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  85 */       int L = i - 2;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  90 */       if (L > 0) {
/*     */         
/*  92 */         int numberOfBits = rcs.getCodingLength();
/*  93 */         int size = rcs.size();
/*     */         
/*  95 */         char[] cValue = new char[L];
/*  96 */         value = new StringValue(cValue);
/*     */         
/*  98 */         for (int k = 0; k < L; k++) {
/*     */           
/* 100 */           int codePoint, code = valueChannel.decodeNBitUnsignedInteger(numberOfBits);
/*     */           
/* 102 */           if (code == size) {
/*     */             
/* 104 */             codePoint = valueChannel.decodeUnsignedInteger();
/*     */           } else {
/* 106 */             codePoint = rcs.getCodePoint(code);
/*     */           } 
/*     */           
/* 109 */           Character.toChars(codePoint, cValue, k);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 116 */         stringDecoder.addValue(qnContext, value);
/*     */       } else {
/* 118 */         value = StringCoder.EMPTY_STRING_VALUE;
/*     */       } 
/*     */     } 
/*     */     
/* 122 */     return (Value)value;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\AbstractTypeDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */