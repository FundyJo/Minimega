/*    */ package com.siemens.ct.exi.core.grammars;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.GrammarContext;
/*    */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractGrammars
/*    */   implements Grammars
/*    */ {
/*    */   protected Grammar documentGrammar;
/*    */   protected Grammar fragmentGrammar;
/*    */   private final GrammarContext grammarContext;
/*    */   private final boolean isSchemaInformed;
/*    */   
/*    */   public AbstractGrammars(boolean isSchemaInformed, GrammarContext grammarContext) {
/* 50 */     this.isSchemaInformed = isSchemaInformed;
/* 51 */     this.grammarContext = grammarContext;
/*    */   }
/*    */   
/*    */   public GrammarContext getGrammarContext() {
/* 55 */     return this.grammarContext;
/*    */   }
/*    */   
/*    */   public boolean isSchemaInformed() {
/* 59 */     return this.isSchemaInformed;
/*    */   }
/*    */   
/*    */   public Grammar getDocumentGrammar() {
/* 63 */     return this.documentGrammar;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 68 */     if (this == o)
/* 69 */       return true; 
/* 70 */     if (!(o instanceof AbstractGrammars)) {
/* 71 */       return false;
/*    */     }
/* 73 */     AbstractGrammars that = (AbstractGrammars)o;
/*    */     
/* 75 */     if (this.isSchemaInformed != that.isSchemaInformed)
/* 76 */       return false; 
/* 77 */     if ((this.documentGrammar != null) ? 
/* 78 */       !this.documentGrammar.equals(that.documentGrammar) : (that.documentGrammar != null))
/* 79 */       return false; 
/* 80 */     if ((this.fragmentGrammar != null) ? 
/* 81 */       !this.fragmentGrammar.equals(that.fragmentGrammar) : (that.fragmentGrammar != null))
/* 82 */       return false; 
/* 83 */     return (this.grammarContext != null) ? 
/* 84 */       this.grammarContext.equals(that.grammarContext) : ((that.grammarContext == null));
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\AbstractGrammars.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */