/*    */ package com.siemens.ct.exi.core.grammars.production;
/*    */ 
/*    */ import com.siemens.ct.exi.core.grammars.event.Event;
/*    */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractProduction
/*    */   implements Production
/*    */ {
/*    */   protected final Grammar next;
/*    */   protected final int eventCode;
/*    */   protected final Event event;
/*    */   
/*    */   public AbstractProduction(Grammar next, Event event, int eventCode) {
/* 43 */     this.next = next;
/* 44 */     this.event = event;
/* 45 */     this.eventCode = eventCode;
/*    */   }
/*    */   
/*    */   public abstract int getEventCode();
/*    */   
/*    */   public Event getEvent() {
/* 51 */     return this.event;
/*    */   }
/*    */   
/*    */   public Grammar getNextGrammar() {
/* 55 */     return this.next;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     return "[" + this.eventCode + "] " + this.event + " -> " + this.next;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 65 */     if (this == o)
/* 66 */       return true; 
/* 67 */     if (!(o instanceof AbstractProduction)) {
/* 68 */       return false;
/*    */     }
/* 70 */     AbstractProduction that = (AbstractProduction)o;
/*    */     
/* 72 */     if (this.eventCode != that.eventCode) {
/* 73 */       return false;
/*    */     }
/*    */     
/* 76 */     return (this.event != null) ? this.event.equals(that.event) : ((that.event == null));
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\production\AbstractProduction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */