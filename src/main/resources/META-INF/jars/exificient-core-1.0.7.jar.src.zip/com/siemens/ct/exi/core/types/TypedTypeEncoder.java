/*     */ package com.siemens.ct.exi.core.types;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.DatetimeDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.EnumDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.EnumerationDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.ExtendedStringDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.ListDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.NBitUnsignedIntegerDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.RestrictedCharacterSetDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringEncoder;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringEncoderImpl;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import com.siemens.ct.exi.core.values.AbstractBinaryValue;
/*     */ import com.siemens.ct.exi.core.values.BinaryBase64Value;
/*     */ import com.siemens.ct.exi.core.values.BinaryHexValue;
/*     */ import com.siemens.ct.exi.core.values.BooleanValue;
/*     */ import com.siemens.ct.exi.core.values.DateTimeValue;
/*     */ import com.siemens.ct.exi.core.values.DecimalValue;
/*     */ import com.siemens.ct.exi.core.values.FloatValue;
/*     */ import com.siemens.ct.exi.core.values.IntegerValue;
/*     */ import com.siemens.ct.exi.core.values.ListValue;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypedTypeEncoder
/*     */   extends AbstractTypeEncoder
/*     */ {
/*     */   public Datatype lastDatatype;
/*     */   protected final boolean doNormalize;
/*     */   protected byte[] lastBytes;
/*     */   protected BooleanValue lastBool;
/*     */   protected int lastBooleanID;
/*     */   protected boolean lastBoolean;
/*     */   protected DecimalValue lastDecimal;
/*     */   protected FloatValue lastFloat;
/*     */   protected IntegerValue lastNBitInteger;
/*     */   protected IntegerValue lastUnsignedInteger;
/*     */   protected IntegerValue lastInteger;
/*     */   protected DateTimeValue lastDatetime;
/*     */   protected String lastString;
/*     */   protected int lastEnumIndex;
/*     */   protected ListValue lastListValues;
/*     */   
/*     */   public TypedTypeEncoder() throws EXIException {
/*  71 */     this(false);
/*     */   }
/*     */   
/*     */   public TypedTypeEncoder(boolean doNormalize) throws EXIException {
/*  75 */     this((QName[])null, (QName[])null, (Map<QName, Datatype>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedTypeEncoder(QName[] dtrMapTypes, QName[] dtrMapRepresentations, Map<QName, Datatype> dtrMapRepresentationsDatatype) throws EXIException {
/*  81 */     this(dtrMapTypes, dtrMapRepresentations, dtrMapRepresentationsDatatype, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedTypeEncoder(QName[] dtrMapTypes, QName[] dtrMapRepresentations, Map<QName, Datatype> dtrMapRepresentationsDatatype, boolean doNormalize) throws EXIException {
/*  88 */     super(dtrMapTypes, dtrMapRepresentations, dtrMapRepresentationsDatatype);
/*  89 */     this.doNormalize = doNormalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid(Datatype datatype, Value value) {
/*     */     NBitUnsignedIntegerDatatype nbitDT;
/*     */     EnumerationDatatype enumDT;
/*     */     int index;
/* 107 */     if (this.dtrMapInUse && datatype
/* 108 */       .getBuiltInType() != BuiltInType.EXTENDED_STRING) {
/* 109 */       this.lastDatatype = getDtrDatatype(datatype);
/*     */     } else {
/* 111 */       this.lastDatatype = datatype;
/*     */     } 
/*     */     
/* 114 */     switch (this.lastDatatype.getBuiltInType()) {
/*     */       case BINARY_BASE64:
/*     */       case BINARY_HEX:
/* 117 */         if (value instanceof AbstractBinaryValue) {
/* 118 */           this.lastBytes = ((AbstractBinaryValue)value).toBytes();
/* 119 */           return true;
/*     */         } 
/* 121 */         return isValidString(value.toString());
/*     */       
/*     */       case BOOLEAN:
/* 124 */         if (value instanceof BooleanValue) {
/* 125 */           this.lastBool = (BooleanValue)value;
/* 126 */           return true;
/*     */         } 
/* 128 */         return isValidString(value.toString());
/*     */       
/*     */       case BOOLEAN_FACET:
/* 131 */         if (value instanceof BooleanValue) {
/* 132 */           this.lastBoolean = ((BooleanValue)value).toBoolean();
/*     */           
/* 134 */           this.lastBooleanID = this.lastBoolean ? 2 : 0;
/* 135 */           return true;
/*     */         } 
/* 137 */         return isValidString(value.toString());
/*     */       
/*     */       case DECIMAL:
/* 140 */         if (value instanceof DecimalValue) {
/* 141 */           this.lastDecimal = (DecimalValue)value;
/* 142 */           return true;
/*     */         } 
/* 144 */         return isValidString(value.toString());
/*     */       
/*     */       case FLOAT:
/* 147 */         if (value instanceof FloatValue) {
/* 148 */           this.lastFloat = (FloatValue)value;
/* 149 */           return true;
/*     */         } 
/* 151 */         return isValidString(value.toString());
/*     */       
/*     */       case NBIT_UNSIGNED_INTEGER:
/* 154 */         nbitDT = (NBitUnsignedIntegerDatatype)this.lastDatatype;
/* 155 */         if (value instanceof IntegerValue) {
/* 156 */           this.lastNBitInteger = (IntegerValue)value;
/* 157 */           return (this.lastNBitInteger.compareTo(nbitDT.getLowerBound()) >= 0 && this.lastNBitInteger
/* 158 */             .compareTo(nbitDT.getUpperBound()) <= 0);
/*     */         } 
/*     */         
/* 161 */         return isValidString(value.toString());
/*     */       
/*     */       case UNSIGNED_INTEGER:
/* 164 */         if (value instanceof IntegerValue) {
/* 165 */           this.lastUnsignedInteger = (IntegerValue)value;
/* 166 */           return this.lastUnsignedInteger.isPositive();
/*     */         } 
/* 168 */         return isValidString(value.toString());
/*     */       
/*     */       case INTEGER:
/* 171 */         if (value instanceof IntegerValue) {
/* 172 */           this.lastInteger = (IntegerValue)value;
/* 173 */           return true;
/*     */         } 
/* 175 */         return isValidString(value.toString());
/*     */ 
/*     */       
/*     */       case DATETIME:
/* 179 */         if (value instanceof DateTimeValue) {
/* 180 */           this.lastDatetime = (DateTimeValue)value;
/* 181 */           return true;
/*     */         } 
/* 183 */         return isValidString(value.toString());
/*     */       
/*     */       case STRING:
/* 186 */         this.lastString = value.toString();
/* 187 */         return true;
/*     */ 
/*     */ 
/*     */       
/*     */       case RCS_STRING:
/* 192 */         this.lastString = value.toString();
/* 193 */         return true;
/*     */       case EXTENDED_STRING:
/* 195 */         this.lastString = value.toString();
/* 196 */         return true;
/*     */       case ENUMERATION:
/* 198 */         enumDT = (EnumerationDatatype)this.lastDatatype;
/* 199 */         index = 0;
/* 200 */         while (index < enumDT.getEnumerationSize()) {
/* 201 */           if (enumDT.getEnumValue(index).equals(value)) {
/* 202 */             this.lastEnumIndex = index;
/* 203 */             return true;
/*     */           } 
/* 205 */           index++;
/*     */         } 
/* 207 */         return false;
/*     */       case LIST:
/* 209 */         if (value instanceof ListValue) {
/* 210 */           ListDatatype listDT = (ListDatatype)this.lastDatatype;
/* 211 */           ListValue lv = (ListValue)value;
/* 212 */           if (listDT.getListDatatype().getBuiltInType() == lv
/* 213 */             .getListDatatype().getBuiltInType()) {
/* 214 */             this.lastListValues = lv;
/* 215 */             return true;
/*     */           } 
/* 217 */           this.lastListValues = null;
/* 218 */           return false;
/*     */         } 
/*     */         
/* 221 */         return isValidString(value.toString());
/*     */ 
/*     */       
/*     */       case QNAME:
/* 225 */         return false;
/*     */     } 
/*     */ 
/*     */     
/* 229 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValidString(String value) {
/*     */     BinaryBase64Value bvb;
/*     */     BinaryHexValue bvh;
/*     */     boolean retValue;
/*     */     NBitUnsignedIntegerDatatype nbitDT;
/*     */     DatetimeDatatype datetimeDT;
/*     */     ListDatatype listDT;
/* 240 */     switch (this.lastDatatype.getBuiltInType()) {
/*     */       case BINARY_BASE64:
/* 242 */         value = value.trim();
/* 243 */         bvb = BinaryBase64Value.parse(value);
/* 244 */         if (bvb == null) {
/* 245 */           return false;
/*     */         }
/* 247 */         this.lastBytes = bvb.toBytes();
/* 248 */         return true;
/*     */       
/*     */       case BINARY_HEX:
/* 251 */         value = value.trim();
/* 252 */         bvh = BinaryHexValue.parse(value);
/* 253 */         if (bvh == null) {
/* 254 */           return false;
/*     */         }
/* 256 */         this.lastBytes = bvh.toBytes();
/* 257 */         return true;
/*     */       
/*     */       case BOOLEAN:
/* 260 */         this.lastBool = BooleanValue.parse(value);
/* 261 */         return (this.lastBool != null);
/*     */       case BOOLEAN_FACET:
/* 263 */         value = value.trim();
/* 264 */         retValue = true;
/*     */         
/* 266 */         if (value.equals("false")) {
/* 267 */           this.lastBooleanID = 0;
/* 268 */           this.lastBoolean = false;
/* 269 */         } else if (value.equals("0")) {
/* 270 */           this.lastBooleanID = 1;
/* 271 */           this.lastBoolean = false;
/* 272 */         } else if (value.equals("true")) {
/* 273 */           this.lastBooleanID = 2;
/* 274 */           this.lastBoolean = true;
/* 275 */         } else if (value.equals("1")) {
/* 276 */           this.lastBooleanID = 3;
/* 277 */           this.lastBoolean = true;
/*     */         } else {
/* 279 */           retValue = false;
/*     */         } 
/*     */         
/* 282 */         return retValue;
/*     */       case DECIMAL:
/* 284 */         this.lastDecimal = DecimalValue.parse(value);
/* 285 */         return (this.lastDecimal != null);
/*     */       case FLOAT:
/* 287 */         this.lastFloat = FloatValue.parse(value);
/* 288 */         return (this.lastFloat != null);
/*     */       case NBIT_UNSIGNED_INTEGER:
/* 290 */         this.lastNBitInteger = IntegerValue.parse(value);
/* 291 */         if (this.lastNBitInteger == null) {
/* 292 */           return false;
/*     */         }
/* 294 */         nbitDT = (NBitUnsignedIntegerDatatype)this.lastDatatype;
/* 295 */         return (this.lastNBitInteger.compareTo(nbitDT.getLowerBound()) >= 0 && this.lastNBitInteger
/* 296 */           .compareTo(nbitDT.getUpperBound()) <= 0);
/*     */ 
/*     */       
/*     */       case UNSIGNED_INTEGER:
/* 300 */         this.lastUnsignedInteger = IntegerValue.parse(value);
/* 301 */         if (this.lastUnsignedInteger != null) {
/* 302 */           return this.lastUnsignedInteger.isPositive();
/*     */         }
/* 304 */         return false;
/*     */       
/*     */       case INTEGER:
/* 307 */         this.lastInteger = IntegerValue.parse(value);
/* 308 */         return (this.lastInteger != null);
/*     */       case DATETIME:
/* 310 */         datetimeDT = (DatetimeDatatype)this.lastDatatype;
/* 311 */         this.lastDatetime = DateTimeValue.parse(value, datetimeDT
/* 312 */             .getDatetimeType());
/* 313 */         return (this.lastDatetime != null);
/*     */       case LIST:
/* 315 */         listDT = (ListDatatype)this.lastDatatype;
/* 316 */         this.lastListValues = ListValue.parse(value, listDT.getListDatatype());
/* 317 */         return (this.lastListValues != null);
/*     */     } 
/* 319 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void normalize(Datatype datatype) {
/* 324 */     switch (datatype.getBuiltInType()) {
/*     */ 
/*     */       
/*     */       case DATETIME:
/* 328 */         if (this.lastDatetime != null) {
/* 329 */           this.lastDatetime = this.lastDatetime.normalize();
/*     */         }
/*     */         break;
/*     */       case LIST:
/* 333 */         if (this.lastListValues != null) {
/* 334 */           Datatype dt = this.lastListValues.getListDatatype();
/* 335 */           for (Value v : this.lastListValues.toValues()) {
/* 336 */             isValid(dt, v);
/* 337 */             normalize(dt);
/*     */           } 
/*     */         }  break;
/*     */     }  } public void writeValue(QNameContext qnContext, EncoderChannel valueChannel, StringEncoder stringEncoder) throws IOException { NBitUnsignedIntegerDatatype nbitDT; IntegerValue iv;
/*     */     RestrictedCharacterSetDatatype rcsDT;
/*     */     ExtendedStringDatatype esDT;
/*     */     EnumerationDatatype enumDT;
/*     */     ListDatatype listDT;
/*     */     Datatype listDatatype;
/*     */     Value[] values;
/*     */     int i;
/* 348 */     if (this.doNormalize) {
/* 349 */       normalize(this.lastDatatype);
/*     */     }
/*     */ 
/*     */     
/* 353 */     switch (this.lastDatatype.getBuiltInType()) {
/*     */       case BINARY_BASE64:
/*     */       case BINARY_HEX:
/* 356 */         valueChannel.encodeBinary(this.lastBytes);
/*     */         return;
/*     */       case BOOLEAN:
/* 359 */         valueChannel.encodeBoolean(this.lastBool.toBoolean());
/*     */         return;
/*     */       case BOOLEAN_FACET:
/* 362 */         valueChannel.encodeNBitUnsignedInteger(this.lastBooleanID, 2);
/*     */         return;
/*     */       case DECIMAL:
/* 365 */         valueChannel.encodeDecimal(this.lastDecimal.isNegative(), this.lastDecimal
/* 366 */             .getIntegral(), this.lastDecimal.getRevFractional());
/*     */         return;
/*     */       case FLOAT:
/* 369 */         valueChannel.encodeFloat(this.lastFloat);
/*     */         return;
/*     */       case NBIT_UNSIGNED_INTEGER:
/* 372 */         nbitDT = (NBitUnsignedIntegerDatatype)this.lastDatatype;
/* 373 */         iv = this.lastNBitInteger.subtract(nbitDT.getLowerBound());
/* 374 */         valueChannel.encodeNBitUnsignedInteger(iv.intValue(), nbitDT
/* 375 */             .getNumberOfBits());
/*     */         return;
/*     */       case UNSIGNED_INTEGER:
/* 378 */         valueChannel.encodeUnsignedIntegerValue(this.lastUnsignedInteger);
/*     */         return;
/*     */       case INTEGER:
/* 381 */         valueChannel.encodeIntegerValue(this.lastInteger);
/*     */         return;
/*     */       case DATETIME:
/* 384 */         valueChannel.encodeDateTime(this.lastDatetime);
/*     */         return;
/*     */       case STRING:
/* 387 */         stringEncoder.writeValue(qnContext, valueChannel, this.lastString);
/*     */         return;
/*     */       case RCS_STRING:
/* 390 */         rcsDT = (RestrictedCharacterSetDatatype)this.lastDatatype;
/* 391 */         writeRCSValue(rcsDT, qnContext, valueChannel, stringEncoder, this.lastString);
/*     */         return;
/*     */       
/*     */       case EXTENDED_STRING:
/* 395 */         esDT = (ExtendedStringDatatype)this.lastDatatype;
/* 396 */         writeExtendedValue(esDT, qnContext, valueChannel, stringEncoder, this.lastString);
/*     */         return;
/*     */       
/*     */       case ENUMERATION:
/* 400 */         enumDT = (EnumerationDatatype)this.lastDatatype;
/* 401 */         valueChannel.encodeNBitUnsignedInteger(this.lastEnumIndex, enumDT
/* 402 */             .getCodingLength());
/*     */         return;
/*     */       case LIST:
/* 405 */         listDT = (ListDatatype)this.lastDatatype;
/* 406 */         listDatatype = listDT.getListDatatype();
/*     */ 
/*     */         
/* 409 */         values = this.lastListValues.toValues();
/* 410 */         valueChannel.encodeUnsignedInteger(values.length);
/*     */ 
/*     */         
/* 413 */         for (i = 0; i < values.length; i++) {
/* 414 */           Value v = values[i];
/* 415 */           boolean valid = isValid(listDatatype, v);
/* 416 */           if (!valid) {
/* 417 */             throw new RuntimeException("ListValue is not valid, " + v);
/*     */           }
/* 419 */           writeValue(qnContext, valueChannel, stringEncoder);
/*     */         } 
/*     */         return;
/*     */       case QNAME:
/* 423 */         throw new IOException("QName is not an allowed as EXI datatype");
/*     */     } 
/* 425 */     throw new IOException("EXI datatype not supported"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getEnumIndex(EnumDatatype grammarStrings, StringValue sv) {
/* 432 */     for (int i = 0; i < grammarStrings.getEnumerationSize(); i++) {
/* 433 */       Value v = grammarStrings.getEnumValue(i);
/* 434 */       if (sv.equals(v)) {
/* 435 */         return i;
/*     */       }
/*     */     } 
/* 438 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeExtendedValue(ExtendedStringDatatype esDT, QNameContext context, EncoderChannel valueChannel, StringEncoder stringEncoder, String value) throws IOException {
/* 445 */     EnumDatatype grammarStrings = esDT.getGrammarStrings();
/*     */     
/* 447 */     StringEncoderImpl.ValueContainer vc = stringEncoder.getValueContainer(value);
/*     */     
/* 449 */     if (vc != null) {
/*     */       
/* 451 */       if (stringEncoder.isLocalValuePartitions() && context
/* 452 */         .equals(vc.context))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 458 */         valueChannel.encodeUnsignedInteger(0);
/* 459 */         int numberBitsLocal = MethodsBag.getCodingLength(stringEncoder
/* 460 */             .getNumberOfStringValues(context));
/* 461 */         valueChannel.encodeNBitUnsignedInteger(vc.localValueID, numberBitsLocal);
/*     */ 
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */         
/* 469 */         valueChannel.encodeUnsignedInteger(1);
/*     */ 
/*     */         
/* 472 */         int numberBitsGlobal = MethodsBag.getCodingLength(stringEncoder
/* 473 */             .getValueContainerSize());
/* 474 */         valueChannel.encodeNBitUnsignedInteger(vc.globalValueID, numberBitsGlobal);
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 485 */       int gindex = -1;
/* 486 */       if (grammarStrings != null && (
/* 487 */         gindex = getEnumIndex(grammarStrings, new StringValue(value))) >= 0) {
/*     */ 
/*     */ 
/*     */         
/* 491 */         valueChannel.encodeUnsignedInteger(2);
/* 492 */         valueChannel.encodeNBitUnsignedInteger(gindex, grammarStrings
/* 493 */             .getCodingLength());
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 500 */         int L = value.codePointCount(0, value.length());
/* 501 */         valueChannel.encodeUnsignedInteger(L + 6);
/*     */ 
/*     */ 
/*     */         
/* 505 */         if (L > 0) {
/* 506 */           valueChannel.encodeStringOnly(value);
/*     */ 
/*     */ 
/*     */           
/* 510 */           stringEncoder.addValue(context, value);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\TypedTypeEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */