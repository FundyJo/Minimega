/*     */ package com.siemens.ct.exi.core.values;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryHexValue
/*     */   extends AbstractBinaryValue
/*     */ {
/*     */   private int lengthData;
/*     */   private static final int BASELENGTH = 128;
/*     */   private static final int LOOKUPLENGTH = 16;
/*     */   
/*     */   public BinaryHexValue(byte[] bytes) {
/*  39 */     super(ValueType.BINARY_HEX, bytes);
/*     */   }
/*     */   
/*     */   public static BinaryHexValue parse(String val) {
/*  43 */     byte[] bytes = decode(val);
/*  44 */     if (bytes == null) {
/*  45 */       return null;
/*     */     }
/*  47 */     return new BinaryHexValue(bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCharactersLength() {
/*  52 */     if (this.slen == -1) {
/*  53 */       this.lengthData = this.bytes.length;
/*  54 */       this.slen = this.lengthData * 2;
/*     */     } 
/*  56 */     return this.slen;
/*     */   }
/*     */   
/*     */   public void getCharacters(char[] cbuffer, int offset) {
/*  60 */     getCharactersLength();
/*     */ 
/*     */     
/*  63 */     for (int i = 0; i < this.lengthData; i++) {
/*  64 */       int temp = this.bytes[i];
/*  65 */       if (temp < 0)
/*  66 */         temp += 256; 
/*  67 */       cbuffer[offset + i * 2] = lookUpHexAlphabet[temp >> 4];
/*  68 */       cbuffer[offset + i * 2 + 1] = lookUpHexAlphabet[temp & 0xF];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  76 */     if (o == null) {
/*  77 */       return false;
/*     */     }
/*  79 */     if (o instanceof BinaryHexValue) {
/*  80 */       return _equals(((BinaryHexValue)o).bytes);
/*     */     }
/*  82 */     BinaryHexValue bv = parse(o.toString());
/*  83 */     return (bv == null) ? false : _equals(bv.bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  90 */     int hc = 0;
/*  91 */     for (int i = 0; i < this.bytes.length; i++) {
/*  92 */       hc = hc * 31 ^ this.bytes[i];
/*     */     }
/*     */     
/*  95 */     return hc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static final byte[] hexNumberTable = new byte[128];
/* 106 */   private static final char[] lookUpHexAlphabet = new char[16];
/*     */   static {
/*     */     int i;
/* 109 */     for (i = 0; i < 128; i++) {
/* 110 */       hexNumberTable[i] = -1;
/*     */     }
/* 112 */     for (i = 57; i >= 48; i--) {
/* 113 */       hexNumberTable[i] = (byte)(i - 48);
/*     */     }
/* 115 */     for (i = 70; i >= 65; i--) {
/* 116 */       hexNumberTable[i] = (byte)(i - 65 + 10);
/*     */     }
/* 118 */     for (i = 102; i >= 97; i--) {
/* 119 */       hexNumberTable[i] = (byte)(i - 97 + 10);
/*     */     }
/*     */     
/* 122 */     for (i = 0; i < 10; i++) {
/* 123 */       lookUpHexAlphabet[i] = (char)(48 + i);
/*     */     }
/* 125 */     for (i = 10; i <= 15; i++) {
/* 126 */       lookUpHexAlphabet[i] = (char)(65 + i - 10);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(String encoded) {
/* 138 */     if (encoded == null)
/* 139 */       return null; 
/* 140 */     int lengthData = encoded.length();
/* 141 */     if (lengthData % 2 != 0) {
/* 142 */       return null;
/*     */     }
/* 144 */     char[] binaryData = encoded.toCharArray();
/* 145 */     int lengthDecode = lengthData / 2;
/* 146 */     byte[] decodedData = new byte[lengthDecode];
/*     */ 
/*     */     
/* 149 */     for (int i = 0; i < lengthDecode; i++) {
/* 150 */       char tempChar = binaryData[i * 2];
/* 151 */       byte temp1 = (tempChar < '') ? hexNumberTable[tempChar] : -1;
/* 152 */       if (temp1 == -1)
/* 153 */         return null; 
/* 154 */       tempChar = binaryData[i * 2 + 1];
/* 155 */       byte temp2 = (tempChar < '') ? hexNumberTable[tempChar] : -1;
/* 156 */       if (temp2 == -1)
/* 157 */         return null; 
/* 158 */       decodedData[i] = (byte)(temp1 << 4 | temp2);
/*     */     } 
/* 160 */     return decodedData;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\BinaryHexValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */