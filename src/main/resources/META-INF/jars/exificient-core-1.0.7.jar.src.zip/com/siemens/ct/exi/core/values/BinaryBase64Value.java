/*     */ package com.siemens.ct.exi.core.values;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryBase64Value
/*     */   extends AbstractBinaryValue
/*     */ {
/*     */   private int fewerThan24bits;
/*     */   private int numberTriplets;
/*     */   private int numberQuartet;
/*     */   private static final int BASELENGTH = 128;
/*     */   private static final int LOOKUPLENGTH = 64;
/*     */   private static final int TWENTYFOURBITGROUP = 24;
/*     */   private static final int EIGHTBIT = 8;
/*     */   private static final int SIXTEENBIT = 16;
/*     */   private static final int FOURBYTE = 4;
/*     */   private static final int SIGN = -128;
/*     */   private static final char PAD = '=';
/*     */   
/*     */   public BinaryBase64Value(byte[] bytes) {
/*  40 */     super(ValueType.BINARY_BASE64, bytes);
/*     */   }
/*     */   
/*     */   public static BinaryBase64Value parse(String val) {
/*  44 */     byte[] bytes = decode(val);
/*  45 */     if (bytes == null) {
/*  46 */       return null;
/*     */     }
/*  48 */     return new BinaryBase64Value(bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCharactersLength() {
/*  53 */     if (this.slen == -1) {
/*  54 */       int lengthDataBits = this.bytes.length * 8;
/*  55 */       if (lengthDataBits == 0) {
/*  56 */         this.slen = 0;
/*     */       } else {
/*  58 */         this.fewerThan24bits = lengthDataBits % 24;
/*  59 */         this.numberTriplets = lengthDataBits / 24;
/*  60 */         this
/*  61 */           .numberQuartet = (this.fewerThan24bits != 0) ? (this.numberTriplets + 1) : this.numberTriplets;
/*     */         
/*  63 */         this.slen = this.numberQuartet * 4;
/*     */       } 
/*     */     } 
/*  66 */     return this.slen;
/*     */   }
/*     */   
/*     */   public void getCharacters(char[] cbuffer, int offset) {
/*  70 */     getCharactersLength();
/*     */     
/*  72 */     byte k = 0, l = 0, b1 = 0, b2 = 0, b3 = 0;
/*     */     
/*  74 */     int encodedIndex = 0;
/*  75 */     int dataIndex = 0;
/*     */     
/*  77 */     for (int i = 0; i < this.numberTriplets; i++) {
/*  78 */       b1 = this.bytes[dataIndex++];
/*  79 */       b2 = this.bytes[dataIndex++];
/*  80 */       b3 = this.bytes[dataIndex++];
/*     */       
/*  82 */       l = (byte)(b2 & 0xF);
/*  83 */       k = (byte)(b1 & 0x3);
/*     */ 
/*     */       
/*  86 */       byte val1 = ((b1 & Byte.MIN_VALUE) == 0) ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */ 
/*     */       
/*  89 */       byte val2 = ((b2 & Byte.MIN_VALUE) == 0) ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */       
/*  91 */       byte val3 = ((b3 & Byte.MIN_VALUE) == 0) ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/*     */       
/*  93 */       cbuffer[offset + encodedIndex++] = lookUpBase64Alphabet[val1];
/*  94 */       cbuffer[offset + encodedIndex++] = lookUpBase64Alphabet[val2 | k << 4];
/*     */       
/*  96 */       cbuffer[offset + encodedIndex++] = lookUpBase64Alphabet[l << 2 | val3];
/*     */       
/*  98 */       cbuffer[offset + encodedIndex++] = lookUpBase64Alphabet[b3 & 0x3F];
/*     */     } 
/*     */ 
/*     */     
/* 102 */     if (this.fewerThan24bits == 8) {
/* 103 */       b1 = this.bytes[dataIndex];
/* 104 */       k = (byte)(b1 & 0x3);
/*     */ 
/*     */       
/* 107 */       byte val1 = ((b1 & Byte.MIN_VALUE) == 0) ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 108 */       cbuffer[offset + encodedIndex++] = lookUpBase64Alphabet[val1];
/* 109 */       cbuffer[offset + encodedIndex++] = lookUpBase64Alphabet[k << 4];
/* 110 */       cbuffer[offset + encodedIndex++] = '=';
/* 111 */       cbuffer[offset + encodedIndex++] = '=';
/* 112 */     } else if (this.fewerThan24bits == 16) {
/* 113 */       b1 = this.bytes[dataIndex];
/* 114 */       b2 = this.bytes[dataIndex + 1];
/* 115 */       l = (byte)(b2 & 0xF);
/* 116 */       k = (byte)(b1 & 0x3);
/*     */ 
/*     */       
/* 119 */       byte val1 = ((b1 & Byte.MIN_VALUE) == 0) ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/*     */       
/* 121 */       byte val2 = ((b2 & Byte.MIN_VALUE) == 0) ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/*     */       
/* 123 */       cbuffer[offset + encodedIndex++] = lookUpBase64Alphabet[val1];
/* 124 */       cbuffer[offset + encodedIndex++] = lookUpBase64Alphabet[val2 | k << 4];
/*     */       
/* 126 */       cbuffer[offset + encodedIndex++] = lookUpBase64Alphabet[l << 2];
/* 127 */       cbuffer[offset + encodedIndex++] = '=';
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 135 */     if (o == null) {
/* 136 */       return false;
/*     */     }
/* 138 */     if (o instanceof BinaryBase64Value) {
/* 139 */       return _equals(((BinaryBase64Value)o).bytes);
/*     */     }
/* 141 */     BinaryBase64Value bv = parse(o.toString());
/* 142 */     return (bv == null) ? false : _equals(bv.bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 149 */     int hc = 0;
/* 150 */     for (byte b : this.bytes) {
/* 151 */       hc = hc * 31 ^ b;
/*     */     }
/*     */     
/* 154 */     return hc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   private static final byte[] base64Alphabet = new byte[128];
/* 172 */   private static final char[] lookUpBase64Alphabet = new char[64];
/*     */   
/*     */   static {
/*     */     int i;
/* 176 */     for (i = 0; i < 128; i++) {
/* 177 */       base64Alphabet[i] = -1;
/*     */     }
/* 179 */     for (i = 90; i >= 65; i--) {
/* 180 */       base64Alphabet[i] = (byte)(i - 65);
/*     */     }
/* 182 */     for (i = 122; i >= 97; i--) {
/* 183 */       base64Alphabet[i] = (byte)(i - 97 + 26);
/*     */     }
/*     */     
/* 186 */     for (i = 57; i >= 48; i--) {
/* 187 */       base64Alphabet[i] = (byte)(i - 48 + 52);
/*     */     }
/*     */     
/* 190 */     base64Alphabet[43] = 62;
/* 191 */     base64Alphabet[47] = 63;
/*     */     
/* 193 */     for (i = 0; i <= 25; i++)
/* 194 */       lookUpBase64Alphabet[i] = (char)(65 + i); 
/*     */     int j;
/* 196 */     for (i = 26, j = 0; i <= 51; i++, j++) {
/* 197 */       lookUpBase64Alphabet[i] = (char)(97 + j);
/*     */     }
/* 199 */     for (i = 52, j = 0; i <= 61; i++, j++)
/* 200 */       lookUpBase64Alphabet[i] = (char)(48 + j); 
/* 201 */     lookUpBase64Alphabet[62] = '+';
/* 202 */     lookUpBase64Alphabet[63] = '/';
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean isWhiteSpace(char octect) {
/* 207 */     return (octect == ' ' || octect == '\r' || octect == '\n' || octect == '\t');
/*     */   }
/*     */   
/*     */   protected static boolean isPad(char octect) {
/* 211 */     return (octect == '=');
/*     */   }
/*     */   
/*     */   protected static boolean isData(char octect) {
/* 215 */     return (octect < '' && base64Alphabet[octect] != -1);
/*     */   }
/*     */   
/*     */   protected static boolean isBase64(char octect) {
/* 219 */     return (isWhiteSpace(octect) || isPad(octect) || isData(octect));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(String encoded) {
/* 231 */     if (encoded == null) {
/* 232 */       return null;
/*     */     }
/* 234 */     char[] base64Data = encoded.toCharArray();
/*     */     
/* 236 */     int len = removeWhiteSpace(base64Data);
/*     */     
/* 238 */     if (len % 4 != 0) {
/* 239 */       return null;
/*     */     }
/*     */     
/* 242 */     int numberQuadruple = len / 4;
/*     */     
/* 244 */     if (numberQuadruple == 0) {
/* 245 */       return new byte[0];
/*     */     }
/* 247 */     byte[] decodedData = null;
/* 248 */     byte b1 = 0, b2 = 0, b3 = 0, b4 = 0;
/* 249 */     char d1 = Character.MIN_VALUE, d2 = Character.MIN_VALUE, d3 = Character.MIN_VALUE, d4 = Character.MIN_VALUE;
/*     */     
/* 251 */     int i = 0;
/* 252 */     int encodedIndex = 0;
/* 253 */     int dataIndex = 0;
/* 254 */     decodedData = new byte[numberQuadruple * 3];
/*     */     
/* 256 */     for (; i < numberQuadruple - 1; i++) {
/*     */       
/* 258 */       if (!isData(d1 = base64Data[dataIndex++]) || 
/* 259 */         !isData(d2 = base64Data[dataIndex++]) || 
/* 260 */         !isData(d3 = base64Data[dataIndex++]) || 
/* 261 */         !isData(d4 = base64Data[dataIndex++])) {
/* 262 */         return null;
/*     */       }
/* 264 */       b1 = base64Alphabet[d1];
/* 265 */       b2 = base64Alphabet[d2];
/* 266 */       b3 = base64Alphabet[d3];
/* 267 */       b4 = base64Alphabet[d4];
/*     */       
/* 269 */       decodedData[encodedIndex++] = (byte)(b1 << 2 | b2 >> 4);
/* 270 */       decodedData[encodedIndex++] = (byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF);
/* 271 */       decodedData[encodedIndex++] = (byte)(b3 << 6 | b4);
/*     */     } 
/*     */     
/* 274 */     if (!isData(d1 = base64Data[dataIndex++]) || 
/* 275 */       !isData(d2 = base64Data[dataIndex++])) {
/* 276 */       return null;
/*     */     }
/*     */     
/* 279 */     b1 = base64Alphabet[d1];
/* 280 */     b2 = base64Alphabet[d2];
/*     */     
/* 282 */     d3 = base64Data[dataIndex++];
/* 283 */     d4 = base64Data[dataIndex++];
/* 284 */     if (!isData(d3) || !isData(d4)) {
/* 285 */       if (isPad(d3) && isPad(d4)) {
/* 286 */         if ((b2 & 0xF) != 0)
/* 287 */           return null; 
/* 288 */         byte[] tmp = new byte[i * 3 + 1];
/* 289 */         System.arraycopy(decodedData, 0, tmp, 0, i * 3);
/* 290 */         tmp[encodedIndex] = (byte)(b1 << 2 | b2 >> 4);
/* 291 */         return tmp;
/* 292 */       }  if (!isPad(d3) && isPad(d4)) {
/* 293 */         b3 = base64Alphabet[d3];
/* 294 */         if ((b3 & 0x3) != 0)
/* 295 */           return null; 
/* 296 */         byte[] tmp = new byte[i * 3 + 2];
/* 297 */         System.arraycopy(decodedData, 0, tmp, 0, i * 3);
/* 298 */         tmp[encodedIndex++] = (byte)(b1 << 2 | b2 >> 4);
/* 299 */         tmp[encodedIndex] = (byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF);
/* 300 */         return tmp;
/*     */       } 
/* 302 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 306 */     b3 = base64Alphabet[d3];
/* 307 */     b4 = base64Alphabet[d4];
/* 308 */     decodedData[encodedIndex++] = (byte)(b1 << 2 | b2 >> 4);
/* 309 */     decodedData[encodedIndex++] = (byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF);
/* 310 */     decodedData[encodedIndex++] = (byte)(b3 << 6 | b4);
/*     */ 
/*     */ 
/*     */     
/* 314 */     return decodedData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int removeWhiteSpace(char[] data) {
/* 325 */     if (data == null) {
/* 326 */       return 0;
/*     */     }
/*     */     
/* 329 */     int newSize = 0;
/* 330 */     int len = data.length;
/* 331 */     for (int i = 0; i < len; i++) {
/* 332 */       if (!isWhiteSpace(data[i]))
/* 333 */         data[newSize++] = data[i]; 
/*     */     } 
/* 335 */     return newSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\BinaryBase64Value.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */