/*    */ package com.siemens.ct.exi.core.io.channel;
/*    */ 
/*    */ import com.siemens.ct.exi.core.io.BitInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BitDecoderChannel
/*    */   extends AbstractDecoderChannel
/*    */   implements DecoderChannel
/*    */ {
/*    */   protected BitInputStream istream;
/*    */   
/*    */   public BitDecoderChannel(InputStream is) {
/* 55 */     this.istream = new BitInputStream(is);
/*    */   }
/*    */   
/*    */   public final int decode() throws IOException {
/* 59 */     return this.istream.read();
/*    */   }
/*    */   
/*    */   public void align() throws IOException {
/* 63 */     this.istream.align();
/*    */   }
/*    */   
/*    */   public int lookAhead() throws IOException {
/* 67 */     return this.istream.lookAhead();
/*    */   }
/*    */   
/*    */   public void skip(long n) throws IOException {
/* 71 */     this.istream.skip(n);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int decodeNBitUnsignedInteger(int n) throws IOException {
/* 78 */     assert n >= 0;
/* 79 */     return (n == 0) ? 0 : this.istream.readBits(n);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean decodeBoolean() throws IOException {
/* 87 */     return (this.istream.readBit() == 1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] decodeBinary() throws IOException {
/* 94 */     int length = decodeUnsignedInteger();
/* 95 */     byte[] result = new byte[length];
/*    */     
/* 97 */     this.istream.read(result, 0, length);
/* 98 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\channel\BitDecoderChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */