package com.siemens.ct.exi.core.types;

import com.siemens.ct.exi.core.context.QNameContext;
import com.siemens.ct.exi.core.datatype.Datatype;
import com.siemens.ct.exi.core.datatype.strings.StringEncoder;
import com.siemens.ct.exi.core.io.channel.EncoderChannel;
import com.siemens.ct.exi.core.values.Value;
import java.io.IOException;

public interface TypeEncoder extends TypeCoder {
  boolean isValid(Datatype paramDatatype, Value paramValue);
  
  void writeValue(QNameContext paramQNameContext, EncoderChannel paramEncoderChannel, StringEncoder paramStringEncoder) throws IOException;
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\TypeEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */