package com.siemens.ct.exi.core.datatype;

import com.siemens.ct.exi.core.values.Value;

public interface EnumDatatype extends Datatype {
  int getCodingLength();
  
  int getEnumerationSize();
  
  Value getEnumValue(int paramInt);
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\EnumDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */