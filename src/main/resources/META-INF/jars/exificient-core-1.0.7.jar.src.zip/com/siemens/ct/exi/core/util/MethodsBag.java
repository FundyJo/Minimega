/*     */ package com.siemens.ct.exi.core.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodsBag
/*     */ {
/*  40 */   private static final double log2div = Math.log(2.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int numberOf7BitBlocksToRepresent(int n) {
/*  51 */     assert n >= 0;
/*     */ 
/*     */     
/*  54 */     if (n < 128) {
/*  55 */       return 1;
/*     */     }
/*     */     
/*  58 */     if (n < 16384) {
/*  59 */       return 2;
/*     */     }
/*     */     
/*  62 */     if (n < 2097152) {
/*  63 */       return 3;
/*     */     }
/*     */     
/*  66 */     if (n < 268435456) {
/*  67 */       return 4;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  72 */     return 5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int numberOf7BitBlocksToRepresent(long l) {
/*  86 */     if (l < -1L) {
/*  87 */       return numberOf7BitBlocksToRepresent((int)l);
/*     */     }
/*     */     
/*  90 */     if (l < 34359738368L) {
/*  91 */       return 5;
/*     */     }
/*     */     
/*  94 */     if (l < 4398046511104L) {
/*  95 */       return 6;
/*     */     }
/*     */     
/*  98 */     if (l < 562949953421312L) {
/*  99 */       return 7;
/*     */     }
/*     */     
/* 102 */     if (l < 72057594037927936L) {
/* 103 */       return 8;
/*     */     }
/*     */     
/* 106 */     if (l < Long.MIN_VALUE) {
/* 107 */       return 9;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 112 */     return 10;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int getCodingLength(int characteristics) {
/* 117 */     assert characteristics >= 0;
/*     */     
/* 119 */     switch (characteristics) {
/*     */       case 0:
/*     */       case 1:
/* 122 */         return 0;
/*     */       case 2:
/* 124 */         return 1;
/*     */       case 3:
/*     */       case 4:
/* 127 */         return 2;
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/* 132 */         return 3;
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/*     */       case 12:
/*     */       case 13:
/*     */       case 14:
/*     */       case 15:
/*     */       case 16:
/* 141 */         return 4;
/*     */       
/*     */       case 17:
/*     */       case 18:
/*     */       case 19:
/*     */       case 20:
/*     */       case 21:
/*     */       case 22:
/*     */       case 23:
/*     */       case 24:
/*     */       case 25:
/*     */       case 26:
/*     */       case 27:
/*     */       case 28:
/*     */       case 29:
/*     */       case 30:
/*     */       case 31:
/*     */       case 32:
/* 159 */         return 5;
/*     */       
/*     */       case 33:
/*     */       case 34:
/*     */       case 35:
/*     */       case 36:
/*     */       case 37:
/*     */       case 38:
/*     */       case 39:
/*     */       case 40:
/*     */       case 41:
/*     */       case 42:
/*     */       case 43:
/*     */       case 44:
/*     */       case 45:
/*     */       case 46:
/*     */       case 47:
/*     */       case 48:
/*     */       case 49:
/*     */       case 50:
/*     */       case 51:
/*     */       case 52:
/*     */       case 53:
/*     */       case 54:
/*     */       case 55:
/*     */       case 56:
/*     */       case 57:
/*     */       case 58:
/*     */       case 59:
/*     */       case 60:
/*     */       case 61:
/*     */       case 62:
/*     */       case 63:
/*     */       case 64:
/* 193 */         return 6;
/*     */     } 
/* 195 */     assert characteristics > 64;
/* 196 */     if (characteristics < 129)
/*     */     {
/* 198 */       return 7; } 
/* 199 */     if (characteristics < 257)
/*     */     {
/* 201 */       return 8; } 
/* 202 */     if (characteristics < 513)
/*     */     {
/* 204 */       return 9; } 
/* 205 */     if (characteristics < 1025)
/*     */     {
/* 207 */       return 10; } 
/* 208 */     if (characteristics < 2049)
/*     */     {
/* 210 */       return 11; } 
/* 211 */     if (characteristics < 4097)
/*     */     {
/* 213 */       return 12; } 
/* 214 */     if (characteristics < 8193)
/*     */     {
/* 216 */       return 13; } 
/* 217 */     if (characteristics < 16385)
/*     */     {
/* 219 */       return 14; } 
/* 220 */     if (characteristics < 32769)
/*     */     {
/* 222 */       return 15;
/*     */     }
/* 224 */     return (int)Math.ceil(Math.log(characteristics) / log2div);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   public static final char[] INTEGER_MIN_VALUE_CHARARRAY = "-2147483648"
/* 236 */     .toCharArray();
/* 237 */   public static final char[] LONG_MIN_VALUE_CHARARRAY = "-9223372036854775808"
/* 238 */     .toCharArray();
/*     */   
/* 240 */   static final char[] DigitOnes = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 250 */   static final char[] DigitTens = new char[] { '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '4', '4', '4', '4', '4', '4', '4', '4', '4', '4', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '6', '6', '6', '6', '6', '6', '6', '6', '6', '6', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '8', '8', '8', '8', '8', '8', '8', '8', '8', '8', '9', '9', '9', '9', '9', '9', '9', '9', '9', '9' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   static final char[] digits = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 268 */   static final int[] sizeTable = new int[] { 9, 99, 999, 9999, 99999, 999999, 9999999, 99999999, 999999999, Integer.MAX_VALUE };
/*     */ 
/*     */ 
/*     */   
/*     */   static final int stringSize(int x) {
/* 273 */     for (int i = 0;; i++) {
/* 274 */       if (x <= sizeTable[i])
/* 275 */         return i + 1; 
/*     */     } 
/*     */   }
/*     */   
/*     */   static final int stringSize(long x) {
/* 280 */     long p = 10L;
/* 281 */     for (int i = 1; i < 19; i++) {
/* 282 */       if (x < p)
/* 283 */         return i; 
/* 284 */       p = 10L * p;
/*     */     } 
/* 286 */     return 19;
/*     */   }
/*     */   
/*     */   public static final int getStringSize(int i) {
/* 290 */     return (i < 0) ? (stringSize(-i) + 1) : stringSize(i);
/*     */   }
/*     */   
/*     */   public static final int getStringSize(long l) {
/* 294 */     if (l == Long.MIN_VALUE)
/*     */     {
/* 296 */       return 20;
/*     */     }
/* 298 */     return (l < 0L) ? (stringSize(-l) + 1) : stringSize(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void itos(int i, int index, char[] buf) {
/* 318 */     assert i != Integer.MIN_VALUE;
/*     */ 
/*     */     
/* 321 */     char sign = Character.MIN_VALUE;
/*     */     
/* 323 */     if (i < 0) {
/* 324 */       sign = '-';
/* 325 */       i = -i;
/*     */     } 
/*     */ 
/*     */     
/* 329 */     while (i >= 65536) {
/* 330 */       int q = i / 100;
/*     */       
/* 332 */       int r = i - (q << 6) + (q << 5) + (q << 2);
/* 333 */       i = q;
/* 334 */       buf[--index] = DigitOnes[r];
/* 335 */       buf[--index] = DigitTens[r];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 341 */       int q = i * 52429 >>> 19;
/* 342 */       int r = i - (q << 3) + (q << 1);
/* 343 */       buf[--index] = digits[r];
/* 344 */       i = q;
/* 345 */     } while (i != 0);
/*     */ 
/*     */     
/* 348 */     if (sign != '\000') {
/* 349 */       buf[--index] = sign;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void itos(long i, int index, char[] buf) {
/* 367 */     if (i == Long.MIN_VALUE) {
/*     */       
/* 369 */       buf[--index] = '8';
/* 370 */       buf[--index] = '0';
/* 371 */       buf[--index] = '8';
/* 372 */       buf[--index] = '5';
/* 373 */       buf[--index] = '7';
/* 374 */       buf[--index] = '7';
/* 375 */       buf[--index] = '4';
/* 376 */       buf[--index] = '5';
/* 377 */       buf[--index] = '8';
/* 378 */       buf[--index] = '6';
/* 379 */       buf[--index] = '3';
/* 380 */       buf[--index] = '0';
/* 381 */       buf[--index] = '2';
/* 382 */       buf[--index] = '7';
/* 383 */       buf[--index] = '3';
/* 384 */       buf[--index] = '3';
/* 385 */       buf[--index] = '2';
/* 386 */       buf[--index] = '2';
/* 387 */       buf[--index] = '9';
/* 388 */       buf[--index] = '-';
/*     */       return;
/*     */     } 
/* 391 */     assert i != Long.MIN_VALUE;
/*     */ 
/*     */ 
/*     */     
/* 395 */     char sign = Character.MIN_VALUE;
/*     */     
/* 397 */     if (i < 0L) {
/* 398 */       sign = '-';
/* 399 */       i = -i;
/*     */     } 
/*     */ 
/*     */     
/* 403 */     while (i > 2147483647L) {
/* 404 */       long q = i / 100L;
/*     */       
/* 406 */       int r = (int)(i - (q << 6L) + (q << 5L) + (q << 2L));
/* 407 */       i = q;
/* 408 */       buf[--index] = DigitOnes[r];
/* 409 */       buf[--index] = DigitTens[r];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 414 */     int i2 = (int)i;
/* 415 */     while (i2 >= 65536) {
/* 416 */       int q2 = i2 / 100;
/*     */       
/* 418 */       int r = i2 - (q2 << 6) + (q2 << 5) + (q2 << 2);
/* 419 */       i2 = q2;
/* 420 */       buf[--index] = DigitOnes[r];
/* 421 */       buf[--index] = DigitTens[r];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 427 */       int q2 = i2 * 52429 >>> 19;
/* 428 */       int r = i2 - (q2 << 3) + (q2 << 1);
/* 429 */       buf[--index] = digits[r];
/* 430 */       i2 = q2;
/* 431 */     } while (i2 != 0);
/*     */ 
/*     */     
/* 434 */     if (sign != '\000') {
/* 435 */       buf[--index] = sign;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int itosReverse(int i, int index, char[] buf) {
/* 455 */     assert i >= 0;
/*     */     
/* 457 */     int posChar = index;
/*     */ 
/*     */     
/* 460 */     while (i >= 65536) {
/* 461 */       int q = i / 100;
/*     */       
/* 463 */       int r = i - (q << 6) + (q << 5) + (q << 2);
/* 464 */       i = q;
/* 465 */       buf[posChar++] = DigitOnes[r];
/* 466 */       buf[posChar++] = DigitTens[r];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 472 */       int q = i * 52429 >>> 19;
/* 473 */       int r = i - (q << 3) + (q << 1);
/* 474 */       buf[posChar++] = digits[r];
/* 475 */       i = q;
/* 476 */     } while (i != 0);
/*     */ 
/*     */ 
/*     */     
/* 480 */     return posChar - index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void itosReverse(long i, int index, char[] buf) {
/* 497 */     assert i >= 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 502 */     while (i > 2147483647L) {
/* 503 */       long q = i / 100L;
/*     */       
/* 505 */       int r = (int)(i - (q << 6L) + (q << 5L) + (q << 2L));
/* 506 */       i = q;
/* 507 */       buf[index++] = DigitOnes[r];
/* 508 */       buf[index++] = DigitTens[r];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 513 */     int i2 = (int)i;
/* 514 */     while (i2 >= 65536) {
/* 515 */       int q2 = i2 / 100;
/*     */       
/* 517 */       int r = i2 - (q2 << 6) + (q2 << 5) + (q2 << 2);
/* 518 */       i2 = q2;
/* 519 */       buf[index++] = DigitOnes[r];
/* 520 */       buf[index++] = DigitTens[r];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 526 */       int q2 = i2 * 52429 >>> 19;
/* 527 */       int r = i2 - (q2 << 3) + (q2 << 1);
/* 528 */       buf[index++] = digits[r];
/* 529 */       i2 = q2;
/* 530 */     } while (i2 != 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\cor\\util\MethodsBag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */