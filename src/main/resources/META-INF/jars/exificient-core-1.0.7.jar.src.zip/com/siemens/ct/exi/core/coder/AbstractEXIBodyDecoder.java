/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIBodyDecoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.container.DocType;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.container.ProcessingInstruction;
/*     */ import com.siemens.ct.exi.core.context.GrammarContext;
/*     */ import com.siemens.ct.exi.core.context.GrammarUriContext;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringDecoder;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.AttributeNS;
/*     */ import com.siemens.ct.exi.core.grammars.event.Characters;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElementNS;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.GrammarType;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import com.siemens.ct.exi.core.io.channel.DecoderChannel;
/*     */ import com.siemens.ct.exi.core.types.BuiltIn;
/*     */ import com.siemens.ct.exi.core.types.TypeDecoder;
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import com.siemens.ct.exi.core.util.xml.QNameUtilities;
/*     */ import com.siemens.ct.exi.core.values.BooleanValue;
/*     */ import com.siemens.ct.exi.core.values.QNameValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEXIBodyDecoder
/*     */   extends AbstractEXIBodyCoder
/*     */   implements EXIBodyDecoder
/*     */ {
/*     */   protected Event nextEvent;
/*     */   protected Grammar nextGrammar;
/*     */   protected EventType nextEventType;
/*     */   protected DecoderChannel channel;
/*     */   protected final int numberOfUriContexts;
/*     */   protected final TypeDecoder typeDecoder;
/*     */   protected final StringDecoder stringDecoder;
/*     */   protected QNameContext attributeQNameContext;
/*     */   protected String attributePrefix;
/*     */   protected Value attributeValue;
/*     */   
/*     */   public AbstractEXIBodyDecoder(EXIFactory exiFactory) throws EXIException {
/*  95 */     super(exiFactory);
/*     */ 
/*     */     
/*  98 */     this.typeDecoder = exiFactory.createTypeDecoder();
/*  99 */     this.stringDecoder = exiFactory.createStringDecoder();
/*     */     
/* 101 */     this
/* 102 */       .numberOfUriContexts = this.grammar.getGrammarContext().getNumberOfGrammarUriContexts();
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void pushElement(Grammar updContextGrammar, StartElement se) {
/* 107 */     super.pushElement(updContextGrammar, se);
/* 108 */     if (!this.preservePrefix && this.elementContextStackIndex == 1) {
/*     */ 
/*     */       
/* 111 */       GrammarContext gc = this.grammar.getGrammarContext();
/* 112 */       for (int i = 2; i < gc.getNumberOfGrammarUriContexts(); i++) {
/* 113 */         GrammarUriContext guc = gc.getGrammarUriContext(i);
/* 114 */         String pfx = guc.getDefaultPrefix();
/* 115 */         declarePrefix(pfx, guc.getNamespaceUri());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initForEachRun() throws EXIException, IOException {
/* 122 */     super.initForEachRun();
/*     */     
/* 124 */     this.stringDecoder.clear();
/* 125 */     if (this.exiFactory.getSharedStrings() != null) {
/* 126 */       this.stringDecoder.setSharedStrings(this.exiFactory.getSharedStrings());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected QNameContext decodeQName(DecoderChannel channel) throws IOException {
/* 133 */     return decodeLocalName(decodeUri(channel), channel);
/*     */   }
/*     */   
/*     */   protected AbstractEXIBodyCoder.RuntimeUriContext decodeUri(DecoderChannel channel) throws IOException {
/*     */     AbstractEXIBodyCoder.RuntimeUriContext uc;
/* 138 */     int numberBitsUri = MethodsBag.getCodingLength(getNumberOfUris() + 1);
/* 139 */     int uriID = channel.decodeNBitUnsignedInteger(numberBitsUri);
/*     */ 
/*     */ 
/*     */     
/* 143 */     if (uriID == 0) {
/*     */ 
/*     */ 
/*     */       
/* 147 */       String uri = new String(channel.decodeString());
/*     */       
/* 149 */       uc = addUri(uri);
/*     */     }
/*     */     else {
/*     */       
/* 153 */       uc = getUri(--uriID);
/*     */     } 
/*     */     
/* 156 */     return uc;
/*     */   }
/*     */ 
/*     */   
/*     */   protected QNameContext decodeLocalName(AbstractEXIBodyCoder.RuntimeUriContext uc, DecoderChannel channel) throws IOException {
/*     */     QNameContext qnc;
/* 162 */     int length = channel.decodeUnsignedInteger();
/*     */ 
/*     */ 
/*     */     
/* 166 */     if (length > 0) {
/*     */ 
/*     */ 
/*     */       
/* 170 */       String localName = new String(channel.decodeStringOnly(length - 1));
/*     */ 
/*     */       
/* 173 */       qnc = uc.addQNameContext(localName);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 182 */       int n = MethodsBag.getCodingLength(uc.getNumberOfQNames());
/* 183 */       int localNameID = channel.decodeNBitUnsignedInteger(n);
/* 184 */       qnc = uc.getQNameContext(localNameID);
/*     */     } 
/*     */     
/* 187 */     return qnc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String decodeQNamePrefix(AbstractEXIBodyCoder.RuntimeUriContext uc, DecoderChannel channel) throws IOException {
/* 193 */     String prefix = null;
/*     */     
/* 195 */     if (uc.namespaceUriID == 0) {
/*     */       
/* 197 */       prefix = "";
/*     */     } else {
/* 199 */       int numberOfPrefixes = uc.getNumberOfPrefixes();
/* 200 */       if (numberOfPrefixes > 0) {
/* 201 */         int id = 0;
/* 202 */         if (numberOfPrefixes > 1) {
/* 203 */           id = channel.decodeNBitUnsignedInteger(
/* 204 */               MethodsBag.getCodingLength(numberOfPrefixes));
/*     */         }
/*     */         
/* 207 */         prefix = uc.getPrefix(id);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     return prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String decodeNamespacePrefix(AbstractEXIBodyCoder.RuntimeUriContext uc, DecoderChannel channel) throws IOException {
/*     */     String prefix;
/* 222 */     int nPfx = MethodsBag.getCodingLength(uc.getNumberOfPrefixes() + 1);
/* 223 */     int pfxID = channel.decodeNBitUnsignedInteger(nPfx);
/*     */     
/* 225 */     if (pfxID == 0) {
/*     */ 
/*     */ 
/*     */       
/* 229 */       prefix = new String(channel.decodeString());
/*     */       
/* 231 */       uc.addPrefix(prefix);
/*     */     }
/*     */     else {
/*     */       
/* 235 */       prefix = uc.getPrefix(pfxID - 1);
/*     */     } 
/*     */     
/* 238 */     return prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final EventType decodeEventCode() throws EXIException, IOException {
/* 244 */     Grammar currentGrammar = getCurrentGrammar();
/*     */     
/* 246 */     int codeLength = this.fidelityOptions.get1stLevelEventCodeLength(currentGrammar);
/* 247 */     int ec = this.channel.decodeNBitUnsignedInteger(codeLength);
/*     */     
/* 249 */     assert ec >= 0;
/*     */     
/* 251 */     if (ec < currentGrammar.getNumberOfEvents()) {
/*     */       
/* 253 */       Production ei = currentGrammar.getProduction(ec);
/* 254 */       this.nextEvent = ei.getEvent();
/* 255 */       this.nextGrammar = ei.getNextGrammar();
/* 256 */       this.nextEventType = this.nextEvent.getEventType();
/*     */     } else {
/*     */       
/* 259 */       int ec2 = decode2ndLevelEventCode();
/*     */       
/* 261 */       if (ec2 == -1) {
/*     */         
/* 263 */         int ec3 = decode3rdLevelEventCode();
/* 264 */         this.nextEventType = this.fidelityOptions.get3rdLevelEventType(ec3);
/*     */ 
/*     */         
/* 267 */         this.nextEvent = null;
/* 268 */         this.nextGrammar = null;
/*     */       } else {
/* 270 */         this.nextEventType = this.fidelityOptions.get2ndLevelEventType(ec2, currentGrammar);
/*     */ 
/*     */         
/* 273 */         if (this.nextEventType == EventType.ATTRIBUTE_INVALID_VALUE) {
/* 274 */           updateInvalidValueAttribute(ec);
/*     */         } else {
/*     */           
/* 277 */           this.nextEvent = null;
/* 278 */           this.nextGrammar = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 283 */     return this.nextEventType;
/*     */   }
/*     */   
/*     */   public String getAttributePrefix() {
/* 287 */     return this.attributePrefix;
/*     */   }
/*     */   
/*     */   public String getAttributeQNameAsString() {
/* 291 */     if (this.preservePrefix) {
/* 292 */       return QNameUtilities.getQualifiedName(this.attributeQNameContext
/* 293 */           .getLocalName(), this.attributePrefix);
/*     */     }
/* 295 */     return this.attributeQNameContext.getDefaultQNameAsString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Value getAttributeValue() {
/* 300 */     return this.attributeValue;
/*     */   }
/*     */   protected void updateInvalidValueAttribute(int ec) throws EXIException {
/*     */     int ec3AT;
/* 304 */     SchemaInformedGrammar sir = (SchemaInformedGrammar)getCurrentGrammar();
/*     */ 
/*     */     
/*     */     try {
/* 308 */       ec3AT = this.channel.decodeNBitUnsignedInteger(
/* 309 */           MethodsBag.getCodingLength(sir.getNumberOfDeclaredAttributes() + 1));
/* 310 */     } catch (IOException e) {
/* 311 */       throw new EXIException(e);
/*     */     } 
/*     */     
/* 314 */     if (ec3AT < sir.getNumberOfDeclaredAttributes()) {
/*     */       
/* 316 */       ec = ec3AT + sir.getLeastAttributeEventCode();
/* 317 */       Production ei = sir.getProduction(ec);
/* 318 */       this.nextEvent = ei.getEvent();
/* 319 */       this.nextGrammar = ei.getNextGrammar();
/* 320 */     } else if (ec3AT == sir.getNumberOfDeclaredAttributes()) {
/*     */       
/* 322 */       this.nextEventType = EventType.ATTRIBUTE_ANY_INVALID_VALUE;
/*     */     } else {
/* 324 */       throw new EXIException("Error occured while decoding deviated attribute");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int decode2ndLevelEventCode() throws EXIException, IOException {
/* 330 */     Grammar currentGrammar = getCurrentGrammar();
/*     */     
/* 332 */     int ch2 = this.fidelityOptions.get2ndLevelCharacteristics(currentGrammar);
/* 333 */     int level2 = this.channel.decodeNBitUnsignedInteger(
/* 334 */         MethodsBag.getCodingLength(ch2));
/*     */     
/* 336 */     int ch3 = this.fidelityOptions.get3rdLevelCharacteristics();
/*     */     
/* 338 */     if (ch3 > 0) {
/* 339 */       return (level2 < ch2 - 1) ? level2 : -1;
/*     */     }
/* 341 */     return (level2 < ch2) ? level2 : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int decode3rdLevelEventCode() throws EXIException, IOException {
/* 346 */     int ch3 = this.fidelityOptions.get3rdLevelCharacteristics();
/*     */     
/* 348 */     return this.channel.decodeNBitUnsignedInteger(
/* 349 */         MethodsBag.getCodingLength(ch3));
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void decodeStartDocumentStructure() throws EXIException {
/* 354 */     updateCurrentRule(getCurrentGrammar().getProduction(0).getNextGrammar());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void decodeEndDocumentStructure() throws EXIException, IOException {
/* 360 */     if (this.limitGrammarLearning && 
/* 361 */       this.maxBuiltInElementGrammars != -1) {
/*     */       
/* 363 */       int evolvedGrs = 0;
/*     */ 
/*     */       
/* 366 */       Iterator<StartElement> iterSEs = this.runtimeGlobalElements.values().iterator();
/* 367 */       while (iterSEs.hasNext()) {
/* 368 */         StartElement se = iterSEs.next();
/* 369 */         Grammar stg = se.getGrammar();
/* 370 */         assert stg.getGrammarType() == GrammarType.BUILT_IN_START_TAG_CONTENT;
/* 371 */         Grammar ecg = stg.getElementContentGrammar();
/* 372 */         assert ecg.getGrammarType() == GrammarType.BUILT_IN_ELEMENT_CONTENT;
/*     */         
/* 374 */         if (ecg.getNumberOfEvents() != 1) {
/*     */           
/* 376 */           evolvedGrs++; continue;
/*     */         } 
/* 378 */         if (stg.getNumberOfEvents() > 1) {
/* 379 */           evolvedGrs++; continue;
/* 380 */         }  if (stg.getNumberOfEvents() == 1)
/*     */         {
/* 382 */           if (!isBuiltInStartTagGrammarWithAtXsiTypeOnly(stg)) {
/* 383 */             evolvedGrs++;
/*     */           }
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 389 */       if (evolvedGrs > this.maxBuiltInElementGrammars) {
/* 390 */         throw new RuntimeException("EXI profile stream does not respect parameter maxBuiltInElementGrammars. Expected " + this.maxBuiltInElementGrammars + " but was " + evolvedGrs);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final QNameContext decodeStartElementStructure() throws IOException {
/* 448 */     assert this.nextEventType == EventType.START_ELEMENT;
/*     */     
/* 450 */     StartElement se = (StartElement)this.nextEvent;
/*     */     
/* 452 */     pushElement(this.nextGrammar, se);
/*     */     
/* 454 */     QNameContext qnc = se.getQNameContext();
/* 455 */     handleElementPrefix(qnc);
/*     */     
/* 457 */     return qnc;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final QNameContext decodeStartElementNSStructure() throws IOException {
/* 462 */     assert this.nextEventType == EventType.START_ELEMENT_NS;
/*     */     
/* 464 */     StartElementNS seNS = (StartElementNS)this.nextEvent;
/*     */     
/* 466 */     AbstractEXIBodyCoder.RuntimeUriContext uc = getUri(seNS.getNamespaceUriID());
/* 467 */     QNameContext qnc = decodeLocalName(uc, this.channel);
/*     */ 
/*     */     
/* 470 */     StartElement nextSE = getGlobalStartElement(qnc);
/*     */ 
/*     */     
/* 473 */     pushElement(this.nextGrammar, nextSE);
/*     */     
/* 475 */     handleElementPrefix(qnc);
/*     */     
/* 477 */     return qnc;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final QNameContext decodeStartElementGenericStructure() throws IOException {
/* 482 */     assert this.nextEventType == EventType.START_ELEMENT_GENERIC;
/*     */     
/* 484 */     QNameContext qnc = decodeQName(this.channel);
/*     */ 
/*     */     
/* 487 */     StartElement nextSE = getGlobalStartElement(qnc);
/*     */ 
/*     */     
/* 490 */     getCurrentGrammar().learnStartElement(nextSE);
/*     */     
/* 492 */     pushElement(this.nextGrammar.getElementContentGrammar(), nextSE);
/*     */ 
/*     */     
/* 495 */     handleElementPrefix(qnc);
/*     */     
/* 497 */     return qnc;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final QNameContext decodeStartElementGenericUndeclaredStructure() throws IOException {
/* 502 */     assert this.nextEventType == EventType.START_ELEMENT_GENERIC_UNDECLARED;
/*     */     
/* 504 */     QNameContext qnc = decodeQName(this.channel);
/*     */ 
/*     */     
/* 507 */     StartElement nextSE = getGlobalStartElement(qnc);
/*     */ 
/*     */     
/* 510 */     Grammar currentGrammar = getCurrentGrammar();
/* 511 */     currentGrammar.learnStartElement(nextSE);
/*     */ 
/*     */     
/* 514 */     pushElement(currentGrammar.getElementContentGrammar(), nextSE);
/*     */ 
/*     */     
/* 517 */     handleElementPrefix(qnc);
/*     */     
/* 519 */     return qnc;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final AbstractEXIBodyCoder.ElementContext decodeEndElementStructure() throws EXIException, IOException {
/* 524 */     return popElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AbstractEXIBodyCoder.ElementContext decodeEndElementUndeclaredStructure() throws EXIException, IOException {
/* 530 */     getCurrentGrammar().learnEndElement();
/*     */     
/* 532 */     return popElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void decodeAttributeXsiNilStructure() throws EXIException, IOException {
/* 540 */     this.attributeQNameContext = getXsiNilContext();
/*     */     
/* 542 */     handleAttributePrefix(this.attributeQNameContext);
/*     */     
/* 544 */     if (this.preserveLexicalValues) {
/*     */       
/* 546 */       this.attributeValue = this.typeDecoder.readValue((Datatype)this.booleanDatatype, 
/* 547 */           getXsiNilContext(), this.channel, this.stringDecoder);
/*     */     } else {
/*     */       
/* 550 */       this.attributeValue = (Value)this.channel.decodeBooleanValue();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 555 */     boolean xsiNil = false;
/*     */     
/* 557 */     if (this.attributeValue instanceof BooleanValue) {
/* 558 */       BooleanValue bv = (BooleanValue)this.attributeValue;
/* 559 */       xsiNil = bv.toBoolean();
/*     */     
/*     */     }
/* 562 */     else if (this.attributeValue instanceof BooleanValue) {
/* 563 */       xsiNil = ((BooleanValue)this.attributeValue).toBoolean();
/*     */     } else {
/* 565 */       BooleanValue bv = BooleanValue.parse(this.attributeValue.toString());
/* 566 */       if (bv != null) {
/* 567 */         xsiNil = bv.toBoolean();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 574 */     Grammar currentGrammar = getCurrentGrammar();
/* 575 */     if (xsiNil && currentGrammar.isSchemaInformed())
/*     */     {
/* 577 */       updateCurrentRule((Grammar)((SchemaInformedFirstStartTagGrammar)currentGrammar)
/* 578 */           .getTypeEmpty());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void decodeAttributeXsiTypeStructure() throws EXIException, IOException {
/* 587 */     this.attributeQNameContext = getXsiTypeContext();
/*     */     
/* 589 */     handleAttributePrefix(this.attributeQNameContext);
/*     */     
/* 591 */     QNameContext qncType = null;
/*     */ 
/*     */     
/* 594 */     if (this.preserveLexicalValues) {
/*     */       
/* 596 */       this.attributeValue = this.typeDecoder.readValue(
/* 597 */           BuiltIn.getDefaultDatatype(), getXsiTypeContext(), this.channel, this.stringDecoder);
/*     */       
/* 599 */       String sType = this.attributeValue.toString();
/*     */       
/* 601 */       String qncTypePrefix = QNameUtilities.getPrefixPart(sType);
/*     */ 
/*     */       
/* 604 */       String qnameURI = getURI(qncTypePrefix);
/*     */       
/* 606 */       AbstractEXIBodyCoder.RuntimeUriContext uc = getUri(qnameURI);
/* 607 */       if (uc != null) {
/*     */         
/* 609 */         String qnameLocalName = QNameUtilities.getLocalPart(sType);
/* 610 */         qncType = uc.getQNameContext(qnameLocalName);
/*     */       } 
/*     */     } else {
/*     */       String qncTypePrefix;
/* 614 */       qncType = decodeQName(this.channel);
/*     */       
/* 616 */       if (this.preservePrefix) {
/* 617 */         qncTypePrefix = decodeQNamePrefix(
/* 618 */             getUri(qncType.getNamespaceUriID()), this.channel);
/*     */       } else {
/* 620 */         checkDefaultPrefixNamespaceDeclaration(qncType);
/* 621 */         qncTypePrefix = qncType.getDefaultPrefix();
/*     */       } 
/* 623 */       this
/* 624 */         .attributeValue = (Value)new QNameValue(qncType.getNamespaceUri(), qncType.getLocalName(), qncTypePrefix);
/*     */     } 
/*     */ 
/*     */     
/* 628 */     if (qncType != null && qncType.getTypeGrammar() != null)
/*     */     {
/* 630 */       updateCurrentRule((Grammar)qncType.getTypeGrammar());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void handleElementPrefix(QNameContext qnc) throws IOException {
/*     */     String pfx;
/* 637 */     if (this.preservePrefix) {
/* 638 */       pfx = decodeQNamePrefix(getUri(qnc.getNamespaceUriID()), this.channel);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 643 */       checkDefaultPrefixNamespaceDeclaration(qnc);
/* 644 */       pfx = qnc.getDefaultPrefix();
/*     */     } 
/* 646 */     getElementContext().setPrefix(pfx);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void handleAttributePrefix(QNameContext qnc) throws IOException {
/* 651 */     if (this.preservePrefix) {
/* 652 */       this.attributePrefix = decodeQNamePrefix(
/* 653 */           getUri(qnc.getNamespaceUriID()), this.channel);
/*     */     } else {
/* 655 */       checkDefaultPrefixNamespaceDeclaration(qnc);
/* 656 */       this.attributePrefix = qnc.getDefaultPrefix();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void checkDefaultPrefixNamespaceDeclaration(QNameContext qnc) {
/* 661 */     assert !this.preservePrefix;
/*     */     
/* 663 */     if (qnc.getNamespaceUriID() >= this.numberOfUriContexts) {
/*     */ 
/*     */ 
/*     */       
/* 667 */       String uri = qnc.getNamespaceUri();
/* 668 */       String pfx = getPrefix(uri);
/*     */       
/* 670 */       if (pfx == null) {
/* 671 */         pfx = qnc.getDefaultPrefix();
/* 672 */         declarePrefix(pfx, uri);
/*     */       } 
/*     */       
/* 675 */       assert qnc.getDefaultPrefix().equals(pfx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final Datatype decodeAttributeStructure() throws EXIException, IOException {
/* 681 */     Attribute at = (Attribute)this.nextEvent;
/*     */     
/* 683 */     this.attributeQNameContext = at.getQNameContext();
/*     */     
/* 685 */     handleAttributePrefix(this.attributeQNameContext);
/*     */ 
/*     */     
/* 688 */     updateCurrentRule(this.nextGrammar);
/*     */     
/* 690 */     return at.getDatatype();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void decodeAttributeNSStructure() throws EXIException, IOException {
/* 696 */     AttributeNS atNS = (AttributeNS)this.nextEvent;
/* 697 */     AbstractEXIBodyCoder.RuntimeUriContext uc = getUri(atNS.getNamespaceUriID());
/* 698 */     this.attributeQNameContext = decodeLocalName(uc, this.channel);
/*     */ 
/*     */     
/* 701 */     handleAttributePrefix(this.attributeQNameContext);
/*     */     
/* 703 */     updateCurrentRule(this.nextGrammar);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void decodeAttributeAnyInvalidValueStructure() throws EXIException, IOException {
/* 708 */     decodeAttributeGenericStructureOnly();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void decodeAttributeGenericStructure() throws EXIException, IOException {
/* 714 */     decodeAttributeGenericStructureOnly();
/*     */ 
/*     */     
/* 717 */     updateCurrentRule(this.nextGrammar);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void decodeAttributeGenericUndeclaredStructure() throws EXIException, IOException {
/* 722 */     decodeAttributeGenericStructureOnly();
/* 723 */     getCurrentGrammar()
/* 724 */       .learnAttribute(new Attribute(this.attributeQNameContext));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final void decodeAttributeGenericStructureOnly() throws EXIException, IOException {
/* 730 */     this.attributeQNameContext = decodeQName(this.channel);
/*     */ 
/*     */     
/* 733 */     handleAttributePrefix(this.attributeQNameContext);
/*     */   }
/*     */   
/*     */   protected final Datatype decodeCharactersStructure() throws EXIException {
/* 737 */     assert this.nextEventType == EventType.CHARACTERS;
/*     */     
/* 739 */     updateCurrentRule(this.nextGrammar);
/* 740 */     return ((Characters)this.nextEvent).getDatatype();
/*     */   }
/*     */   
/*     */   protected final void decodeCharactersGenericStructure() throws EXIException {
/* 744 */     assert this.nextEventType == EventType.CHARACTERS_GENERIC;
/*     */     
/* 746 */     updateCurrentRule(this.nextGrammar);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void decodeCharactersGenericUndeclaredStructure() throws EXIException {
/* 751 */     assert this.nextEventType == EventType.CHARACTERS_GENERIC_UNDECLARED;
/*     */     
/* 753 */     Grammar currentGrammar = getCurrentGrammar();
/* 754 */     currentGrammar.learnCharacters();
/*     */     
/* 756 */     updateCurrentRule(currentGrammar.getElementContentGrammar());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final NamespaceDeclaration decodeNamespaceDeclarationStructure() throws EXIException, IOException {
/* 762 */     AbstractEXIBodyCoder.RuntimeUriContext euc = decodeUri(this.channel);
/* 763 */     String nsPrefix = decodeNamespacePrefix(euc, this.channel);
/*     */     
/* 765 */     boolean local_element_ns = this.channel.decodeBoolean();
/* 766 */     if (local_element_ns) {
/* 767 */       getElementContext().setPrefix(nsPrefix);
/*     */     }
/*     */ 
/*     */     
/* 771 */     NamespaceDeclaration nsDecl = new NamespaceDeclaration(euc.getNamespaceUri(), nsPrefix);
/* 772 */     declarePrefix(nsDecl);
/* 773 */     return nsDecl;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final char[] decodeEntityReferenceStructure() throws EXIException, IOException {
/* 779 */     char[] er = this.channel.decodeString();
/*     */     
/* 781 */     updateCurrentRule(getCurrentGrammar().getElementContentGrammar());
/* 782 */     return er;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final char[] decodeCommentStructure() throws EXIException, IOException {
/* 787 */     char[] comment = this.channel.decodeString();
/*     */     
/* 789 */     updateCurrentRule(getCurrentGrammar().getElementContentGrammar());
/* 790 */     return comment;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ProcessingInstruction decodeProcessingInstructionStructure() throws EXIException, IOException {
/* 796 */     String piTarget = new String(this.channel.decodeString());
/* 797 */     String piData = new String(this.channel.decodeString());
/*     */     
/* 799 */     updateCurrentRule(getCurrentGrammar().getElementContentGrammar());
/* 800 */     return new ProcessingInstruction(piTarget, piData);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final DocType decodeDocTypeStructure() throws EXIException, IOException {
/* 806 */     char[] name = this.channel.decodeString();
/* 807 */     char[] publicID = this.channel.decodeString();
/* 808 */     char[] systemID = this.channel.decodeString();
/* 809 */     char[] text = this.channel.decodeString();
/* 810 */     return new DocType(name, publicID, systemID, text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeStartSelfContainedFragment() throws EXIException, IOException {
/* 817 */     throw new RuntimeException("[EXI] SelfContained");
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\AbstractEXIBodyDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */