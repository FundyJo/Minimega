package com.siemens.ct.exi.core.io.channel;

import com.siemens.ct.exi.core.types.DateTimeType;
import com.siemens.ct.exi.core.values.BooleanValue;
import com.siemens.ct.exi.core.values.DateTimeValue;
import com.siemens.ct.exi.core.values.DecimalValue;
import com.siemens.ct.exi.core.values.FloatValue;
import com.siemens.ct.exi.core.values.IntegerValue;
import java.io.IOException;

public interface DecoderChannel {
  int decode() throws IOException;
  
  void align() throws IOException;
  
  void skip(long paramLong) throws IOException;
  
  int decodeNBitUnsignedInteger(int paramInt) throws IOException;
  
  IntegerValue decodeNBitUnsignedIntegerValue(int paramInt) throws IOException;
  
  boolean decodeBoolean() throws IOException;
  
  BooleanValue decodeBooleanValue() throws IOException;
  
  byte[] decodeBinary() throws IOException;
  
  char[] decodeString() throws IOException;
  
  char[] decodeStringOnly(int paramInt) throws IOException;
  
  int decodeUnsignedInteger() throws IOException;
  
  IntegerValue decodeUnsignedIntegerValue() throws IOException;
  
  IntegerValue decodeIntegerValue() throws IOException;
  
  DecimalValue decodeDecimalValue() throws IOException;
  
  FloatValue decodeFloatValue() throws IOException;
  
  DateTimeValue decodeDateTimeValue(DateTimeType paramDateTimeType) throws IOException;
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\channel\DecoderChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */