/*     */ package com.siemens.ct.exi.core.datatype.strings;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoundedStringEncoderImpl
/*     */   extends StringEncoderImpl
/*     */ {
/*     */   protected final int valueMaxLength;
/*     */   protected final int valuePartitionCapacity;
/*     */   protected int globalID;
/*     */   protected StringEncoderImpl.ValueContainer[] globalIdMapping;
/*     */   
/*     */   public BoundedStringEncoderImpl(boolean localValuePartitions, int valueMaxLength, int valuePartitionCapacity) {
/*  54 */     super(localValuePartitions);
/*  55 */     this.valueMaxLength = valueMaxLength;
/*  56 */     this.valuePartitionCapacity = valuePartitionCapacity;
/*     */     
/*  58 */     this.globalID = -1;
/*  59 */     if (valuePartitionCapacity >= 0)
/*     */     {
/*  61 */       this.globalIdMapping = new StringEncoderImpl.ValueContainer[valuePartitionCapacity];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addValue(QNameContext context, String value) {
/*  68 */     if (this.valueMaxLength < 0 || value.length() <= this.valueMaxLength)
/*     */     {
/*  70 */       if (this.valuePartitionCapacity < 0) {
/*     */         
/*  72 */         super.addValue(context, value);
/*     */       
/*     */       }
/*  75 */       else if (this.valuePartitionCapacity != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  86 */         assert !this.stringValues.containsKey(value);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  94 */         if (++this.globalID == this.valuePartitionCapacity) {
/*  95 */           this.globalID = 0;
/*     */         }
/*     */ 
/*     */         
/*  99 */         StringEncoderImpl.ValueContainer vc = new StringEncoderImpl.ValueContainer(value, context, getNumberOfStringValues(context), this.globalID);
/*     */         
/* 101 */         if (this.stringValues.size() == this.valuePartitionCapacity) {
/*     */           
/* 103 */           StringEncoderImpl.ValueContainer vcFree = this.globalIdMapping[this.globalID];
/*     */ 
/*     */           
/* 106 */           freeStringValue(vcFree.context, vcFree.localValueID);
/*     */ 
/*     */           
/* 109 */           this.stringValues.remove(vcFree.value);
/*     */         } 
/*     */ 
/*     */         
/* 113 */         this.stringValues.put(value, vc);
/*     */ 
/*     */         
/* 116 */         addLocalValue(context, new StringValue(value));
/*     */         
/* 118 */         this.globalIdMapping[this.globalID] = vc;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void freeStringValue(QNameContext qnc, int localValueID) {
/* 124 */     if (this.localValuePartitions) {
/* 125 */       assert this.localValues.get(qnc) != null;
/* 126 */       List<StringValue> lvs = this.localValues.get(qnc);
/* 127 */       assert localValueID < lvs.size();
/* 128 */       assert lvs.get(localValueID) != null;
/* 129 */       lvs.set(localValueID, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 135 */     super.clear();
/* 136 */     this.globalID = -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\strings\BoundedStringEncoderImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */