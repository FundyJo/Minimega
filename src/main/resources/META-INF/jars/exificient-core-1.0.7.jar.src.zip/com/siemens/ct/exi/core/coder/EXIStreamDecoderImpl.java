/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.CodingMode;
/*     */ import com.siemens.ct.exi.core.EXIBodyDecoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EXIStreamDecoder;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.io.channel.BitDecoderChannel;
/*     */ import com.siemens.ct.exi.core.io.channel.DecoderChannel;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIStreamDecoderImpl
/*     */   implements EXIStreamDecoder
/*     */ {
/*     */   protected final EXIHeaderDecoder exiHeader;
/*     */   protected EXIBodyDecoder exiBody;
/*     */   protected final EXIFactory noOptionsFactory;
/*     */   
/*     */   public EXIStreamDecoderImpl(EXIFactory noOptionsFactory) throws EXIException {
/*  66 */     this.exiHeader = new EXIHeaderDecoder();
/*     */     
/*  68 */     this.exiBody = noOptionsFactory.createEXIBodyDecoder();
/*  69 */     this.noOptionsFactory = noOptionsFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public EXIBodyDecoder getBodyOnlyDecoder(InputStream is) throws EXIException, IOException {
/*  74 */     is = checkBufferedAndPushbackStream(is);
/*  75 */     this.exiBody.setInputStream(is);
/*  76 */     return this.exiBody;
/*     */   }
/*     */ 
/*     */   
/*     */   public EXIBodyDecoder decodeHeader(InputStream is) throws EXIException, IOException {
/*  81 */     is = checkBufferedAndPushbackStream(is);
/*     */     
/*  83 */     BitDecoderChannel headerChannel = new BitDecoderChannel(is);
/*     */     
/*  85 */     EXIFactory exiFactory = this.exiHeader.parse(headerChannel, this.noOptionsFactory);
/*     */ 
/*     */     
/*  88 */     if (exiFactory != this.noOptionsFactory)
/*     */     {
/*  90 */       this.exiBody = exiFactory.createEXIBodyDecoder();
/*     */     }
/*     */     
/*  93 */     if (exiFactory.getCodingMode() == CodingMode.BIT_PACKED) {
/*     */       
/*  95 */       this.exiBody.setInputChannel((DecoderChannel)headerChannel);
/*     */     } else {
/*  97 */       this.exiBody.setInputStream(is);
/*     */     } 
/*     */     
/* 100 */     return this.exiBody;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream checkBufferedAndPushbackStream(InputStream is) {
/* 111 */     if (!(is instanceof java.io.PushbackInputStream))
/*     */     {
/* 113 */       if (!(is instanceof BufferedInputStream) && !(is instanceof java.io.ByteArrayInputStream))
/*     */       {
/*     */         
/* 116 */         is = new BufferedInputStream(is);
/*     */       }
/*     */     }
/* 119 */     return is;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIStreamDecoderImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */