/*    */ package com.siemens.ct.exi.core.container;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessingInstruction
/*    */ {
/*    */   public final String target;
/*    */   public final String data;
/*    */   
/*    */   public ProcessingInstruction(String target, String data) {
/* 39 */     this.target = target;
/* 40 */     this.data = data;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\container\ProcessingInstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */