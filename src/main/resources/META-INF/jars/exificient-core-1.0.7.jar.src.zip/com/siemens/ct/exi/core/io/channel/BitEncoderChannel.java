/*     */ package com.siemens.ct.exi.core.io.channel;
/*     */ 
/*     */ import com.siemens.ct.exi.core.io.BitOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitEncoderChannel
/*     */   extends AbstractEncoderChannel
/*     */   implements EncoderChannel
/*     */ {
/*     */   protected BitOutputStream ostream;
/*     */   
/*     */   public BitEncoderChannel(OutputStream ostream) {
/*  53 */     this.ostream = new BitOutputStream(ostream);
/*     */   }
/*     */   
/*     */   public OutputStream getOutputStream() {
/*  57 */     return (OutputStream)this.ostream;
/*     */   }
/*     */   
/*     */   public int getLength() {
/*  61 */     return this.ostream.getLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*  68 */     this.ostream.flush();
/*     */   }
/*     */   
/*     */   public void align() throws IOException {
/*  72 */     this.ostream.align();
/*     */   }
/*     */   
/*     */   public void encode(int b) throws IOException {
/*  76 */     this.ostream.writeBits(b, 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encode(byte[] b, int off, int len) throws IOException {
/*  81 */     for (int i = off; i < off + len; i++) {
/*  82 */       this.ostream.writeBits(b[i], 8);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeNBitUnsignedInteger(int b, int n) throws IOException {
/*  91 */     if (b < 0 || n < 0) {
/*  92 */       throw new IllegalArgumentException("Encode negative value as unsigned integer is invalid!");
/*     */     }
/*     */     
/*  95 */     assert b >= 0;
/*  96 */     assert n >= 0;
/*     */     
/*  98 */     this.ostream.writeBits(b, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBoolean(boolean b) throws IOException {
/* 106 */     if (b) {
/* 107 */       this.ostream.writeBit1();
/*     */     } else {
/* 109 */       this.ostream.writeBit0();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\channel\BitEncoderChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */