package com.siemens.ct.exi.core.datatype.strings;

import com.siemens.ct.exi.core.context.QNameContext;
import com.siemens.ct.exi.core.io.channel.EncoderChannel;
import java.io.IOException;

public interface StringEncoder extends StringCoder {
  void addValue(QNameContext paramQNameContext, String paramString);
  
  void writeValue(QNameContext paramQNameContext, EncoderChannel paramEncoderChannel, String paramString) throws IOException;
  
  boolean isStringHit(String paramString) throws IOException;
  
  StringEncoderImpl.ValueContainer getValueContainer(String paramString);
  
  int getValueContainerSize();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\strings\StringEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */