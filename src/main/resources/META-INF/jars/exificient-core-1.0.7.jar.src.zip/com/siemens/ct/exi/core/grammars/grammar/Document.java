/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Document
/*    */   extends AbstractSchemaInformedGrammar
/*    */ {
/*    */   public Document() {}
/*    */   
/*    */   public Document(String label) {
/* 42 */     this();
/* 43 */     setLabel(label);
/*    */   }
/*    */   
/*    */   public GrammarType getGrammarType() {
/* 47 */     return GrammarType.DOCUMENT;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 51 */     return "Document" + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\Document.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */