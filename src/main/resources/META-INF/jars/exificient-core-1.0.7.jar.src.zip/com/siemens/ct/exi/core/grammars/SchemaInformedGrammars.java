/*     */ package com.siemens.ct.exi.core.grammars;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.GrammarContext;
/*     */ import com.siemens.ct.exi.core.exceptions.UnsupportedOption;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Document;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Fragment;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedGrammar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaInformedGrammars
/*     */   extends AbstractGrammars
/*     */ {
/*     */   protected boolean builtInXMLSchemaTypesOnly = false;
/*     */   protected String schemaId;
/*     */   protected final SchemaInformedGrammar elementFragmentGrammar;
/*     */   
/*     */   public SchemaInformedGrammars(GrammarContext grammarContext, Document document, Fragment fragment, SchemaInformedGrammar elementFragmentGrammar) {
/*  52 */     super(true, grammarContext);
/*     */     
/*  54 */     this.documentGrammar = (Grammar)document;
/*  55 */     this.fragmentGrammar = (Grammar)fragment;
/*  56 */     this.elementFragmentGrammar = elementFragmentGrammar;
/*  57 */     this.schemaId = "";
/*     */   }
/*     */   
/*     */   public void setBuiltInXMLSchemaTypesOnly(boolean builtInXMLSchemaTypesOnly) {
/*  61 */     this.builtInXMLSchemaTypesOnly = builtInXMLSchemaTypesOnly;
/*  62 */     this.schemaId = "";
/*     */   }
/*     */   
/*     */   public final String getSchemaId() {
/*  66 */     return this.schemaId;
/*     */   }
/*     */   
/*     */   public void setSchemaId(String schemaId) throws UnsupportedOption {
/*  70 */     if (this.builtInXMLSchemaTypesOnly && !"".equals(schemaId)) {
/*  71 */       throw new UnsupportedOption("XML Schema types only grammars do have schemaId == '' associated with it.");
/*     */     }
/*     */     
/*  74 */     if (schemaId == null || "".equals(schemaId)) {
/*  75 */       throw new UnsupportedOption("Schema-informed grammars do have schemaId != '' && schemaId != null associated with it.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  80 */     this.schemaId = schemaId;
/*     */   }
/*     */   
/*     */   public boolean isBuiltInXMLSchemaTypesOnly() {
/*  84 */     return this.builtInXMLSchemaTypesOnly;
/*     */   }
/*     */   
/*     */   public Grammar getFragmentGrammar() {
/*  88 */     return this.fragmentGrammar;
/*     */   }
/*     */   
/*     */   public SchemaInformedGrammar getSchemaInformedElementFragmentGrammar() {
/*  92 */     return this.elementFragmentGrammar;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  97 */     if (this == o)
/*  98 */       return true; 
/*  99 */     if (!(o instanceof SchemaInformedGrammars))
/* 100 */       return false; 
/* 101 */     if (!super.equals(o)) {
/* 102 */       return false;
/*     */     }
/* 104 */     SchemaInformedGrammars grammars = (SchemaInformedGrammars)o;
/*     */     
/* 106 */     if (this.builtInXMLSchemaTypesOnly != grammars.builtInXMLSchemaTypesOnly)
/* 107 */       return false; 
/* 108 */     if ((this.schemaId != null) ? !this.schemaId.equals(grammars.schemaId) : (grammars.schemaId != null))
/*     */     {
/* 110 */       return false; } 
/* 111 */     return (this.elementFragmentGrammar != null) ? 
/* 112 */       this.elementFragmentGrammar.equals(grammars.elementFragmentGrammar) : (
/* 113 */       (grammars.elementFragmentGrammar == null));
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\SchemaInformedGrammars.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */