/*     */ package com.siemens.ct.exi.core.datatype.charset;
/*     */ 
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRestrictedCharacterSet
/*     */   implements RestrictedCharacterSet
/*     */ {
/*  63 */   protected Map<Integer, Integer> codeSet = new HashMap<>();
/*  64 */   protected List<Integer> codePointList = new ArrayList<>();
/*     */   protected int size;
/*     */   
/*     */   public int getCodePoint(int code) {
/*  68 */     return ((Integer)this.codePointList.get(code)).intValue();
/*     */   }
/*     */   protected int codingLength;
/*     */   public int getCode(int codePoint) {
/*  72 */     Integer code = this.codeSet.get(Integer.valueOf(codePoint));
/*     */     
/*  74 */     return (code == null) ? -1 : code.intValue();
/*     */   }
/*     */   
/*     */   public int size() {
/*  78 */     return this.size;
/*     */   }
/*     */   
/*     */   public int getCodingLength() {
/*  82 */     return this.codingLength;
/*     */   }
/*     */   
/*     */   protected void addValue(int codePoint) {
/*  86 */     this.codeSet.put(Integer.valueOf(codePoint), Integer.valueOf(this.codeSet.size()));
/*  87 */     this.codePointList.add(Integer.valueOf(codePoint));
/*     */ 
/*     */     
/*  90 */     assert this.codeSet.size() == this.codePointList.size();
/*  91 */     this.size = this.codeSet.size();
/*  92 */     this.codingLength = MethodsBag.getCodingLength(this.size + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  97 */     if (o instanceof AbstractRestrictedCharacterSet) {
/*  98 */       AbstractRestrictedCharacterSet other = (AbstractRestrictedCharacterSet)o;
/*  99 */       if (size() == other.size()) {
/* 100 */         for (int code = 0; code < size(); code++) {
/* 101 */           if (getCodePoint(code) != other.getCodePoint(code)) {
/* 102 */             return false;
/*     */           }
/*     */         } 
/* 105 */         return true;
/*     */       } 
/*     */     } 
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 113 */     return this.codeSet.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 118 */     return this.codePointList.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\charset\AbstractRestrictedCharacterSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */