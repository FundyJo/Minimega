/*    */ package com.siemens.ct.exi.core.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLParsingException
/*    */   extends EXIException
/*    */ {
/*    */   private static final long serialVersionUID = -1568757949406610062L;
/*    */   
/*    */   public XMLParsingException(String message) {
/* 42 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\exceptions\XMLParsingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */