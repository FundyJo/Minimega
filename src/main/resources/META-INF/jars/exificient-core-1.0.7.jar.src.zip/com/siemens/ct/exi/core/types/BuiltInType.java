/*    */ package com.siemens.ct.exi.core.types;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BuiltInType
/*    */ {
/* 43 */   BINARY_BASE64,
/*    */ 
/*    */   
/* 46 */   BINARY_HEX,
/*    */ 
/*    */   
/* 49 */   BOOLEAN,
/*    */ 
/*    */   
/* 52 */   BOOLEAN_FACET,
/*    */ 
/*    */   
/* 55 */   DECIMAL,
/*    */ 
/*    */   
/* 58 */   FLOAT,
/*    */ 
/*    */   
/* 61 */   NBIT_UNSIGNED_INTEGER,
/*    */ 
/*    */   
/* 64 */   UNSIGNED_INTEGER,
/*    */ 
/*    */   
/* 67 */   INTEGER,
/*    */ 
/*    */   
/* 70 */   DATETIME,
/*    */ 
/*    */   
/* 73 */   STRING,
/*    */ 
/*    */   
/* 76 */   RCS_STRING,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   EXTENDED_STRING,
/*    */ 
/*    */   
/* 85 */   ENUMERATION,
/*    */ 
/*    */   
/* 88 */   LIST,
/*    */ 
/*    */   
/* 91 */   QNAME;
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\BuiltInType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */