/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchemaInformedElement
/*    */   extends AbstractSchemaInformedContent
/*    */   implements Cloneable
/*    */ {
/*    */   public GrammarType getGrammarType() {
/* 48 */     return GrammarType.SCHEMA_INFORMED_ELEMENT_CONTENT;
/*    */   }
/*    */ 
/*    */   
/*    */   public SchemaInformedElement clone() {
/* 53 */     SchemaInformedElement clone = (SchemaInformedElement)super.clone();
/* 54 */     return clone;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 58 */     return "Element" + super.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 63 */     return (obj instanceof SchemaInformedElement && super.equals(obj));
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\SchemaInformedElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */