/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ import com.siemens.ct.exi.core.grammars.event.EndDocument;
/*    */ import com.siemens.ct.exi.core.grammars.event.Event;
/*    */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuiltInFragmentContent
/*    */   extends AbstractBuiltInGrammar
/*    */ {
/*    */   public BuiltInFragmentContent() {
/* 53 */     addTerminalProduction((Event)new EndDocument());
/*    */     
/* 55 */     addProduction(START_ELEMENT_GENERIC, this);
/*    */   }
/*    */   
/*    */   public GrammarType getGrammarType() {
/* 59 */     return GrammarType.BUILT_IN_FRAGMENT_CONTENT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void learnStartElement(StartElement se) {
/* 68 */     if (!contains((Event)se))
/*    */     {
/* 70 */       addProduction((Event)se, this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\BuiltInFragmentContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */