/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.types.BuiltInType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringDatatype
/*    */   extends AbstractDatatype
/*    */ {
/*    */   protected final boolean isDerivedByUnion;
/*    */   
/*    */   public StringDatatype(QNameContext schemaType) {
/* 42 */     this(schemaType, WhiteSpace.preserve);
/*    */   }
/*    */   
/*    */   public StringDatatype(QNameContext schemaType, WhiteSpace whiteSpace) {
/* 46 */     this(schemaType, false);
/*    */     
/* 48 */     this.whiteSpace = whiteSpace;
/*    */   }
/*    */   
/*    */   public DatatypeID getDatatypeID() {
/* 52 */     return DatatypeID.exi_string;
/*    */   }
/*    */   
/*    */   public StringDatatype(QNameContext schemaType, boolean isDerivedByUnion) {
/* 56 */     super(BuiltInType.STRING, schemaType);
/* 57 */     this.isDerivedByUnion = isDerivedByUnion;
/*    */   }
/*    */   
/*    */   public boolean isDerivedByUnion() {
/* 61 */     return this.isDerivedByUnion;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\StringDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */