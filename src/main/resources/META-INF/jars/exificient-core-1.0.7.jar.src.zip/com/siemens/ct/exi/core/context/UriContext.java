package com.siemens.ct.exi.core.context;

public interface UriContext {
  int getNamespaceUriID();
  
  String getNamespaceUri();
  
  int getNumberOfQNames();
  
  int getNumberOfPrefixes();
  
  String getPrefix(int paramInt);
  
  int getPrefixID(String paramString);
  
  QNameContext getQNameContext(int paramInt);
  
  QNameContext getQNameContext(String paramString);
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\context\UriContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */