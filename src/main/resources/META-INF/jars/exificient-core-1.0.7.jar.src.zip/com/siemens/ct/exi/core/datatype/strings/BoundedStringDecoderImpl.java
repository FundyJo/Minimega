/*     */ package com.siemens.ct.exi.core.datatype.strings;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoundedStringDecoderImpl
/*     */   extends StringDecoderImpl
/*     */ {
/*     */   protected final int valueMaxLength;
/*     */   protected final int valuePartitionCapacity;
/*     */   protected int globalID;
/*     */   protected LocalIDMap[] localIdMapping;
/*     */   
/*     */   static class LocalIDMap
/*     */   {
/*     */     final int localID;
/*     */     final QNameContext context;
/*     */     
/*     */     public LocalIDMap(int localID, QNameContext context) {
/*  56 */       this.localID = localID;
/*  57 */       this.context = context;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public BoundedStringDecoderImpl(boolean localValuePartitions, int valueMaxLength, int valuePartitionCapacity) {
/*  63 */     super(localValuePartitions);
/*  64 */     this.valueMaxLength = valueMaxLength;
/*  65 */     this.valuePartitionCapacity = valuePartitionCapacity;
/*     */     
/*  67 */     this.globalID = -1;
/*  68 */     if (valuePartitionCapacity > 0 && localValuePartitions) {
/*  69 */       this.localIdMapping = new LocalIDMap[valuePartitionCapacity];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addValue(QNameContext context, StringValue value) {
/*  76 */     if (this.valueMaxLength < 0 || value.getCharactersLength() <= this.valueMaxLength)
/*     */     {
/*  78 */       if (this.valuePartitionCapacity < 0) {
/*     */         
/*  80 */         super.addValue(context, value);
/*     */       
/*     */       }
/*  83 */       else if (this.valuePartitionCapacity != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  94 */         assert !this.globalValues.contains(value);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 102 */         if (++this.globalID == this.valuePartitionCapacity) {
/* 103 */           this.globalID = 0;
/*     */         }
/*     */         
/* 106 */         if (this.globalValues.size() > this.globalID) {
/* 107 */           Value prev = (Value)this.globalValues.set(this.globalID, value);
/* 108 */           if (prev != null)
/*     */           {
/* 110 */             if (this.localValuePartitions) {
/* 111 */               LocalIDMap lvsFree = this.localIdMapping[this.globalID];
/* 112 */               assert lvsFree != null;
/*     */             } 
/*     */           }
/*     */         } else {
/* 116 */           assert !this.globalValues.contains(value);
/* 117 */           this.globalValues.add(value);
/*     */         } 
/*     */         
/* 120 */         if (this.localValuePartitions) {
/*     */           
/* 122 */           this.localIdMapping[this.globalID] = new LocalIDMap(
/* 123 */               getNumberOfStringValues(context), context);
/*     */ 
/*     */           
/* 126 */           addLocalValue(context, value);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 134 */     super.clear();
/* 135 */     this.globalID = -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\strings\BoundedStringDecoderImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */