/*     */ package com.siemens.ct.exi.core.grammars.grammar;
/*     */ 
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.EndElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElementGeneric;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGrammar
/*     */   implements Grammar
/*     */ {
/*  49 */   protected static final SchemaInformedGrammar END_RULE = new SchemaInformedElement();
/*     */   static {
/*  51 */     END_RULE.setLabel("<END>");
/*     */   }
/*     */   
/*  54 */   protected static final Event START_ELEMENT_GENERIC = (Event)new StartElementGeneric();
/*  55 */   protected static final Event END_ELEMENT = (Event)new EndElement();
/*     */   
/*  57 */   protected String label = null;
/*     */ 
/*     */   
/*  60 */   protected int stopLearningContainerSize = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractGrammar(String label) {
/*  66 */     this();
/*  67 */     this.label = label;
/*     */   }
/*     */   
/*     */   public void addTerminalProduction(Event event) {
/*  71 */     assert event.isEventType(EventType.END_ELEMENT) || event
/*  72 */       .isEventType(EventType.END_DOCUMENT);
/*     */     
/*  74 */     addProduction(event, END_RULE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void learnStartElement(StartElement se) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void learnEndElement() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void learnAttribute(Attribute at) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void learnCharacters() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopLearning() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int learningStopped() {
/* 100 */     return this.stopLearningContainerSize;
/*     */   }
/*     */   
/*     */   public void setLabel(String label) {
/* 104 */     this.label = label;
/*     */   }
/*     */   
/*     */   public String getLabel() {
/* 108 */     if (this.label != null && !this.label.equals("")) {
/* 109 */       return this.label;
/*     */     }
/* 111 */     return getClass().getName() + "[" + hashCode() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getEventCode(EventType eventType, List<EventType> events) {
/* 117 */     for (int i = 0; i < events.size(); i++) {
/* 118 */       if (((EventType)events.get(i)).equals(eventType)) {
/* 119 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 123 */     return -1;
/*     */   }
/*     */   
/*     */   public Grammar getElementContentGrammar() {
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 132 */     if (this == obj)
/* 133 */       return true; 
/* 134 */     if (obj instanceof Grammar) {
/* 135 */       Grammar gr = (Grammar)obj;
/*     */       
/* 137 */       int numberOfEvents = gr.getNumberOfEvents();
/*     */       
/* 139 */       if (getNumberOfEvents() == numberOfEvents) {
/* 140 */         for (int i = 0; i < numberOfEvents; i++) {
/* 141 */           Production ei = gr.getProduction(i);
/*     */           
/* 143 */           if (!ei.getEvent().equals(getProduction(i).getEvent())) {
/* 144 */             return false;
/*     */           }
/*     */         } 
/*     */         
/* 148 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 152 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 156 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean checkQualifiedName(QName c, String namespaceURI, String localName) {
/* 161 */     return (c.getLocalPart().equals(localName) && c.getNamespaceURI()
/* 162 */       .equals(namespaceURI));
/*     */   }
/*     */   
/*     */   public AbstractGrammar() {}
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\AbstractGrammar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */