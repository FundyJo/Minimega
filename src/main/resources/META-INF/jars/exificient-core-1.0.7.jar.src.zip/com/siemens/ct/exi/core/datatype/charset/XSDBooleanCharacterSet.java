/*    */ package com.siemens.ct.exi.core.datatype.charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XSDBooleanCharacterSet
/*    */   extends AbstractRestrictedCharacterSet
/*    */ {
/*    */   public XSDBooleanCharacterSet() {
/* 45 */     addValue(9);
/* 46 */     addValue(10);
/* 47 */     addValue(13);
/* 48 */     addValue(32);
/*    */     
/* 50 */     addValue(48);
/* 51 */     addValue(49);
/*    */     
/* 53 */     addValue(97);
/* 54 */     addValue(101);
/* 55 */     addValue(102);
/* 56 */     addValue(108);
/* 57 */     addValue(114);
/* 58 */     addValue(115);
/* 59 */     addValue(116);
/* 60 */     addValue(117);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\charset\XSDBooleanCharacterSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */