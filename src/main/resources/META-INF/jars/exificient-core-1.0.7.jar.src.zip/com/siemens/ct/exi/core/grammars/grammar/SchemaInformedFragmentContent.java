/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchemaInformedFragmentContent
/*    */   extends AbstractSchemaInformedGrammar
/*    */ {
/*    */   public SchemaInformedFragmentContent() {}
/*    */   
/*    */   public SchemaInformedFragmentContent(String label) {
/* 49 */     this();
/* 50 */     setLabel(label);
/*    */   }
/*    */   
/*    */   public GrammarType getGrammarType() {
/* 54 */     return GrammarType.SCHEMA_INFORMED_FRAGMENT_CONTENT;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 58 */     return "FragmentContent" + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\SchemaInformedFragmentContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */