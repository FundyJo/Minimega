/*    */ package com.siemens.ct.exi.core.datatype.charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XSDDecimalCharacterSet
/*    */   extends AbstractRestrictedCharacterSet
/*    */ {
/*    */   public XSDDecimalCharacterSet() {
/* 45 */     addValue(9);
/* 46 */     addValue(10);
/* 47 */     addValue(13);
/* 48 */     addValue(32);
/*    */     
/* 50 */     addValue(43);
/* 51 */     addValue(45);
/* 52 */     addValue(46);
/*    */     
/* 54 */     for (int i = 48; i <= 57; i++)
/* 55 */       addValue((char)i); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\charset\XSDDecimalCharacterSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */