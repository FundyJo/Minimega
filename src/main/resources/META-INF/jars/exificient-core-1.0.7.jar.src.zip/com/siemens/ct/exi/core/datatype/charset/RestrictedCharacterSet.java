package com.siemens.ct.exi.core.datatype.charset;

public interface RestrictedCharacterSet {
  int getCodePoint(int paramInt);
  
  int getCode(int paramInt);
  
  int size();
  
  int getCodingLength();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\charset\RestrictedCharacterSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */