/*    */ package com.siemens.ct.exi.core.grammars.event;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartElement
/*    */   extends AbstractEvent
/*    */ {
/*    */   protected final QName qname;
/*    */   protected final QNameContext qnameContext;
/*    */   private Grammar grammar;
/*    */   
/*    */   public StartElement(QNameContext qnc) {
/* 46 */     super(EventType.START_ELEMENT);
/* 47 */     this.qnameContext = qnc;
/* 48 */     this.qname = this.qnameContext.getQName();
/*    */   }
/*    */   
/*    */   public StartElement(QNameContext qnc, Grammar grammar) {
/* 52 */     this(qnc);
/* 53 */     setGrammar(grammar);
/*    */   }
/*    */   
/*    */   public QNameContext getQNameContext() {
/* 57 */     return this.qnameContext;
/*    */   }
/*    */   
/*    */   public QName getQName() {
/* 61 */     return this.qname;
/*    */   }
/*    */   
/*    */   public void setGrammar(Grammar grammar) {
/* 65 */     this.grammar = grammar;
/*    */   }
/*    */   
/*    */   public Grammar getGrammar() {
/* 69 */     return this.grammar;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 73 */     return super.toString() + "(" + this.qname.toString() + ")";
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 78 */     return this.qname.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 83 */     if (this == obj)
/* 84 */       return true; 
/* 85 */     if (obj instanceof StartElement) {
/* 86 */       StartElement otherSE = (StartElement)obj;
/* 87 */       return this.qnameContext.equals(otherSE.qnameContext);
/*    */     } 
/* 89 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\StartElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */