/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.types.BuiltInType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanDatatype
/*    */   extends AbstractDatatype
/*    */ {
/*    */   public BooleanDatatype(QNameContext schemaType) {
/* 39 */     super(BuiltInType.BOOLEAN, schemaType);
/*    */   }
/*    */   
/*    */   public DatatypeID getDatatypeID() {
/* 43 */     return DatatypeID.exi_boolean;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\BooleanDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */