/*     */ package com.siemens.ct.exi.core.grammars.grammar;
/*     */ 
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.AttributeNS;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElementNS;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import com.siemens.ct.exi.core.grammars.production.SchemaInformedProduction;
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import com.siemens.ct.exi.core.util.sort.AttributeSort;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSchemaInformedGrammar
/*     */   extends AbstractGrammar
/*     */   implements SchemaInformedGrammar
/*     */ {
/*  53 */   Production[] containers = new Production[0];
/*     */ 
/*     */   
/*     */   protected int codeLengthA;
/*     */ 
/*     */   
/*     */   protected int codeLengthB;
/*     */   
/*     */   protected boolean hasEndElement = false;
/*     */ 
/*     */   
/*     */   public boolean hasEndElement() {
/*  65 */     return this.hasEndElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   protected int leastAttributeEventCode = -1;
/*  72 */   protected int numberOfDeclaredAttributes = 0;
/*     */ 
/*     */   
/*     */   public AbstractSchemaInformedGrammar() {
/*  76 */     init();
/*     */   }
/*     */   
/*     */   public AbstractSchemaInformedGrammar(String label) {
/*  80 */     super(label);
/*  81 */     init();
/*     */   }
/*     */   
/*     */   protected final boolean isTerminalRule() {
/*  85 */     return (this == END_RULE);
/*     */   }
/*     */   
/*     */   private void init() {
/*  89 */     this.containers = new Production[0];
/*     */   }
/*     */   
/*     */   public final boolean isSchemaInformed() {
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public int getNumberOfDeclaredAttributes() {
/*  97 */     return this.numberOfDeclaredAttributes;
/*     */   }
/*     */   
/*     */   public int getLeastAttributeEventCode() {
/* 101 */     return this.leastAttributeEventCode;
/*     */   }
/*     */   
/*     */   public final int getNumberOfEvents() {
/* 105 */     return this.containers.length;
/*     */   }
/*     */   
/*     */   public void addProduction(Event event, Grammar grammar) {
/* 109 */     if (isTerminalRule())
/*     */     {
/* 111 */       throw new IllegalArgumentException("EndGrammar can not have events attached");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     if ((!event.isEventType(EventType.END_ELEMENT) && 
/* 118 */       !event.isEventType(EventType.ATTRIBUTE_GENERIC) && 
/* 119 */       !event.isEventType(EventType.START_ELEMENT_GENERIC)) || 
/* 120 */       getProduction(event.getEventType()) == null) {
/*     */ 
/*     */ 
/*     */       
/* 124 */       if (event.isEventType(EventType.END_ELEMENT)) {
/* 125 */         this.hasEndElement = true;
/*     */       }
/*     */ 
/*     */       
/* 129 */       for (int i = 0; i < this.containers.length; i++) {
/* 130 */         Production ei = this.containers[i];
/* 131 */         if (ei.getEvent().equals(event) && 
/* 132 */           ei.getNextGrammar() != grammar)
/*     */         {
/* 134 */           throw new IllegalArgumentException("Same event " + event + " with indistinguishable 'next' grammar");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 142 */       updateSortedEvents(event, grammar);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 147 */   static final AttributeSort attributeSort = new AttributeSort();
/*     */ 
/*     */   
/*     */   protected void updateSortedEvents(Event newEvent, Grammar newGrammar) {
/* 151 */     List<Event> sortedEvents = new ArrayList<>();
/*     */ 
/*     */     
/* 154 */     Event o2 = newEvent;
/*     */     
/* 156 */     boolean added = false;
/*     */ 
/*     */     
/* 159 */     for (int i = 0; i < this.containers.length; i++) {
/* 160 */       Production ei = this.containers[i];
/* 161 */       Event o1 = ei.getEvent();
/*     */       
/* 163 */       if (!added) {
/*     */         
/* 165 */         int diff = o1.getEventType().ordinal() - o2.getEventType().ordinal();
/* 166 */         if (diff == 0) {
/*     */           int cmpA; AttributeNS atNS1; AttributeNS atNS2; int cmpNS;
/* 168 */           switch (o1.getEventType()) {
/*     */ 
/*     */ 
/*     */             
/*     */             case ATTRIBUTE:
/* 173 */               cmpA = attributeSort.compare((Attribute)o1, (Attribute)o2);
/*     */               
/* 175 */               if (cmpA < 0)
/*     */                 break; 
/* 177 */               if (cmpA > 0) {
/*     */                 
/* 179 */                 sortedEvents.add(o2);
/* 180 */                 added = true; break;
/*     */               } 
/* 182 */               assert cmpA == 0;
/*     */               
/* 184 */               throw new RuntimeException("Twice the same attribute name when sorting");
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             case ATTRIBUTE_NS:
/* 190 */               atNS1 = (AttributeNS)o1;
/* 191 */               atNS2 = (AttributeNS)o2;
/* 192 */               cmpNS = atNS1.getNamespaceURI().compareTo(atNS2
/* 193 */                   .getNamespaceURI());
/* 194 */               if (cmpNS < 0)
/*     */                 break; 
/* 196 */               if (cmpNS > 0) {
/*     */                 
/* 198 */                 sortedEvents.add(o2);
/* 199 */                 added = true; break;
/*     */               } 
/* 201 */               assert cmpNS == 0;
/*     */               
/* 203 */               throw new RuntimeException("Twice the same attribute uri in AT(uri*) when sorting");
/*     */ 
/*     */ 
/*     */             
/*     */             case START_ELEMENT:
/*     */             case START_ELEMENT_NS:
/*     */               break;
/*     */ 
/*     */             
/*     */             default:
/* 213 */               throw new RuntimeException("No valid event type for sorting");
/*     */           } 
/*     */         
/* 216 */         } else if (diff >= 0) {
/*     */ 
/*     */           
/* 219 */           assert diff > 0;
/*     */           
/* 221 */           sortedEvents.add(o2);
/* 222 */           added = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 227 */       sortedEvents.add(o1);
/*     */     } 
/*     */     
/* 230 */     if (!added) {
/* 231 */       sortedEvents.add(o2);
/*     */     }
/*     */     
/* 234 */     assert sortedEvents.size() == this.containers.length + 1;
/*     */ 
/*     */     
/* 237 */     Production[] newContainers = new Production[sortedEvents.size()];
/* 238 */     int eventCode = 0;
/* 239 */     boolean newOneAdded = false;
/*     */     int j;
/* 241 */     for (j = 0; j < sortedEvents.size(); j++) {
/* 242 */       Event ev = sortedEvents.get(j);
/* 243 */       if (ev == newEvent) {
/* 244 */         newContainers[eventCode] = (Production)new SchemaInformedProduction(newGrammar, newEvent, eventCode);
/*     */         
/* 246 */         newOneAdded = true;
/*     */       }
/*     */       else {
/*     */         
/* 250 */         Production oldEI = this.containers[newOneAdded ? (eventCode - 1) : eventCode];
/* 251 */         newContainers[eventCode] = (Production)new SchemaInformedProduction(oldEI
/* 252 */             .getNextGrammar(), oldEI.getEvent(), eventCode);
/*     */       } 
/* 254 */       eventCode++;
/*     */     } 
/*     */     
/* 257 */     this.containers = newContainers;
/*     */ 
/*     */     
/* 260 */     this.codeLengthA = MethodsBag.getCodingLength(getNumberOfEvents());
/* 261 */     this.codeLengthB = MethodsBag.getCodingLength(getNumberOfEvents() + 1);
/*     */ 
/*     */     
/* 264 */     this.leastAttributeEventCode = -1;
/* 265 */     this.numberOfDeclaredAttributes = 0;
/*     */     
/* 267 */     for (j = 0; j < this.containers.length; j++) {
/* 268 */       Production er = this.containers[j];
/* 269 */       if (er.getEvent().isEventType(EventType.ATTRIBUTE)) {
/* 270 */         if (this.leastAttributeEventCode == -1)
/*     */         {
/* 272 */           this.leastAttributeEventCode = j;
/*     */         }
/*     */         
/* 275 */         this.numberOfDeclaredAttributes++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void joinGrammars(Grammar rule) {
/* 285 */     for (int i = 0; i < rule.getNumberOfEvents(); i++) {
/* 286 */       Production ei = rule.getProduction(i);
/* 287 */       addProduction(ei.getEvent(), ei.getNextGrammar());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 294 */     StringBuilder sb = new StringBuilder();
/* 295 */     sb.append('[');
/*     */     
/* 297 */     for (int i = 0; i < getNumberOfEvents(); i++) {
/* 298 */       sb.append(getProduction(i).getEvent().toString());
/* 299 */       if (i < getNumberOfEvents() - 1) {
/* 300 */         sb.append(", ");
/*     */       }
/*     */     } 
/*     */     
/* 304 */     sb.append(']');
/*     */     
/* 306 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaInformedGrammar clone() {
/*     */     try {
/* 312 */       return (SchemaInformedGrammar)super.clone();
/* 313 */     } catch (CloneNotSupportedException e) {
/* 314 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public SchemaInformedGrammar duplicate() {
/* 319 */     return clone();
/*     */   }
/*     */   
/*     */   public Production getProduction(EventType eventType) {
/* 323 */     for (int i = 0; i < this.containers.length; i++) {
/* 324 */       Production ei = this.containers[i];
/* 325 */       if (ei.getEvent().isEventType(eventType)) {
/* 326 */         return ei;
/*     */       }
/*     */     } 
/* 329 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Production getStartElementProduction(String namespaceURI, String localName) {
/* 334 */     for (int i = 0; i < this.containers.length; i++) {
/* 335 */       Production ei = this.containers[i];
/* 336 */       if (ei.getEvent().isEventType(EventType.START_ELEMENT) && 
/* 337 */         checkQualifiedName(((StartElement)ei
/* 338 */           .getEvent()).getQName(), namespaceURI, localName))
/*     */       {
/* 340 */         return ei;
/*     */       }
/*     */     } 
/* 343 */     return null;
/*     */   }
/*     */   
/*     */   public Production getStartElementNSProduction(String namespaceURI) {
/* 347 */     for (int i = 0; i < this.containers.length; i++) {
/* 348 */       Production ei = this.containers[i];
/* 349 */       if (ei.getEvent().isEventType(EventType.START_ELEMENT_NS) && ((StartElementNS)ei
/* 350 */         .getEvent()).getNamespaceURI()
/* 351 */         .equals(namespaceURI)) {
/* 352 */         return ei;
/*     */       }
/*     */     } 
/* 355 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Production getAttributeProduction(String namespaceURI, String localName) {
/* 360 */     for (int i = 0; i < this.containers.length; i++) {
/* 361 */       Production ei = this.containers[i];
/* 362 */       if (ei.getEvent().isEventType(EventType.ATTRIBUTE) && 
/* 363 */         checkQualifiedName(((Attribute)ei
/* 364 */           .getEvent()).getQName(), namespaceURI, localName))
/*     */       {
/* 366 */         return ei;
/*     */       }
/*     */     } 
/* 369 */     return null;
/*     */   }
/*     */   
/*     */   public Production getAttributeNSProduction(String namespaceURI) {
/* 373 */     for (int i = 0; i < this.containers.length; i++) {
/* 374 */       Production ei = this.containers[i];
/* 375 */       if (ei.getEvent().isEventType(EventType.ATTRIBUTE_NS) && ((AttributeNS)ei
/* 376 */         .getEvent()).getNamespaceURI().equals(namespaceURI))
/*     */       {
/* 378 */         return ei;
/*     */       }
/*     */     } 
/* 381 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Production getProduction(int eventCode) {
/* 386 */     assert eventCode >= 0 && eventCode < this.containers.length;
/* 387 */     return this.containers[eventCode];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 392 */     if (this == o)
/* 393 */       return true; 
/* 394 */     if (!(o instanceof AbstractSchemaInformedGrammar))
/* 395 */       return false; 
/* 396 */     if (!super.equals(o)) {
/* 397 */       return false;
/*     */     }
/* 399 */     AbstractSchemaInformedGrammar that = (AbstractSchemaInformedGrammar)o;
/*     */     
/* 401 */     if (this.codeLengthA != that.codeLengthA)
/* 402 */       return false; 
/* 403 */     if (this.codeLengthB != that.codeLengthB)
/* 404 */       return false; 
/* 405 */     if (this.hasEndElement != that.hasEndElement)
/* 406 */       return false; 
/* 407 */     if (this.leastAttributeEventCode != that.leastAttributeEventCode)
/* 408 */       return false; 
/* 409 */     if (this.numberOfDeclaredAttributes != that.numberOfDeclaredAttributes)
/* 410 */       return false; 
/* 411 */     return Arrays.equals((Object[])this.containers, (Object[])that.containers);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\AbstractSchemaInformedGrammar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */