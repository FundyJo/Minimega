/*    */ package com.siemens.ct.exi.core.grammars.production;
/*    */ 
/*    */ import com.siemens.ct.exi.core.grammars.event.Event;
/*    */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchemaLessProduction
/*    */   extends AbstractProduction
/*    */ {
/*    */   protected final Grammar father;
/*    */   
/*    */   public SchemaLessProduction(Grammar father, Grammar next, Event event, int eventCode) {
/* 42 */     super(next, event, eventCode);
/* 43 */     this.father = father;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getEventCode() {
/* 49 */     return this.father.getNumberOfEvents() - 1 - this.eventCode;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 55 */     if (this == o)
/* 56 */       return true; 
/* 57 */     if (!(o instanceof SchemaLessProduction))
/* 58 */       return false; 
/* 59 */     if (!super.equals(o)) {
/* 60 */       return false;
/*    */     }
/* 62 */     SchemaLessProduction that = (SchemaLessProduction)o;
/*    */     
/* 64 */     return (this.father != null) ? this.father.equals(that.father) : (
/* 65 */       (that.father == null));
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\production\SchemaLessProduction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */