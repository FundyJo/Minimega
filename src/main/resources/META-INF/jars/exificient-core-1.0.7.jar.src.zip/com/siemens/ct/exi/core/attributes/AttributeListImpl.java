/*     */ package com.siemens.ct.exi.core.attributes;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeListImpl
/*     */   implements AttributeList
/*     */ {
/*  45 */   public static final int XMLNS_PFX_START = "xmlns"
/*  46 */     .length() + 1;
/*     */   
/*     */   protected final boolean isSchemaInformed;
/*     */   
/*     */   protected final boolean isCanonical;
/*     */   
/*     */   protected final boolean preserveSchemaLocation;
/*     */   
/*     */   protected final boolean preservePrefixes;
/*     */   
/*     */   protected boolean hasXsiType;
/*     */   
/*     */   protected String xsiTypeRaw;
/*     */   
/*     */   protected String xsiTypePrefix;
/*     */   
/*     */   protected boolean hasXsiNil;
/*     */   
/*     */   protected String xsiNil;
/*     */   
/*     */   protected String xsiNilPrefix;
/*     */   
/*     */   protected final List<String> attributeURI;
/*     */   protected final List<String> attributeLocalName;
/*     */   protected final List<String> attributeValue;
/*     */   protected final List<String> attributePrefix;
/*     */   protected List<NamespaceDeclaration> nsDecls;
/*     */   
/*     */   public AttributeListImpl(EXIFactory exiFactory) {
/*  75 */     this.isSchemaInformed = exiFactory.getGrammars().isSchemaInformed();
/*  76 */     this.isCanonical = exiFactory.getEncodingOptions().isOptionEnabled("http://www.w3.org/TR/exi-c14n");
/*     */     
/*  78 */     this
/*  79 */       .preserveSchemaLocation = exiFactory.getEncodingOptions().isOptionEnabled("INCLUDE_XSI_SCHEMALOCATION");
/*  80 */     this.preservePrefixes = exiFactory.getFidelityOptions().isFidelityEnabled("PRESERVE_PREFIXES");
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.attributeURI = new ArrayList<>();
/*  85 */     this.attributeLocalName = new ArrayList<>();
/*  86 */     this.attributeValue = new ArrayList<>();
/*  87 */     this.attributePrefix = new ArrayList<>();
/*     */     
/*  89 */     this.nsDecls = new ArrayList<>();
/*     */   }
/*     */   
/*     */   public void clear() {
/*  93 */     this.hasXsiType = false;
/*  94 */     this.hasXsiNil = false;
/*     */     
/*  96 */     this.attributeURI.clear();
/*  97 */     this.attributeLocalName.clear();
/*  98 */     this.attributeValue.clear();
/*  99 */     this.attributePrefix.clear();
/*     */     
/* 101 */     this.xsiTypeRaw = null;
/*     */     
/* 103 */     this.nsDecls.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasXsiType() {
/* 110 */     return this.hasXsiType;
/*     */   }
/*     */   
/*     */   public String getXsiTypeRaw() {
/* 114 */     return this.xsiTypeRaw;
/*     */   }
/*     */   
/*     */   public String getXsiTypePrefix() {
/* 118 */     return this.xsiTypePrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasXsiNil() {
/* 125 */     return this.hasXsiNil;
/*     */   }
/*     */   
/*     */   public String getXsiNil() {
/* 129 */     return this.xsiNil;
/*     */   }
/*     */   
/*     */   public String getXsiNilPrefix() {
/* 133 */     return this.xsiNilPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfAttributes() {
/* 140 */     return this.attributeURI.size();
/*     */   }
/*     */   
/*     */   public String getAttributeURI(int index) {
/* 144 */     return this.attributeURI.get(index);
/*     */   }
/*     */   
/*     */   public String getAttributeLocalName(int index) {
/* 148 */     return this.attributeLocalName.get(index);
/*     */   }
/*     */   
/*     */   public String getAttributeValue(int index) {
/* 152 */     return this.attributeValue.get(index);
/*     */   }
/*     */   
/*     */   public String getAttributePrefix(int index) {
/* 156 */     return this.attributePrefix.get(index);
/*     */   }
/*     */   
/*     */   private void setXsiType(String rawType, String xsiPrefix) {
/* 160 */     this.hasXsiType = true;
/* 161 */     this.xsiTypeRaw = rawType;
/* 162 */     this.xsiTypePrefix = xsiPrefix;
/*     */   }
/*     */   
/*     */   private void setXsiNil(String rawNil, String xsiPrefix) {
/* 166 */     this.hasXsiNil = true;
/* 167 */     this.xsiNil = rawNil;
/* 168 */     this.xsiNilPrefix = xsiPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addNamespaceDeclaration(String uri, String pfx) {
/* 210 */     if (this.nsDecls.size() == 0 || !this.isCanonical) {
/* 211 */       this.nsDecls.add(new NamespaceDeclaration(uri, pfx));
/*     */     } else {
/*     */       
/* 214 */       int i = getNumberOfNamespaceDeclarations();
/*     */ 
/*     */       
/* 217 */       while (i > 0 && isGreaterNS(i - 1, pfx))
/*     */       {
/* 219 */         i--;
/*     */       }
/*     */ 
/*     */       
/* 223 */       this.nsDecls.add(i, new NamespaceDeclaration(uri, pfx));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfNamespaceDeclarations() {
/* 229 */     return this.nsDecls.size();
/*     */   }
/*     */   
/*     */   public NamespaceDeclaration getNamespaceDeclaration(int index) {
/* 233 */     assert index >= 0 && index < this.nsDecls.size();
/* 234 */     return this.nsDecls.get(index);
/*     */   }
/*     */   
/*     */   public void addAttribute(QName at, String value) {
/* 238 */     addAttribute(at.getNamespaceURI(), at.getLocalPart(), at.getPrefix(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAttribute(String uri, String localName, String pfx, String value) {
/* 244 */     uri = (uri == null) ? "" : uri;
/* 245 */     pfx = (pfx == null) ? "" : pfx;
/*     */ 
/*     */     
/* 248 */     if (uri.equals("http://www.w3.org/2001/XMLSchema-instance")) {
/*     */       
/* 250 */       if (localName.equals("type")) {
/*     */         
/* 252 */         setXsiType(value, pfx);
/*     */       
/*     */       }
/* 255 */       else if (localName.equals("nil")) {
/* 256 */         setXsiNil(value, pfx);
/* 257 */       } else if ((!localName.equals("schemaLocation") && 
/* 258 */         !localName.equals("noNamespaceSchemaLocation")) || this.preserveSchemaLocation) {
/*     */ 
/*     */ 
/*     */         
/* 262 */         insertAttribute(uri, localName, pfx, value);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 269 */       insertAttribute(uri, localName, pfx, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void insertAttribute(String uri, String localName, String pfx, String value) {
/* 275 */     if (this.isSchemaInformed || this.isCanonical) {
/*     */       
/* 277 */       int i = getNumberOfAttributes();
/*     */ 
/*     */       
/* 280 */       while (i > 0 && isGreaterAttribute(i - 1, uri, localName))
/*     */       {
/* 282 */         i--;
/*     */       }
/*     */ 
/*     */       
/* 286 */       this.attributeURI.add(i, uri);
/* 287 */       this.attributeLocalName.add(i, localName);
/* 288 */       this.attributePrefix.add(i, pfx);
/* 289 */       this.attributeValue.add(i, value);
/*     */     } else {
/*     */       
/* 292 */       this.attributeURI.add(uri);
/* 293 */       this.attributeLocalName.add(localName);
/* 294 */       this.attributePrefix.add(pfx);
/* 295 */       this.attributeValue.add(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isGreaterAttribute(int attributeIndex, String uri, String localName) {
/* 302 */     int compLocalName = getAttributeLocalName(attributeIndex).compareTo(localName);
/*     */ 
/*     */     
/* 305 */     if (compLocalName > 0)
/*     */     {
/* 307 */       return true; } 
/* 308 */     if (compLocalName < 0)
/*     */     {
/* 310 */       return false;
/*     */     }
/*     */     
/* 313 */     return (getAttributeURI(attributeIndex).compareTo(uri) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isGreaterNS(int nsIndex, String prefix) {
/* 320 */     int compPrefix = (getNamespaceDeclaration(nsIndex)).prefix.compareTo(prefix);
/*     */     
/* 322 */     if (compPrefix > 0)
/*     */     {
/* 324 */       return true;
/*     */     }
/*     */     
/* 327 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\attributes\AttributeListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */