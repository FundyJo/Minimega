package com.siemens.ct.exi.core.grammars.production;

import com.siemens.ct.exi.core.grammars.event.Event;
import com.siemens.ct.exi.core.grammars.grammar.Grammar;

public interface Production {
  Event getEvent();
  
  Grammar getNextGrammar();
  
  int getEventCode();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\production\Production.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */