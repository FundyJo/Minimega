package com.siemens.ct.exi.core.io.channel;

import com.siemens.ct.exi.core.values.DateTimeValue;
import com.siemens.ct.exi.core.values.FloatValue;
import com.siemens.ct.exi.core.values.IntegerValue;
import java.io.IOException;
import java.io.OutputStream;

public interface EncoderChannel {
  OutputStream getOutputStream();
  
  void flush() throws IOException;
  
  int getLength();
  
  void align() throws IOException;
  
  void encode(int paramInt) throws IOException;
  
  void encode(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  void encodeNBitUnsignedInteger(int paramInt1, int paramInt2) throws IOException;
  
  void encodeBoolean(boolean paramBoolean) throws IOException;
  
  void encodeBinary(byte[] paramArrayOfbyte) throws IOException;
  
  void encodeString(String paramString) throws IOException;
  
  void encodeStringOnly(String paramString) throws IOException;
  
  void encodeUnsignedInteger(int paramInt) throws IOException;
  
  void encodeUnsignedIntegerValue(IntegerValue paramIntegerValue) throws IOException;
  
  void encodeInteger(int paramInt) throws IOException;
  
  void encodeIntegerValue(IntegerValue paramIntegerValue) throws IOException;
  
  void encodeDecimal(boolean paramBoolean, IntegerValue paramIntegerValue1, IntegerValue paramIntegerValue2) throws IOException;
  
  void encodeFloat(FloatValue paramFloatValue) throws IOException;
  
  void encodeDateTime(DateTimeValue paramDateTimeValue) throws IOException;
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\channel\EncoderChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */