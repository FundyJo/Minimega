/*     */ package com.siemens.ct.exi.core.datatype;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.types.BuiltInType;
/*     */ import com.siemens.ct.exi.core.types.DateTimeType;
/*     */ import com.siemens.ct.exi.core.values.DateTimeValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatetimeDatatype
/*     */   extends AbstractDatatype
/*     */ {
/*     */   DateTimeType datetimeType;
/*     */   private DateTimeValue lastValidDatetime;
/*     */   
/*     */   public DatetimeDatatype(DateTimeType dateType, QNameContext schemaType) {
/*  46 */     super(BuiltInType.DATETIME, schemaType);
/*  47 */     this.datetimeType = dateType;
/*     */   }
/*     */   
/*     */   public DatatypeID getDatatypeID() {
/*     */     DatatypeID dtID;
/*  52 */     switch (this.datetimeType) {
/*     */       case dateTime:
/*  54 */         dtID = DatatypeID.exi_dateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  80 */         return dtID;case time: dtID = DatatypeID.exi_time; return dtID;case date: dtID = DatatypeID.exi_date; return dtID;case gYearMonth: dtID = DatatypeID.exi_gYearMonth; return dtID;case gYear: dtID = DatatypeID.exi_gYear; return dtID;case gMonthDay: dtID = DatatypeID.exi_gMonthDay; return dtID;case gDay: dtID = DatatypeID.exi_gDay; return dtID;case gMonth: dtID = DatatypeID.exi_gMonth; return dtID;
/*     */     } 
/*     */     throw new UnsupportedOperationException();
/*     */   } public DateTimeType getDatetimeType() {
/*  84 */     return this.datetimeType;
/*     */   }
/*     */   
/*     */   protected boolean isValidString(String value) {
/*  88 */     this.lastValidDatetime = DateTimeValue.parse(value, this.datetimeType);
/*  89 */     return (this.lastValidDatetime != null);
/*     */   }
/*     */   
/*     */   public boolean isValid(Value value) {
/*  93 */     if (value instanceof DateTimeValue) {
/*  94 */       this.lastValidDatetime = (DateTimeValue)value;
/*  95 */       return true;
/*     */     } 
/*  97 */     return isValidString(value.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 103 */     if (super.equals(o) && o instanceof DatetimeDatatype) {
/* 104 */       DatetimeDatatype dt = (DatetimeDatatype)o;
/* 105 */       return (this.datetimeType == dt.getDatetimeType());
/*     */     } 
/* 107 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\DatetimeDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */