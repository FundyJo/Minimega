package com.siemens.ct.exi.core.datatype.strings;

import com.siemens.ct.exi.core.context.QNameContext;
import com.siemens.ct.exi.core.io.channel.DecoderChannel;
import com.siemens.ct.exi.core.values.StringValue;
import java.io.IOException;

public interface StringDecoder extends StringCoder {
  void addValue(QNameContext paramQNameContext, StringValue paramStringValue);
  
  StringValue readValue(QNameContext paramQNameContext, DecoderChannel paramDecoderChannel) throws IOException;
  
  StringValue readValueLocalHit(QNameContext paramQNameContext, DecoderChannel paramDecoderChannel) throws IOException;
  
  StringValue readValueGlobalHit(DecoderChannel paramDecoderChannel) throws IOException;
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\strings\StringDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */