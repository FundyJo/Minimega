/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.types.BuiltInType;
/*    */ import com.siemens.ct.exi.core.values.DecimalValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecimalDatatype
/*    */   extends AbstractDatatype
/*    */ {
/*    */   protected DecimalValue lastValidDecimal;
/*    */   
/*    */   public DecimalDatatype(QNameContext schemaType) {
/* 42 */     super(BuiltInType.DECIMAL, schemaType);
/*    */   }
/*    */   
/*    */   public DatatypeID getDatatypeID() {
/* 46 */     return DatatypeID.exi_decimal;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\DecimalDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */