/*    */ package com.siemens.ct.exi.core.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EXIException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -8954797101782288026L;
/*    */   
/*    */   public EXIException() {}
/*    */   
/*    */   public EXIException(String message) {
/* 45 */     super(message);
/*    */   }
/*    */   
/*    */   public EXIException(String message, Throwable cause) {
/* 49 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public EXIException(Throwable cause) {
/* 53 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\exceptions\EXIException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */