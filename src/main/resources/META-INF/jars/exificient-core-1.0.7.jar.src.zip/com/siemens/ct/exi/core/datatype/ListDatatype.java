/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.types.BuiltInType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListDatatype
/*    */   extends AbstractDatatype
/*    */ {
/*    */   private Datatype listDatatype;
/*    */   
/*    */   public ListDatatype(Datatype listDatatype, QNameContext schemaType) {
/* 41 */     super(BuiltInType.LIST, schemaType);
/*    */     
/* 43 */     if (listDatatype.getBuiltInType() == BuiltInType.LIST) {
/* 44 */       throw new IllegalArgumentException();
/*    */     }
/*    */     
/* 47 */     this.listDatatype = listDatatype;
/*    */   }
/*    */   
/*    */   public DatatypeID getDatatypeID() {
/* 51 */     return this.listDatatype.getDatatypeID();
/*    */   }
/*    */   
/*    */   public Datatype getListDatatype() {
/* 55 */     return this.listDatatype;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 60 */     if (super.equals(o) && o instanceof ListDatatype) {
/* 61 */       ListDatatype l = (ListDatatype)o;
/* 62 */       return this.listDatatype.equals(l.listDatatype);
/*    */     } 
/* 64 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\ListDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */