/*     */ package com.siemens.ct.exi.core.grammars.grammar;
/*     */ 
/*     */ import com.siemens.ct.exi.core.FidelityOptions;
/*     */ import com.siemens.ct.exi.core.grammars.event.Characters;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.types.BuiltIn;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBuiltInContent
/*     */   extends AbstractBuiltInGrammar
/*     */ {
/*  49 */   protected static final Map<FidelityOptions, List<EventType>> optionsStartTag = new HashMap<>();
/*  50 */   protected static final Map<FidelityOptions, List<EventType>> optionsChildContent = new HashMap<>();
/*     */ 
/*     */   
/*     */   protected boolean learnedCH = false;
/*     */ 
/*     */   
/*     */   protected static List<EventType> get2ndLevelEventsStartTagItems(FidelityOptions fidelityOptions) {
/*  57 */     if (!optionsStartTag.containsKey(fidelityOptions)) {
/*  58 */       List<EventType> events = new ArrayList<>();
/*     */ 
/*     */ 
/*     */       
/*  62 */       events.add(EventType.END_ELEMENT_UNDECLARED);
/*  63 */       events.add(EventType.ATTRIBUTE_GENERIC_UNDECLARED);
/*     */ 
/*     */       
/*  66 */       if (fidelityOptions
/*  67 */         .isFidelityEnabled("PRESERVE_PREFIXES")) {
/*  68 */         events.add(EventType.NAMESPACE_DECLARATION);
/*     */       }
/*     */       
/*  71 */       if (fidelityOptions.isFidelityEnabled("SELF_CONTAINED")) {
/*  72 */         events.add(EventType.SELF_CONTAINED);
/*     */       }
/*     */ 
/*     */       
/*  76 */       optionsStartTag.put(fidelityOptions, events);
/*     */     } 
/*     */     
/*  79 */     return optionsStartTag.get(fidelityOptions);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static List<EventType> get2ndLevelEventsChildContentItems(FidelityOptions fidelityOptions) {
/*  84 */     if (!optionsChildContent.containsKey(fidelityOptions)) {
/*  85 */       List<EventType> events = new ArrayList<>();
/*     */ 
/*     */ 
/*     */       
/*  89 */       events.add(EventType.START_ELEMENT_GENERIC_UNDECLARED);
/*  90 */       events.add(EventType.CHARACTERS_GENERIC_UNDECLARED);
/*     */ 
/*     */       
/*  93 */       if (fidelityOptions.isFidelityEnabled("PRESERVE_DTDS")) {
/*  94 */         events.add(EventType.ENTITY_REFERENCE);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  99 */       optionsChildContent.put(fidelityOptions, events);
/*     */     } 
/*     */     
/* 102 */     return optionsChildContent.get(fidelityOptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void learnCharacters() {
/* 111 */     if (!this.learnedCH) {
/* 112 */       addProduction((Event)new Characters(BuiltIn.getDefaultDatatype()), 
/* 113 */           getElementContentGrammar());
/* 114 */       this.learnedCH = true;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\AbstractBuiltInContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */