/*     */ package com.siemens.ct.exi.core.types;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.DatatypeID;
/*     */ import com.siemens.ct.exi.core.datatype.RestrictedCharacterSetDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.charset.RestrictedCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDBase64CharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDBooleanCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDDateTimeCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDDecimalCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDDoubleCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDHexBinaryCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDIntegerCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDStringCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringDecoder;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.io.channel.DecoderChannel;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexicalTypeDecoder
/*     */   extends AbstractTypeDecoder
/*     */ {
/*  56 */   protected RestrictedCharacterSetDatatype rcsBase64Binary = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDBase64CharacterSet(), null);
/*     */   
/*  58 */   protected RestrictedCharacterSetDatatype rcsHexBinary = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDHexBinaryCharacterSet(), null);
/*     */   
/*  60 */   protected RestrictedCharacterSetDatatype rcsBoolean = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDBooleanCharacterSet(), null);
/*     */   
/*  62 */   protected RestrictedCharacterSetDatatype rcsDateTime = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDDateTimeCharacterSet(), null);
/*     */   
/*  64 */   protected RestrictedCharacterSetDatatype rcsDecimal = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDDecimalCharacterSet(), null);
/*     */   
/*  66 */   protected RestrictedCharacterSetDatatype rcsDouble = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDDoubleCharacterSet(), null);
/*     */   
/*  68 */   protected RestrictedCharacterSetDatatype rcsInteger = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDIntegerCharacterSet(), null);
/*     */   
/*  70 */   protected RestrictedCharacterSetDatatype rcsString = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDStringCharacterSet(), null);
/*     */ 
/*     */   
/*     */   public LexicalTypeDecoder() throws EXIException {
/*  74 */     this((QName[])null, (QName[])null, (Map<QName, Datatype>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexicalTypeDecoder(QName[] dtrMapTypes, QName[] dtrMapRepresentations, Map<QName, Datatype> dtrMapRepresentationsDatatype) throws EXIException {
/*  81 */     super(dtrMapTypes, dtrMapRepresentations, dtrMapRepresentationsDatatype);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Value readValue(Datatype datatype, QNameContext qnContext, DecoderChannel valueChannel, StringDecoder stringDecoder) throws IOException {
/*  87 */     if (this.dtrMapInUse) {
/*  88 */       datatype = getDtrDatatype(datatype);
/*     */     }
/*     */     
/*  91 */     switch (datatype.getDatatypeID()) {
/*     */       case exi_base64Binary:
/*  93 */         return readRCSValue(this.rcsBase64Binary, qnContext, valueChannel, stringDecoder);
/*     */       
/*     */       case exi_hexBinary:
/*  96 */         return readRCSValue(this.rcsHexBinary, qnContext, valueChannel, stringDecoder);
/*     */       
/*     */       case exi_boolean:
/*  99 */         return readRCSValue(this.rcsBoolean, qnContext, valueChannel, stringDecoder);
/*     */       
/*     */       case exi_dateTime:
/*     */       case exi_time:
/*     */       case exi_date:
/*     */       case exi_gYearMonth:
/*     */       case exi_gYear:
/*     */       case exi_gMonthDay:
/*     */       case exi_gDay:
/*     */       case exi_gMonth:
/* 109 */         return readRCSValue(this.rcsDateTime, qnContext, valueChannel, stringDecoder);
/*     */       
/*     */       case exi_decimal:
/* 112 */         return readRCSValue(this.rcsDecimal, qnContext, valueChannel, stringDecoder);
/*     */       
/*     */       case exi_double:
/* 115 */         return readRCSValue(this.rcsDouble, qnContext, valueChannel, stringDecoder);
/*     */       
/*     */       case exi_integer:
/* 118 */         return readRCSValue(this.rcsInteger, qnContext, valueChannel, stringDecoder);
/*     */ 
/*     */       
/*     */       case exi_string:
/* 122 */         return (Value)stringDecoder.readValue(qnContext, valueChannel);
/*     */     } 
/* 124 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\LexicalTypeDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */