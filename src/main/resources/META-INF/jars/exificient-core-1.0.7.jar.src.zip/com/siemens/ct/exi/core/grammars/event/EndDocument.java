/*    */ package com.siemens.ct.exi.core.grammars.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndDocument
/*    */   extends AbstractEvent
/*    */ {
/*    */   public EndDocument() {
/* 36 */     super(EventType.END_DOCUMENT);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\event\EndDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */