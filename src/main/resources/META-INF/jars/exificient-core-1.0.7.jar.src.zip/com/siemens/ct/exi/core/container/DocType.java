/*    */ package com.siemens.ct.exi.core.container;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocType
/*    */ {
/*    */   public final char[] name;
/*    */   public final char[] publicID;
/*    */   public final char[] systemID;
/*    */   public final char[] text;
/*    */   
/*    */   public DocType(char[] name, char[] publicID, char[] systemID, char[] text) {
/* 40 */     this.name = name;
/* 41 */     this.publicID = publicID;
/* 42 */     this.systemID = systemID;
/* 43 */     this.text = text;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\container\DocType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */