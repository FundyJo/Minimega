/*    */ package com.siemens.ct.exi.core.util.xml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLWhitespace
/*    */ {
/*    */   public static final char WS_SPACE = ' ';
/*    */   public static final char WS_NL = '\n';
/*    */   public static final char WS_CR = '\r';
/*    */   public static final char WS_TAB = '\t';
/*    */   
/*    */   public static int getLeadingWhitespaces(char[] ch, int start, int length) {
/* 41 */     int end = start + length;
/* 42 */     int leadingWS = 0;
/*    */     
/* 44 */     while (start < end && isWhiteSpace(ch[start])) {
/* 45 */       start++;
/* 46 */       leadingWS++;
/*    */     } 
/*    */     
/* 49 */     return leadingWS;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int getTrailingWhitespaces(char[] ch, int start, int length) {
/* 54 */     int pos = start + length - 1;
/* 55 */     int trailingWS = 0;
/*    */     
/* 57 */     while (pos >= start && isWhiteSpace(ch[pos])) {
/* 58 */       pos--;
/* 59 */       trailingWS++;
/*    */     } 
/*    */     
/* 62 */     return trailingWS;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isWhiteSpaceOnly(char[] ch, int start, int length) {
/* 67 */     if (!isWhiteSpace(ch[start])) {
/* 68 */       return false;
/*    */     }
/* 70 */     int end = start + length;
/* 71 */     while (++start < end && isWhiteSpace(ch[start]));
/*    */ 
/*    */     
/* 74 */     return (start == end);
/*    */   }
/*    */   
/*    */   public static boolean isWhiteSpaceOnly(String chars) {
/* 78 */     if (!isWhiteSpace(chars.charAt(0))) {
/* 79 */       return false;
/*    */     }
/*    */     
/* 82 */     int end = chars.length();
/* 83 */     int start = 1;
/* 84 */     while (start < end && isWhiteSpace(chars.charAt(start++)));
/*    */ 
/*    */     
/* 87 */     return (start == end);
/*    */   }
/*    */   
/*    */   public static boolean isWhiteSpace(char c) {
/* 91 */     return (c == ' ' || c == '\n' || c == '\r' || c == '\t');
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\cor\\util\xml\XMLWhitespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */