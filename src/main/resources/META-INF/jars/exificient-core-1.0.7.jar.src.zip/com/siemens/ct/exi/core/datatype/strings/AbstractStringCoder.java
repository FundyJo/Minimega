/*    */ package com.siemens.ct.exi.core.datatype.strings;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.values.StringValue;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractStringCoder
/*    */   implements StringCoder
/*    */ {
/*    */   protected final boolean localValuePartitions;
/*    */   protected Map<QNameContext, List<StringValue>> localValues;
/*    */   
/*    */   public AbstractStringCoder(boolean localValuePartitions, int initialQNameLists) {
/* 51 */     this.localValuePartitions = localValuePartitions;
/* 52 */     this.localValues = new HashMap<>(initialQNameLists);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isLocalValuePartitions() {
/* 57 */     return this.localValuePartitions;
/*    */   }
/*    */   
/*    */   public int getNumberOfStringValues(QNameContext qnc) {
/* 61 */     int n = 0;
/* 62 */     List<StringValue> lvs = this.localValues.get(qnc);
/* 63 */     if (lvs != null) {
/* 64 */       n = lvs.size();
/*    */     }
/*    */     
/* 67 */     return n;
/*    */   }
/*    */   
/*    */   protected void addLocalValue(QNameContext qnc, StringValue value) {
/* 71 */     if (this.localValuePartitions) {
/* 72 */       List<StringValue> lvs = this.localValues.get(qnc);
/* 73 */       if (lvs == null) {
/* 74 */         lvs = new ArrayList<>();
/* 75 */         this.localValues.put(qnc, lvs);
/*    */       } 
/* 77 */       lvs.add(value);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void clear() {
/* 83 */     if (this.localValuePartitions)
/*    */     {
/* 85 */       for (List<StringValue> lvs : this.localValues.values())
/* 86 */         lvs.clear(); 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\strings\AbstractStringCoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */