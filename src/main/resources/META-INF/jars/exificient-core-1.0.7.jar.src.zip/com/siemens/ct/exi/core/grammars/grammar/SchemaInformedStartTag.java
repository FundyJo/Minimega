/*     */ package com.siemens.ct.exi.core.grammars.grammar;
/*     */ 
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import com.siemens.ct.exi.core.grammars.production.SchemaInformedProduction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaInformedStartTag
/*     */   extends AbstractSchemaInformedContent
/*     */   implements SchemaInformedStartTagGrammar, Cloneable
/*     */ {
/*     */   protected Grammar elementContent2;
/*  63 */   protected SchemaInformedStartTagGrammar sifst = null;
/*     */   
/*  65 */   static final SchemaInformedGrammar elementContent2Empty = new SchemaInformedElement();
/*     */   static {
/*  67 */     elementContent2Empty.addTerminalProduction(END_ELEMENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaInformedStartTag(SchemaInformedGrammar elementContent2) {
/*  75 */     this();
/*  76 */     this.elementContent2 = elementContent2;
/*     */   }
/*     */   
/*     */   public GrammarType getGrammarType() {
/*  80 */     return GrammarType.SCHEMA_INFORMED_START_TAG_CONTENT;
/*     */   }
/*     */   
/*     */   public void setElementContentGrammar(Grammar elementContent2) {
/*  84 */     this.elementContent2 = elementContent2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Grammar getElementContentGrammar() {
/*  89 */     assert this.elementContent2 != null;
/*  90 */     return this.elementContent2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaInformedStartTag clone() {
/*  97 */     SchemaInformedStartTag clone = (SchemaInformedStartTag)super.clone();
/*     */ 
/*     */     
/* 100 */     for (int i = 0; i < clone.containers.length; i++) {
/* 101 */       Production ei = clone.containers[i];
/* 102 */       if (ei.getNextGrammar() == this) {
/* 103 */         clone.containers[i] = (Production)new SchemaInformedProduction(clone, ei
/* 104 */             .getEvent(), i);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 109 */     return clone;
/*     */   }
/*     */   
/*     */   protected SchemaInformedStartTagGrammar getTypeEmptyInternal() {
/* 113 */     if (this.sifst == null) {
/* 114 */       if (getGrammarType() == GrammarType.SCHEMA_INFORMED_FIRST_START_TAG_CONTENT) {
/* 115 */         this.sifst = new SchemaInformedFirstStartTag();
/* 116 */       } else if (getGrammarType() == GrammarType.SCHEMA_INFORMED_START_TAG_CONTENT) {
/* 117 */         this.sifst = new SchemaInformedStartTag();
/*     */       } else {
/* 119 */         throw new RuntimeException("Unexpected GrammarType " + 
/* 120 */             getGrammarType() + " for typeEmpty " + this);
/*     */       } 
/* 122 */       this.sifst.setElementContentGrammar(elementContent2Empty);
/*     */       
/* 124 */       for (int i = 0; i < getNumberOfEvents(); i++) {
/* 125 */         Production prod = getProduction(i);
/* 126 */         Event ev = prod.getEvent();
/* 127 */         Grammar ng = prod.getNextGrammar();
/* 128 */         switch (ev.getEventType()) {
/*     */           case ATTRIBUTE:
/*     */           case ATTRIBUTE_NS:
/*     */           case ATTRIBUTE_GENERIC:
/* 132 */             if (ng == this) {
/* 133 */               this.sifst.addProduction(ev, this.sifst); break;
/* 134 */             }  if (ng.getGrammarType() == GrammarType.SCHEMA_INFORMED_FIRST_START_TAG_CONTENT) {
/* 135 */               SchemaInformedFirstStartTag ng2 = (SchemaInformedFirstStartTag)ng;
/* 136 */               this.sifst.addProduction(ev, ng2.getTypeEmptyInternal()); break;
/* 137 */             }  if (ng.getGrammarType() == GrammarType.SCHEMA_INFORMED_START_TAG_CONTENT) {
/* 138 */               SchemaInformedStartTag ng2 = (SchemaInformedStartTag)ng;
/* 139 */               this.sifst.addProduction(ev, ng2.getTypeEmptyInternal()); break;
/*     */             } 
/* 141 */             throw new RuntimeException("Unexpected GrammarType " + ng
/* 142 */                 .getGrammarType() + " for typeEmpty " + this);
/*     */ 
/*     */ 
/*     */           
/*     */           default:
/* 147 */             if (!this.sifst.hasEndElement()) {
/* 148 */               this.sifst.addTerminalProduction(END_ELEMENT);
/*     */             }
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 154 */     return this.sifst;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 158 */     String s = "StartTag";
/* 159 */     return s + super.toString();
/*     */   }
/*     */   
/*     */   public SchemaInformedStartTag() {}
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\SchemaInformedStartTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */