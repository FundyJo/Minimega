/*     */ package com.siemens.ct.exi.core;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Constants
/*     */ {
/*     */   public static final String W3C_EXI_NS_URI = "http://www.w3.org/2009/exi";
/*     */   public static final String W3C_EXI_LN_BASE64BINARY = "base64Binary";
/*     */   public static final String W3C_EXI_LN_HEXBINARY = "hexBinary";
/*     */   public static final String W3C_EXI_LN_BOOLEAN = "boolean";
/*     */   public static final String W3C_EXI_LN_DATETIME = "dateTime";
/*     */   public static final String W3C_EXI_LN_TIME = "time";
/*     */   public static final String W3C_EXI_LN_DATE = "date";
/*     */   public static final String W3C_EXI_LN_GYEARMONTH = "gYearMonth";
/*     */   public static final String W3C_EXI_LN_GYEAR = "gYear";
/*     */   public static final String W3C_EXI_LN_GMONTHDAY = "gMonthDay";
/*     */   public static final String W3C_EXI_LN_GDAY = "gDay";
/*     */   public static final String W3C_EXI_LN_GMONTH = "gMonth";
/*     */   public static final String W3C_EXI_LN_DECIMAL = "decimal";
/*     */   public static final String W3C_EXI_LN_DOUBLE = "double";
/*     */   public static final String W3C_EXI_LN_INTEGER = "integer";
/*     */   public static final String W3C_EXI_LN_STRING = "string";
/*     */   public static final String W3C_EXI_FEATURE_BODY_ONLY = "http://www.w3.org/exi/features/exi-body-only";
/* 168 */   public static final String[] PREFIXES_EMPTY = new String[] { "" };
/* 169 */   public static final String[] LOCAL_NAMES_EMPTY = new String[0];
/*     */   
/* 171 */   public static final String[] PREFIXES_XML = new String[] { "xml" };
/* 172 */   public static final String[] LOCAL_NAMES_XML = new String[] { "base", "id", "lang", "space" };
/*     */   
/* 174 */   public static final String[] PREFIXES_XSI = new String[] { "xsi" };
/* 175 */   public static final String[] LOCAL_NAMES_XSI = new String[] { "nil", "type" };
/*     */   
/* 177 */   public static final String[] PREFIXES_XSD = new String[0];
/* 178 */   public static final String[] LOCAL_NAMES_XSD = new String[] { "ENTITIES", "ENTITY", "ID", "IDREF", "IDREFS", "NCName", "NMTOKEN", "NMTOKENS", "NOTATION", "Name", "QName", "anySimpleType", "anyType", "anyURI", "base64Binary", "boolean", "byte", "date", "dateTime", "decimal", "double", "duration", "float", "gDay", "gMonth", "gMonthDay", "gYear", "gYearMonth", "hexBinary", "int", "integer", "language", "long", "negativeInteger", "nonNegativeInteger", "nonPositiveInteger", "normalizedString", "positiveInteger", "short", "string", "time", "token", "unsignedByte", "unsignedInt", "unsignedLong", "unsignedShort" };
/*     */ 
/*     */   
/*     */   public static final String EMPTY_STRING = "";
/*     */ 
/*     */   
/*     */   public static final String XSI_SCHEMA_LOCATION = "schemaLocation";
/*     */   
/*     */   public static final String XSI_NONAMESPACE_SCHEMA_LOCATION = "noNamespaceSchemaLocation";
/*     */   
/*     */   public static final String XML_NS_PREFIX = "xml";
/*     */   
/*     */   public static final String XML_NULL_NS_URI = "";
/*     */   
/*     */   public static final String XML_DEFAULT_NS_PREFIX = "";
/*     */   
/*     */   public static final String XML_NS_ATTRIBUTE_NS_URI = "http://www.w3.org/2000/xmlns/";
/*     */   
/*     */   public static final String XML_NS_ATTRIBUTE = "xmlns";
/*     */   
/*     */   public static final String XML_NS_URI = "http://www.w3.org/XML/1998/namespace";
/*     */   
/*     */   public static final String XML_SCHEMA_INSTANCE_NS_URI = "http://www.w3.org/2001/XMLSchema-instance";
/*     */   
/*     */   public static final String XML_SCHEMA_NS_URI = "http://www.w3.org/2001/XMLSchema";
/*     */   
/*     */   public static final String XSI_PFX = "xsi";
/*     */   
/*     */   public static final String XSI_TYPE = "type";
/*     */   
/*     */   public static final String XSI_NIL = "nil";
/*     */   
/*     */   public static final String COLON = ":";
/*     */   
/*     */   public static final String XSD_LIST_DELIM = " ";
/*     */   
/*     */   public static final char XSD_LIST_DELIM_CHAR = ' ';
/*     */   
/* 216 */   public static final char[] XSD_LIST_DELIM_CHAR_ARRAY = new char[] { ' ' };
/*     */ 
/*     */   
/*     */   public static final String XSD_ANY_TYPE = "anyType";
/*     */ 
/*     */   
/*     */   public static final String XSD_BOOLEAN_TRUE = "true";
/*     */   
/*     */   public static final String XSD_BOOLEAN_1 = "1";
/*     */   
/*     */   public static final String XSD_BOOLEAN_FALSE = "false";
/*     */   
/*     */   public static final String XSD_BOOLEAN_0 = "0";
/*     */   
/* 230 */   public static final char[] XSD_BOOLEAN_TRUE_ARRAY = "true"
/* 231 */     .toCharArray();
/* 232 */   public static final char[] XSD_BOOLEAN_1_ARRAY = "1"
/* 233 */     .toCharArray();
/* 234 */   public static final char[] XSD_BOOLEAN_FALSE_ARRAY = "false"
/* 235 */     .toCharArray();
/* 236 */   public static final char[] XSD_BOOLEAN_0_ARRAY = "0"
/* 237 */     .toCharArray();
/*     */   
/*     */   public static final String DECODED_BOOLEAN_TRUE = "true";
/*     */   public static final String DECODED_BOOLEAN_FALSE = "false";
/* 241 */   public static final char[] DECODED_BOOLEAN_TRUE_ARRAY = "true"
/* 242 */     .toCharArray();
/* 243 */   public static final char[] DECODED_BOOLEAN_FALSE_ARRAY = "false"
/* 244 */     .toCharArray();
/*     */ 
/*     */   
/*     */   public static final int NOT_FOUND = -1;
/*     */ 
/*     */   
/*     */   public static final int MAX_NUMBER_OF_VALUES = 100;
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_BLOCK_SIZE = 1000000;
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_VALUE_MAX_LENGTH = -1;
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_VALUE_PARTITON_CAPACITY = -1;
/*     */   
/*     */   public static final String FLOAT_INFINITY = "INF";
/*     */   
/*     */   public static final String FLOAT_MINUS_INFINITY = "-INF";
/*     */   
/*     */   public static final String FLOAT_NOT_A_NUMBER = "NaN";
/*     */   
/* 267 */   public static final char[] FLOAT_INFINITY_CHARARRAY = "INF"
/* 268 */     .toCharArray();
/* 269 */   public static final char[] FLOAT_MINUS_INFINITY_CHARARRAY = "-INF"
/* 270 */     .toCharArray();
/* 271 */   public static final char[] FLOAT_NOT_A_NUMBER_CHARARRAY = "NaN"
/* 272 */     .toCharArray();
/*     */   public static final int FLOAT_SPECIAL_VALUES = -16384;
/*     */   public static final int FLOAT_MANTISSA_INFINITY = 1;
/*     */   public static final int FLOAT_MANTISSA_MINUS_INFINITY = -1;
/*     */   public static final int FLOAT_MANTISSA_NOT_A_NUMBER = 0;
/*     */   public static final long FLOAT_EXPONENT_MIN_RANGE = -16383L;
/*     */   public static final long FLOAT_EXPONENT_MAX_RANGE = 16383L;
/*     */   public static final long FLOAT_MANTISSA_MIN_RANGE = -9223372036854775808L;
/*     */   public static final long FLOAT_MANTISSA_MAX_RANGE = 9223372036854775807L;
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */