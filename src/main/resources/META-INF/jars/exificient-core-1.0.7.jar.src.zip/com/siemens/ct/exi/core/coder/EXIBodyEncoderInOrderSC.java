/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.exceptions.ErrorHandler;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIBodyEncoderInOrderSC
/*     */   extends EXIBodyEncoderInOrder
/*     */ {
/*     */   protected EXIBodyEncoderInOrderSC scEncoder;
/*     */   
/*     */   public EXIBodyEncoderInOrderSC(EXIFactory exiFactory) throws EXIException {
/*  74 */     super(exiFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initForEachRun() throws EXIException, IOException {
/*  79 */     super.initForEachRun();
/*     */ 
/*     */     
/*  82 */     this.scEncoder = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setErrorHandler(ErrorHandler errorHandler) {
/*  87 */     if (this.scEncoder == null) {
/*  88 */       super.setErrorHandler(errorHandler);
/*     */     } else {
/*  90 */       this.scEncoder.setErrorHandler(errorHandler);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeStartDocument() throws EXIException, IOException {
/*  96 */     if (this.scEncoder == null) {
/*  97 */       super.encodeStartDocument();
/*     */     } else {
/*  99 */       this.scEncoder.encodeStartDocument();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeEndDocument() throws EXIException, IOException {
/* 105 */     if (this.scEncoder == null) {
/* 106 */       super.encodeEndDocument();
/*     */     } else {
/* 108 */       this.scEncoder.encodeEndDocument();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void encodeEndSC() throws EXIException, IOException {
/* 114 */     this.scEncoder.encodeEndDocument();
/*     */ 
/*     */     
/* 117 */     this.channel.align();
/*     */     
/* 119 */     this.scEncoder = null;
/* 120 */     popElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeStartElement(String uri, String localName, String prefix) throws EXIException, IOException {
/* 137 */     if (this.scEncoder == null) {
/* 138 */       super.encodeStartElement(uri, localName, prefix);
/* 139 */       QName qname = (getElementContext()).qnameContext.getQName();
/*     */ 
/*     */       
/* 142 */       if (this.exiFactory.isSelfContainedElement(qname)) {
/* 143 */         int ec2 = this.fidelityOptions.get2ndLevelEventCode(EventType.SELF_CONTAINED, 
/* 144 */             getCurrentGrammar());
/* 145 */         encode2ndLevelEventCode(ec2);
/*     */ 
/*     */ 
/*     */         
/* 149 */         this.channel.align();
/*     */ 
/*     */         
/* 152 */         if (this.exiFactory.getSelfContainedHandler() != null) {
/* 153 */           this.exiFactory.getSelfContainedHandler().scElement(uri, localName, this.channel);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 158 */         encodeStartSC(uri, localName, prefix);
/*     */       } 
/*     */     } else {
/* 161 */       this.scEncoder.encodeStartElement(uri, localName, prefix);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encodeStartSC(String uri, String localName, String prefix) throws EXIException, IOException {
/* 169 */     EXIFactory scEXIFactory = this.exiFactory.clone();
/* 170 */     scEXIFactory.setFragment(true);
/* 171 */     this
/* 172 */       .scEncoder = (EXIBodyEncoderInOrderSC)scEXIFactory.createEXIBodyEncoder();
/* 173 */     this.scEncoder.channel = this.channel;
/* 174 */     this.scEncoder.setErrorHandler(this.errorHandler);
/*     */ 
/*     */ 
/*     */     
/* 178 */     this.scEncoder.encodeStartDocument();
/*     */     
/* 180 */     this.scEncoder.encodeStartElementNoSC(uri, localName, prefix);
/*     */     
/* 182 */     if (this.preservePrefix)
/*     */     {
/* 184 */       this.scEncoder.encodeNamespaceDeclaration(uri, prefix);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void encodeStartElementNoSC(String uri, String localName, String prefix) throws EXIException, IOException {
/* 190 */     super.encodeStartElement(uri, localName, prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeEndElement() throws EXIException, IOException {
/* 195 */     if (this.scEncoder == null) {
/* 196 */       super.encodeEndElement();
/*     */     } else {
/*     */       
/* 199 */       QName qname = (this.scEncoder.getElementContext()).qnameContext.getQName();
/*     */       
/* 201 */       this.scEncoder.encodeEndElement();
/*     */       
/* 203 */       if ((getElementContext()).qnameContext.getQName().equals(qname) && this.scEncoder
/* 204 */         .getCurrentGrammar().getProduction(EventType.END_DOCUMENT) != null)
/*     */       {
/* 206 */         encodeEndSC();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAttribute(String uri, String localName, String prefix, Value value) throws EXIException, IOException {
/* 214 */     if (this.scEncoder == null) {
/* 215 */       super.encodeAttribute(uri, localName, prefix, value);
/*     */     } else {
/* 217 */       this.scEncoder.encodeAttribute(uri, localName, prefix, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAttribute(QName at, Value value) throws EXIException, IOException {
/* 224 */     if (this.scEncoder == null) {
/* 225 */       super.encodeAttribute(at, value);
/*     */     } else {
/* 227 */       this.scEncoder.encodeAttribute(at, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeNamespaceDeclaration(String uri, String prefix) throws EXIException, IOException {
/* 234 */     if (this.scEncoder == null) {
/* 235 */       super.encodeNamespaceDeclaration(uri, prefix);
/*     */     } else {
/* 237 */       this.scEncoder.encodeNamespaceDeclaration(uri, prefix);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAttributeXsiNil(Value nil, String pfx) throws EXIException, IOException {
/* 244 */     if (this.scEncoder == null) {
/* 245 */       super.encodeAttributeXsiNil(nil, pfx);
/*     */     } else {
/* 247 */       this.scEncoder.encodeAttributeXsiNil(nil, pfx);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAttributeXsiType(Value type, String pfx) throws EXIException, IOException {
/* 254 */     if (this.scEncoder == null) {
/* 255 */       super.encodeAttributeXsiType(type, pfx);
/*     */     } else {
/* 257 */       this.scEncoder.encodeAttributeXsiType(type, pfx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeCharacters(Value chars) throws EXIException, IOException {
/* 263 */     if (this.scEncoder == null) {
/* 264 */       super.encodeCharacters(chars);
/*     */     } else {
/* 266 */       this.scEncoder.encodeCharacters(chars);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeDocType(String name, String publicID, String systemID, String text) throws EXIException, IOException {
/* 273 */     if (this.scEncoder == null) {
/* 274 */       super.encodeDocType(name, publicID, systemID, text);
/*     */     } else {
/* 276 */       this.scEncoder.encodeDocType(name, publicID, systemID, text);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeEntityReference(String name) throws EXIException, IOException {
/* 283 */     if (this.scEncoder == null) {
/* 284 */       super.encodeEntityReference(name);
/*     */     } else {
/* 286 */       this.scEncoder.encodeEntityReference(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeComment(char[] ch, int start, int length) throws EXIException, IOException {
/* 293 */     if (this.scEncoder == null) {
/* 294 */       super.encodeComment(ch, start, length);
/*     */     } else {
/* 296 */       this.scEncoder.encodeComment(ch, start, length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeProcessingInstruction(String target, String data) throws EXIException, IOException {
/* 303 */     if (this.scEncoder == null) {
/* 304 */       super.encodeProcessingInstruction(target, data);
/*     */     } else {
/* 306 */       this.scEncoder.encodeProcessingInstruction(target, data);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIBodyEncoderInOrderSC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */