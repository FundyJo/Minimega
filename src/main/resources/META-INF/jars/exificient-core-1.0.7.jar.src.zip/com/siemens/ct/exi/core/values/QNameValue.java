/*     */ package com.siemens.ct.exi.core.values;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QNameValue
/*     */   extends AbstractValue
/*     */ {
/*     */   protected final String namespaceUri;
/*     */   protected final String localName;
/*     */   protected final String prefix;
/*     */   protected char[] characters;
/*     */   protected final String sValue;
/*     */   
/*     */   public QNameValue(String namespaceUri, String localName, String prefix) {
/*  43 */     super(ValueType.QNAME);
/*  44 */     this.namespaceUri = namespaceUri;
/*  45 */     this.localName = localName;
/*  46 */     this.prefix = prefix;
/*     */     
/*  48 */     if (prefix == null || prefix.length() == 0) {
/*  49 */       this.sValue = localName;
/*     */     } else {
/*  51 */       this.sValue = prefix + ":" + localName;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getNamespaceUri() {
/*  56 */     return this.namespaceUri;
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/*  60 */     return this.localName;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  64 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public int getCharactersLength() {
/*  68 */     return this.sValue.length();
/*     */   }
/*     */   
/*     */   public char[] getCharacters() {
/*  72 */     if (this.characters == null) {
/*  73 */       int len = this.sValue.length();
/*  74 */       this.characters = new char[len];
/*  75 */       this.sValue.getChars(0, this.sValue.length(), this.characters, 0);
/*     */     } 
/*  77 */     return this.characters;
/*     */   }
/*     */   
/*     */   public void getCharacters(char[] cbuffer, int offset) {
/*  81 */     for (int i = 0; i < this.sValue.length(); i++) {
/*  82 */       cbuffer[i + offset] = this.sValue.charAt(i);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  88 */     return this.sValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(char[] cbuffer, int offset) {
/*  93 */     return this.sValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  98 */     if (o == null) {
/*  99 */       return false;
/*     */     }
/* 101 */     if (o instanceof QNameValue) {
/* 102 */       QNameValue other = (QNameValue)o;
/* 103 */       return (this.namespaceUri.equals(other.namespaceUri) && this.localName
/* 104 */         .equals(other.localName));
/*     */     } 
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 112 */     return this.namespaceUri.hashCode() ^ this.localName.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\QNameValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */