package com.siemens.ct.exi.core.attributes;

import com.siemens.ct.exi.core.container.NamespaceDeclaration;
import javax.xml.namespace.QName;

public interface AttributeList {
  void clear();
  
  void addNamespaceDeclaration(String paramString1, String paramString2);
  
  int getNumberOfNamespaceDeclarations();
  
  NamespaceDeclaration getNamespaceDeclaration(int paramInt);
  
  void addAttribute(String paramString1, String paramString2, String paramString3, String paramString4);
  
  void addAttribute(QName paramQName, String paramString);
  
  boolean hasXsiType();
  
  String getXsiTypeRaw();
  
  String getXsiTypePrefix();
  
  boolean hasXsiNil();
  
  String getXsiNil();
  
  String getXsiNilPrefix();
  
  int getNumberOfAttributes();
  
  String getAttributeURI(int paramInt);
  
  String getAttributeLocalName(int paramInt);
  
  String getAttributeValue(int paramInt);
  
  String getAttributePrefix(int paramInt);
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\attributes\AttributeList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */