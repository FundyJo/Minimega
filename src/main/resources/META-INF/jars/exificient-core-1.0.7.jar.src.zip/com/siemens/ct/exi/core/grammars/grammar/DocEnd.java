/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocEnd
/*    */   extends AbstractSchemaInformedGrammar
/*    */ {
/*    */   public DocEnd() {}
/*    */   
/*    */   public DocEnd(String label) {
/* 43 */     this();
/* 44 */     setLabel(label);
/*    */   }
/*    */   
/*    */   public GrammarType getGrammarType() {
/* 48 */     return GrammarType.DOC_END;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 52 */     return "DocEnd" + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\DocEnd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */