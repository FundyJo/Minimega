/*     */ package com.siemens.ct.exi.core;
/*     */ 
/*     */ import com.siemens.ct.exi.core.exceptions.UnsupportedOption;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.GrammarType;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedStartTagGrammar;
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FidelityOptions
/*     */ {
/*     */   public static final String FEATURE_COMMENT = "PRESERVE_COMMENTS";
/*     */   public static final String FEATURE_PI = "PRESERVE_PIS";
/*     */   public static final String FEATURE_DTD = "PRESERVE_DTDS";
/*     */   public static final String FEATURE_PREFIX = "PRESERVE_PREFIXES";
/*     */   public static final String FEATURE_LEXICAL_VALUE = "PRESERVE_LEXICAL_VALUES";
/*     */   public static final String FEATURE_SC = "SELF_CONTAINED";
/*     */   public static final String FEATURE_STRICT = "STRICT";
/*     */   protected Set<String> options;
/*     */   protected boolean isStrict = false;
/*     */   protected boolean isComment = false;
/*     */   protected boolean isPI = false;
/*     */   protected boolean isDTD = false;
/*     */   protected boolean isPrefix = false;
/*     */   protected boolean isLexicalValue = false;
/*     */   protected boolean isSC = false;
/*     */   
/*     */   protected FidelityOptions() {
/*  84 */     this.options = new HashSet<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FidelityOptions createDefault() {
/*  93 */     FidelityOptions fo = new FidelityOptions();
/*     */     
/*  95 */     return fo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FidelityOptions createStrict() {
/* 105 */     FidelityOptions fo = new FidelityOptions();
/*     */     
/* 107 */     fo.options.add("STRICT");
/* 108 */     fo.isStrict = true;
/*     */     
/* 110 */     return fo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FidelityOptions createAll() {
/* 125 */     FidelityOptions fo = new FidelityOptions();
/*     */     
/* 127 */     fo.options.add("PRESERVE_COMMENTS");
/* 128 */     fo.isComment = true;
/* 129 */     fo.options.add("PRESERVE_PIS");
/* 130 */     fo.isPI = true;
/* 131 */     fo.options.add("PRESERVE_DTDS");
/* 132 */     fo.isDTD = true;
/* 133 */     fo.options.add("PRESERVE_PREFIXES");
/* 134 */     fo.isPrefix = true;
/* 135 */     fo.options.add("PRESERVE_LEXICAL_VALUES");
/* 136 */     fo.isLexicalValue = true;
/*     */ 
/*     */ 
/*     */     
/* 140 */     return fo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFidelity(String key, boolean decision) throws UnsupportedOption {
/* 155 */     if (key.equals("STRICT")) {
/* 156 */       if (decision) {
/*     */ 
/*     */ 
/*     */         
/* 160 */         boolean prevContainedLexVal = this.options.contains("PRESERVE_LEXICAL_VALUES");
/*     */         
/* 162 */         this.options.clear();
/* 163 */         this.isComment = false;
/* 164 */         this.isPI = false;
/* 165 */         this.isDTD = false;
/* 166 */         this.isPrefix = false;
/* 167 */         this.isLexicalValue = false;
/* 168 */         this.isSC = false;
/*     */         
/* 170 */         if (prevContainedLexVal) {
/* 171 */           this.options.add("PRESERVE_LEXICAL_VALUES");
/* 172 */           this.isLexicalValue = true;
/*     */         } 
/* 174 */         this.options.add("STRICT");
/*     */         
/* 176 */         this.isStrict = true;
/*     */       } else {
/*     */         
/* 179 */         this.options.remove(key);
/* 180 */         this.isStrict = false;
/*     */       } 
/* 182 */     } else if (key.equals("PRESERVE_LEXICAL_VALUES")) {
/*     */       
/* 184 */       if (decision) {
/* 185 */         this.options.add(key);
/* 186 */         this.isLexicalValue = true;
/*     */       } else {
/*     */         
/* 189 */         this.options.remove(key);
/* 190 */         this.isLexicalValue = false;
/*     */       } 
/* 192 */     } else if (key.equals("PRESERVE_COMMENTS") || key.equals("PRESERVE_PIS") || key
/* 193 */       .equals("PRESERVE_DTDS") || key.equals("PRESERVE_PREFIXES") || key
/* 194 */       .equals("SELF_CONTAINED")) {
/* 195 */       if (decision) {
/* 196 */         if (isStrict()) {
/* 197 */           this.options.remove("STRICT");
/* 198 */           this.isStrict = false;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 203 */         this.options.add(key);
/* 204 */         if (key.equals("PRESERVE_COMMENTS")) {
/* 205 */           this.isComment = true;
/*     */         }
/* 207 */         if (key.equals("PRESERVE_PIS")) {
/* 208 */           this.isPI = true;
/*     */         }
/* 210 */         if (key.equals("PRESERVE_DTDS")) {
/* 211 */           this.isDTD = true;
/*     */         }
/* 213 */         if (key.equals("PRESERVE_PREFIXES")) {
/* 214 */           this.isPrefix = true;
/*     */         }
/* 216 */         if (key.equals("SELF_CONTAINED")) {
/* 217 */           this.isSC = true;
/*     */         }
/*     */       } else {
/*     */         
/* 221 */         this.options.remove(key);
/* 222 */         if (key.equals("PRESERVE_COMMENTS")) {
/* 223 */           this.isComment = false;
/*     */         }
/* 225 */         if (key.equals("PRESERVE_PIS")) {
/* 226 */           this.isPI = false;
/*     */         }
/* 228 */         if (key.equals("PRESERVE_DTDS")) {
/* 229 */           this.isDTD = false;
/*     */         }
/* 231 */         if (key.equals("PRESERVE_PREFIXES")) {
/* 232 */           this.isPrefix = false;
/*     */         }
/* 234 */         if (key.equals("SELF_CONTAINED")) {
/* 235 */           this.isSC = false;
/*     */         }
/*     */       } 
/*     */     } else {
/* 239 */       throw new UnsupportedOption("FidelityOption '" + key + "' is unknown!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFidelityEnabled(String key) {
/* 252 */     return this.options.contains(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isStrict() {
/* 262 */     return this.isStrict;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 267 */     if (o instanceof FidelityOptions) {
/* 268 */       FidelityOptions other = (FidelityOptions)o;
/* 269 */       return this.options.equals(other.options);
/*     */     } 
/*     */     
/* 272 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 277 */     return this.options.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 282 */     return this.options.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int get1stLevelEventCodeLength(Grammar grammar) {
/* 288 */     switch (grammar.getGrammarType())
/*     */     
/*     */     { case DOCUMENT:
/*     */       case FRAGMENT:
/* 292 */         cl1 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 328 */         return cl1;case DOC_END: if (this.isComment || this.isPI) { cl1 = 1; } else { cl1 = 0; }  return cl1;case SCHEMA_INFORMED_DOC_CONTENT: case BUILT_IN_DOC_CONTENT: cl1 = MethodsBag.getCodingLength(grammar.getNumberOfEvents() + ((this.isDTD || this.isComment || this.isPI) ? 1 : 0)); return cl1;case SCHEMA_INFORMED_FRAGMENT_CONTENT: case BUILT_IN_FRAGMENT_CONTENT: cl1 = MethodsBag.getCodingLength(grammar.getNumberOfEvents() + ((this.isComment || this.isPI) ? 1 : 0)); return cl1;case SCHEMA_INFORMED_FIRST_START_TAG_CONTENT: case SCHEMA_INFORMED_START_TAG_CONTENT: case SCHEMA_INFORMED_ELEMENT_CONTENT: cl1 = MethodsBag.getCodingLength(grammar.getNumberOfEvents() + ((get2ndLevelCharacteristics(grammar) > 0) ? 1 : 0)); return cl1;case BUILT_IN_START_TAG_CONTENT: case BUILT_IN_ELEMENT_CONTENT: cl1 = MethodsBag.getCodingLength(grammar.getNumberOfEvents() + 1); return cl1; }  int cl1 = -1; return cl1; } public EventType get2ndLevelEventType(int ec2, Grammar grammar) { SchemaInformedFirstStartTagGrammar sifst; int dec; SchemaInformedStartTagGrammar sist;
/*     */     int i;
/*     */     SchemaInformedGrammar sig;
/*     */     int j;
/* 332 */     EventType eventType = null;
/*     */     
/* 334 */     switch (grammar.getGrammarType()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case SCHEMA_INFORMED_DOC_CONTENT:
/*     */       case BUILT_IN_DOC_CONTENT:
/* 346 */         if (this.isDTD && ec2 == 0) {
/* 347 */           eventType = EventType.DOC_TYPE;
/*     */         }
/*     */         break;
/*     */       
/*     */       case SCHEMA_INFORMED_FIRST_START_TAG_CONTENT:
/* 352 */         sifst = (SchemaInformedFirstStartTagGrammar)grammar;
/* 353 */         if (this.isStrict) {
/*     */           
/* 355 */           if (sifst.isTypeCastable()) {
/* 356 */             if (ec2 == 0) {
/* 357 */               eventType = EventType.ATTRIBUTE_XSI_TYPE; break;
/* 358 */             }  if (ec2 == 1)
/* 359 */               eventType = EventType.ATTRIBUTE_XSI_NIL;  break;
/*     */           } 
/* 361 */           if (sifst.isNillable() && ec2 == 0) {
/* 362 */             eventType = EventType.ATTRIBUTE_XSI_NIL;
/*     */           }
/*     */           
/*     */           break;
/*     */         } 
/* 367 */         dec = 0;
/* 368 */         if (sifst.hasEndElement()) {
/* 369 */           dec++;
/*     */         }
/* 371 */         if (ec2 == 0 - dec) {
/* 372 */           eventType = EventType.END_ELEMENT_UNDECLARED; break;
/*     */         } 
/* 374 */         if (ec2 == 1 - dec) {
/* 375 */           eventType = EventType.ATTRIBUTE_XSI_TYPE; break;
/* 376 */         }  if (ec2 == 2 - dec) {
/* 377 */           eventType = EventType.ATTRIBUTE_XSI_NIL; break;
/* 378 */         }  if (ec2 == 3 - dec) {
/* 379 */           eventType = EventType.ATTRIBUTE_GENERIC_UNDECLARED; break;
/* 380 */         }  if (ec2 == 4 - dec) {
/* 381 */           eventType = EventType.ATTRIBUTE_INVALID_VALUE; break;
/*     */         } 
/* 383 */         if (!this.isPrefix) {
/* 384 */           dec++;
/*     */         }
/* 386 */         if (ec2 == 5 - dec) {
/* 387 */           eventType = EventType.NAMESPACE_DECLARATION; break;
/*     */         } 
/* 389 */         if (!this.isSC) {
/* 390 */           dec++;
/*     */         }
/* 392 */         if (ec2 == 6 - dec) {
/* 393 */           eventType = EventType.SELF_CONTAINED; break;
/*     */         } 
/* 395 */         if (ec2 == 7 - dec) {
/* 396 */           eventType = EventType.START_ELEMENT_GENERIC_UNDECLARED; break;
/* 397 */         }  if (ec2 == 8 - dec) {
/* 398 */           eventType = EventType.CHARACTERS_GENERIC_UNDECLARED; break;
/*     */         } 
/* 400 */         if (!this.isDTD) {
/* 401 */           dec++;
/*     */         }
/* 403 */         if (ec2 == 9 - dec) {
/* 404 */           eventType = EventType.ENTITY_REFERENCE;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case SCHEMA_INFORMED_START_TAG_CONTENT:
/* 414 */         sist = (SchemaInformedStartTagGrammar)grammar;
/* 415 */         if (this.isStrict) {
/*     */           break;
/*     */         }
/*     */         
/* 419 */         i = 0;
/* 420 */         if (sist.hasEndElement()) {
/* 421 */           i++;
/*     */         }
/* 423 */         if (ec2 == 0 - i) {
/* 424 */           eventType = EventType.END_ELEMENT_UNDECLARED; break;
/*     */         } 
/* 426 */         if (ec2 == 1 - i) {
/* 427 */           eventType = EventType.ATTRIBUTE_GENERIC_UNDECLARED; break;
/* 428 */         }  if (ec2 == 2 - i) {
/* 429 */           eventType = EventType.ATTRIBUTE_INVALID_VALUE; break;
/*     */         } 
/* 431 */         if (ec2 == 3 - i) {
/* 432 */           eventType = EventType.START_ELEMENT_GENERIC_UNDECLARED; break;
/* 433 */         }  if (ec2 == 4 - i) {
/* 434 */           eventType = EventType.CHARACTERS_GENERIC_UNDECLARED; break;
/*     */         } 
/* 436 */         if (!this.isDTD) {
/* 437 */           i++;
/*     */         }
/* 439 */         if (ec2 == 5 - i) {
/* 440 */           eventType = EventType.ENTITY_REFERENCE;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case SCHEMA_INFORMED_ELEMENT_CONTENT:
/* 448 */         sig = (SchemaInformedGrammar)grammar;
/* 449 */         if (this.isStrict) {
/*     */           break;
/*     */         }
/*     */         
/* 453 */         j = 0;
/* 454 */         if (sig.hasEndElement()) {
/* 455 */           j++;
/*     */         }
/* 457 */         if (ec2 == 0 - j) {
/* 458 */           eventType = EventType.END_ELEMENT_UNDECLARED; break;
/*     */         } 
/* 460 */         if (ec2 == 1 - j) {
/* 461 */           eventType = EventType.START_ELEMENT_GENERIC_UNDECLARED; break;
/* 462 */         }  if (ec2 == 2 - j) {
/* 463 */           eventType = EventType.CHARACTERS_GENERIC_UNDECLARED; break;
/*     */         } 
/* 465 */         if (!this.isDTD) {
/* 466 */           j++;
/*     */         }
/* 468 */         if (ec2 == 3 - j) {
/* 469 */           eventType = EventType.ENTITY_REFERENCE;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case BUILT_IN_START_TAG_CONTENT:
/* 478 */         if (ec2 == 0) {
/* 479 */           eventType = EventType.END_ELEMENT_UNDECLARED; break;
/*     */         } 
/* 481 */         if (ec2 == 1) {
/* 482 */           eventType = EventType.ATTRIBUTE_GENERIC_UNDECLARED; break;
/*     */         } 
/* 484 */         j = 0;
/* 485 */         if (!this.isPrefix) {
/* 486 */           j++;
/*     */         }
/* 488 */         if (ec2 == 2 - j) {
/* 489 */           eventType = EventType.NAMESPACE_DECLARATION; break;
/*     */         } 
/* 491 */         if (!this.isSC) {
/* 492 */           j++;
/*     */         }
/* 494 */         if (ec2 == 3 - j) {
/* 495 */           eventType = EventType.SELF_CONTAINED; break;
/*     */         } 
/* 497 */         if (ec2 == 4 - j) {
/* 498 */           eventType = EventType.START_ELEMENT_GENERIC_UNDECLARED; break;
/* 499 */         }  if (ec2 == 5 - j) {
/* 500 */           eventType = EventType.CHARACTERS_GENERIC_UNDECLARED; break;
/*     */         } 
/* 502 */         if (!this.isDTD) {
/* 503 */           j++;
/*     */         }
/* 505 */         if (ec2 == 6 - j) {
/* 506 */           eventType = EventType.ENTITY_REFERENCE;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case BUILT_IN_ELEMENT_CONTENT:
/* 516 */         if (ec2 == 0) {
/* 517 */           eventType = EventType.START_ELEMENT_GENERIC_UNDECLARED; break;
/* 518 */         }  if (ec2 == 1) {
/* 519 */           eventType = EventType.CHARACTERS_GENERIC_UNDECLARED; break;
/*     */         } 
/* 521 */         if (this.isDTD && ec2 == 2) {
/* 522 */           eventType = EventType.ENTITY_REFERENCE;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 528 */     return eventType; } public int get2ndLevelEventCode(EventType eventType, Grammar grammar) { SchemaInformedFirstStartTagGrammar sifst; int dec;
/*     */     SchemaInformedStartTagGrammar sist;
/*     */     int i;
/*     */     SchemaInformedGrammar sig;
/* 532 */     int j, ec2 = -1;
/* 533 */     switch (grammar.getGrammarType()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case SCHEMA_INFORMED_DOC_CONTENT:
/*     */       case BUILT_IN_DOC_CONTENT:
/* 545 */         if (this.isDTD && eventType == EventType.DOC_TYPE) {
/* 546 */           ec2 = 0;
/*     */         }
/*     */         break;
/*     */       
/*     */       case SCHEMA_INFORMED_FIRST_START_TAG_CONTENT:
/* 551 */         sifst = (SchemaInformedFirstStartTagGrammar)grammar;
/* 552 */         if (this.isStrict) {
/*     */           
/* 554 */           if (sifst.isTypeCastable()) {
/* 555 */             if (eventType == EventType.ATTRIBUTE_XSI_TYPE) {
/* 556 */               ec2 = 0; break;
/* 557 */             }  if (eventType == EventType.ATTRIBUTE_XSI_NIL)
/* 558 */               ec2 = 1;  break;
/*     */           } 
/* 560 */           if (sifst.isNillable() && eventType == EventType.ATTRIBUTE_XSI_NIL)
/*     */           {
/* 562 */             ec2 = 0;
/*     */           }
/*     */           
/*     */           break;
/*     */         } 
/* 567 */         dec = 0;
/* 568 */         if (sifst.hasEndElement()) {
/* 569 */           dec++;
/*     */         }
/* 571 */         if (eventType == EventType.END_ELEMENT_UNDECLARED) {
/* 572 */           ec2 = 0 - dec; break;
/*     */         } 
/* 574 */         if (eventType == EventType.ATTRIBUTE_XSI_TYPE) {
/* 575 */           ec2 = 1 - dec; break;
/* 576 */         }  if (eventType == EventType.ATTRIBUTE_XSI_NIL) {
/* 577 */           ec2 = 2 - dec; break;
/* 578 */         }  if (eventType == EventType.ATTRIBUTE_GENERIC_UNDECLARED) {
/* 579 */           ec2 = 3 - dec; break;
/* 580 */         }  if (eventType == EventType.ATTRIBUTE_INVALID_VALUE) {
/* 581 */           ec2 = 4 - dec; break;
/*     */         } 
/* 583 */         if (!this.isPrefix) {
/* 584 */           dec++;
/*     */         }
/* 586 */         if (eventType == EventType.NAMESPACE_DECLARATION) {
/* 587 */           ec2 = 5 - dec; break;
/*     */         } 
/* 589 */         if (!this.isSC) {
/* 590 */           dec++;
/*     */         }
/* 592 */         if (eventType == EventType.SELF_CONTAINED) {
/* 593 */           ec2 = 6 - dec; break;
/*     */         } 
/* 595 */         if (eventType == EventType.START_ELEMENT_GENERIC_UNDECLARED) {
/* 596 */           ec2 = 7 - dec; break;
/* 597 */         }  if (eventType == EventType.CHARACTERS_GENERIC_UNDECLARED) {
/* 598 */           ec2 = 8 - dec; break;
/*     */         } 
/* 600 */         if (!this.isDTD) {
/* 601 */           dec++;
/*     */         }
/* 603 */         if (eventType == EventType.ENTITY_REFERENCE) {
/* 604 */           ec2 = 9 - dec;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case SCHEMA_INFORMED_START_TAG_CONTENT:
/* 614 */         sist = (SchemaInformedStartTagGrammar)grammar;
/* 615 */         if (this.isStrict) {
/*     */           break;
/*     */         }
/*     */         
/* 619 */         i = 0;
/* 620 */         if (sist.hasEndElement()) {
/* 621 */           i++;
/*     */         }
/* 623 */         if (eventType == EventType.END_ELEMENT_UNDECLARED) {
/* 624 */           ec2 = 0 - i; break;
/*     */         } 
/* 626 */         if (eventType == EventType.ATTRIBUTE_GENERIC_UNDECLARED) {
/* 627 */           ec2 = 1 - i; break;
/* 628 */         }  if (eventType == EventType.ATTRIBUTE_INVALID_VALUE) {
/* 629 */           ec2 = 2 - i; break;
/*     */         } 
/* 631 */         if (eventType == EventType.START_ELEMENT_GENERIC_UNDECLARED) {
/* 632 */           ec2 = 3 - i; break;
/* 633 */         }  if (eventType == EventType.CHARACTERS_GENERIC_UNDECLARED) {
/* 634 */           ec2 = 4 - i; break;
/*     */         } 
/* 636 */         if (!this.isDTD) {
/* 637 */           i++;
/*     */         }
/* 639 */         if (eventType == EventType.ENTITY_REFERENCE) {
/* 640 */           ec2 = 5 - i;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case SCHEMA_INFORMED_ELEMENT_CONTENT:
/* 648 */         sig = (SchemaInformedGrammar)grammar;
/* 649 */         if (this.isStrict) {
/*     */           break;
/*     */         }
/*     */         
/* 653 */         j = 0;
/* 654 */         if (sig.hasEndElement()) {
/* 655 */           j++;
/*     */         }
/* 657 */         if (eventType == EventType.END_ELEMENT_UNDECLARED) {
/* 658 */           ec2 = 0 - j; break;
/*     */         } 
/* 660 */         if (eventType == EventType.START_ELEMENT_GENERIC_UNDECLARED) {
/* 661 */           ec2 = 1 - j; break;
/* 662 */         }  if (eventType == EventType.CHARACTERS_GENERIC_UNDECLARED) {
/* 663 */           ec2 = 2 - j; break;
/*     */         } 
/* 665 */         if (!this.isDTD) {
/* 666 */           j++;
/*     */         }
/* 668 */         if (eventType == EventType.ENTITY_REFERENCE) {
/* 669 */           ec2 = 3 - j;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case BUILT_IN_START_TAG_CONTENT:
/* 678 */         if (eventType == EventType.END_ELEMENT_UNDECLARED) {
/* 679 */           ec2 = 0; break;
/*     */         } 
/* 681 */         if (eventType == EventType.ATTRIBUTE_GENERIC_UNDECLARED) {
/* 682 */           ec2 = 1; break;
/*     */         } 
/* 684 */         j = 0;
/* 685 */         if (!this.isPrefix) {
/* 686 */           j++;
/*     */         }
/* 688 */         if (eventType == EventType.NAMESPACE_DECLARATION) {
/* 689 */           ec2 = 2 - j; break;
/*     */         } 
/* 691 */         if (!this.isSC) {
/* 692 */           j++;
/*     */         }
/* 694 */         if (eventType == EventType.SELF_CONTAINED) {
/* 695 */           ec2 = 3 - j; break;
/*     */         } 
/* 697 */         if (eventType == EventType.START_ELEMENT_GENERIC_UNDECLARED) {
/* 698 */           ec2 = 4 - j; break;
/* 699 */         }  if (eventType == EventType.CHARACTERS_GENERIC_UNDECLARED) {
/* 700 */           ec2 = 5 - j; break;
/*     */         } 
/* 702 */         if (!this.isDTD) {
/* 703 */           j++;
/*     */         }
/* 705 */         if (eventType == EventType.ENTITY_REFERENCE) {
/* 706 */           ec2 = 6 - j;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case BUILT_IN_ELEMENT_CONTENT:
/* 716 */         if (eventType == EventType.START_ELEMENT_GENERIC_UNDECLARED) {
/* 717 */           ec2 = 0; break;
/* 718 */         }  if (eventType == EventType.CHARACTERS_GENERIC_UNDECLARED) {
/* 719 */           ec2 = 1; break;
/*     */         } 
/* 721 */         if (this.isDTD && eventType == EventType.ENTITY_REFERENCE) {
/* 722 */           ec2 = 2;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 728 */     return ec2; } public int get2ndLevelCharacteristics(Grammar grammar) {
/*     */     SchemaInformedFirstStartTagGrammar sifst;
/*     */     SchemaInformedStartTagGrammar sist;
/*     */     SchemaInformedGrammar sig;
/* 732 */     int ch2 = 0;
/* 733 */     switch (grammar.getGrammarType()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case DOC_END:
/* 740 */         if (get3rdLevelCharacteristics() > 0) {
/* 741 */           ch2++;
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case SCHEMA_INFORMED_DOC_CONTENT:
/*     */       case BUILT_IN_DOC_CONTENT:
/* 748 */         if (this.isDTD) {
/* 749 */           ch2++;
/*     */         }
/* 751 */         if (get3rdLevelCharacteristics() > 0) {
/* 752 */           ch2++;
/*     */         }
/*     */         break;
/*     */       case SCHEMA_INFORMED_FRAGMENT_CONTENT:
/*     */       case BUILT_IN_FRAGMENT_CONTENT:
/* 757 */         if (get3rdLevelCharacteristics() > 0) {
/* 758 */           ch2++;
/*     */         }
/*     */         break;
/*     */       
/*     */       case SCHEMA_INFORMED_FIRST_START_TAG_CONTENT:
/* 763 */         sifst = (SchemaInformedFirstStartTagGrammar)grammar;
/* 764 */         if (this.isStrict) {
/*     */ 
/*     */           
/* 767 */           ch2 = (sifst.isTypeCastable() ? 1 : 0) + (sifst.isNillable() ? 1 : 0);
/*     */           
/*     */           break;
/*     */         } 
/* 771 */         if (!sifst.hasEndElement()) {
/* 772 */           ch2++;
/*     */         }
/* 774 */         ch2 += 4;
/* 775 */         if (this.isPrefix) {
/* 776 */           ch2++;
/*     */         }
/* 778 */         if (this.isSC) {
/* 779 */           ch2++;
/*     */         }
/* 781 */         ch2 += 2;
/* 782 */         if (this.isDTD) {
/* 783 */           ch2++;
/*     */         }
/* 785 */         if (get3rdLevelCharacteristics() > 0) {
/* 786 */           ch2++;
/*     */         }
/*     */         break;
/*     */       
/*     */       case SCHEMA_INFORMED_START_TAG_CONTENT:
/* 791 */         sist = (SchemaInformedStartTagGrammar)grammar;
/* 792 */         if (this.isStrict) {
/*     */           break;
/*     */         }
/*     */         
/* 796 */         if (!sist.hasEndElement()) {
/* 797 */           ch2++;
/*     */         }
/* 799 */         ch2 += 4;
/* 800 */         if (this.isDTD) {
/* 801 */           ch2++;
/*     */         }
/* 803 */         if (get3rdLevelCharacteristics() > 0) {
/* 804 */           ch2++;
/*     */         }
/*     */         break;
/*     */       
/*     */       case SCHEMA_INFORMED_ELEMENT_CONTENT:
/* 809 */         sig = (SchemaInformedGrammar)grammar;
/* 810 */         if (this.isStrict) {
/*     */           break;
/*     */         }
/*     */         
/* 814 */         if (!sig.hasEndElement()) {
/* 815 */           ch2++;
/*     */         }
/* 817 */         ch2 += 2;
/* 818 */         if (this.isDTD) {
/* 819 */           ch2++;
/*     */         }
/* 821 */         if (get3rdLevelCharacteristics() > 0) {
/* 822 */           ch2++;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case BUILT_IN_START_TAG_CONTENT:
/* 829 */         ch2 += 2;
/* 830 */         if (this.isPrefix) {
/* 831 */           ch2++;
/*     */         }
/* 833 */         if (this.isSC) {
/* 834 */           ch2++;
/*     */         }
/* 836 */         ch2 += 2;
/* 837 */         if (this.isDTD) {
/* 838 */           ch2++;
/*     */         }
/* 840 */         if (get3rdLevelCharacteristics() > 0) {
/* 841 */           ch2++;
/*     */         }
/*     */         break;
/*     */       
/*     */       case BUILT_IN_ELEMENT_CONTENT:
/* 846 */         ch2 += 2;
/* 847 */         if (this.isDTD) {
/* 848 */           ch2++;
/*     */         }
/* 850 */         if (get3rdLevelCharacteristics() > 0) {
/* 851 */           ch2++;
/*     */         }
/*     */         break;
/*     */     } 
/* 855 */     return ch2;
/*     */   }
/*     */   
/*     */   public EventType get3rdLevelEventType(int ec3) {
/* 859 */     EventType eventType = null;
/*     */     
/* 861 */     if (ec3 == 0) {
/* 862 */       if (this.isComment)
/* 863 */         return EventType.COMMENT; 
/* 864 */       if (this.isPI) {
/* 865 */         eventType = EventType.PROCESSING_INSTRUCTION;
/*     */       }
/* 867 */     } else if (ec3 == 1) {
/* 868 */       assert isFidelityEnabled("PRESERVE_COMMENTS");
/* 869 */       assert this.isComment;
/* 870 */       assert isFidelityEnabled("PRESERVE_PIS");
/* 871 */       assert this.isPI;
/* 872 */       eventType = EventType.PROCESSING_INSTRUCTION;
/*     */     } 
/*     */     
/* 875 */     return eventType;
/*     */   }
/*     */   
/*     */   public int get3rdLevelEventCode(EventType eventType) {
/* 879 */     int ec3 = -1;
/*     */     
/* 881 */     if (!this.isStrict)
/*     */     {
/* 883 */       if (this.isComment) {
/* 884 */         if (EventType.COMMENT == eventType) {
/* 885 */           ec3 = 0;
/* 886 */         } else if (EventType.PROCESSING_INSTRUCTION == eventType) {
/* 887 */           ec3 = 1;
/*     */         } 
/* 889 */       } else if (this.isPI && 
/* 890 */         EventType.PROCESSING_INSTRUCTION == eventType) {
/* 891 */         ec3 = 0;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 896 */     return ec3;
/*     */   }
/*     */   
/*     */   public int get3rdLevelCharacteristics() {
/* 900 */     int ch = 0;
/* 901 */     if (this.isComment) {
/* 902 */       ch++;
/*     */     }
/* 904 */     if (this.isPI) {
/* 905 */       ch++;
/*     */     }
/* 907 */     return ch;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\FidelityOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */