/*     */ package com.siemens.ct.exi.core.context;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrammarUriContext
/*     */   extends AbstractUriContext
/*     */ {
/*  40 */   public static String[] EMPTY_PREFIXES = new String[0];
/*     */ 
/*     */   
/*     */   final QNameContext[] grammarQNames;
/*     */ 
/*     */   
/*     */   final String[] grammarPrefixes;
/*     */ 
/*     */   
/*     */   final String defaultPrefix;
/*     */ 
/*     */   
/*     */   public GrammarUriContext(int namespaceUriID, String namespaceUri, QNameContext[] grammarQNames, String[] grammarPrefixes) {
/*  53 */     super(namespaceUriID, namespaceUri);
/*  54 */     this.grammarQNames = grammarQNames;
/*  55 */     this.grammarPrefixes = grammarPrefixes;
/*     */     
/*  57 */     switch (namespaceUriID) {
/*     */       
/*     */       case 0:
/*  60 */         this.defaultPrefix = "";
/*     */         return;
/*     */       case 1:
/*  63 */         this.defaultPrefix = "xml";
/*     */         return;
/*     */       case 2:
/*  66 */         this.defaultPrefix = "xsi";
/*     */         return;
/*     */     } 
/*  69 */     this.defaultPrefix = "ns" + namespaceUriID;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultPrefix() {
/*  74 */     return this.defaultPrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public GrammarUriContext(int namespaceUriID, String namespaceUri, QNameContext[] grammarQNames) {
/*  79 */     this(namespaceUriID, namespaceUri, grammarQNames, EMPTY_PREFIXES);
/*     */   }
/*     */   
/*     */   public int getNumberOfQNames() {
/*  83 */     return this.grammarQNames.length;
/*     */   }
/*     */   
/*     */   public QNameContext getQNameContext(int localNameID) {
/*  87 */     if (localNameID < this.grammarQNames.length) {
/*  88 */       return this.grammarQNames[localNameID];
/*     */     }
/*  90 */     return null;
/*     */   }
/*     */   
/*     */   public QNameContext getQNameContext(String localName) {
/*  94 */     assert localName != null;
/*  95 */     return binarySearch(this.grammarQNames, localName);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static QNameContext binarySearch(QNameContext[] grammarQNames, String localName) {
/* 100 */     Objects.requireNonNull(grammarQNames, "grammarQNames parameter cannot be null");
/*     */     
/* 102 */     int low = 0;
/* 103 */     int high = grammarQNames.length - 1;
/*     */     
/* 105 */     while (low <= high) {
/* 106 */       int mid = low + high >> 1;
/* 107 */       QNameContext midVal = grammarQNames[mid];
/* 108 */       int cmp = midVal.compareTo(localName);
/*     */       
/* 110 */       if (cmp < 0) {
/* 111 */         low = mid + 1; continue;
/* 112 */       }  if (cmp > 0) {
/* 113 */         high = mid - 1;
/*     */         continue;
/*     */       } 
/* 116 */       return midVal;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 121 */     return null;
/*     */   }
/*     */   
/*     */   public int getNumberOfPrefixes() {
/* 125 */     return this.grammarPrefixes.length;
/*     */   }
/*     */   
/*     */   public String getPrefix(int prefixID) {
/* 129 */     assert prefixID >= 0;
/* 130 */     String pfx = null;
/* 131 */     if (prefixID < this.grammarPrefixes.length) {
/* 132 */       pfx = this.grammarPrefixes[prefixID];
/*     */     }
/* 134 */     return pfx;
/*     */   }
/*     */   
/*     */   public int getPrefixID(String prefix) {
/* 138 */     for (int i = 0; i < this.grammarPrefixes.length; i++) {
/* 139 */       String pfx = this.grammarPrefixes[i];
/* 140 */       if (pfx.equals(prefix)) {
/* 141 */         return i;
/*     */       }
/*     */     } 
/* 144 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 149 */     if (this == o)
/* 150 */       return true; 
/* 151 */     if (!(o instanceof GrammarUriContext))
/* 152 */       return false; 
/* 153 */     if (!super.equals(o)) {
/* 154 */       return false;
/*     */     }
/* 156 */     GrammarUriContext that = (GrammarUriContext)o;
/* 157 */     if (!super.equals(that))
/* 158 */       return false; 
/* 159 */     if (!Arrays.equals((Object[])this.grammarQNames, (Object[])that.grammarQNames))
/* 160 */       return false; 
/* 161 */     if (!Arrays.equals((Object[])this.grammarPrefixes, (Object[])that.grammarPrefixes))
/* 162 */       return false; 
/* 163 */     return (this.defaultPrefix != null) ? this.defaultPrefix.equals(that.defaultPrefix) : (
/* 164 */       (that.defaultPrefix == null));
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\context\GrammarUriContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */