/*     */ package com.siemens.ct.exi.core.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   public static final int BITS_IN_BYTE = 8;
/*  45 */   protected int buffer = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   protected int capacity = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OutputStream ostream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int len;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BitOutputStream(OutputStream ostream) {
/*  69 */     this.ostream = ostream;
/*  70 */     this.len = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getUnderlyingOutputStream() {
/*  79 */     return this.ostream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  88 */     return this.len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void flushBuffer() throws IOException {
/*  98 */     if (this.capacity == 0) {
/*  99 */       this.ostream.write(this.buffer);
/* 100 */       this.capacity = 8;
/* 101 */       this.buffer = 0;
/* 102 */       this.len++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isByteAligned() {
/* 113 */     return (this.capacity == 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBitsInBuffer() {
/* 124 */     return 8 - this.capacity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 132 */     align();
/* 133 */     this.ostream.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void align() throws IOException {
/* 144 */     if (this.capacity < 8) {
/* 145 */       this.ostream.write(this.buffer << this.capacity);
/* 146 */       this.capacity = 8;
/* 147 */       this.buffer = 0;
/* 148 */       this.len++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBit0() throws IOException {
/* 159 */     this.buffer <<= 1;
/* 160 */     this.capacity--;
/* 161 */     flushBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBit1() throws IOException {
/* 171 */     this.buffer = this.buffer << 1 | 0x1;
/* 172 */     this.capacity--;
/* 173 */     flushBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeBit(int b) throws IOException {
/* 186 */     this.buffer = this.buffer << 1 | b & 0x1;
/* 187 */     this.capacity--;
/* 188 */     flushBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBits(int b, int n) throws IOException {
/* 203 */     if (n <= this.capacity) {
/*     */       
/* 205 */       this.buffer = this.buffer << n | b & 255 >> 8 - n;
/* 206 */       this.capacity -= n;
/* 207 */       if (this.capacity == 0) {
/* 208 */         this.ostream.write(this.buffer);
/* 209 */         this.capacity = 8;
/* 210 */         this.len++;
/*     */       } 
/*     */     } else {
/*     */       
/* 214 */       this.buffer = this.buffer << this.capacity | b >>> n - this.capacity & 255 >> 8 - this.capacity;
/*     */       
/* 216 */       n -= this.capacity;
/* 217 */       this.ostream.write(this.buffer);
/* 218 */       this.len++;
/*     */ 
/*     */       
/* 221 */       while (n >= 8) {
/* 222 */         n -= 8;
/* 223 */         this.ostream.write(b >>> n);
/* 224 */         this.len++;
/*     */       } 
/*     */ 
/*     */       
/* 228 */       this.buffer = b;
/*     */       
/* 230 */       this.capacity = 8 - n;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeDirectByte(int b) throws IOException {
/* 244 */     this.ostream.write(b);
/* 245 */     this.len++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeDirectBytes(byte[] b, int off, int len) throws IOException {
/* 263 */     this.ostream.write(b, off, len);
/* 264 */     len += len;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 269 */     writeBits(b, 8);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\BitOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */