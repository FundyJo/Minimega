package com.siemens.ct.exi.core;

import com.siemens.ct.exi.core.attributes.AttributeList;
import com.siemens.ct.exi.core.exceptions.EXIException;
import com.siemens.ct.exi.core.exceptions.ErrorHandler;
import com.siemens.ct.exi.core.io.channel.EncoderChannel;
import com.siemens.ct.exi.core.values.Value;
import java.io.IOException;
import java.io.OutputStream;
import javax.xml.namespace.QName;

public interface EXIBodyEncoder {
  void setOutputStream(OutputStream paramOutputStream) throws EXIException, IOException;
  
  void setOutputChannel(EncoderChannel paramEncoderChannel) throws EXIException, IOException;
  
  void flush() throws IOException;
  
  void setErrorHandler(ErrorHandler paramErrorHandler);
  
  void encodeStartDocument() throws EXIException, IOException;
  
  void encodeEndDocument() throws EXIException, IOException;
  
  void encodeStartElement(String paramString1, String paramString2, String paramString3) throws EXIException, IOException;
  
  void encodeStartElement(QName paramQName) throws EXIException, IOException;
  
  void encodeEndElement() throws EXIException, IOException;
  
  void encodeAttributeList(AttributeList paramAttributeList) throws EXIException, IOException;
  
  void encodeAttribute(String paramString1, String paramString2, String paramString3, Value paramValue) throws EXIException, IOException;
  
  void encodeAttribute(QName paramQName, Value paramValue) throws EXIException, IOException;
  
  void encodeNamespaceDeclaration(String paramString1, String paramString2) throws EXIException, IOException;
  
  void encodeAttributeXsiNil(Value paramValue, String paramString) throws EXIException, IOException;
  
  void encodeAttributeXsiType(Value paramValue, String paramString) throws EXIException, IOException;
  
  void encodeCharacters(Value paramValue) throws EXIException, IOException;
  
  void encodeDocType(String paramString1, String paramString2, String paramString3, String paramString4) throws EXIException, IOException;
  
  void encodeEntityReference(String paramString) throws EXIException, IOException;
  
  void encodeComment(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws EXIException, IOException;
  
  void encodeProcessingInstruction(String paramString1, String paramString2) throws EXIException, IOException;
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\EXIBodyEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */