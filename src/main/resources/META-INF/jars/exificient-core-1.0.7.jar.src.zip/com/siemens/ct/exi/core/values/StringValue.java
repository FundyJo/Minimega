/*    */ package com.siemens.ct.exi.core.values;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringValue
/*    */   extends AbstractValue
/*    */ {
/*    */   protected char[] characters;
/*    */   protected String sValue;
/*    */   
/*    */   public StringValue(char[] ca) {
/* 39 */     super(ValueType.STRING);
/* 40 */     this.characters = ca;
/*    */   }
/*    */   
/*    */   public StringValue(String s) {
/* 44 */     super(ValueType.STRING);
/*    */     
/* 46 */     this.sValue = s;
/*    */   }
/*    */   
/*    */   private void checkCharacters() {
/* 50 */     if (this.characters == null) {
/* 51 */       this.characters = this.sValue.toCharArray();
/*    */     }
/*    */   }
/*    */   
/*    */   public int getCharactersLength() {
/* 56 */     checkCharacters();
/* 57 */     return this.characters.length;
/*    */   }
/*    */   
/*    */   public char[] getCharacters() {
/* 61 */     checkCharacters();
/* 62 */     return this.characters;
/*    */   }
/*    */   
/*    */   public void getCharacters(char[] cbuffer, int offset) {
/* 66 */     checkCharacters();
/*    */ 
/*    */     
/* 69 */     System.arraycopy(this.characters, 0, cbuffer, offset, this.characters.length);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     if (this.sValue == null) {
/* 75 */       this.sValue = new String(this.characters);
/*    */     }
/* 77 */     return this.sValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString(char[] cbuffer, int offset) {
/* 82 */     return toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 87 */     if (o == null) {
/* 88 */       return false;
/*    */     }
/* 90 */     return (this == o) ? true : toString().equals(o.toString());
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 95 */     return toString().hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\StringValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */