/*     */ package com.siemens.ct.exi.core.values;
/*     */ 
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.types.TypedTypeEncoder;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListValue
/*     */   extends AbstractValue
/*     */ {
/*     */   protected final Value[] values;
/*     */   protected final Datatype listDatatype;
/*     */   protected final int numberOfValues;
/*     */   
/*     */   public ListValue(Value[] values, Datatype listDatatype) {
/*  48 */     super(ValueType.LIST);
/*  49 */     this.values = values;
/*  50 */     this.numberOfValues = values.length;
/*  51 */     this.listDatatype = listDatatype;
/*     */   }
/*     */   
/*     */   public int getNumberOfValues() {
/*  55 */     return this.numberOfValues;
/*     */   }
/*     */   
/*     */   public Value[] toValues() {
/*  59 */     return this.values;
/*     */   }
/*     */   
/*     */   public Datatype getListDatatype() {
/*  63 */     return this.listDatatype;
/*     */   }
/*     */   
/*     */   public int getCharactersLength() {
/*  67 */     if (this.slen == -1) {
/*  68 */       this.slen = (this.values.length > 0) ? (this.values.length - 1) : 0;
/*     */       
/*  70 */       int vlen = this.values.length;
/*  71 */       for (int i = 0; i < vlen; i++) {
/*  72 */         this.slen += this.values[i].getCharactersLength();
/*     */       }
/*     */     } 
/*  75 */     return this.slen;
/*     */   }
/*     */   
/*     */   public void getCharacters(char[] cbuffer, int offset) {
/*  79 */     if (this.values.length > 0) {
/*     */ 
/*     */       
/*  82 */       int vlenMinus1 = this.values.length - 1;
/*  83 */       for (int i = 0; i < vlenMinus1; i++) {
/*  84 */         Value value = this.values[i];
/*  85 */         value.getCharacters(cbuffer, offset);
/*  86 */         offset += value.getCharactersLength();
/*  87 */         cbuffer[offset++] = ' ';
/*     */       } 
/*     */ 
/*     */       
/*  91 */       Value iVal = this.values[vlenMinus1];
/*  92 */       iVal.getCharacters(cbuffer, offset);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static ListValue parse(String value, Datatype listDatatype) {
/*  98 */     StringTokenizer st = new StringTokenizer(value);
/*  99 */     Value[] values = new Value[st.countTokens()];
/* 100 */     int index = 0;
/* 101 */     while (st.hasMoreTokens()) {
/* 102 */       Value nextToken = new StringValue(st.nextToken());
/*     */       try {
/* 104 */         TypedTypeEncoder typedTypeEncoder = new TypedTypeEncoder();
/* 105 */         if (typedTypeEncoder.isValid(listDatatype, nextToken)) {
/* 106 */           values[index++] = nextToken;
/*     */           continue;
/*     */         } 
/* 109 */         return null;
/*     */       }
/* 111 */       catch (EXIException e) {
/* 112 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     return new ListValue(values, listDatatype);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final boolean _equals(ListValue o) {
/* 121 */     if (this.listDatatype.getBuiltInType() != o.listDatatype.getBuiltInType()) {
/* 122 */       return false;
/*     */     }
/*     */     
/* 125 */     if (this.values.length == o.values.length) {
/* 126 */       for (int i = 0; i < this.values.length; i++) {
/* 127 */         if (!this.values[i].equals(o.values[i])) {
/* 128 */           return false;
/*     */         }
/*     */       } 
/* 131 */       return true;
/*     */     } 
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 139 */     if (o == null) {
/* 140 */       return false;
/*     */     }
/* 142 */     if (o instanceof ListValue) {
/* 143 */       return _equals((ListValue)o);
/*     */     }
/* 145 */     ListValue lv = parse(o.toString(), this.listDatatype);
/* 146 */     return (lv == null) ? false : _equals(lv);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 152 */     int hc = 0;
/* 153 */     for (Value val : this.values) {
/* 154 */       hc = hc * 31 ^ val.hashCode();
/*     */     }
/* 156 */     return hc;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\values\ListValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */