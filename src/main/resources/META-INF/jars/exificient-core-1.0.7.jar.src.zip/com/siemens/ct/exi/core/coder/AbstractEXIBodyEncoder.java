/*      */ package com.siemens.ct.exi.core.coder;
/*      */ 
/*      */ import com.siemens.ct.exi.core.EXIBodyEncoder;
/*      */ import com.siemens.ct.exi.core.EXIFactory;
/*      */ import com.siemens.ct.exi.core.EncodingOptions;
/*      */ import com.siemens.ct.exi.core.attributes.AttributeList;
/*      */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*      */ import com.siemens.ct.exi.core.context.QNameContext;
/*      */ import com.siemens.ct.exi.core.datatype.Datatype;
/*      */ import com.siemens.ct.exi.core.datatype.WhiteSpace;
/*      */ import com.siemens.ct.exi.core.datatype.strings.StringCoder;
/*      */ import com.siemens.ct.exi.core.datatype.strings.StringEncoder;
/*      */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*      */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*      */ import com.siemens.ct.exi.core.grammars.event.AttributeNS;
/*      */ import com.siemens.ct.exi.core.grammars.event.Characters;
/*      */ import com.siemens.ct.exi.core.grammars.event.DatatypeEvent;
/*      */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*      */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*      */ import com.siemens.ct.exi.core.grammars.event.StartElementNS;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.GrammarType;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedGrammar;
/*      */ import com.siemens.ct.exi.core.grammars.production.Production;
/*      */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*      */ import com.siemens.ct.exi.core.types.BuiltIn;
/*      */ import com.siemens.ct.exi.core.types.TypeEncoder;
/*      */ import com.siemens.ct.exi.core.util.MethodsBag;
/*      */ import com.siemens.ct.exi.core.util.xml.QNameUtilities;
/*      */ import com.siemens.ct.exi.core.values.BooleanValue;
/*      */ import com.siemens.ct.exi.core.values.QNameValue;
/*      */ import com.siemens.ct.exi.core.values.StringValue;
/*      */ import com.siemens.ct.exi.core.values.Value;
/*      */ import com.siemens.ct.exi.core.values.ValueType;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javax.xml.namespace.QName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractEXIBodyEncoder
/*      */   extends AbstractEXIBodyCoder
/*      */   implements EXIBodyEncoder
/*      */ {
/*      */   protected final EXIHeaderEncoder exiHeader;
/*   81 */   protected String sePrefix = null;
/*      */ 
/*      */   
/*   84 */   protected String seUri = null;
/*      */ 
/*      */   
/*      */   protected EncoderChannel channel;
/*      */ 
/*      */   
/*      */   protected final TypeEncoder typeEncoder;
/*      */ 
/*      */   
/*      */   protected final StringEncoder stringEncoder;
/*      */ 
/*      */   
/*      */   protected final EncodingOptions encodingOptions;
/*      */ 
/*      */   
/*      */   protected List<Value> bChars;
/*      */ 
/*      */   
/*      */   protected boolean isXmlSpacePreserve;
/*      */ 
/*      */   
/*      */   protected EventType lastEvent;
/*      */   
/*  107 */   private final String MISUSE_OF_PRESERVE_PREFIXES_ERROR = "A prefix with value null cannot be used in Preserve.Prefixes mode. Report prefix or set your XML reader to do so. e.g., SAX xmlReader.setFeature(\"http://xml.org/sax/features/namespaces\", true); and xmlReader.setFeature(\"http://xml.org/sax/features/namespace-prefixes\", false);";
/*      */   
/*      */   public AbstractEXIBodyEncoder(EXIFactory exiFactory) throws EXIException {
/*  110 */     super(exiFactory);
/*  111 */     this.exiHeader = new EXIHeaderEncoder();
/*      */ 
/*      */     
/*  114 */     this.typeEncoder = exiFactory.createTypeEncoder();
/*  115 */     this.stringEncoder = exiFactory.createStringEncoder();
/*  116 */     this.encodingOptions = exiFactory.getEncodingOptions();
/*  117 */     this.bChars = new ArrayList<>();
/*      */   }
/*      */   private char[] cbuffer;
/*      */   
/*      */   public void initForEachRun() throws EXIException, IOException {
/*  122 */     super.initForEachRun();
/*      */     
/*  124 */     this.learnedProductions = 0;
/*  125 */     this.stringEncoder.clear();
/*  126 */     if (this.exiFactory.getSharedStrings() != null) {
/*  127 */       this.stringEncoder.setSharedStrings(this.exiFactory.getSharedStrings());
/*      */     }
/*      */     
/*  130 */     this.bChars.clear();
/*  131 */     this.isXmlSpacePreserve = false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected QNameContext encodeQName(String namespaceUri, String localName, EncoderChannel channel) throws IOException {
/*  137 */     AbstractEXIBodyCoder.RuntimeUriContext ruc = encodeUri(namespaceUri, channel);
/*      */ 
/*      */     
/*  140 */     return encodeLocalName(localName, ruc, channel);
/*      */   }
/*      */ 
/*      */   
/*      */   protected AbstractEXIBodyCoder.RuntimeUriContext encodeUri(String namespaceUri, EncoderChannel channel) throws IOException {
/*  145 */     int numberBitsUri = MethodsBag.getCodingLength(getNumberOfUris() + 1);
/*  146 */     AbstractEXIBodyCoder.RuntimeUriContext ruc = getUri(namespaceUri);
/*      */     
/*  148 */     if (ruc == null) {
/*      */ 
/*      */ 
/*      */       
/*  152 */       channel.encodeNBitUnsignedInteger(0, numberBitsUri);
/*  153 */       channel.encodeString(namespaceUri);
/*      */       
/*  155 */       ruc = addUri(namespaceUri);
/*      */     }
/*      */     else {
/*      */       
/*  159 */       channel.encodeNBitUnsignedInteger(ruc.namespaceUriID + 1, numberBitsUri);
/*      */     } 
/*      */ 
/*      */     
/*  163 */     return ruc;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void encodeQNamePrefix(QNameContext qnContext, String prefix, EncoderChannel channel) throws IOException, EXIException {
/*  169 */     if (prefix == null) {
/*  170 */       throwWarning("A prefix with value null cannot be used in Preserve.Prefixes mode. Report prefix or set your XML reader to do so. e.g., SAX xmlReader.setFeature(\"http://xml.org/sax/features/namespaces\", true); and xmlReader.setFeature(\"http://xml.org/sax/features/namespace-prefixes\", false);");
/*      */     }
/*      */     
/*  173 */     int namespaceUriID = qnContext.getNamespaceUriID();
/*      */     
/*  175 */     if (namespaceUriID != 0) {
/*      */ 
/*      */ 
/*      */       
/*  179 */       AbstractEXIBodyCoder.RuntimeUriContext ruc = getUri(namespaceUriID);
/*  180 */       int numberOfPrefixes = ruc.getNumberOfPrefixes();
/*  181 */       if (numberOfPrefixes != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  187 */         if (numberOfPrefixes != 1) {
/*      */ 
/*      */           
/*  190 */           int pfxID = ruc.getPrefixID(prefix);
/*  191 */           if (pfxID == -1)
/*      */           {
/*      */             
/*  194 */             pfxID = 0;
/*      */           }
/*      */ 
/*      */           
/*  198 */           channel.encodeNBitUnsignedInteger(pfxID, 
/*  199 */               MethodsBag.getCodingLength(numberOfPrefixes));
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected QNameContext encodeLocalName(String localName, AbstractEXIBodyCoder.RuntimeUriContext ruc, EncoderChannel channel) throws IOException {
/*  208 */     QNameContext qnc = ruc.getQNameContext(localName);
/*      */     
/*  210 */     if (qnc == null) {
/*      */ 
/*      */ 
/*      */       
/*  214 */       channel.encodeUnsignedInteger(localName.length() + 1);
/*  215 */       channel.encodeStringOnly(localName);
/*      */ 
/*      */ 
/*      */       
/*  219 */       qnc = ruc.addQNameContext(localName);
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  226 */       channel.encodeUnsignedInteger(0);
/*  227 */       int n = MethodsBag.getCodingLength(ruc.getNumberOfQNames());
/*  228 */       channel.encodeNBitUnsignedInteger(qnc.getLocalNameID(), n);
/*      */     } 
/*      */     
/*  231 */     return qnc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void encodeNamespacePrefix(AbstractEXIBodyCoder.RuntimeUriContext uriContext, String prefix, EncoderChannel channel) throws IOException {
/*  238 */     int nPfx = MethodsBag.getCodingLength(uriContext.getNumberOfPrefixes() + 1);
/*  239 */     int pfxID = uriContext.getPrefixID(prefix);
/*      */     
/*  241 */     if (pfxID == -1) {
/*      */ 
/*      */ 
/*      */       
/*  245 */       channel.encodeNBitUnsignedInteger(0, nPfx);
/*  246 */       channel.encodeString(prefix);
/*      */       
/*  248 */       uriContext.addPrefix(prefix);
/*      */     }
/*      */     else {
/*      */       
/*  252 */       channel.encodeNBitUnsignedInteger(pfxID + 1, nPfx);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() throws IOException {
/*  260 */     this.channel.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeString(String text) throws IOException {
/*  269 */     this.channel.encodeString(text);
/*      */   }
/*      */   
/*      */   protected boolean isTypeValid(Datatype datatype, Value value) {
/*  273 */     return this.typeEncoder.isValid(datatype, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void writeValue(QNameContext paramQNameContext) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void encode1stLevelEventCode(int pos) throws IOException {
/*  285 */     int codeLength = this.fidelityOptions.get1stLevelEventCodeLength(getCurrentGrammar());
/*  286 */     if (codeLength > 0) {
/*  287 */       this.channel.encodeNBitUnsignedInteger(pos, codeLength);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void encode2ndLevelEventCode(int pos) throws IOException {
/*  293 */     Grammar currentGrammar = getCurrentGrammar();
/*  294 */     this.channel.encodeNBitUnsignedInteger(currentGrammar.getNumberOfEvents(), this.fidelityOptions
/*  295 */         .get1stLevelEventCodeLength(currentGrammar));
/*      */ 
/*      */ 
/*      */     
/*  299 */     int ch2 = this.fidelityOptions.get2ndLevelCharacteristics(currentGrammar);
/*  300 */     assert pos < ch2;
/*      */     
/*  302 */     this.channel.encodeNBitUnsignedInteger(pos, MethodsBag.getCodingLength(ch2));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void encode3rdLevelEventCode(int pos) throws IOException {
/*  307 */     Grammar currentGrammar = getCurrentGrammar();
/*  308 */     this.channel.encodeNBitUnsignedInteger(currentGrammar.getNumberOfEvents(), this.fidelityOptions
/*  309 */         .get1stLevelEventCodeLength(currentGrammar));
/*      */ 
/*      */ 
/*      */     
/*  313 */     int ch2 = this.fidelityOptions.get2ndLevelCharacteristics(currentGrammar);
/*  314 */     int ec2 = (ch2 > 0) ? (ch2 - 1) : 0;
/*  315 */     this.channel.encodeNBitUnsignedInteger(ec2, MethodsBag.getCodingLength(ch2));
/*      */ 
/*      */     
/*  318 */     int ch3 = this.fidelityOptions.get3rdLevelCharacteristics();
/*      */     
/*  320 */     assert pos < ch3;
/*  321 */     this.channel.encodeNBitUnsignedInteger(pos, MethodsBag.getCodingLength(ch3));
/*      */   }
/*      */   
/*      */   public void encodeStartDocument() throws EXIException, IOException {
/*  325 */     if (this.channel == null) {
/*  326 */       throw new EXIException("No valid EXI OutputStream set for encoding. Please use setOutput( ... )");
/*      */     }
/*      */     
/*  329 */     initForEachRun();
/*      */     
/*  331 */     Production ei = getCurrentGrammar().getProduction(EventType.START_DOCUMENT);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  336 */     if (ei == null) {
/*  337 */       throw new EXIException("No EXI Event found for startDocument");
/*      */     }
/*      */ 
/*      */     
/*  341 */     updateCurrentRule(ei.getNextGrammar());
/*      */     
/*  343 */     this.lastEvent = EventType.START_DOCUMENT;
/*      */   }
/*      */   
/*      */   public void encodeEndDocument() throws EXIException, IOException {
/*  347 */     checkPendingCharacters(EventType.END_DOCUMENT);
/*      */     
/*  349 */     Production ei = getCurrentGrammar().getProduction(EventType.END_DOCUMENT);
/*      */ 
/*      */     
/*  352 */     if (ei != null) {
/*      */       
/*  354 */       encode1stLevelEventCode(ei.getEventCode());
/*      */     } else {
/*  356 */       throw new EXIException("No EXI Event found for endDocument");
/*      */     } 
/*      */     
/*  359 */     this.lastEvent = EventType.END_DOCUMENT;
/*      */   }
/*      */   
/*      */   public void encodeStartElement(QName se) throws EXIException, IOException {
/*  363 */     encodeStartElement(se.getNamespaceURI(), se.getLocalPart(), se
/*  364 */         .getPrefix());
/*      */   }
/*      */   public void encodeStartElement(String uri, String localName, String prefix) throws EXIException, IOException {
/*      */     Grammar updContextRule;
/*      */     StartElement nextSE;
/*  369 */     checkPendingCharacters(EventType.START_ELEMENT);
/*      */     
/*  371 */     this.sePrefix = prefix;
/*  372 */     this.seUri = uri;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  379 */     Grammar currentGrammar = getCurrentGrammar(); Production ei;
/*  380 */     if ((ei = currentGrammar.getStartElementProduction(uri, localName)) != null) {
/*  381 */       assert ei.getEvent().isEventType(EventType.START_ELEMENT);
/*      */       
/*  383 */       encode1stLevelEventCode(ei.getEventCode());
/*      */       
/*  385 */       nextSE = (StartElement)ei.getEvent();
/*      */       
/*  387 */       if (this.preservePrefix) {
/*  388 */         encodeQNamePrefix(nextSE.getQNameContext(), prefix, this.channel);
/*      */       }
/*      */       
/*  391 */       updContextRule = ei.getNextGrammar();
/*      */     }
/*  393 */     else if ((ei = currentGrammar.getStartElementNSProduction(uri)) != null) {
/*  394 */       assert ei.getEvent().isEventType(EventType.START_ELEMENT_NS);
/*      */       
/*  396 */       encode1stLevelEventCode(ei.getEventCode());
/*      */       
/*  398 */       StartElementNS seNS = (StartElementNS)ei.getEvent();
/*  399 */       AbstractEXIBodyCoder.RuntimeUriContext uc = getUri(seNS.getNamespaceUriID());
/*      */ 
/*      */       
/*  402 */       QNameContext qnc = encodeLocalName(localName, uc, this.channel);
/*  403 */       if (this.preservePrefix) {
/*  404 */         encodeQNamePrefix(qnc, prefix, this.channel);
/*      */       }
/*      */ 
/*      */       
/*  408 */       updContextRule = ei.getNextGrammar();
/*      */       
/*  410 */       nextSE = getGlobalStartElement(qnc);
/*      */     }
/*      */     else {
/*      */       
/*  414 */       if ((ei = currentGrammar.getProduction(EventType.START_ELEMENT_GENERIC)) != null) {
/*  415 */         assert ei.getEvent()
/*  416 */           .isEventType(EventType.START_ELEMENT_GENERIC);
/*      */         
/*  418 */         encode1stLevelEventCode(ei.getEventCode());
/*      */ 
/*      */         
/*  421 */         updContextRule = ei.getNextGrammar();
/*      */       } else {
/*      */         
/*  424 */         int ecSEundeclared = this.fidelityOptions.get2ndLevelEventCode(EventType.START_ELEMENT_GENERIC_UNDECLARED, currentGrammar);
/*      */ 
/*      */ 
/*      */         
/*  428 */         if (ecSEundeclared == -1)
/*      */         {
/*  430 */           throw new EXIException("Unexpected SE {" + uri + "}" + localName + ", " + this.exiFactory
/*  431 */               .toString());
/*      */         }
/*      */ 
/*      */         
/*  435 */         switch (limitGrammars()) {
/*      */           case XSI_TYPE:
/*  437 */             insertXsiTypeAnyType();
/*  438 */             currentGrammar = getCurrentGrammar();
/*      */ 
/*      */             
/*  441 */             ei = currentGrammar.getProduction(EventType.START_ELEMENT_GENERIC);
/*  442 */             assert ei != null;
/*  443 */             encode1stLevelEventCode(ei.getEventCode());
/*      */             
/*  445 */             updContextRule = ei.getNextGrammar();
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  450 */             encode2ndLevelEventCode(ecSEundeclared);
/*      */             
/*  452 */             updContextRule = currentGrammar.getElementContentGrammar();
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       } 
/*  458 */       QNameContext qnc = encodeQName(uri, localName, this.channel);
/*  459 */       if (this.preservePrefix) {
/*  460 */         encodeQNamePrefix(qnc, prefix, this.channel);
/*      */       }
/*      */ 
/*      */       
/*  464 */       nextSE = getGlobalStartElement(qnc);
/*      */ 
/*      */ 
/*      */       
/*  468 */       currentGrammar.learnStartElement(nextSE);
/*  469 */       productionLearningCounting(currentGrammar);
/*      */     } 
/*      */ 
/*      */     
/*  473 */     pushElement(updContextRule, nextSE);
/*      */     
/*  475 */     this.lastEvent = EventType.START_ELEMENT;
/*      */   }
/*      */   
/*      */   private enum ProfileDisablingMechanism
/*      */   {
/*  480 */     NONE,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  485 */     XSI_TYPE,
/*      */     
/*  487 */     GHOST_PRODUCTION;
/*      */   }
/*      */   
/*      */   private final void productionLearningCounting(Grammar g) {
/*  491 */     if (this.limitGrammarLearning)
/*      */     {
/*      */       
/*  494 */       if (this.maxBuiltInProductions >= 0 && 
/*  495 */         !g.isSchemaInformed() && g
/*  496 */         .getGrammarType() != GrammarType.BUILT_IN_FRAGMENT_CONTENT) {
/*  497 */         this.learnedProductions++;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final ProfileDisablingMechanism limitGrammars() throws EXIException, IOException {
/*  505 */     ProfileDisablingMechanism retVal = ProfileDisablingMechanism.NONE;
/*      */     
/*  507 */     Grammar currGrammar = getCurrentGrammar();
/*      */     
/*  509 */     if (this.limitGrammarLearning && this.grammar.isSchemaInformed() && 
/*  510 */       !currGrammar.isSchemaInformed()) {
/*      */ 
/*      */       
/*  513 */       if (this.maxBuiltInElementGrammars != -1) {
/*  514 */         int csize = this.runtimeGlobalElements.size();
/*  515 */         if (csize > this.maxBuiltInElementGrammars) {
/*  516 */           if (currGrammar.getNumberOfEvents() == 0) {
/*      */             
/*  518 */             retVal = ProfileDisablingMechanism.XSI_TYPE;
/*  519 */           } else if (isBuiltInStartTagGrammarWithAtXsiTypeOnly(currGrammar)) {
/*      */             
/*  521 */             retVal = ProfileDisablingMechanism.XSI_TYPE;
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  527 */       if (this.maxBuiltInProductions != -1 && retVal == ProfileDisablingMechanism.NONE && this.learnedProductions >= this.maxBuiltInProductions)
/*      */       {
/*      */ 
/*      */         
/*  531 */         if (this.lastEvent == EventType.START_ELEMENT || this.lastEvent == EventType.NAMESPACE_DECLARATION) {
/*      */ 
/*      */           
/*  534 */           retVal = ProfileDisablingMechanism.XSI_TYPE;
/*      */         } else {
/*      */           
/*  537 */           retVal = ProfileDisablingMechanism.GHOST_PRODUCTION;
/*  538 */           currGrammar.stopLearning();
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  544 */     return retVal;
/*      */   }
/*      */   
/*      */   private final void insertXsiTypeAnyType() throws EXIException, IOException {
/*  548 */     String pfx = null;
/*  549 */     if (this.preservePrefix) {
/*      */ 
/*      */       
/*  552 */       pfx = getPrefix("http://www.w3.org/2001/XMLSchema");
/*  553 */       if (pfx == null) {
/*      */         
/*  555 */         pfx = "xsdP";
/*  556 */         encodeNamespaceDeclaration("http://www.w3.org/2001/XMLSchema", pfx);
/*      */       } 
/*      */     } 
/*      */     
/*  560 */     QNameValue type = new QNameValue("http://www.w3.org/2001/XMLSchema", "anyType", pfx);
/*      */ 
/*      */ 
/*      */     
/*  564 */     encodeAttributeXsiType((Value)type, pfx, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public void encodeNamespaceDeclaration(String uri, String prefix) throws EXIException, IOException {
/*  569 */     declarePrefix(prefix, uri);
/*      */     
/*  571 */     if (this.preservePrefix) {
/*      */ 
/*      */ 
/*      */       
/*  575 */       Grammar currentGrammar = getCurrentGrammar();
/*  576 */       int ec2 = this.fidelityOptions.get2ndLevelEventCode(EventType.NAMESPACE_DECLARATION, currentGrammar);
/*      */       
/*  578 */       assert this.fidelityOptions.get2ndLevelEventType(ec2, currentGrammar) == EventType.NAMESPACE_DECLARATION;
/*  579 */       encode2ndLevelEventCode(ec2);
/*      */ 
/*      */       
/*  582 */       AbstractEXIBodyCoder.RuntimeUriContext euc = encodeUri(uri, this.channel);
/*  583 */       encodeNamespacePrefix(euc, prefix, this.channel);
/*      */ 
/*      */       
/*  586 */       if (this.sePrefix == null) {
/*      */         
/*  588 */         throwWarning("A prefix with value null cannot be used in Preserve.Prefixes mode. Report prefix or set your XML reader to do so. e.g., SAX xmlReader.setFeature(\"http://xml.org/sax/features/namespaces\", true); and xmlReader.setFeature(\"http://xml.org/sax/features/namespace-prefixes\", false);");
/*      */         
/*  590 */         this.channel.encodeBoolean(uri.equals(this.seUri));
/*      */       } else {
/*  592 */         this.channel.encodeBoolean(prefix.equals(this.sePrefix));
/*      */       } 
/*      */       
/*  595 */       this.lastEvent = EventType.NAMESPACE_DECLARATION;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void encodeEndElement() throws EXIException, IOException {
/*  600 */     checkPendingCharacters(EventType.END_ELEMENT);
/*      */     
/*  602 */     Grammar currentGrammar = getCurrentGrammar();
/*  603 */     Production ei = currentGrammar.getProduction(EventType.END_ELEMENT);
/*      */     
/*  605 */     if (ei != null) {
/*      */       
/*  607 */       encode1stLevelEventCode(ei.getEventCode());
/*      */     } else {
/*      */       
/*  610 */       int ecEEundeclared = this.fidelityOptions.get2ndLevelEventCode(EventType.END_ELEMENT_UNDECLARED, currentGrammar);
/*      */ 
/*      */       
/*  613 */       if (ecEEundeclared == -1) {
/*      */ 
/*      */         
/*      */         try {
/*  617 */           encodeCharactersForce((Value)StringCoder.EMPTY_STRING_VALUE);
/*  618 */           currentGrammar = getCurrentGrammar();
/*  619 */           ei = currentGrammar.getProduction(EventType.END_ELEMENT);
/*  620 */           encode1stLevelEventCode(ei.getEventCode());
/*  621 */         } catch (Exception e) {
/*      */           
/*  623 */           throw new EXIException("Unexpected EE {" + 
/*  624 */               getElementContext() + ", " + this.exiFactory
/*  625 */               .toString());
/*      */         } 
/*      */       } else {
/*      */         
/*  629 */         switch (limitGrammars()) {
/*      */           case XSI_TYPE:
/*  631 */             insertXsiTypeAnyType();
/*  632 */             currentGrammar = getCurrentGrammar();
/*      */             
/*  634 */             ei = currentGrammar.getProduction(EventType.END_ELEMENT);
/*  635 */             assert ei != null;
/*  636 */             encode1stLevelEventCode(ei.getEventCode());
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  641 */             encode2ndLevelEventCode(ecEEundeclared);
/*      */             
/*  643 */             currentGrammar.learnEndElement();
/*  644 */             productionLearningCounting(currentGrammar);
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       } 
/*      */     } 
/*  651 */     AbstractEXIBodyCoder.ElementContext ec = popElement();
/*      */ 
/*      */     
/*  654 */     if (ec.isXmlSpacePreserve() != null) {
/*      */ 
/*      */       
/*  657 */       boolean isOtherPreserve = false;
/*  658 */       for (int i = this.elementContextStackIndex; i >= 0; i--) {
/*  659 */         Boolean isP = this.elementContextStack[i].isXmlSpacePreserve();
/*  660 */         if (isP != null) {
/*  661 */           isOtherPreserve = isP.booleanValue();
/*      */           break;
/*      */         } 
/*      */       } 
/*  665 */       this.isXmlSpacePreserve = isOtherPreserve;
/*      */     } 
/*      */     
/*  668 */     this.lastEvent = EventType.END_ELEMENT;
/*      */   }
/*      */ 
/*      */   
/*      */   public void encodeAttributeList(AttributeList attributes) throws EXIException, IOException {
/*      */     int i;
/*  674 */     for (i = 0; i < attributes.getNumberOfNamespaceDeclarations(); i++) {
/*  675 */       NamespaceDeclaration ns = attributes.getNamespaceDeclaration(i);
/*  676 */       encodeNamespaceDeclaration(ns.namespaceURI, ns.prefix);
/*      */     } 
/*      */ 
/*      */     
/*  680 */     if (attributes.hasXsiType()) {
/*  681 */       encodeAttributeXsiType((Value)new StringValue(attributes.getXsiTypeRaw()), attributes
/*  682 */           .getXsiTypePrefix());
/*      */     }
/*      */ 
/*      */     
/*  686 */     if (attributes.hasXsiNil()) {
/*  687 */       encodeAttributeXsiNil((Value)new StringValue(attributes.getXsiNil()), attributes
/*  688 */           .getXsiNilPrefix());
/*      */     }
/*      */ 
/*      */     
/*  692 */     for (i = 0; i < attributes.getNumberOfAttributes(); i++) {
/*  693 */       encodeAttribute(attributes.getAttributeURI(i), attributes
/*  694 */           .getAttributeLocalName(i), attributes
/*  695 */           .getAttributePrefix(i), (Value)new StringValue(attributes
/*  696 */             .getAttributeValue(i)));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void encodeAttributeXsiType(Value type, String pfx) throws EXIException, IOException {
/*  702 */     boolean force2ndLevelProduction = false;
/*  703 */     if (limitGrammars() == ProfileDisablingMechanism.XSI_TYPE) {
/*  704 */       force2ndLevelProduction = true;
/*      */     }
/*  706 */     encodeAttributeXsiType(type, pfx, force2ndLevelProduction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void encodeAttributeXsiType(Value type, String pfx, boolean force2ndLevelProduction) throws EXIException, IOException {
/*      */     String qnamePrefix, qnameURI, qnameLocalName;
/*      */     QNameContext qncType;
/*  719 */     if (type instanceof QNameValue) {
/*  720 */       QNameValue qv = (QNameValue)type;
/*  721 */       qnameURI = qv.getNamespaceUri();
/*  722 */       qnamePrefix = qv.getPrefix();
/*  723 */       qnameLocalName = qv.getLocalName();
/*      */     } else {
/*  725 */       String sType = type.toString();
/*      */       
/*  727 */       qnamePrefix = QNameUtilities.getPrefixPart(sType);
/*      */       
/*  729 */       qnameURI = getURI(qnamePrefix);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  736 */       if (qnameURI == null) {
/*      */         
/*  738 */         qnameURI = "";
/*  739 */         qnameLocalName = sType;
/*      */       } else {
/*  741 */         qnameLocalName = QNameUtilities.getLocalPart(sType);
/*      */       } 
/*      */     } 
/*      */     
/*  745 */     Grammar currentGrammar = getCurrentGrammar();
/*      */     
/*  747 */     int ec2 = this.fidelityOptions.get2ndLevelEventCode(EventType.ATTRIBUTE_XSI_TYPE, currentGrammar);
/*      */ 
/*      */     
/*  750 */     if (ec2 != -1) {
/*      */       
/*  752 */       assert this.fidelityOptions.get2ndLevelEventType(ec2, currentGrammar) == EventType.ATTRIBUTE_XSI_TYPE;
/*      */ 
/*      */       
/*  755 */       encode2ndLevelEventCode(ec2);
/*      */       
/*  757 */       if (this.preservePrefix) {
/*  758 */         encodeQNamePrefix(getXsiTypeContext(), pfx, this.channel);
/*      */       }
/*      */     } else {
/*      */       Production ei;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  767 */       if (force2ndLevelProduction) {
/*      */         
/*  769 */         ei = null;
/*      */       } else {
/*  771 */         ei = currentGrammar.getAttributeProduction("http://www.w3.org/2001/XMLSchema-instance", "type");
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  776 */       if (ei != null) {
/*  777 */         encode1stLevelEventCode(ei.getEventCode());
/*      */       } else {
/*      */         
/*  780 */         if (!force2ndLevelProduction)
/*      */         {
/*  782 */           ei = currentGrammar.getProduction(EventType.ATTRIBUTE_GENERIC);
/*      */         }
/*      */         
/*  785 */         if (ei != null) {
/*  786 */           encode1stLevelEventCode(ei.getEventCode());
/*      */         } else {
/*  788 */           ec2 = this.fidelityOptions.get2ndLevelEventCode(EventType.ATTRIBUTE_GENERIC_UNDECLARED, currentGrammar);
/*      */ 
/*      */           
/*  791 */           if (ec2 != -1) {
/*  792 */             encode2ndLevelEventCode(ec2);
/*  793 */             QNameContext qNameContext1 = getXsiTypeContext();
/*      */             
/*  795 */             if (this.limitGrammarLearning)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  803 */               if (this.runtimeGlobalElements.size() > this.maxBuiltInElementGrammars && currentGrammar
/*  804 */                 .getNumberOfEvents() == 0) {
/*      */                 
/*  806 */                 currentGrammar.stopLearning();
/*      */               } else {
/*  808 */                 productionLearningCounting(currentGrammar);
/*      */               } 
/*      */             }
/*  811 */             currentGrammar.learnAttribute(new Attribute(qNameContext1));
/*      */           } else {
/*  813 */             throw new EXIException("TypeCast " + type + " not encodable!");
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  818 */         QNameContext qNameContext = getXsiTypeContext();
/*  819 */         encodeQName(qNameContext.getNamespaceUri(), qNameContext.getLocalName(), this.channel);
/*      */ 
/*      */         
/*  822 */         if (this.preservePrefix) {
/*  823 */           encodeQNamePrefix(qNameContext, pfx, this.channel);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  830 */     if (this.preserveLexicalValues) {
/*      */ 
/*      */       
/*  833 */       if (qnamePrefix.length() > 0 && !this.preservePrefix) {
/*  834 */         throw new EXIException("[EXI] xsi:type='" + type + "' not encodable. Preserve lexicalValues requires prefixes preserved as well!");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  841 */       this.typeEncoder.isValid(BuiltIn.getDefaultDatatype(), type);
/*  842 */       this.typeEncoder.writeValue(getXsiTypeContext(), this.channel, this.stringEncoder);
/*      */       
/*  844 */       AbstractEXIBodyCoder.RuntimeUriContext uc = getUri(qnameURI);
/*  845 */       if (uc != null) {
/*  846 */         qncType = uc.getQNameContext(qnameLocalName);
/*      */       } else {
/*  848 */         qncType = null;
/*      */       } 
/*      */     } else {
/*      */       
/*  852 */       qncType = encodeQName(qnameURI, qnameLocalName, this.channel);
/*      */       
/*  854 */       if (this.preservePrefix) {
/*  855 */         encodeQNamePrefix(qncType, qnamePrefix, this.channel);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  860 */     if (qncType != null && qncType.getTypeGrammar() != null)
/*      */     {
/*  862 */       updateCurrentRule((Grammar)qncType.getTypeGrammar());
/*      */     }
/*      */     
/*  865 */     this.lastEvent = EventType.ATTRIBUTE_XSI_TYPE;
/*      */   }
/*      */ 
/*      */   
/*      */   public void encodeAttributeXsiNil(Value nil, String pfx) throws EXIException, IOException {
/*  870 */     Grammar currentGrammar = getCurrentGrammar();
/*  871 */     if (currentGrammar.isSchemaInformed()) {
/*  872 */       SchemaInformedGrammar siCurrentRule = (SchemaInformedGrammar)currentGrammar;
/*      */       
/*  874 */       boolean validNil = false;
/*  875 */       boolean validNilValue = false;
/*  876 */       if (nil instanceof BooleanValue) {
/*  877 */         validNil = true;
/*  878 */         validNilValue = ((BooleanValue)nil).toBoolean();
/*      */       } else {
/*  880 */         BooleanValue bv = BooleanValue.parse(nil.toString());
/*  881 */         if (bv != null) {
/*  882 */           validNil = true;
/*  883 */           validNilValue = bv.toBoolean();
/*      */         } 
/*      */       } 
/*      */       
/*  887 */       if (validNil) {
/*      */ 
/*      */         
/*  890 */         if (!this.preserveLexicalValues && !validNilValue && 
/*      */           
/*  892 */           !this.encodingOptions.isOptionEnabled("INCLUDE_INSIGNIFICANT_XSI_NIL")) {
/*      */           return;
/*      */         }
/*      */ 
/*      */         
/*  897 */         int ec2 = this.fidelityOptions.get2ndLevelEventCode(EventType.ATTRIBUTE_XSI_NIL, (Grammar)siCurrentRule);
/*      */ 
/*      */         
/*  900 */         if (ec2 != -1) {
/*      */           
/*  902 */           encode2ndLevelEventCode(ec2);
/*      */           
/*  904 */           if (this.preservePrefix) {
/*  905 */             encodeQNamePrefix(getXsiNilContext(), pfx, this.channel);
/*      */           }
/*      */ 
/*      */           
/*  909 */           if (this.preserveLexicalValues) {
/*      */             
/*  911 */             this.typeEncoder.isValid((Datatype)this.booleanDatatype, nil);
/*  912 */             this.typeEncoder.writeValue(getXsiTypeContext(), this.channel, this.stringEncoder);
/*      */           }
/*      */           else {
/*      */             
/*  916 */             this.channel.encodeBoolean(validNilValue);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  921 */           if (validNilValue)
/*      */           {
/*  923 */             updateCurrentRule((Grammar)((SchemaInformedFirstStartTagGrammar)siCurrentRule)
/*  924 */                 .getTypeEmpty());
/*      */           }
/*      */         } else {
/*      */           
/*  928 */           Production ei = currentGrammar.getProduction(EventType.ATTRIBUTE_GENERIC);
/*  929 */           if (ei != null) {
/*  930 */             encode1stLevelEventCode(ei.getEventCode());
/*      */             
/*  932 */             AbstractEXIBodyCoder.RuntimeUriContext euc = encodeUri("http://www.w3.org/2001/XMLSchema-instance", this.channel);
/*      */             
/*  934 */             encodeLocalName("nil", euc, this.channel);
/*  935 */             if (this.preservePrefix) {
/*  936 */               encodeQNamePrefix(getXsiNilContext(), pfx, this.channel);
/*      */             }
/*      */ 
/*      */             
/*  940 */             if (this.preserveLexicalValues) {
/*      */               
/*  942 */               this.typeEncoder.isValid((Datatype)this.booleanDatatype, nil);
/*      */               
/*  944 */               this.typeEncoder.writeValue(getXsiNilContext(), this.channel, this.stringEncoder);
/*      */             }
/*      */             else {
/*      */               
/*  948 */               this.channel.encodeBoolean(validNilValue);
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  953 */             if (validNilValue)
/*      */             {
/*  955 */               updateCurrentRule((Grammar)((SchemaInformedFirstStartTagGrammar)siCurrentRule)
/*  956 */                   .getTypeEmpty());
/*      */             }
/*      */           } else {
/*  959 */             throw new EXIException("Attribute xsi=nil='" + nil + "' cannot be encoded!");
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  967 */         SchemaInformedGrammar sig = (SchemaInformedGrammar)currentGrammar;
/*  968 */         encodeSchemaInvalidAttributeEventCode(sig
/*  969 */             .getNumberOfDeclaredAttributes());
/*  970 */         AbstractEXIBodyCoder.RuntimeUriContext euc = encodeUri("http://www.w3.org/2001/XMLSchema-instance", this.channel);
/*      */         
/*  972 */         encodeLocalName("nil", euc, this.channel);
/*  973 */         if (this.preservePrefix) {
/*  974 */           encodeQNamePrefix(getXsiNilContext(), pfx, this.channel);
/*      */         }
/*      */         
/*  977 */         Datatype datatype = BuiltIn.getDefaultDatatype();
/*  978 */         isTypeValid(datatype, nil);
/*  979 */         writeValue(getXsiTypeContext());
/*      */       } 
/*      */     } else {
/*      */       
/*  983 */       encodeAttribute("http://www.w3.org/2001/XMLSchema-instance", "nil", pfx, nil);
/*      */     } 
/*      */ 
/*      */     
/*  987 */     this.lastEvent = EventType.ATTRIBUTE_XSI_NIL;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void encodeSchemaInvalidAttributeEventCode(int eventCode3) throws IOException {
/*  992 */     Grammar currentGrammar = getCurrentGrammar();
/*      */     
/*  994 */     int ec2ATdeviated = this.fidelityOptions.get2ndLevelEventCode(EventType.ATTRIBUTE_INVALID_VALUE, currentGrammar);
/*      */     
/*  996 */     encode2ndLevelEventCode(ec2ATdeviated);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1001 */     SchemaInformedGrammar sig = (SchemaInformedGrammar)currentGrammar;
/* 1002 */     this.channel.encodeNBitUnsignedInteger(eventCode3, 
/* 1003 */         MethodsBag.getCodingLength(sig.getNumberOfDeclaredAttributes() + 1));
/*      */   }
/*      */ 
/*      */   
/*      */   public void encodeAttribute(QName at, Value value) throws EXIException, IOException {
/* 1008 */     encodeAttribute(at.getNamespaceURI(), at.getLocalPart(), at
/* 1009 */         .getPrefix(), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void encodeAttribute(String uri, String localName, String prefix, Value value) throws EXIException, IOException {
/*      */     QNameContext qnc;
/* 1018 */     Grammar next, currentGrammar = getCurrentGrammar(); Production ei;
/* 1019 */     if ((ei = currentGrammar.getAttributeProduction(uri, localName)) != null) {
/*      */       
/* 1021 */       Attribute at = (Attribute)ei.getEvent();
/* 1022 */       qnc = at.getQNameContext();
/*      */       
/* 1024 */       if (isTypeValid(at.getDatatype(), value)) {
/* 1025 */         encode1stLevelEventCode(ei.getEventCode());
/*      */       } else {
/*      */         
/* 1028 */         SchemaInformedGrammar sig = (SchemaInformedGrammar)currentGrammar;
/*      */         
/* 1030 */         int eventCode3 = ei.getEventCode() - sig.getLeastAttributeEventCode();
/* 1031 */         encodeSchemaInvalidAttributeEventCode(eventCode3);
/* 1032 */         isTypeValid(BuiltIn.getDefaultDatatype(), value);
/*      */       } 
/* 1034 */       next = ei.getNextGrammar();
/*      */     } else {
/*      */       
/* 1037 */       switch (limitGrammars()) {
/*      */         case XSI_TYPE:
/* 1039 */           insertXsiTypeAnyType();
/* 1040 */           currentGrammar = getCurrentGrammar();
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1048 */       ei = currentGrammar.getAttributeNSProduction(uri);
/* 1049 */       if (ei == null) {
/* 1050 */         ei = currentGrammar.getProduction(EventType.ATTRIBUTE_GENERIC);
/* 1051 */         if (ei == null);
/*      */       } 
/*      */ 
/*      */       
/*      */       Attribute globalAT;
/*      */ 
/*      */       
/* 1058 */       if (currentGrammar.isSchemaInformed() && (
/* 1059 */         globalAT = getGlobalAttribute(uri, localName)) != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1068 */         if (isTypeValid(globalAT.getDatatype(), value)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1076 */           if (ei == null) {
/* 1077 */             encodeAttributeEventCodeUndeclared(currentGrammar, localName);
/*      */           } else {
/*      */             
/* 1080 */             encode1stLevelEventCode(ei.getEventCode());
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */           
/* 1094 */           SchemaInformedGrammar sig = (SchemaInformedGrammar)currentGrammar;
/* 1095 */           encodeSchemaInvalidAttributeEventCode(sig
/* 1096 */               .getNumberOfDeclaredAttributes());
/* 1097 */           isTypeValid(BuiltIn.getDefaultDatatype(), value);
/*      */         } 
/*      */         
/* 1100 */         if (ei == null || ei
/* 1101 */           .getEvent().isEventType(EventType.ATTRIBUTE_GENERIC)) {
/*      */ 
/*      */           
/* 1104 */           qnc = encodeQName(uri, localName, this.channel);
/* 1105 */           next = (ei == null) ? currentGrammar : ei.getNextGrammar();
/*      */         } else {
/*      */           
/* 1108 */           AttributeNS atNS = (AttributeNS)ei.getEvent();
/*      */           
/* 1110 */           AbstractEXIBodyCoder.RuntimeUriContext uc = getUri(atNS.getNamespaceUriID());
/* 1111 */           qnc = encodeLocalName(localName, uc, this.channel);
/* 1112 */           next = ei.getNextGrammar();
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1118 */         isTypeValid(BuiltIn.getDefaultDatatype(), value);
/*      */         
/* 1120 */         if (ei == null) {
/*      */ 
/*      */           
/* 1123 */           qnc = encodeUndeclaredAT(currentGrammar, uri, localName);
/*      */           
/* 1125 */           next = currentGrammar;
/*      */         } else {
/*      */           
/* 1128 */           qnc = encodeDeclaredAT(ei, uri, localName);
/* 1129 */           next = ei.getNextGrammar();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1135 */     assert qnc != null;
/* 1136 */     if (this.preservePrefix) {
/* 1137 */       encodeQNamePrefix(qnc, prefix, this.channel);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1142 */     writeValue(qnc);
/*      */ 
/*      */     
/* 1145 */     assert next != null;
/* 1146 */     updateCurrentRule(next);
/*      */     
/* 1148 */     if (value.getValueType() == ValueType.STRING && "http://www.w3.org/XML/1998/namespace"
/* 1149 */       .equals(uri)) {
/* 1150 */       AbstractEXIBodyCoder.ElementContext ec = getElementContext();
/* 1151 */       if ("preserve".equals(value.toString())) {
/* 1152 */         this.isXmlSpacePreserve = true;
/* 1153 */         ec.setXmlSpacePreserve(Boolean.TRUE);
/* 1154 */       } else if ("default".equals(value.toString())) {
/* 1155 */         this.isXmlSpacePreserve = false;
/* 1156 */         ec.setXmlSpacePreserve(Boolean.FALSE);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1161 */     this.lastEvent = EventType.ATTRIBUTE;
/*      */   }
/*      */ 
/*      */   
/*      */   private void encodeAttributeEventCodeUndeclared(Grammar currentGrammar, String localName) throws IOException, EXIException {
/* 1166 */     int ecATundeclared = this.fidelityOptions.get2ndLevelEventCode(EventType.ATTRIBUTE_GENERIC_UNDECLARED, currentGrammar);
/*      */ 
/*      */     
/* 1169 */     if (ecATundeclared == -1) {
/* 1170 */       assert this.fidelityOptions.isStrict();
/* 1171 */       throw new EXIException("Attribute '" + localName + "' cannot be encoded!");
/*      */     } 
/*      */     
/* 1174 */     assert ecATundeclared != -1;
/*      */     
/* 1176 */     encode2ndLevelEventCode(ecATundeclared);
/*      */   }
/*      */ 
/*      */   
/*      */   private QNameContext encodeDeclaredAT(Production ei, String uri, String localName) throws IOException {
/*      */     QNameContext qnc;
/* 1182 */     encode1stLevelEventCode(ei.getEventCode());
/*      */ 
/*      */     
/* 1185 */     if (ei.getEvent().isEventType(EventType.ATTRIBUTE_NS)) {
/*      */       
/* 1187 */       AttributeNS atNS = (AttributeNS)ei.getEvent();
/*      */       
/* 1189 */       AbstractEXIBodyCoder.RuntimeUriContext uc = getUri(atNS.getNamespaceUriID());
/* 1190 */       qnc = encodeLocalName(localName, uc, this.channel);
/*      */     }
/*      */     else {
/*      */       
/* 1194 */       qnc = encodeQName(uri, localName, this.channel);
/*      */     } 
/* 1196 */     return qnc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private QNameContext encodeUndeclaredAT(Grammar currentGrammar, String uri, String localName) throws EXIException, IOException {
/* 1203 */     encodeAttributeEventCodeUndeclared(currentGrammar, localName);
/*      */ 
/*      */     
/* 1206 */     QNameContext qnc = encodeQName(uri, localName, this.channel);
/*      */ 
/*      */     
/* 1209 */     currentGrammar.learnAttribute(new Attribute(qnc));
/* 1210 */     productionLearningCounting(currentGrammar);
/*      */     
/* 1212 */     return qnc;
/*      */   }
/*      */   
/*      */   protected Attribute getGlobalAttribute(String uri, String localName) {
/* 1216 */     AbstractEXIBodyCoder.RuntimeUriContext uc = getUri(uri);
/* 1217 */     if (uc != null) {
/* 1218 */       return getGlobalAttribute(uc, localName);
/*      */     }
/*      */     
/* 1221 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Attribute getGlobalAttribute(AbstractEXIBodyCoder.RuntimeUriContext uc, String localName) {
/* 1226 */     assert uc != null;
/* 1227 */     QNameContext qnc = uc.getQNameContext(localName);
/* 1228 */     if (qnc != null) {
/* 1229 */       return qnc.getGlobalAttribute();
/*      */     }
/*      */     
/* 1232 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WhiteSpace getDatatypeWhiteSpace() {
/* 1354 */     Grammar currGr = getCurrentGrammar();
/* 1355 */     if (currGr.isSchemaInformed() && currGr.getNumberOfEvents() > 0) {
/* 1356 */       Production prod = currGr.getProduction(0);
/* 1357 */       if (prod.getEvent().getEventType() == EventType.CHARACTERS) {
/* 1358 */         Characters ch = (Characters)prod.getEvent();
/* 1359 */         return ch.getDatatype().getWhiteSpace();
/*      */       } 
/*      */     } 
/*      */     
/* 1363 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void replace(char[] chars, int len) {
/* 1370 */     for (int i = 0; i < len; i++) {
/* 1371 */       if (chars[i] == '\t' || chars[i] == '\n' || chars[i] == '\r') {
/* 1372 */         chars[i] = ' ';
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   static void shiftLeft(char[] chars, int pos, int len) {
/* 1378 */     System.arraycopy(chars, pos + 1, chars, pos, len - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int collapse(char[] chars, int len) {
/* 1387 */     replace(chars, len);
/*      */     
/* 1389 */     int newLen = len;
/*      */ 
/*      */     
/* 1392 */     if (newLen > 1) {
/* 1393 */       int i = 0;
/* 1394 */       while (i < newLen - 1) {
/* 1395 */         char thisChar = chars[i];
/* 1396 */         char nextChar = chars[i + 1];
/* 1397 */         if (thisChar == ' ' && nextChar == ' ') {
/*      */           
/* 1399 */           shiftLeft(chars, i, newLen - i);
/* 1400 */           newLen--; continue;
/*      */         } 
/* 1402 */         i++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1408 */     newLen = trimSpaces(chars, newLen);
/*      */     
/* 1410 */     return newLen;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static int trimSpaces(char[] chars, int len) {
/* 1416 */     int newLen = len;
/*      */ 
/*      */     
/* 1419 */     while (newLen > 0 && chars[0] == ' ') {
/*      */       
/* 1421 */       shiftLeft(chars, 0, newLen);
/* 1422 */       newLen--;
/*      */     } 
/*      */     
/* 1425 */     int i = newLen - 1;
/* 1426 */     while (i >= 0 && chars[i] == ' ') {
/*      */       
/* 1428 */       newLen--;
/* 1429 */       i--;
/*      */     } 
/*      */     
/* 1432 */     return newLen;
/*      */   }
/*      */   
/*      */   static boolean isWS(char c) {
/* 1436 */     return (c == ' ' || c == '\n' || c == '\r' || c == '\t');
/*      */   }
/*      */   
/*      */   static boolean isSolelyWS(char[] chars, int len) {
/* 1440 */     for (int i = 0; i < len; i++) {
/* 1441 */       if (!isWS(chars[i])) {
/* 1442 */         return false;
/*      */       }
/*      */     } 
/* 1445 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   static int trimWS(char[] chars, int len) {
/* 1450 */     int newLen = len;
/*      */ 
/*      */     
/* 1453 */     while (newLen > 0 && isWS(chars[0])) {
/*      */       
/* 1455 */       shiftLeft(chars, 0, newLen);
/* 1456 */       newLen--;
/*      */     } 
/*      */     
/* 1459 */     int i = newLen - 1;
/* 1460 */     while (i >= 0 && isWS(chars[i])) {
/*      */       
/* 1462 */       newLen--;
/* 1463 */       i--;
/*      */     } 
/*      */     
/* 1466 */     return newLen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int modeValuesToCBuffer() {
/* 1473 */     int len = 0;
/* 1474 */     for (int i = 0; i < this.bChars.size(); i++) {
/* 1475 */       len += ((Value)this.bChars.get(i)).getCharactersLength();
/*      */     }
/* 1477 */     if (this.cbuffer == null || this.cbuffer.length < len) {
/* 1478 */       this.cbuffer = new char[len];
/*      */     }
/* 1480 */     int pos = 0;
/* 1481 */     for (int j = 0; j < this.bChars.size(); j++) {
/* 1482 */       Value v = this.bChars.get(j);
/* 1483 */       v.getCharacters(this.cbuffer, pos);
/* 1484 */       pos += v.getCharactersLength();
/*      */     } 
/* 1486 */     assert len == pos;
/* 1487 */     return len;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void checkPendingCharacters(EventType nextEvent) throws EXIException, IOException {
/* 1492 */     int numberOfValues = this.bChars.size();
/* 1493 */     if (numberOfValues > 0) {
/* 1494 */       if (numberOfValues == 1 && ((Value)this.bChars
/* 1495 */         .get(0)).getValueType() != ValueType.STRING) {
/*      */         
/* 1497 */         encodeCharactersForce(this.bChars.get(0));
/*      */       } else {
/*      */         
/* 1500 */         WhiteSpace ws = getDatatypeWhiteSpace();
/*      */         
/* 1502 */         if (!this.preserveLexicalValues && !this.isXmlSpacePreserve && ws != WhiteSpace.preserve) {
/* 1503 */           int len = modeValuesToCBuffer();
/* 1504 */           if (ws == WhiteSpace.replace) {
/*      */ 
/*      */ 
/*      */             
/* 1508 */             replace(this.cbuffer, len);
/* 1509 */           } else if (ws == WhiteSpace.collapse) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1514 */             replace(this.cbuffer, len);
/* 1515 */             len = collapse(this.cbuffer, len);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/* 1523 */           else if ((this.lastEvent != EventType.START_ELEMENT && this.lastEvent != EventType.ATTRIBUTE && this.lastEvent != EventType.ATTRIBUTE_XSI_NIL && this.lastEvent != EventType.ATTRIBUTE_XSI_TYPE && this.lastEvent != EventType.NAMESPACE_DECLARATION) || (nextEvent != EventType.END_ELEMENT && nextEvent != EventType.COMMENT && nextEvent != EventType.PROCESSING_INSTRUCTION && nextEvent != EventType.DOC_TYPE)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1536 */             if (isSolelyWS(this.cbuffer, len)) {
/* 1537 */               len = 0;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1543 */           if (len != 0)
/*      */           {
/*      */             
/* 1546 */             StringValue sv = new StringValue(new String(this.cbuffer, 0, len));
/*      */             
/* 1548 */             encodeCharactersForce((Value)sv);
/*      */           }
/*      */         
/*      */         }
/* 1552 */         else if (numberOfValues == 1) {
/* 1553 */           encodeCharactersForce(this.bChars.get(0));
/*      */         }
/*      */         else {
/*      */           
/* 1557 */           int len = modeValuesToCBuffer();
/* 1558 */           StringValue sv = new StringValue(new String(this.cbuffer, 0, len));
/*      */           
/* 1560 */           encodeCharactersForce((Value)sv);
/*      */         } 
/*      */       } 
/*      */       
/* 1564 */       this.bChars.clear();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void encodeCharacters(Value chars) throws EXIException, IOException {
/* 1569 */     this.bChars.add(chars);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void encodeCharactersForce(Value chars) throws EXIException, IOException {
/* 1575 */     Grammar currentGrammar = getCurrentGrammar();
/* 1576 */     Production ei = currentGrammar.getProduction(EventType.CHARACTERS);
/*      */ 
/*      */     
/* 1579 */     if (ei != null && 
/* 1580 */       isTypeValid(((DatatypeEvent)ei.getEvent()).getDatatype(), chars)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1585 */       encode1stLevelEventCode(ei.getEventCode());
/*      */       
/* 1587 */       writeValue((getElementContext()).qnameContext);
/*      */       
/* 1589 */       updateCurrentRule(ei.getNextGrammar());
/*      */     } else {
/*      */       
/* 1592 */       ei = currentGrammar.getProduction(EventType.CHARACTERS_GENERIC);
/*      */       
/* 1594 */       if (ei != null) {
/*      */         
/* 1596 */         encode1stLevelEventCode(ei.getEventCode());
/*      */         
/* 1598 */         isTypeValid(BuiltIn.getDefaultDatatype(), chars);
/* 1599 */         writeValue((getElementContext()).qnameContext);
/*      */         
/* 1601 */         updateCurrentRule(ei.getNextGrammar());
/*      */       }
/*      */       else {
/*      */         
/* 1605 */         int ecCHundeclared = this.fidelityOptions.get2ndLevelEventCode(EventType.CHARACTERS_GENERIC_UNDECLARED, currentGrammar);
/*      */ 
/*      */ 
/*      */         
/* 1609 */         if (ecCHundeclared == -1) {
/* 1610 */           if (this.exiFactory.isFragment()) {
/*      */             
/* 1612 */             throwWarning("Skip CH: '" + chars + "'");
/* 1613 */           } else if (!this.isXmlSpacePreserve && this.fidelityOptions
/* 1614 */             .isStrict() && chars
/* 1615 */             .toString().trim().length() == 0) {
/*      */             
/* 1617 */             throwWarning("Skip CH: '" + chars + "'");
/*      */           } else {
/* 1619 */             throw new EXIException("Characters '" + chars + "' cannot be encoded!");
/*      */           } 
/*      */         } else {
/*      */           Grammar updContextRule;
/*      */ 
/*      */ 
/*      */           
/* 1626 */           switch (limitGrammars()) {
/*      */             case XSI_TYPE:
/* 1628 */               insertXsiTypeAnyType();
/* 1629 */               currentGrammar = getCurrentGrammar();
/*      */ 
/*      */               
/* 1632 */               ei = currentGrammar.getProduction(EventType.CHARACTERS_GENERIC);
/* 1633 */               assert ei != null;
/* 1634 */               encode1stLevelEventCode(ei.getEventCode());
/*      */               
/* 1636 */               updContextRule = ei.getNextGrammar();
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 1641 */               encode2ndLevelEventCode(ecCHundeclared);
/*      */               
/* 1643 */               currentGrammar.learnCharacters();
/* 1644 */               productionLearningCounting(currentGrammar);
/*      */ 
/*      */               
/* 1647 */               updContextRule = currentGrammar.getElementContentGrammar();
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/* 1652 */           isTypeValid(BuiltIn.getDefaultDatatype(), chars);
/* 1653 */           writeValue((getElementContext()).qnameContext);
/*      */           
/* 1655 */           updateCurrentRule(updContextRule);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void encodeDocType(String name, String publicID, String systemID, String text) throws EXIException, IOException {
/* 1663 */     if (this.fidelityOptions.isFidelityEnabled("PRESERVE_DTDS")) {
/* 1664 */       checkPendingCharacters(EventType.DOC_TYPE);
/*      */ 
/*      */       
/* 1667 */       int ec2 = this.fidelityOptions.get2ndLevelEventCode(EventType.DOC_TYPE, 
/* 1668 */           getCurrentGrammar());
/* 1669 */       encode2ndLevelEventCode(ec2);
/*      */ 
/*      */       
/* 1672 */       writeString(name);
/* 1673 */       writeString(publicID);
/* 1674 */       writeString(systemID);
/* 1675 */       writeString(text);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void doLimitGrammarLearningForErCmPi() throws EXIException, IOException {
/* 1681 */     switch (limitGrammars()) {
/*      */       case XSI_TYPE:
/* 1683 */         insertXsiTypeAnyType();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void encodeEntityReference(String name) throws EXIException, IOException {
/* 1693 */     if (this.fidelityOptions.isFidelityEnabled("PRESERVE_DTDS")) {
/* 1694 */       checkPendingCharacters(EventType.ENTITY_REFERENCE);
/*      */ 
/*      */       
/* 1697 */       doLimitGrammarLearningForErCmPi();
/*      */ 
/*      */       
/* 1700 */       Grammar currentGrammar = getCurrentGrammar();
/* 1701 */       int ec2 = this.fidelityOptions.get2ndLevelEventCode(EventType.ENTITY_REFERENCE, currentGrammar);
/*      */       
/* 1703 */       encode2ndLevelEventCode(ec2);
/*      */ 
/*      */       
/* 1706 */       writeString(name);
/*      */ 
/*      */       
/* 1709 */       updateCurrentRule(currentGrammar.getElementContentGrammar());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void encodeComment(char[] ch, int start, int length) throws EXIException, IOException {
/* 1715 */     if (this.fidelityOptions.isFidelityEnabled("PRESERVE_COMMENTS")) {
/* 1716 */       checkPendingCharacters(EventType.COMMENT);
/*      */ 
/*      */       
/* 1719 */       doLimitGrammarLearningForErCmPi();
/*      */ 
/*      */       
/* 1722 */       Grammar currentGrammar = getCurrentGrammar();
/* 1723 */       int ec3 = this.fidelityOptions.get3rdLevelEventCode(EventType.COMMENT);
/* 1724 */       encode3rdLevelEventCode(ec3);
/*      */ 
/*      */       
/* 1727 */       writeString(new String(ch, start, length));
/*      */ 
/*      */       
/* 1730 */       updateCurrentRule(currentGrammar.getElementContentGrammar());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void encodeProcessingInstruction(String target, String data) throws EXIException, IOException {
/* 1736 */     if (this.fidelityOptions.isFidelityEnabled("PRESERVE_PIS")) {
/* 1737 */       checkPendingCharacters(EventType.PROCESSING_INSTRUCTION);
/*      */ 
/*      */       
/* 1740 */       doLimitGrammarLearningForErCmPi();
/*      */ 
/*      */       
/* 1743 */       Grammar currentGrammar = getCurrentGrammar();
/*      */       
/* 1745 */       int ec3 = this.fidelityOptions.get3rdLevelEventCode(EventType.PROCESSING_INSTRUCTION);
/* 1746 */       encode3rdLevelEventCode(ec3);
/*      */ 
/*      */       
/* 1749 */       writeString(target);
/* 1750 */       writeString(data);
/*      */ 
/*      */       
/* 1753 */       updateCurrentRule(currentGrammar.getElementContentGrammar());
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\AbstractEXIBodyEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */