/*     */ package com.siemens.ct.exi.core.io;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BitInputStream
/*     */ {
/*     */   public static final int BUFFER_CAPACITY = 8;
/*  45 */   private int capacity = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private int buffer = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream istream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BitInputStream(InputStream istream) {
/*  65 */     this.istream = istream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInputStream(InputStream istream) {
/*  77 */     this.istream = istream;
/*  78 */     this.buffer = this.capacity = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private final int readDirectByte() throws IOException {
/*     */     int b;
/*  84 */     if ((b = this.istream.read()) == -1) {
/*  85 */       throw new EOFException("Premature EOS found while reading data.");
/*     */     }
/*  87 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void readBuffer() throws IOException {
/*  94 */     this.buffer = readDirectByte();
/*  95 */     this.capacity = 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void align() throws IOException {
/* 105 */     if (this.capacity != 0) {
/* 106 */       this.capacity = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lookAhead() throws IOException {
/* 118 */     if (this.capacity == 0) {
/* 119 */       readBuffer();
/*     */     }
/* 121 */     return this.buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skip(long n) throws IOException {
/* 133 */     if (this.capacity == 0) {
/*     */       
/* 135 */       while (n != 0L) {
/* 136 */         n -= this.istream.skip(n);
/*     */       }
/*     */     } else {
/*     */       
/* 140 */       for (int i = 0; i < n; n++) {
/* 141 */         readBits(8);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBit() throws IOException {
/* 154 */     if (this.capacity == 0) {
/* 155 */       readBuffer();
/*     */     }
/* 157 */     return this.buffer >> --this.capacity & 0x1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBits(int n) throws IOException {
/*     */     int result;
/* 171 */     assert n > 0;
/*     */ 
/*     */     
/* 174 */     if (n <= this.capacity) {
/*     */       
/* 176 */       result = this.buffer >> (this.capacity -= n) & 255 >> 8 - n;
/*     */     }
/* 178 */     else if (this.capacity == 0 && n == 8) {
/*     */       
/* 180 */       result = readDirectByte();
/*     */     } else {
/*     */       
/* 183 */       result = this.buffer & 255 >> 8 - this.capacity;
/* 184 */       n -= this.capacity;
/* 185 */       this.capacity = 0;
/*     */ 
/*     */       
/* 188 */       while (n > 7) {
/* 189 */         if (this.capacity == 0) {
/* 190 */           readBuffer();
/*     */         }
/* 192 */         result = result << 8 | this.buffer;
/* 193 */         n -= 8;
/* 194 */         this.capacity = 0;
/*     */       } 
/*     */ 
/*     */       
/* 198 */       if (n > 0) {
/* 199 */         if (this.capacity == 0) {
/* 200 */           readBuffer();
/*     */         }
/* 202 */         result = result << n | this.buffer >> (this.capacity = 8 - n);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 207 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int read() throws IOException {
/* 219 */     return (this.capacity == 0) ? readDirectByte() : 
/* 220 */       readBits(8);
/*     */   }
/*     */   
/*     */   public void read(byte[] b, int off, int len) throws IOException {
/* 224 */     assert len >= 0;
/*     */     
/* 226 */     if (len != 0)
/*     */     {
/* 228 */       if (this.capacity == 0) {
/*     */         
/* 230 */         int readBytes = 0;
/*     */         do {
/* 232 */           int br = this.istream.read(b, readBytes, len - readBytes);
/* 233 */           if (br == -1) {
/* 234 */             throw new EOFException("Premature EOS found while reading data.");
/*     */           }
/*     */           
/* 237 */           readBytes += br;
/* 238 */         } while (readBytes < len);
/*     */       } else {
/* 240 */         int shift = 8 - this.capacity;
/*     */         
/* 242 */         for (int i = 0; i < len; i++)
/* 243 */           b[i] = (byte)(this.buffer << shift | (this.buffer = readDirectByte()) >> this.capacity); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\io\BitInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */