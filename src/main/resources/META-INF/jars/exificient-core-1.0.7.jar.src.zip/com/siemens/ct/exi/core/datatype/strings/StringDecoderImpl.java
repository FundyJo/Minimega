/*     */ package com.siemens.ct.exi.core.datatype.strings;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.io.channel.DecoderChannel;
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringDecoderImpl
/*     */   extends AbstractStringCoder
/*     */   implements StringDecoder
/*     */ {
/*     */   protected List<StringValue> globalValues;
/*     */   
/*     */   public StringDecoderImpl(boolean localValuePartitions) {
/*  49 */     this(localValuePartitions, 60);
/*     */   }
/*     */   
/*     */   public StringDecoderImpl(boolean localValuePartitions, int initialQNameLists) {
/*  53 */     super(localValuePartitions, initialQNameLists);
/*  54 */     this.globalValues = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringValue readValue(QNameContext context, DecoderChannel valueChannel) throws IOException {
/*     */     StringValue value;
/*  61 */     int L, i = valueChannel.decodeUnsignedInteger();
/*     */     
/*  63 */     switch (i) {
/*     */       
/*     */       case 0:
/*  66 */         if (this.localValuePartitions) {
/*  67 */           StringValue stringValue = readValueLocalHit(context, valueChannel); break;
/*     */         } 
/*  69 */         throw new IOException("EXI stream contains local-value hit even though profile options indicate otherwise.");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*  75 */         value = readValueGlobalHit(valueChannel);
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/*  81 */         L = i - 2;
/*     */ 
/*     */ 
/*     */         
/*  85 */         if (L > 0) {
/*  86 */           value = new StringValue(valueChannel.decodeStringOnly(L));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  92 */           addValue(context, value); break;
/*     */         } 
/*  94 */         value = StringCoder.EMPTY_STRING_VALUE;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     assert value != null;
/* 102 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringValue readValueLocalHit(QNameContext qnc, DecoderChannel valueChannel) throws IOException {
/* 107 */     assert this.localValuePartitions;
/* 108 */     int n = MethodsBag.getCodingLength(getNumberOfStringValues(qnc));
/* 109 */     int localID = valueChannel.decodeNBitUnsignedInteger(n);
/* 110 */     List<StringValue> lvs = this.localValues.get(qnc);
/* 111 */     assert lvs != null;
/* 112 */     assert localID < lvs.size();
/* 113 */     return lvs.get(localID);
/*     */   }
/*     */ 
/*     */   
/*     */   public final StringValue readValueGlobalHit(DecoderChannel valueChannel) throws IOException {
/* 118 */     int numberBitsGlobal = MethodsBag.getCodingLength(this.globalValues.size());
/* 119 */     int globalID = valueChannel.decodeNBitUnsignedInteger(numberBitsGlobal);
/* 120 */     return this.globalValues.get(globalID);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addValue(QNameContext qnc, StringValue value) {
/* 125 */     assert !this.globalValues.contains(value);
/* 126 */     this.globalValues.add(value);
/*     */ 
/*     */     
/* 129 */     addLocalValue(qnc, value);
/*     */   }
/*     */   
/*     */   public void clear() {
/* 133 */     super.clear();
/* 134 */     this.globalValues.clear();
/*     */   }
/*     */   
/*     */   public void setSharedStrings(List<String> sharedStrings) {
/* 138 */     for (String s : sharedStrings)
/* 139 */       addValue((QNameContext)null, new StringValue(s)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\strings\StringDecoderImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */