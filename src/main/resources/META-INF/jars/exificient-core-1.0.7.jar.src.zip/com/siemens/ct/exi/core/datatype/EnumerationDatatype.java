/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.types.BuiltInType;
/*    */ import com.siemens.ct.exi.core.util.MethodsBag;
/*    */ import com.siemens.ct.exi.core.values.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumerationDatatype
/*    */   extends AbstractDatatype
/*    */   implements EnumDatatype
/*    */ {
/*    */   protected Datatype dtEnumValues;
/*    */   protected int codingLength;
/*    */   protected Value[] enumValues;
/*    */   
/*    */   public EnumerationDatatype(Value[] enumValues, Datatype dtEnumValues, QNameContext schemaType) {
/* 48 */     super(BuiltInType.ENUMERATION, schemaType);
/*    */     
/* 50 */     if (dtEnumValues.getBuiltInType() != BuiltInType.QNAME && dtEnumValues
/* 51 */       .getBuiltInType() != BuiltInType.ENUMERATION) {
/* 52 */       this.dtEnumValues = dtEnumValues;
/* 53 */       this.enumValues = enumValues;
/* 54 */       this.codingLength = MethodsBag.getCodingLength(enumValues.length);
/*    */     } else {
/* 56 */       throw new RuntimeException("Enumeration type values can't be of type Enumeration or QName");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Datatype getEnumValueDatatype() {
/* 62 */     return this.dtEnumValues;
/*    */   }
/*    */   
/*    */   public DatatypeID getDatatypeID() {
/* 66 */     return this.dtEnumValues.getDatatypeID();
/*    */   }
/*    */   
/*    */   public int getEnumerationSize() {
/* 70 */     return this.enumValues.length;
/*    */   }
/*    */   
/*    */   public int getCodingLength() {
/* 74 */     return this.codingLength;
/*    */   }
/*    */   
/*    */   public Value getEnumValue(int i) {
/* 78 */     assert i >= 0 && i < this.enumValues.length;
/* 79 */     return this.enumValues[i];
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 84 */     if (super.equals(o) && o instanceof EnumerationDatatype) {
/* 85 */       EnumerationDatatype e = (EnumerationDatatype)o;
/* 86 */       if (this.dtEnumValues.equals(e.dtEnumValues) && this.enumValues.length == e.enumValues.length) {
/*    */         
/* 88 */         for (int i = 0; i < this.enumValues.length; i++) {
/* 89 */           if (!this.enumValues[i].equals(e.enumValues[i])) {
/* 90 */             return false;
/*    */           }
/*    */         } 
/* 93 */         return true;
/*    */       } 
/*    */     } 
/* 96 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\EnumerationDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */