/*    */ package com.siemens.ct.exi.core.datatype;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.types.BuiltInType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BinaryBase64Datatype
/*    */   extends AbstractBinaryDatatype
/*    */ {
/*    */   public BinaryBase64Datatype(QNameContext schemaType) {
/* 39 */     super(BuiltInType.BINARY_BASE64, schemaType);
/*    */   }
/*    */   
/*    */   public DatatypeID getDatatypeID() {
/* 43 */     return DatatypeID.exi_base64Binary;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\BinaryBase64Datatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */