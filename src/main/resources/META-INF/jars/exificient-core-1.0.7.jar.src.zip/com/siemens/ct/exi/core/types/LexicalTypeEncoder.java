/*     */ package com.siemens.ct.exi.core.types;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.DatatypeID;
/*     */ import com.siemens.ct.exi.core.datatype.RestrictedCharacterSetDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.charset.RestrictedCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDBase64CharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDBooleanCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDDateTimeCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDDecimalCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDDoubleCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDHexBinaryCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDIntegerCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.charset.XSDStringCharacterSet;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringEncoder;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexicalTypeEncoder
/*     */   extends AbstractTypeEncoder
/*     */ {
/*  56 */   protected RestrictedCharacterSetDatatype rcsBase64Binary = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDBase64CharacterSet(), null);
/*     */   
/*  58 */   protected RestrictedCharacterSetDatatype rcsHexBinary = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDHexBinaryCharacterSet(), null);
/*     */   
/*  60 */   protected RestrictedCharacterSetDatatype rcsBoolean = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDBooleanCharacterSet(), null);
/*     */   
/*  62 */   protected RestrictedCharacterSetDatatype rcsDateTime = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDDateTimeCharacterSet(), null);
/*     */   
/*  64 */   protected RestrictedCharacterSetDatatype rcsDecimal = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDDecimalCharacterSet(), null);
/*     */   
/*  66 */   protected RestrictedCharacterSetDatatype rcsDouble = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDDoubleCharacterSet(), null);
/*     */   
/*  68 */   protected RestrictedCharacterSetDatatype rcsInteger = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDIntegerCharacterSet(), null);
/*     */   
/*  70 */   protected RestrictedCharacterSetDatatype rcsString = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)new XSDStringCharacterSet(), null);
/*     */   
/*     */   protected Value lastValue;
/*     */   
/*     */   public Datatype lastDatatype;
/*     */   
/*     */   public LexicalTypeEncoder() throws EXIException {
/*  77 */     this((QName[])null, (QName[])null, (Map<QName, Datatype>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexicalTypeEncoder(QName[] dtrMapTypes, QName[] dtrMapRepresentations, Map<QName, Datatype> dtrMapRepresentationsDatatype) throws EXIException {
/*  84 */     super(dtrMapTypes, dtrMapRepresentations, dtrMapRepresentationsDatatype);
/*     */   }
/*     */   
/*     */   public boolean isValid(Datatype datatype, Value value) {
/*  88 */     if (this.dtrMapInUse) {
/*  89 */       this.lastDatatype = getDtrDatatype(datatype);
/*     */     } else {
/*  91 */       this.lastDatatype = datatype;
/*     */     } 
/*     */     
/*  94 */     this.lastValue = value;
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeValue(QNameContext qnContext, EncoderChannel valueChannel, StringEncoder stringEncoder) throws IOException {
/* 100 */     String lastValueString = this.lastValue.toString();
/* 101 */     switch (this.lastDatatype.getDatatypeID()) {
/*     */       case exi_base64Binary:
/* 103 */         isValid((Datatype)this.rcsBase64Binary, this.lastValue);
/* 104 */         writeRCSValue(this.rcsBase64Binary, qnContext, valueChannel, stringEncoder, lastValueString);
/*     */         return;
/*     */       
/*     */       case exi_hexBinary:
/* 108 */         isValid((Datatype)this.rcsHexBinary, this.lastValue);
/* 109 */         writeRCSValue(this.rcsHexBinary, qnContext, valueChannel, stringEncoder, lastValueString);
/*     */         return;
/*     */       
/*     */       case exi_boolean:
/* 113 */         isValid((Datatype)this.rcsBoolean, this.lastValue);
/* 114 */         writeRCSValue(this.rcsBoolean, qnContext, valueChannel, stringEncoder, lastValueString);
/*     */         return;
/*     */       
/*     */       case exi_dateTime:
/*     */       case exi_time:
/*     */       case exi_date:
/*     */       case exi_gYearMonth:
/*     */       case exi_gYear:
/*     */       case exi_gMonthDay:
/*     */       case exi_gDay:
/*     */       case exi_gMonth:
/* 125 */         isValid((Datatype)this.rcsDateTime, this.lastValue);
/* 126 */         writeRCSValue(this.rcsDateTime, qnContext, valueChannel, stringEncoder, lastValueString);
/*     */         return;
/*     */       
/*     */       case exi_decimal:
/* 130 */         isValid((Datatype)this.rcsDecimal, this.lastValue);
/* 131 */         writeRCSValue(this.rcsDecimal, qnContext, valueChannel, stringEncoder, lastValueString);
/*     */         return;
/*     */       
/*     */       case exi_double:
/* 135 */         isValid((Datatype)this.rcsDouble, this.lastValue);
/* 136 */         writeRCSValue(this.rcsDouble, qnContext, valueChannel, stringEncoder, lastValueString);
/*     */         return;
/*     */       
/*     */       case exi_integer:
/* 140 */         isValid((Datatype)this.rcsInteger, this.lastValue);
/* 141 */         writeRCSValue(this.rcsInteger, qnContext, valueChannel, stringEncoder, lastValueString);
/*     */         return;
/*     */ 
/*     */       
/*     */       case exi_string:
/* 146 */         stringEncoder.writeValue(qnContext, valueChannel, this.lastValue
/* 147 */             .toString());
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 152 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\LexicalTypeEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */