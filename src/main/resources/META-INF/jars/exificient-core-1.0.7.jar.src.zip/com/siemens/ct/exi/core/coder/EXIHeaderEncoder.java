/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.CodingMode;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EncodingOptions;
/*     */ import com.siemens.ct.exi.core.FidelityOptions;
/*     */ import com.siemens.ct.exi.core.datatype.strings.StringCoder;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.Grammars;
/*     */ import com.siemens.ct.exi.core.io.channel.BitEncoderChannel;
/*     */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*     */ import com.siemens.ct.exi.core.values.BooleanValue;
/*     */ import com.siemens.ct.exi.core.values.DecimalValue;
/*     */ import com.siemens.ct.exi.core.values.IntegerValue;
/*     */ import com.siemens.ct.exi.core.values.QNameValue;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIHeaderEncoder
/*     */   extends AbstractEXIHeader
/*     */ {
/*     */   public void write(BitEncoderChannel headerChannel, EXIFactory f) throws EXIException {
/*     */     try {
/*  77 */       EncodingOptions headerOptions = f.getEncodingOptions();
/*  78 */       CodingMode codingMode = f.getCodingMode();
/*     */ 
/*     */       
/*  81 */       if (headerOptions.isOptionEnabled("INCLUDE_COOKIE")) {
/*     */ 
/*     */         
/*  84 */         headerChannel.encode(36);
/*  85 */         headerChannel.encode(69);
/*  86 */         headerChannel.encode(88);
/*  87 */         headerChannel.encode(73);
/*     */       } 
/*     */ 
/*     */       
/*  91 */       headerChannel.encodeNBitUnsignedInteger(2, 2);
/*     */ 
/*     */ 
/*     */       
/*  95 */       boolean includeOptions = headerOptions.isOptionEnabled("INCLUDE_OPTIONS");
/*  96 */       headerChannel.encodeBoolean(includeOptions);
/*     */ 
/*     */       
/*  99 */       headerChannel.encodeBoolean(false);
/* 100 */       headerChannel.encodeNBitUnsignedInteger(0, 4);
/*     */ 
/*     */       
/* 103 */       if (includeOptions) {
/* 104 */         writeEXIOptions(f, (EncoderChannel)headerChannel);
/*     */       }
/*     */ 
/*     */       
/* 108 */       if (codingMode != CodingMode.BIT_PACKED) {
/* 109 */         headerChannel.align();
/* 110 */         headerChannel.flush();
/*     */       }
/*     */     
/* 113 */     } catch (IOException e) {
/* 114 */       throw new EXIException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEXIOptions(EXIFactory f, EncoderChannel encoderChannel) throws EXIException, IOException {
/* 122 */     EXIBodyEncoderInOrder encoder = (EXIBodyEncoderInOrder)getHeaderFactory().createEXIBodyEncoder();
/* 123 */     encoder.setOutputChannel(encoderChannel);
/*     */     
/* 125 */     encoder.encodeStartDocument();
/* 126 */     encoder.encodeStartElement("http://www.w3.org/2009/exi", "header", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (isLessCommon(f)) {
/* 135 */       encoder.encodeStartElement("http://www.w3.org/2009/exi", "lesscommon", null);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       if (isUncommon(f)) {
/* 141 */         encoder.encodeStartElement("http://www.w3.org/2009/exi", "uncommon", null);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 146 */         if (isUserDefinedMetaData(f))
/*     */         {
/* 148 */           if (f.getEncodingOptions().isOptionEnabled("INCLUDE_PROFILE_VALUES")) {
/*     */ 
/*     */             
/* 151 */             encoder.encodeStartElement("http://www.w3.org/2009/exi", "p", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 167 */             boolean negative = f.isLocalValuePartitions();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 178 */             IntegerValue integral = IntegerValue.valueOf(1 + f
/* 179 */                 .getMaximumNumberOfBuiltInElementGrammars());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 190 */             IntegerValue revFractional = IntegerValue.valueOf(1 + f
/* 191 */                 .getMaximumNumberOfBuiltInProductions());
/*     */             
/* 193 */             QNameValue qnv = new QNameValue("http://www.w3.org/2001/XMLSchema", "decimal", null);
/*     */             
/* 195 */             encoder.encodeAttributeXsiType((Value)qnv, null);
/* 196 */             DecimalValue dv = new DecimalValue(negative, integral, revFractional);
/*     */             
/* 198 */             encoder.encodeCharactersForce((Value)dv);
/*     */ 
/*     */             
/* 201 */             encoder.encodeEndElement();
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 208 */         if (isAlignment(f)) {
/* 209 */           encoder.encodeStartElement("http://www.w3.org/2009/exi", "alignment", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 215 */           if (isByte(f)) {
/* 216 */             encoder.encodeStartElement("http://www.w3.org/2009/exi", "byte", null);
/*     */             
/* 218 */             encoder.encodeEndElement();
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 223 */           if (isPreCompress(f)) {
/* 224 */             encoder.encodeStartElement("http://www.w3.org/2009/exi", "pre-compress", null);
/*     */             
/* 226 */             encoder.encodeEndElement();
/*     */           } 
/*     */           
/* 229 */           encoder.encodeEndElement();
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 235 */         if (isSelfContained(f)) {
/* 236 */           encoder.encodeStartElement("http://www.w3.org/2009/exi", "selfContained", null);
/*     */           
/* 238 */           encoder.encodeEndElement();
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 244 */         if (isValueMaxLength(f)) {
/* 245 */           encoder.encodeStartElement("http://www.w3.org/2009/exi", "valueMaxLength", null);
/*     */ 
/*     */           
/* 248 */           encoder.encodeCharacters((Value)IntegerValue.valueOf(f
/* 249 */                 .getValueMaxLength()));
/* 250 */           encoder.encodeEndElement();
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 256 */         if (isValuePartitionCapacity(f)) {
/* 257 */           encoder.encodeStartElement("http://www.w3.org/2009/exi", "valuePartitionCapacity", null);
/*     */ 
/*     */ 
/*     */           
/* 261 */           encoder.encodeCharacters((Value)IntegerValue.valueOf(f
/* 262 */                 .getValuePartitionCapacity()));
/* 263 */           encoder.encodeEndElement();
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 269 */         if (isDatatypeRepresentationMap(f)) {
/*     */           
/* 271 */           QName[] types = f.getDatatypeRepresentationMapTypes();
/*     */           
/* 273 */           QName[] representations = f.getDatatypeRepresentationMapRepresentations();
/* 274 */           assert types.length == representations.length;
/*     */ 
/*     */           
/* 277 */           for (int i = 0; i < types.length; i++) {
/* 278 */             encoder.encodeStartElement("http://www.w3.org/2009/exi", "datatypeRepresentationMap", null);
/*     */ 
/*     */ 
/*     */             
/* 282 */             QName type = types[i];
/* 283 */             encoder.encodeStartElement(type.getNamespaceURI(), type
/* 284 */                 .getLocalPart(), null);
/* 285 */             encoder.encodeEndElement();
/*     */ 
/*     */             
/* 288 */             QName representation = representations[i];
/* 289 */             encoder.encodeStartElement(representation
/* 290 */                 .getNamespaceURI(), representation
/* 291 */                 .getLocalPart(), null);
/* 292 */             encoder.encodeEndElement();
/*     */             
/* 294 */             encoder.encodeEndElement();
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 299 */         encoder.encodeEndElement();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 305 */       if (isPreserve(f)) {
/* 306 */         encoder.encodeStartElement("http://www.w3.org/2009/exi", "preserve", null);
/*     */ 
/*     */         
/* 309 */         FidelityOptions fo = f.getFidelityOptions();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 314 */         if (fo.isFidelityEnabled("PRESERVE_DTDS")) {
/* 315 */           encoder.encodeStartElement("http://www.w3.org/2009/exi", "dtd", null);
/*     */           
/* 317 */           encoder.encodeEndElement();
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 322 */         if (fo.isFidelityEnabled("PRESERVE_PREFIXES")) {
/* 323 */           encoder.encodeStartElement("http://www.w3.org/2009/exi", "prefixes", null);
/*     */           
/* 325 */           encoder.encodeEndElement();
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 330 */         if (fo.isFidelityEnabled("PRESERVE_LEXICAL_VALUES")) {
/* 331 */           encoder.encodeStartElement("http://www.w3.org/2009/exi", "lexicalValues", null);
/*     */           
/* 333 */           encoder.encodeEndElement();
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 338 */         if (fo.isFidelityEnabled("PRESERVE_COMMENTS")) {
/* 339 */           encoder.encodeStartElement("http://www.w3.org/2009/exi", "comments", null);
/*     */           
/* 341 */           encoder.encodeEndElement();
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 346 */         if (fo.isFidelityEnabled("PRESERVE_PIS")) {
/* 347 */           encoder.encodeStartElement("http://www.w3.org/2009/exi", "pis", null);
/*     */           
/* 349 */           encoder.encodeEndElement();
/*     */         } 
/*     */         
/* 352 */         encoder.encodeEndElement();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 358 */       if (isBlockSize(f)) {
/* 359 */         encoder.encodeStartElement("http://www.w3.org/2009/exi", "blockSize", null);
/*     */ 
/*     */ 
/*     */         
/* 363 */         encoder.encodeCharacters((Value)IntegerValue.valueOf(f.getBlockSize()));
/* 364 */         encoder.encodeEndElement();
/*     */       } 
/*     */       
/* 367 */       encoder.encodeEndElement();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 373 */     if (isCommon(f)) {
/* 374 */       encoder.encodeStartElement("http://www.w3.org/2009/exi", "common", null);
/*     */ 
/*     */ 
/*     */       
/* 378 */       if (isCompression(f)) {
/* 379 */         encoder.encodeStartElement("http://www.w3.org/2009/exi", "compression", null);
/*     */         
/* 381 */         encoder.encodeEndElement();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 386 */       if (isFragment(f)) {
/* 387 */         encoder.encodeStartElement("http://www.w3.org/2009/exi", "fragment", null);
/*     */         
/* 389 */         encoder.encodeEndElement();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 394 */       if (isSchemaId(f)) {
/* 395 */         encoder.encodeStartElement("http://www.w3.org/2009/exi", "schemaId", null);
/*     */ 
/*     */         
/* 398 */         Grammars g = f.getGrammars();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 404 */         if (g.isBuiltInXMLSchemaTypesOnly()) {
/* 405 */           assert "".equals(g.getSchemaId());
/*     */           
/* 407 */           encoder.encodeCharacters((Value)StringCoder.EMPTY_STRING_VALUE);
/*     */         }
/* 409 */         else if (g.isSchemaInformed()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 418 */           String schemaId = g.getSchemaId();
/* 419 */           assert schemaId != null && schemaId.length() > 0;
/*     */           
/* 421 */           encoder.encodeCharacters((Value)new StringValue(schemaId));
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 431 */           encoder.encodeAttributeXsiNil((Value)BooleanValue.BOOLEAN_VALUE_TRUE, null);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 436 */         encoder.encodeEndElement();
/*     */       } 
/*     */       
/* 439 */       encoder.encodeEndElement();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 445 */     if (isStrict(f)) {
/* 446 */       encoder.encodeStartElement("http://www.w3.org/2009/exi", "strict", null);
/* 447 */       encoder.encodeEndElement();
/*     */     } 
/*     */     
/* 450 */     encoder.encodeEndElement();
/* 451 */     encoder.encodeEndDocument();
/*     */   }
/*     */   
/*     */   protected boolean isLessCommon(EXIFactory f) {
/* 455 */     return (isUncommon(f) || isPreserve(f) || isBlockSize(f));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isUncommon(EXIFactory f) {
/* 461 */     return (isUserDefinedMetaData(f) || isAlignment(f) || 
/* 462 */       isSelfContained(f) || isValueMaxLength(f) || 
/* 463 */       isValuePartitionCapacity(f) || isDatatypeRepresentationMap(f));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isUserDefinedMetaData(EXIFactory f) {
/* 468 */     return (f.isGrammarLearningDisabled() || !f.isLocalValuePartitions());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isAlignment(EXIFactory f) {
/* 473 */     return (isByte(f) || isPreCompress(f));
/*     */   }
/*     */   
/*     */   protected boolean isByte(EXIFactory f) {
/* 477 */     return (f.getCodingMode() == CodingMode.BYTE_PACKED);
/*     */   }
/*     */   
/*     */   protected boolean isPreCompress(EXIFactory f) {
/* 481 */     return (f.getCodingMode() == CodingMode.PRE_COMPRESSION);
/*     */   }
/*     */   
/*     */   protected boolean isSelfContained(EXIFactory f) {
/* 485 */     return f.getFidelityOptions().isFidelityEnabled("SELF_CONTAINED");
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueMaxLength(EXIFactory f) {
/* 490 */     return (f.getValueMaxLength() != -1);
/*     */   }
/*     */   
/*     */   protected boolean isValuePartitionCapacity(EXIFactory f) {
/* 494 */     return (f.getValuePartitionCapacity() >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDatatypeRepresentationMap(EXIFactory f) {
/* 500 */     return (!f.getFidelityOptions().isFidelityEnabled("PRESERVE_LEXICAL_VALUES") && f
/*     */       
/* 502 */       .getDatatypeRepresentationMapTypes() != null && (f
/* 503 */       .getDatatypeRepresentationMapTypes()).length > 0);
/*     */   }
/*     */   
/*     */   protected boolean isPreserve(EXIFactory f) {
/* 507 */     FidelityOptions fo = f.getFidelityOptions();
/*     */     
/* 509 */     return (fo.isFidelityEnabled("PRESERVE_DTDS") || fo
/* 510 */       .isFidelityEnabled("PRESERVE_PREFIXES") || fo
/* 511 */       .isFidelityEnabled("PRESERVE_LEXICAL_VALUES") || fo
/* 512 */       .isFidelityEnabled("PRESERVE_COMMENTS") || fo
/* 513 */       .isFidelityEnabled("PRESERVE_PIS"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isBlockSize(EXIFactory f) {
/* 519 */     return (f.getBlockSize() != 1000000 && (f
/* 520 */       .getCodingMode() == CodingMode.COMPRESSION || f.getCodingMode() == CodingMode.PRE_COMPRESSION));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isCommon(EXIFactory f) {
/* 525 */     return (isCompression(f) || isFragment(f) || isSchemaId(f));
/*     */   }
/*     */   
/*     */   protected boolean isCompression(EXIFactory f) {
/* 529 */     return (f.getCodingMode() == CodingMode.COMPRESSION);
/*     */   }
/*     */   
/*     */   protected boolean isFragment(EXIFactory f) {
/* 533 */     return f.isFragment();
/*     */   }
/*     */   
/*     */   protected boolean isSchemaId(EXIFactory f) {
/* 537 */     EncodingOptions ho = f.getEncodingOptions();
/* 538 */     return ho.isOptionEnabled("INCLUDE_SCHEMA_ID");
/*     */   }
/*     */   
/*     */   protected boolean isStrict(EXIFactory f) {
/* 542 */     return f.getFidelityOptions().isStrict();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIHeaderEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */