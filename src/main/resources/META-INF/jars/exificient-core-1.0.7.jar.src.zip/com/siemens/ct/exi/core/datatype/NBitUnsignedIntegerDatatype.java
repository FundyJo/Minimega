/*     */ package com.siemens.ct.exi.core.datatype;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.types.BuiltInType;
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import com.siemens.ct.exi.core.values.IntegerValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBitUnsignedIntegerDatatype
/*     */   extends AbstractDatatype
/*     */ {
/*     */   protected IntegerValue validValue;
/*     */   protected final IntegerValue lowerBound;
/*     */   protected final IntegerValue upperBound;
/*     */   protected final int numberOfBits4Range;
/*     */   
/*     */   public NBitUnsignedIntegerDatatype(IntegerValue lowerBound, IntegerValue upperBound, QNameContext schemaType) {
/*  48 */     super(BuiltInType.NBIT_UNSIGNED_INTEGER, schemaType);
/*     */ 
/*     */     
/*  51 */     assert upperBound.compareTo(lowerBound) >= 0;
/*  52 */     this.lowerBound = lowerBound;
/*  53 */     this.upperBound = upperBound;
/*     */ 
/*     */     
/*  56 */     IntegerValue diff = upperBound.subtract(lowerBound);
/*  57 */     this.numberOfBits4Range = MethodsBag.getCodingLength(diff.intValue() + 1);
/*     */   }
/*     */   
/*     */   public DatatypeID getDatatypeID() {
/*  61 */     return DatatypeID.exi_integer;
/*     */   }
/*     */   
/*     */   public IntegerValue getLowerBound() {
/*  65 */     return this.lowerBound;
/*     */   }
/*     */   
/*     */   public IntegerValue getUpperBound() {
/*  69 */     return this.upperBound;
/*     */   }
/*     */   
/*     */   public int getNumberOfBits() {
/*  73 */     return this.numberOfBits4Range;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 119 */     if (super.equals(o) && o instanceof NBitUnsignedIntegerDatatype) {
/* 120 */       NBitUnsignedIntegerDatatype nb = (NBitUnsignedIntegerDatatype)o;
/* 121 */       return (this.lowerBound.equals(nb.lowerBound) && this.upperBound
/* 122 */         .equals(nb.upperBound));
/*     */     } 
/* 124 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\NBitUnsignedIntegerDatatype.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */