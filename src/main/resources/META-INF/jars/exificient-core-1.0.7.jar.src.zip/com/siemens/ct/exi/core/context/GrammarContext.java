/*    */ package com.siemens.ct.exi.core.context;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GrammarContext
/*    */ {
/*    */   protected final GrammarUriContext[] grammarUriContexts;
/*    */   protected final int numberofQNamesContexts;
/*    */   
/*    */   public GrammarContext(GrammarUriContext[] grammarUriContexts, int numberofQNamesContexts) {
/* 42 */     this.grammarUriContexts = grammarUriContexts;
/* 43 */     this.numberofQNamesContexts = numberofQNamesContexts;
/*    */   }
/*    */   
/*    */   public int getNumberOfGrammarUriContexts() {
/* 47 */     return this.grammarUriContexts.length;
/*    */   }
/*    */   
/*    */   public GrammarUriContext getGrammarUriContext(int id) {
/* 51 */     return this.grammarUriContexts[id];
/*    */   }
/*    */   
/*    */   public GrammarUriContext getGrammarUriContext(String namespaceUri) {
/* 55 */     for (int i = 0; i < this.grammarUriContexts.length; i++) {
/* 56 */       GrammarUriContext uc = this.grammarUriContexts[i];
/* 57 */       if (uc.namespaceUri.equals(namespaceUri)) {
/* 58 */         return uc;
/*    */       }
/*    */     } 
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   public int getNumberOfGrammarQNameContexts() {
/* 65 */     return this.numberofQNamesContexts;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 70 */     if (this == o)
/* 71 */       return true; 
/* 72 */     if (!(o instanceof GrammarContext)) {
/* 73 */       return false;
/*    */     }
/* 75 */     GrammarContext that = (GrammarContext)o;
/*    */     
/* 77 */     if (this.numberofQNamesContexts != that.numberofQNamesContexts)
/* 78 */       return false; 
/* 79 */     return Arrays.equals((Object[])this.grammarUriContexts, (Object[])that.grammarUriContexts);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\context\GrammarContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */