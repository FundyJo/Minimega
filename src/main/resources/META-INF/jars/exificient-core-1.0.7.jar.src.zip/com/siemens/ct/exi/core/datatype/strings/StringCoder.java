/*    */ package com.siemens.ct.exi.core.datatype.strings;
/*    */ 
/*    */ import com.siemens.ct.exi.core.context.QNameContext;
/*    */ import com.siemens.ct.exi.core.values.StringValue;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface StringCoder
/*    */ {
/* 41 */   public static final StringValue EMPTY_STRING_VALUE = new StringValue("");
/*    */   public static final int DEFAULT_INITIAL_QNAME_LISTS = 60;
/*    */   
/*    */   int getNumberOfStringValues(QNameContext paramQNameContext);
/*    */   
/*    */   void clear();
/*    */   
/*    */   void setSharedStrings(List<String> paramList);
/*    */   
/*    */   boolean isLocalValuePartitions();
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\datatype\strings\StringCoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */