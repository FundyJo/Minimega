/*     */ package com.siemens.ct.exi.core.grammars.grammar;
/*     */ 
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import com.siemens.ct.exi.core.grammars.production.SchemaLessProduction;
/*     */ import com.siemens.ct.exi.core.util.MethodsBag;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBuiltInGrammar
/*     */   extends AbstractGrammar
/*     */   implements BuiltInGrammar
/*     */ {
/*     */   protected List<Production> containers;
/*  52 */   protected int ec1Length = -1;
/*     */ 
/*     */   
/*     */   public AbstractBuiltInGrammar() {
/*  56 */     this.containers = new ArrayList<>();
/*  57 */     this.ec1Length = 0;
/*     */   }
/*     */   
/*     */   public boolean hasEndElement() {
/*  61 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void stopLearning() {
/*  66 */     if (this.stopLearningContainerSize == -1) {
/*  67 */       this.stopLearningContainerSize = this.containers.size();
/*     */     }
/*     */   }
/*     */   
/*     */   public final boolean isSchemaInformed() {
/*  72 */     return false;
/*     */   }
/*     */   
/*     */   public Grammar getTypeEmpty() {
/*  76 */     return this;
/*     */   }
/*     */   
/*     */   public int getNumberOfEvents() {
/*  80 */     return this.containers.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addProduction(Event event, Grammar grammar) {
/*  88 */     this.containers.add(new SchemaLessProduction(this, grammar, event, 
/*  89 */           getNumberOfEvents()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     this.ec1Length = MethodsBag.getCodingLength(this.containers.size() + 1);
/*     */   }
/*     */   
/*     */   protected boolean contains(Event event) {
/*  98 */     Iterator<Production> iter = this.containers.iterator();
/*     */     
/* 100 */     while (iter.hasNext()) {
/* 101 */       if (((Production)iter.next()).getEvent().equals(event)) {
/* 102 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 115 */     StringBuilder sb = new StringBuilder(getLabel() + "//\t");
/*     */     
/* 117 */     sb.append("[");
/* 118 */     for (int ec = 0; ec < getNumberOfEvents(); ec++) {
/* 119 */       sb.append("," + getProduction(ec).getEvent());
/*     */     }
/* 121 */     sb.append("]");
/*     */     
/* 123 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public Production getProduction(EventType eventType) {
/* 127 */     for (int i = 0; i < this.containers.size(); i++) {
/* 128 */       Production ei = this.containers.get(i);
/* 129 */       if (ei.getEvent().isEventType(eventType) && 
/* 130 */         !isExiProfilGhostNode(ei)) {
/* 131 */         return ei;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   private final boolean isExiProfilGhostNode(Production ei) {
/* 140 */     if (this.stopLearningContainerSize == -1)
/*     */     {
/* 142 */       return false;
/*     */     }
/* 144 */     return (ei.getEventCode() < getNumberOfEvents() - this.stopLearningContainerSize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Production getStartElementProduction(String namespaceURI, String localName) {
/* 150 */     for (int i = 0; i < this.containers.size(); i++) {
/* 151 */       Production ei = this.containers.get(i);
/* 152 */       if (ei.getEvent().isEventType(EventType.START_ELEMENT) && 
/* 153 */         checkQualifiedName(((StartElement)ei
/* 154 */           .getEvent()).getQName(), namespaceURI, localName))
/*     */       {
/* 156 */         if (!isExiProfilGhostNode(ei)) {
/* 157 */           return ei;
/*     */         }
/*     */       }
/*     */     } 
/* 161 */     return null;
/*     */   }
/*     */   
/*     */   public Production getStartElementNSProduction(String namespaceURI) {
/* 165 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Production getAttributeProduction(String namespaceURI, String localName) {
/* 170 */     for (int i = 0; i < this.containers.size(); i++) {
/* 171 */       Production ei = this.containers.get(i);
/* 172 */       if (ei.getEvent().isEventType(EventType.ATTRIBUTE) && 
/* 173 */         checkQualifiedName(((Attribute)ei
/* 174 */           .getEvent()).getQName(), namespaceURI, localName))
/*     */       {
/* 176 */         if (!isExiProfilGhostNode(ei)) {
/* 177 */           return ei;
/*     */         }
/*     */       }
/*     */     } 
/* 181 */     return null;
/*     */   }
/*     */   
/*     */   public Production getAttributeNSProduction(String namespaceURI) {
/* 185 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Production getProduction(int eventCode) {
/* 190 */     assert eventCode >= 0 && eventCode < this.containers.size();
/* 191 */     return this.containers.get(getNumberOfEvents() - 1 - eventCode);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\AbstractBuiltInGrammar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */