/*    */ package com.siemens.ct.exi.core.grammars.grammar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Fragment
/*    */   extends AbstractSchemaInformedGrammar
/*    */ {
/*    */   public Fragment() {}
/*    */   
/*    */   public Fragment(String label) {
/* 43 */     this();
/* 44 */     setLabel(label);
/*    */   }
/*    */   
/*    */   public GrammarType getGrammarType() {
/* 48 */     return GrammarType.FRAGMENT;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 52 */     return "Fragment" + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\grammars\grammar\Fragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */