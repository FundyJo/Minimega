/*    */ package com.siemens.ct.exi.core.types;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum IntegerType
/*    */ {
/* 37 */   UNSIGNED_INTEGER_8(true),
/*    */ 
/*    */   
/* 40 */   UNSIGNED_INTEGER_16(true),
/*    */ 
/*    */   
/* 43 */   UNSIGNED_INTEGER_32(true),
/*    */ 
/*    */   
/* 46 */   UNSIGNED_INTEGER_64(true),
/*    */ 
/*    */   
/* 49 */   UNSIGNED_INTEGER_BIG(true),
/*    */ 
/*    */   
/* 52 */   INTEGER_8(false),
/*    */ 
/*    */   
/* 55 */   INTEGER_16(false),
/*    */ 
/*    */   
/* 58 */   INTEGER_32(false),
/*    */ 
/*    */   
/* 61 */   INTEGER_64(false),
/*    */ 
/*    */   
/* 64 */   INTEGER_BIG(false);
/*    */   
/*    */   private final boolean isUnsigned;
/*    */   
/*    */   IntegerType(boolean isUnsigned) {
/* 69 */     this.isUnsigned = isUnsigned;
/*    */   }
/*    */   
/*    */   public boolean isUnsigned() {
/* 73 */     return this.isUnsigned;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\types\IntegerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */