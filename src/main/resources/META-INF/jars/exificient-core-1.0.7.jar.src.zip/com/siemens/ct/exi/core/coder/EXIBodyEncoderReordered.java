/*     */ package com.siemens.ct.exi.core.coder;
/*     */ 
/*     */ import com.siemens.ct.exi.core.CodingMode;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.container.ValueAndDatatype;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.io.channel.ByteEncoderChannel;
/*     */ import com.siemens.ct.exi.core.io.channel.EncoderChannel;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.zip.Deflater;
/*     */ import java.util.zip.DeflaterOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIBodyEncoderReordered
/*     */   extends AbstractEXIBodyEncoder
/*     */ {
/*     */   protected OutputStream os;
/*     */   protected Deflater deflater;
/*     */   protected DeflaterOutputStream deflaterOS;
/*     */   protected CodingMode codingMode;
/*     */   protected int blockValues;
/*     */   protected Value lastValue;
/*     */   protected Datatype lastDatatype;
/*     */   protected Map<QNameContext, List<ValueAndDatatype>> channelValuesAndDatatypes;
/*     */   
/*     */   public EXIBodyEncoderReordered(EXIFactory exiFactory) throws EXIException {
/*  73 */     super(exiFactory);
/*     */     
/*  75 */     this.codingMode = exiFactory.getCodingMode();
/*     */ 
/*     */     
/*  78 */     this.channelValuesAndDatatypes = new LinkedHashMap<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initForEachRun() throws EXIException, IOException {
/*  83 */     super.initForEachRun();
/*     */     
/*  85 */     this.blockValues = 0;
/*     */     
/*  87 */     this.channelValuesAndDatatypes.clear();
/*     */   }
/*     */   
/*     */   protected void initBlock() {
/*  91 */     this.blockValues = 0;
/*     */ 
/*     */     
/*  94 */     this.channelValuesAndDatatypes.clear();
/*     */   }
/*     */   
/*     */   protected void addValueAndDatatype(QNameContext qnc, ValueAndDatatype vd) {
/*  98 */     List<ValueAndDatatype> vds = this.channelValuesAndDatatypes.get(qnc);
/*  99 */     if (vds == null) {
/*     */       
/* 101 */       vds = new ArrayList<>();
/*     */       
/* 103 */       this.channelValuesAndDatatypes.put(qnc, vds);
/*     */     } 
/* 105 */     vds.add(vd);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOutputStream(OutputStream os) throws EXIException, IOException {
/* 110 */     this.os = os;
/*     */ 
/*     */     
/* 113 */     this.channel = (EncoderChannel)new ByteEncoderChannel(getStream());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOutputChannel(EncoderChannel encoderChannel) {
/* 118 */     this.channel = encoderChannel;
/* 119 */     this.os = this.channel.getOutputStream();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isTypeValid(Datatype datatype, Value value) {
/* 124 */     this.lastDatatype = datatype;
/* 125 */     this.lastValue = value;
/* 126 */     return super.isTypeValid(datatype, value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeValue(QNameContext valueContext) throws IOException {
/* 131 */     addValueAndDatatype(valueContext, new ValueAndDatatype(this.lastValue, this.lastDatatype));
/*     */ 
/*     */ 
/*     */     
/* 135 */     if (++this.blockValues == this.exiFactory.getBlockSize()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       closeBlock();
/* 142 */       initBlock();
/* 143 */       this.channel = (EncoderChannel)new ByteEncoderChannel(getStream());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected OutputStream getStream() {
/* 149 */     if (this.codingMode == CodingMode.COMPRESSION) {
/*     */       
/* 151 */       if (this.deflater == null) {
/* 152 */         Object o = this.exiFactory.getEncodingOptions().getOptionValue("DEFLATE_COMPRESSION_VALUE");
/*     */         
/* 154 */         int cl = -1;
/* 155 */         if (o != null && o instanceof Integer) {
/* 156 */           cl = ((Integer)o).intValue();
/*     */         }
/* 158 */         this.deflater = new Deflater(cl, true);
/*     */       } else {
/* 160 */         this.deflater.reset();
/*     */       } 
/* 162 */       this.deflaterOS = new DeflaterOutputStream(this.os, this.deflater);
/* 163 */       return this.deflaterOS;
/*     */     } 
/* 165 */     assert this.codingMode == CodingMode.PRE_COMPRESSION;
/* 166 */     return this.os;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void closeBlock() throws IOException {
/* 178 */     if (this.channel.getLength() != 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 188 */       if (this.blockValues <= 100) {
/*     */ 
/*     */ 
/*     */         
/* 192 */         Iterator<QNameContext> iterCh = this.channelValuesAndDatatypes.keySet().iterator();
/* 193 */         while (iterCh.hasNext()) {
/* 194 */           QNameContext contextOrder = iterCh.next();
/*     */           
/* 196 */           List<ValueAndDatatype> lvd = this.channelValuesAndDatatypes.get(contextOrder);
/* 197 */           for (int i = 0; i < lvd.size(); i++) {
/* 198 */             ValueAndDatatype vd = lvd.get(i);
/* 199 */             this.typeEncoder.isValid(vd.datatype, vd.value);
/* 200 */             this.typeEncoder
/* 201 */               .writeValue(contextOrder, this.channel, this.stringEncoder);
/*     */           } 
/*     */         } 
/*     */         
/* 205 */         finalizeStream();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 223 */         finalizeStream();
/*     */ 
/*     */ 
/*     */         
/* 227 */         ByteEncoderChannel byteEncoderChannel = new ByteEncoderChannel(getStream());
/* 228 */         boolean wasThereLeq100 = false;
/*     */ 
/*     */         
/* 231 */         Iterator<QNameContext> iterCh = this.channelValuesAndDatatypes.keySet().iterator();
/* 232 */         while (iterCh.hasNext()) {
/* 233 */           QNameContext contextOrder = iterCh.next();
/*     */           
/* 235 */           List<ValueAndDatatype> lvd = this.channelValuesAndDatatypes.get(contextOrder);
/* 236 */           if (lvd.size() <= 100) {
/* 237 */             for (int i = 0; i < lvd.size(); i++) {
/* 238 */               ValueAndDatatype vd = lvd.get(i);
/* 239 */               this.typeEncoder.isValid(vd.datatype, vd.value);
/* 240 */               this.typeEncoder.writeValue(contextOrder, (EncoderChannel)byteEncoderChannel, this.stringEncoder);
/*     */             } 
/*     */             
/* 243 */             wasThereLeq100 = true;
/*     */           } 
/*     */         } 
/*     */         
/* 247 */         if (wasThereLeq100) {
/* 248 */           finalizeStream();
/*     */         }
/*     */ 
/*     */         
/* 252 */         iterCh = this.channelValuesAndDatatypes.keySet().iterator();
/* 253 */         while (iterCh.hasNext()) {
/* 254 */           QNameContext contextOrder = iterCh.next();
/*     */           
/* 256 */           List<ValueAndDatatype> lvd = this.channelValuesAndDatatypes.get(contextOrder);
/* 257 */           if (lvd.size() > 100) {
/*     */             
/* 259 */             ByteEncoderChannel byteEncoderChannel1 = new ByteEncoderChannel(getStream());
/* 260 */             for (int i = 0; i < lvd.size(); i++) {
/* 261 */               ValueAndDatatype vd = lvd.get(i);
/* 262 */               this.typeEncoder.isValid(vd.datatype, vd.value);
/* 263 */               this.typeEncoder.writeValue(contextOrder, (EncoderChannel)byteEncoderChannel1, this.stringEncoder);
/*     */             } 
/*     */ 
/*     */             
/* 267 */             finalizeStream();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void finalizeStream() throws IOException {
/* 275 */     if (this.codingMode == CodingMode.COMPRESSION) {
/* 276 */       this.deflaterOS.finish();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 284 */     closeBlock();
/*     */ 
/*     */     
/* 287 */     this.os.flush();
/*     */     
/* 289 */     if (this.deflater != null)
/* 290 */       this.deflater.end(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-core-1.0.7.jar!\com\siemens\ct\exi\core\coder\EXIBodyEncoderReordered.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */