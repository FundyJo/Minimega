/*    */ package xyz.nucleoid.map_templates;
/*    */ 
/*    */ import net.minecraft.nbt.CompoundTag;
/*    */ import net.minecraft.nbt.Tag;
/*    */ 
/*    */ public final class TemplateRegion
/*    */ {
/*    */   private final String marker;
/*    */   
/*    */   public TemplateRegion(String marker, BlockBounds bounds, CompoundTag data) {
/* 11 */     this.marker = marker;
/* 12 */     this.bounds = bounds;
/* 13 */     this.data = data;
/*    */   }
/*    */   private final BlockBounds bounds; private CompoundTag data;
/*    */   public String getMarker() {
/* 17 */     return this.marker;
/*    */   }
/*    */   
/*    */   public BlockBounds getBounds() {
/* 21 */     return this.bounds;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CompoundTag getData() {
/* 30 */     return this.data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setData(CompoundTag data) {
/* 39 */     this.data = data;
/*    */   }
/*    */   
/*    */   public CompoundTag serialize(CompoundTag nbt) {
/* 43 */     nbt.putString("marker", this.marker);
/* 44 */     this.bounds.serialize(nbt);
/* 45 */     nbt.put("data", (Tag)this.data);
/* 46 */     return nbt;
/*    */   }
/*    */   
/*    */   public static TemplateRegion deserialize(CompoundTag nbt) {
/* 50 */     String marker = nbt.getString("marker").orElse("");
/* 51 */     CompoundTag data = nbt.getCompound("data").orElse(null);
/* 52 */     return new TemplateRegion(marker, BlockBounds.deserialize(nbt), data);
/*    */   }
/*    */   
/*    */   public TemplateRegion copy() {
/* 56 */     return new TemplateRegion(this.marker, this.bounds, (this.data != null) ? this.data.copy() : null);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\TemplateRegion.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */