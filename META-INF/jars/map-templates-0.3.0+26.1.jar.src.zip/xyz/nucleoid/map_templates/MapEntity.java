/*     */ package xyz.nucleoid.map_templates;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.core.SectionPos;
/*     */ import net.minecraft.core.Vec3i;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.nbt.DoubleTag;
/*     */ import net.minecraft.nbt.ListTag;
/*     */ import net.minecraft.nbt.Tag;
/*     */ import net.minecraft.util.Mth;
/*     */ import net.minecraft.util.ProblemReporter;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.storage.TagValueOutput;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ 
/*     */ public final class MapEntity extends Record {
/*     */   private final Vec3 position;
/*     */   private final CompoundTag nbt;
/*     */   
/*  22 */   public MapEntity(Vec3 position, CompoundTag nbt) { this.position = position; this.nbt = nbt; } public final String toString() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lxyz/nucleoid/map_templates/MapEntity;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #22	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*  22 */     //   0	7	0	this	Lxyz/nucleoid/map_templates/MapEntity; } public Vec3 position() { return this.position; } public final int hashCode() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lxyz/nucleoid/map_templates/MapEntity;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #22	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lxyz/nucleoid/map_templates/MapEntity; } public final boolean equals(Object o) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lxyz/nucleoid/map_templates/MapEntity;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #22	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lxyz/nucleoid/map_templates/MapEntity;
/*  22 */     //   0	8	1	o	Ljava/lang/Object; } public CompoundTag nbt() { return this.nbt; }
/*  23 */    private static final Logger LOGGER = LoggerFactory.getLogger(MapEntity.class);
/*     */   
/*     */   public CompoundTag createEntityNbt(BlockPos origin) {
/*  26 */     CompoundTag nbt = this.nbt.copy();
/*     */     
/*  28 */     Vec3 chunkLocalPos = this.nbt.read("Pos", Vec3.CODEC).orElseThrow();
/*     */     
/*  30 */     Vec3 worldPosition = this.position.add(origin.getX(), origin.getY(), origin.getZ());
/*  31 */     nbt.put("Pos", (Tag)posToList(worldPosition));
/*     */     
/*  33 */     nbt.read("block_pos", BlockPos.CODEC).ifPresent(pos -> {
/*     */           double x = pos.getX() - worldPosition.x + chunkLocalPos.x;
/*     */           
/*     */           double y = pos.getY() - worldPosition.y + chunkLocalPos.y;
/*     */           
/*     */           double z = pos.getZ() - worldPosition.z + chunkLocalPos.z;
/*     */           nbt.store("block_pos", BlockPos.CODEC, BlockPos.containing(x, y, z));
/*     */         });
/*  41 */     return nbt;
/*     */   }
/*     */   
/*     */   public void createEntities(Level world, BlockPos origin, Consumer<Entity> consumer) {
/*  45 */     CompoundTag nbt = createEntityNbt(origin);
/*  46 */     EntityType.loadEntityRecursive(nbt, world, EntitySpawnReason.STRUCTURE, entity -> {
/*     */           consumer.accept(entity);
/*     */           return entity;
/*     */         });
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static MapEntity fromEntity(Entity entity, Vec3 position) {
/*  54 */     ProblemReporter.ScopedCollector errorReporter = new ProblemReporter.ScopedCollector(entity.problemPath(), LOGGER); 
/*  55 */     try { TagValueOutput view = TagValueOutput.createWithContext((ProblemReporter)errorReporter, (HolderLookup.Provider)entity.registryAccess());
/*     */       
/*  57 */       if (!entity.save((ValueOutput)view))
/*  58 */       { MapEntity mapEntity1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  78 */         errorReporter.close(); return mapEntity1; }  view.discard("UUID"); BlockPos minChunkPos = getMinChunkPosFor(position); view.store("Pos", Vec3.CODEC, position.subtract(minChunkPos.getX(), minChunkPos.getY(), minChunkPos.getZ())); view.buildResult().read("block_pos", BlockPos.CODEC).ifPresent(pos -> { BlockPos localPos = pos.subtract((Vec3i)entity.blockPosition()).offset(Mth.floor(position.x()), Mth.floor(position.y()), Mth.floor(position.z())).subtract((Vec3i)minChunkPos); view.store("block_pos", BlockPos.CODEC, localPos); }); MapEntity mapEntity = new MapEntity(position, view.buildResult()); errorReporter.close(); return mapEntity; }
/*     */     catch (Throwable throwable) { try { errorReporter.close(); }
/*     */       catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/*  82 */      } public static MapEntity fromNbt(SectionPos sectionPos, CompoundTag nbt) { Vec3 localPos = nbt.read("Pos", Vec3.CODEC).orElseThrow();
/*  83 */     Vec3 globalPos = localPos.add(sectionPos.minBlockX(), sectionPos.minBlockY(), sectionPos.minBlockZ());
/*     */     
/*  85 */     return new MapEntity(globalPos, nbt); }
/*     */ 
/*     */   
/*     */   MapEntity transformed(MapTransform transform) {
/*  89 */     Vec3 resultPosition = transform.transformedPoint(this.position);
/*  90 */     CompoundTag resultNbt = this.nbt.copy();
/*     */     
/*  92 */     BlockPos minChunkPos = getMinChunkPosFor(this.position);
/*  93 */     BlockPos minResultChunkPos = getMinChunkPosFor(resultPosition);
/*     */     
/*  95 */     resultNbt.put("Pos", (Tag)posToList(resultPosition.subtract(minResultChunkPos.getX(), minResultChunkPos.getY(), minResultChunkPos.getZ())));
/*     */ 
/*     */     
/*  98 */     resultNbt.read("block_pos", BlockPos.CODEC).ifPresent(pos -> {
/*     */           BlockPos attachedPos = pos.offset((Vec3i)minChunkPos);
/*     */ 
/*     */           
/*     */           BlockPos localAttachedPos = transform.transformedPoint(attachedPos).subtract((Vec3i)minResultChunkPos);
/*     */           
/*     */           resultNbt.store("block_pos", BlockPos.CODEC, localAttachedPos);
/*     */         });
/*     */     
/* 107 */     return new MapEntity(resultPosition, resultNbt);
/*     */   }
/*     */   
/*     */   private static BlockPos getMinChunkPosFor(Vec3 position) {
/* 111 */     return new BlockPos(
/* 112 */         Mth.floor(position.x()) & 0xFFFFFFF0, 
/* 113 */         Mth.floor(position.y()) & 0xFFFFFFF0, 
/* 114 */         Mth.floor(position.z()) & 0xFFFFFFF0);
/*     */   }
/*     */ 
/*     */   
/*     */   private static ListTag posToList(Vec3 pos) {
/* 119 */     ListTag list = new ListTag();
/* 120 */     list.add(DoubleTag.valueOf(pos.x));
/* 121 */     list.add(DoubleTag.valueOf(pos.y));
/* 122 */     list.add(DoubleTag.valueOf(pos.z));
/* 123 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\MapEntity.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */