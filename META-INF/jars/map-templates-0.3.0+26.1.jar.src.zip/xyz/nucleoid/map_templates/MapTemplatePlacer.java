/*    */ package xyz.nucleoid.map_templates;
/*    */ 
/*    */ import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
/*    */ import it.unimi.dsi.fastutil.longs.LongIterator;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.server.level.ServerLevel;
/*    */ import net.minecraft.world.level.chunk.LevelChunk;
/*    */ 
/*    */ public final class MapTemplatePlacer extends Record {
/*    */   private final MapTemplate template;
/*    */   
/* 12 */   public MapTemplatePlacer(MapTemplate template) { this.template = template; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lxyz/nucleoid/map_templates/MapTemplatePlacer;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #12	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/* 12 */     //   0	7	0	this	Lxyz/nucleoid/map_templates/MapTemplatePlacer; } public MapTemplate template() { return this.template; }
/*    */   public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lxyz/nucleoid/map_templates/MapTemplatePlacer;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #12	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lxyz/nucleoid/map_templates/MapTemplatePlacer; }
/*    */   public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lxyz/nucleoid/map_templates/MapTemplatePlacer;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #12	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lxyz/nucleoid/map_templates/MapTemplatePlacer;
/* 14 */     //   0	8	1	o	Ljava/lang/Object; } public void placeAt(ServerLevel world, BlockPos origin) { Long2ObjectMap<LevelChunk> chunkCache = collectChunks(world, origin, this.template.bounds);
/*    */     
/* 16 */     placeBlocks(origin, chunkCache);
/* 17 */     placeEntities(world, origin); }
/*    */ 
/*    */   
/*    */   private Long2ObjectMap<LevelChunk> collectChunks(ServerLevel world, BlockPos origin, BlockBounds bounds) {
/* 21 */     LongSet chunkPositions = bounds.offset(origin).asChunks();
/* 22 */     LongIterator chunkIterator = chunkPositions.iterator();
/*    */     
/* 24 */     Long2ObjectOpenHashMap<LevelChunk> chunks = new Long2ObjectOpenHashMap(chunkPositions.size());
/* 25 */     while (chunkIterator.hasNext()) {
/* 26 */       long chunkPos = chunkIterator.nextLong();
/* 27 */       int chunkX = ChunkPos.getX(chunkPos);
/* 28 */       int chunkZ = ChunkPos.getZ(chunkPos);
/*    */       
/* 30 */       chunks.put(chunkPos, world.getChunk(chunkX, chunkZ));
/*    */     } 
/*    */     
/* 33 */     return (Long2ObjectMap<LevelChunk>)chunks;
/*    */   }
/*    */   
/*    */   private void placeBlocks(BlockPos origin, Long2ObjectMap<LevelChunk> chunkCache) {
/* 37 */     MapTemplate template = this.template;
/* 38 */     BlockBounds bounds = template.getBounds();
/*    */     
/* 40 */     BlockPos.MutableBlockPos worldPos = new BlockPos.MutableBlockPos();
/*    */     
/* 42 */     int originX = origin.getX();
/* 43 */     int originY = origin.getY();
/* 44 */     int originZ = origin.getZ();
/*    */     
/* 46 */     for (BlockPos templatePos : bounds) {
/* 47 */       worldPos.setWithOffset((Vec3i)templatePos, originX, originY, originZ);
/*    */       
/* 49 */       BlockState state = template.getBlockState(templatePos);
/* 50 */       if (state.isAir()) {
/*    */         continue;
/*    */       }
/*    */       
/* 54 */       int chunkX = worldPos.getX() >> 4;
/* 55 */       int chunkZ = worldPos.getZ() >> 4;
/*    */       
/* 57 */       long chunkPos = ChunkPos.pack(chunkX, chunkZ);
/* 58 */       LevelChunk chunk = (LevelChunk)chunkCache.get(chunkPos);
/*    */       
/* 60 */       CompoundTag blockEntity = template.getBlockEntityNbt(templatePos, (BlockPos)worldPos);
/* 61 */       if (blockEntity != null) {
/* 62 */         chunk.setBlockEntityNbt(blockEntity);
/*    */       }
/*    */       
/* 65 */       chunk.setBlockState((BlockPos)worldPos, state);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void placeEntities(ServerLevel world, BlockPos origin) {
/* 70 */     MapTemplate template = this.template;
/*    */     
/* 72 */     LongSet chunks = template.getBounds().asChunkSections();
/* 73 */     LongIterator chunkIterator = chunks.iterator();
/*    */     
/* 75 */     while (chunkIterator.hasNext()) {
/* 76 */       long chunkPos = chunkIterator.nextLong();
/* 77 */       int chunkX = SectionPos.x(chunkPos);
/* 78 */       int chunkY = SectionPos.y(chunkPos);
/* 79 */       int chunkZ = SectionPos.z(chunkPos);
/*    */       
/* 81 */       Stream<MapEntity> entities = template.getEntitiesInChunk(chunkX, chunkY, chunkZ);
/* 82 */       entities.forEach(mapEntity -> {
/*    */             Objects.requireNonNull(world);
/*    */             mapEntity.createEntities((Level)world, origin, world::addFreshEntity);
/*    */           });
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\MapTemplatePlacer.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */