/*    */ package xyz.nucleoid.map_templates;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import net.minecraft.core.HolderLookup;
/*    */ import net.minecraft.core.SectionPos;
/*    */ import net.minecraft.nbt.CompoundTag;
/*    */ import net.minecraft.nbt.ListTag;
/*    */ import net.minecraft.nbt.Tag;
/*    */ import net.minecraft.world.entity.Entity;
/*    */ import net.minecraft.world.level.block.Block;
/*    */ import net.minecraft.world.level.block.Blocks;
/*    */ import net.minecraft.world.level.block.state.BlockState;
/*    */ import net.minecraft.world.level.chunk.PalettedContainer;
/*    */ import net.minecraft.world.level.chunk.Strategy;
/*    */ import net.minecraft.world.phys.Vec3;
/*    */ 
/*    */ public final class MapChunk {
/* 18 */   private static final BlockState DEFAULT_BLOCK = Blocks.AIR.defaultBlockState();
/* 19 */   private static final Strategy<BlockState> PALETTE_PROVIDER = Strategy.createForBlockStates((IdMap)Block.BLOCK_STATE_REGISTRY);
/*    */   
/* 21 */   private static final Codec<PalettedContainer<BlockState>> BLOCK_CODEC = PalettedContainer.codecRW(BlockState.CODEC, PALETTE_PROVIDER, DEFAULT_BLOCK);
/*    */   
/*    */   private final SectionPos pos;
/*    */   
/* 25 */   private PalettedContainer<BlockState> container = new PalettedContainer(DEFAULT_BLOCK, PALETTE_PROVIDER);
/* 26 */   private final List<MapEntity> entities = new ArrayList<>();
/*    */   
/*    */   MapChunk(SectionPos pos) {
/* 29 */     this.pos = pos;
/*    */   }
/*    */   
/*    */   public void set(int x, int y, int z, BlockState state) {
/* 33 */     this.container.set(x, y, z, state);
/*    */   }
/*    */   
/*    */   public BlockState get(int x, int y, int z) {
/* 37 */     return (BlockState)this.container.get(x, y, z);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addEntity(Entity entity, Vec3 position) {
/* 49 */     MapEntity mapEntity = MapEntity.fromEntity(entity, position);
/* 50 */     if (mapEntity != null) {
/* 51 */       this.entities.add(mapEntity);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addEntity(MapEntity entity) {
/* 56 */     this.entities.add(entity);
/*    */   }
/*    */   
/*    */   public SectionPos getPos() {
/* 60 */     return this.pos;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<MapEntity> getEntities() {
/* 69 */     return this.entities;
/*    */   }
/*    */   
/*    */   public void serialize(CompoundTag nbt, HolderLookup.Provider registryLookup) {
/* 73 */     nbt.put("block_states", (Tag)BLOCK_CODEC.encodeStart((DynamicOps)NbtOps.INSTANCE, this.container).getOrThrow());
/*    */     
/* 75 */     if (!this.entities.isEmpty()) {
/* 76 */       ListTag entitiesNbt = new ListTag();
/* 77 */       for (MapEntity entity : this.entities) {
/* 78 */         entitiesNbt.add(entity.nbt());
/*    */       }
/* 80 */       nbt.put("entities", (Tag)entitiesNbt);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static MapChunk deserialize(SectionPos pos, CompoundTag nbt, HolderLookup.Provider registryLookup) {
/* 85 */     MapChunk chunk = new MapChunk(pos);
/* 86 */     Optional<PalettedContainer<BlockState>> container = nbt.read("block_states", BLOCK_CODEC);
/*    */     
/* 88 */     if (container.isPresent()) {
/* 89 */       chunk.container = container.get();
/*    */     }
/*    */     
/* 92 */     ListTag entitiesNbt = nbt.getListOrEmpty("entities");
/* 93 */     for (Tag item : entitiesNbt) {
/* 94 */       if (item instanceof CompoundTag) { CompoundTag entityNbt = (CompoundTag)item;
/* 95 */         chunk.entities.add(MapEntity.fromNbt(pos, entityNbt)); }
/*    */     
/*    */     } 
/*    */     
/* 99 */     return chunk;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\MapChunk.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */