/*     */ package xyz.nucleoid.map_templates;
/*     */ import com.mojang.datafixers.DSL;
/*     */ import com.mojang.datafixers.DataFixer;
/*     */ import com.mojang.serialization.Dynamic;
/*     */ import com.mojang.serialization.DynamicOps;
/*     */ import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
/*     */ import it.unimi.dsi.fastutil.longs.Long2ObjectMaps;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectIterator;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.core.HolderLookup;
/*     */ import net.minecraft.core.SectionPos;
/*     */ import net.minecraft.core.Vec3i;
/*     */ import net.minecraft.core.registries.Registries;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.nbt.ListTag;
/*     */ import net.minecraft.nbt.NbtIo;
/*     */ import net.minecraft.nbt.NbtOps;
/*     */ import net.minecraft.nbt.Tag;
/*     */ import net.minecraft.resources.Identifier;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.packs.resources.Resource;
/*     */ import net.minecraft.server.packs.resources.ResourceManager;
/*     */ import net.minecraft.util.datafix.DataFixers;
/*     */ import net.minecraft.util.datafix.fixes.References;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ 
/*     */ public final class MapTemplateSerializer {
/*  34 */   private static final Logger LOGGER = LogManager.getLogger(MapTemplateSerializer.class);
/*  35 */   private static final boolean SKIP_FIXERS = FabricLoader.getInstance().isModLoaded("databreaker");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MapTemplate loadFromResource(MinecraftServer server, Identifier identifier) throws IOException {
/*  41 */     Identifier path = getResourcePathFor(identifier);
/*     */     
/*  43 */     ResourceManager resourceManager = server.getResourceManager();
/*  44 */     Optional<Resource> resource = resourceManager.getResource(path);
/*     */     
/*  46 */     if (resource.isEmpty()) {
/*  47 */       throw new IOException("No resource found for " + String.valueOf(identifier));
/*     */     }
/*     */     
/*  50 */     return loadFrom(((Resource)resource.get()).open(), (HolderLookup.Provider)server.registryAccess());
/*     */   }
/*     */   
/*     */   public static MapTemplate loadFrom(InputStream input, HolderLookup.Provider registryLookup) throws IOException {
/*  54 */     MapTemplate template = MapTemplate.createEmpty();
/*  55 */     load(template, NbtIo.readCompressed(input, NbtAccounter.unlimitedHeap()), registryLookup);
/*  56 */     return template;
/*     */   }
/*     */   
/*     */   public static void saveTo(MapTemplate template, OutputStream output, HolderLookup.Provider registryLookup) throws IOException {
/*  60 */     CompoundTag root = save(template, registryLookup);
/*  61 */     NbtIo.writeCompressed(root, output);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int getDataVersion(CompoundTag root) {
/*  66 */     return root.getIntOr("data_version", 2586);
/*     */   }
/*     */   
/*     */   private static int getCurrentDataVersion() {
/*  70 */     return SharedConstants.getCurrentVersion().dataVersion().version();
/*     */   }
/*     */   
/*     */   private static void load(MapTemplate template, CompoundTag root, HolderLookup.Provider registryLookup) {
/*  74 */     load(template, root, registryLookup, DataFixers.getDataFixer());
/*     */   }
/*     */   
/*     */   private static void load(MapTemplate template, CompoundTag root, HolderLookup.Provider registryLookup, DataFixer fixer) {
/*  78 */     int oldVersion = getDataVersion(root);
/*  79 */     int targetVersion = getCurrentDataVersion();
/*     */     
/*  81 */     ListTag chunkList = root.getListOrEmpty("chunks");
/*  82 */     for (int i = 0; i < chunkList.size(); i++) {
/*  83 */       CompoundTag chunkRoot = chunkList.getCompoundOrEmpty(i);
/*     */       
/*  85 */       if (targetVersion > oldVersion) {
/*     */ 
/*     */         
/*  88 */         if (oldVersion <= 2730) {
/*  89 */           ListTag palette = chunkRoot.getListOrEmpty("palette");
/*  90 */           long[] blockData = chunkRoot.getLongArray("block_states").orElseGet(() -> new long[0]);
/*  91 */           chunkRoot.remove("palette");
/*     */           
/*  93 */           CompoundTag blockStates = new CompoundTag();
/*  94 */           blockStates.putLongArray("data", blockData);
/*  95 */           blockStates.put("palette", (Tag)palette);
/*  96 */           chunkRoot.put("block_states", (Tag)blockStates);
/*     */         } 
/*     */         
/*  99 */         if (!SKIP_FIXERS) {
/* 100 */           ListTag palette = chunkRoot.getCompoundOrEmpty("block_states").getListOrEmpty("palette");
/* 101 */           updateList(palette, fixer, References.BLOCK_STATE, oldVersion, targetVersion);
/*     */           
/* 103 */           ListTag entities = chunkRoot.getListOrEmpty("entities");
/* 104 */           updateList(entities, fixer, References.ENTITY, oldVersion, targetVersion);
/*     */         } else {
/* 106 */           LOGGER.error("Couldn't apply datafixers to template because databreaker is present!");
/*     */         } 
/*     */       } 
/*     */       
/* 110 */       chunkRoot.read("pos", Vec3i.CODEC).ifPresentOrElse(posArray -> {
/*     */             long pos = MapTemplate.chunkPos(posArray.getX(), posArray.getY(), posArray.getZ());
/*     */ 
/*     */             
/*     */             MapChunk chunk = MapChunk.deserialize(SectionPos.of(pos), chunkRoot, registryLookup);
/*     */             
/*     */             template.chunks.put(pos, chunk);
/*     */           }() -> LOGGER.warn("Invalid chunk pos key: {}", chunkRoot.get("pos")));
/*     */     } 
/*     */     
/* 120 */     MapTemplateMetadata metadata = template.metadata;
/*     */     
/* 122 */     ListTag regionList = root.getListOrEmpty("regions");
/* 123 */     for (int j = 0; j < regionList.size(); j++) {
/* 124 */       CompoundTag regionRoot = regionList.getCompoundOrEmpty(j);
/* 125 */       metadata.regions.add(TemplateRegion.deserialize(regionRoot));
/*     */     } 
/*     */     
/* 128 */     ListTag blockEntityList = root.getListOrEmpty("block_entities");
/* 129 */     for (int k = 0; k < blockEntityList.size(); k++) {
/* 130 */       CompoundTag blockEntity = blockEntityList.getCompoundOrEmpty(k);
/*     */       
/* 132 */       if (targetVersion > oldVersion && !SKIP_FIXERS) {
/*     */         
/* 134 */         Dynamic<Tag> dynamic = new Dynamic((DynamicOps)NbtOps.INSTANCE, blockEntity);
/* 135 */         blockEntity = (CompoundTag)fixer.update(References.BLOCK_ENTITY, dynamic, oldVersion, targetVersion).getValue();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       BlockPos pos = new BlockPos(blockEntity.getIntOr("x", 0), blockEntity.getIntOr("y", 0), blockEntity.getIntOr("z", 0));
/*     */       
/* 143 */       template.blockEntities.put(pos.asLong(), blockEntity);
/*     */     } 
/*     */     
/* 146 */     template.bounds = BlockBounds.deserialize(root.getCompound("bounds").orElse(null));
/* 147 */     metadata.data = root.getCompound("data").orElse(null);
/*     */     
/* 149 */     String biomeIdString = root.getString("biome").orElse("");
/* 150 */     if (!Strings.isNullOrEmpty(biomeIdString)) {
/* 151 */       Identifier biomeId = Identifier.tryParse(biomeIdString);
/* 152 */       if (biomeId != null) {
/* 153 */         template.biome = ResourceKey.create(Registries.BIOME, biomeId);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void updateList(ListTag list, DataFixer fixer, DSL.TypeReference type, int oldVersion, int targetVersion) {
/* 159 */     if (list == null)
/*     */       return; 
/* 161 */     for (int i = 0; i < list.size(); i++) {
/* 162 */       CompoundTag nbt = list.getCompoundOrEmpty(i);
/*     */       
/* 164 */       Dynamic<Tag> dynamic = new Dynamic((DynamicOps)NbtOps.INSTANCE, nbt);
/* 165 */       list.set(i, (Tag)fixer.update(type, dynamic, oldVersion, targetVersion).getValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static CompoundTag save(MapTemplate template, HolderLookup.Provider registryLookup) {
/* 170 */     CompoundTag root = new CompoundTag();
/*     */     
/* 172 */     int dataVersion = getCurrentDataVersion();
/* 173 */     root.putInt("data_version", dataVersion);
/*     */     
/* 175 */     ListTag chunkList = new ListTag();
/*     */     
/* 177 */     for (ObjectIterator<Long2ObjectMap.Entry<MapChunk>> objectIterator = Long2ObjectMaps.fastIterable(template.chunks).iterator(); objectIterator.hasNext(); ) { Long2ObjectMap.Entry<MapChunk> entry = objectIterator.next();
/* 178 */       SectionPos pos = SectionPos.of(entry.getLongKey());
/* 179 */       MapChunk chunk = (MapChunk)entry.getValue();
/*     */       
/* 181 */       CompoundTag chunkRoot = new CompoundTag();
/*     */       
/* 183 */       chunkRoot.putIntArray("pos", new int[] { pos.getX(), pos.getY(), pos.getZ() });
/* 184 */       chunk.serialize(chunkRoot, registryLookup);
/*     */       
/* 186 */       chunkList.add(chunkRoot); }
/*     */ 
/*     */     
/* 189 */     root.put("chunks", (Tag)chunkList);
/*     */     
/* 191 */     ListTag blockEntityList = new ListTag();
/* 192 */     blockEntityList.addAll((Collection)template.blockEntities.values());
/* 193 */     root.put("block_entities", (Tag)blockEntityList);
/*     */     
/* 195 */     root.put("bounds", (Tag)template.bounds.serialize(new CompoundTag()));
/*     */     
/* 197 */     if (template.biome != null) {
/* 198 */       root.putString("biome", template.biome.identifier().toString());
/*     */     }
/*     */     
/* 201 */     MapTemplateMetadata metadata = template.metadata;
/*     */     
/* 203 */     ListTag regionList = new ListTag();
/* 204 */     for (TemplateRegion region : metadata.regions) {
/* 205 */       regionList.add(region.serialize(new CompoundTag()));
/*     */     }
/* 207 */     root.put("regions", (Tag)regionList);
/*     */     
/* 209 */     root.put("data", (Tag)metadata.data);
/*     */     
/* 211 */     return root;
/*     */   }
/*     */   
/*     */   public static Identifier getResourcePathFor(Identifier identifier) {
/* 215 */     return identifier.withPath(path -> "map_template/" + path + ".nbt");
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\MapTemplateSerializer.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */