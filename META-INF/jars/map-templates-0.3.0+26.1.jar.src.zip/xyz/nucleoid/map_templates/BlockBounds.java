/*     */ package xyz.nucleoid.map_templates;
/*     */ 
/*     */ import com.mojang.datafixers.kinds.App;
/*     */ import com.mojang.datafixers.kinds.Applicative;
/*     */ import com.mojang.serialization.codecs.RecordCodecBuilder;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
/*     */ import it.unimi.dsi.fastutil.longs.LongSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.function.BiFunction;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.core.Vec3i;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.network.codec.StreamCodec;
/*     */ import net.minecraft.util.RandomSource;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.LevelHeightAccessor;
/*     */ import net.minecraft.world.level.chunk.ChunkAccess;
/*     */ import net.minecraft.world.phys.AABB;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public final class BlockBounds extends Record implements Iterable<BlockPos> {
/*     */   private final BlockPos min;
/*     */   private final BlockPos max;
/*     */   public static final Codec<BlockBounds> CODEC;
/*     */   
/*  28 */   public BlockPos min() { return this.min; } public final String toString() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lxyz/nucleoid/map_templates/BlockBounds;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #28	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lxyz/nucleoid/map_templates/BlockBounds; } public final int hashCode() { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lxyz/nucleoid/map_templates/BlockBounds;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #28	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lxyz/nucleoid/map_templates/BlockBounds; } public final boolean equals(Object o) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lxyz/nucleoid/map_templates/BlockBounds;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #28	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lxyz/nucleoid/map_templates/BlockBounds;
/*  28 */     //   0	8	1	o	Ljava/lang/Object; } public BlockPos max() { return this.max; } static {
/*  29 */     CODEC = RecordCodecBuilder.create(instance -> instance.group((App)BlockPos.CODEC.fieldOf("min").forGetter(BlockBounds::min), (App)BlockPos.CODEC.fieldOf("max").forGetter(BlockBounds::max)).apply((Applicative)instance, BlockBounds::new));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   public static final StreamCodec<ByteBuf, BlockBounds> PACKET_CODEC = StreamCodec.composite(BlockPos.STREAM_CODEC, BlockBounds::min, BlockPos.STREAM_CODEC, BlockBounds::max, BlockBounds::of);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockBounds(BlockPos min, BlockPos max) {
/*  43 */     if (min.getX() > max.getX() || min.getY() > max.getY() || min.getZ() > max.getZ()) {
/*  44 */       String message = String.format("Minimum position (%d, %d, %d) of bounds must be smaller than maximum position (%d, %d, %d)", new Object[] {
/*     */             
/*  46 */             Integer.valueOf(min.getX()), Integer.valueOf(min.getY()), Integer.valueOf(min.getZ()), 
/*  47 */             Integer.valueOf(max.getX()), Integer.valueOf(max.getY()), Integer.valueOf(max.getZ())
/*     */           });
/*     */       
/*  50 */       throw new IllegalArgumentException(message);
/*     */     } 
/*     */     this.min = min;
/*     */     this.max = max;
/*     */   } public static BlockBounds of(BlockPos a, BlockPos b) {
/*  55 */     return new BlockBounds(BlockPos.min(a, b), BlockPos.max(a, b));
/*     */   }
/*     */   
/*     */   public static BlockBounds of(int x0, int y0, int z0, int x1, int y1, int z1) {
/*  59 */     return of(new BlockPos(x0, y0, z0), new BlockPos(x1, y1, z1));
/*     */   }
/*     */   
/*     */   public static BlockBounds ofBlock(BlockPos pos) {
/*  63 */     return new BlockBounds(pos, pos);
/*     */   }
/*     */   
/*     */   public static BlockBounds ofChunk(ChunkAccess chunk) {
/*  67 */     return ofChunk(chunk.getPos(), (LevelHeightAccessor)chunk);
/*     */   }
/*     */   
/*     */   public static BlockBounds ofChunk(ChunkPos chunk, LevelHeightAccessor world) {
/*  71 */     return new BlockBounds(new BlockPos(chunk
/*  72 */           .getMinBlockX(), world.getMinY(), chunk.getMinBlockZ()), new BlockPos(chunk
/*  73 */           .getMaxBlockX(), world.getMaxY(), chunk.getMaxBlockZ()));
/*     */   }
/*     */ 
/*     */   
/*     */   public BlockBounds offset(BlockPos pos) {
/*  78 */     return new BlockBounds(this.min
/*  79 */         .offset((Vec3i)pos), this.max
/*  80 */         .offset((Vec3i)pos));
/*     */   }
/*     */ 
/*     */   
/*     */   public BlockBounds offset(int x, int y, int z) {
/*  85 */     return new BlockBounds(this.min
/*  86 */         .offset(x, y, z), this.max
/*  87 */         .offset(x, y, z));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(BlockPos pos) {
/*  92 */     return contains(pos.getX(), pos.getY(), pos.getZ());
/*     */   }
/*     */   
/*     */   public boolean contains(int x, int y, int z) {
/*  96 */     return (x >= this.min.getX() && y >= this.min.getY() && z >= this.min.getZ() && x <= this.max
/*  97 */       .getX() && y <= this.max.getY() && z <= this.max.getZ());
/*     */   }
/*     */   
/*     */   public boolean contains(int x, int z) {
/* 101 */     return (x >= this.min.getX() && z >= this.min.getZ() && x <= this.max.getX() && z <= this.max.getZ());
/*     */   }
/*     */   
/*     */   public boolean intersects(BlockBounds bounds) {
/* 105 */     return (this.max.getX() >= bounds.min.getX() && this.min.getX() <= bounds.max.getX() && this.max
/* 106 */       .getY() >= bounds.min.getY() && this.min.getY() <= bounds.max.getY() && this.max
/* 107 */       .getZ() >= bounds.min.getZ() && this.min.getZ() <= bounds.max.getZ());
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public BlockBounds intersection(BlockBounds bounds) {
/* 112 */     if (!intersects(bounds)) {
/* 113 */       return null;
/*     */     }
/*     */     
/* 116 */     BlockPos min = BlockPos.max(min(), bounds.min());
/* 117 */     BlockPos max = BlockPos.min(max(), bounds.max());
/* 118 */     return new BlockBounds(min, max);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public BlockBounds union(BlockBounds bounds) {
/* 123 */     BlockPos min = BlockPos.min(min(), bounds.min());
/* 124 */     BlockPos max = BlockPos.max(max(), bounds.max());
/* 125 */     return new BlockBounds(min, max);
/*     */   }
/*     */   
/*     */   public BlockPos size() {
/* 129 */     return this.max.subtract((Vec3i)this.min);
/*     */   }
/*     */   
/*     */   public Vec3 center() {
/* 133 */     return new Vec3((this.min
/* 134 */         .getX() + this.max.getX() + 1) / 2.0D, (this.min
/* 135 */         .getY() + this.max.getY() + 1) / 2.0D, (this.min
/* 136 */         .getZ() + this.max.getZ() + 1) / 2.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3 centerBottom() {
/* 141 */     return new Vec3((this.min
/* 142 */         .getX() + this.max.getX() + 1) / 2.0D, this.min
/* 143 */         .getY(), (this.min
/* 144 */         .getZ() + this.max.getZ() + 1) / 2.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3 centerTop() {
/* 149 */     return new Vec3((this.min
/* 150 */         .getX() + this.max.getX() + 1) / 2.0D, this.max
/* 151 */         .getY() + 1.0D, (this.min
/* 152 */         .getZ() + this.max.getZ() + 1) / 2.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<BlockPos> iterator() {
/* 158 */     return BlockPos.betweenClosed(this.min, this.max).iterator();
/*     */   }
/*     */   
/*     */   public LongSet asChunks() {
/* 162 */     int minChunkX = this.min.getX() >> 4;
/* 163 */     int minChunkZ = this.min.getZ() >> 4;
/* 164 */     int maxChunkX = this.max.getX() >> 4;
/* 165 */     int maxChunkZ = this.max.getZ() >> 4;
/*     */     
/* 167 */     LongOpenHashSet chunks = new LongOpenHashSet((maxChunkX - minChunkX + 1) * (maxChunkZ - minChunkZ + 1));
/*     */     
/* 169 */     for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
/* 170 */       for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
/* 171 */         chunks.add(ChunkPos.pack(chunkX, chunkZ));
/*     */       }
/*     */     } 
/*     */     
/* 175 */     return (LongSet)chunks;
/*     */   }
/*     */   
/*     */   public LongSet asChunkSections() {
/* 179 */     int minChunkX = this.min.getX() >> 4;
/* 180 */     int minChunkY = this.min.getY() >> 4;
/* 181 */     int minChunkZ = this.min.getZ() >> 4;
/* 182 */     int maxChunkX = this.max.getX() >> 4;
/* 183 */     int maxChunkY = this.max.getY() >> 4;
/* 184 */     int maxChunkZ = this.max.getZ() >> 4;
/*     */     
/* 186 */     LongOpenHashSet chunks = new LongOpenHashSet((maxChunkX - minChunkX + 1) * (maxChunkY - minChunkY + 1) * (maxChunkZ - minChunkZ + 1));
/*     */     
/* 188 */     for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
/* 189 */       for (int chunkY = minChunkY; chunkY <= maxChunkY; chunkY++) {
/* 190 */         for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
/* 191 */           chunks.add(SectionPos.asLong(chunkX, chunkY, chunkZ));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 196 */     return (LongSet)chunks;
/*     */   }
/*     */   
/*     */   public BlockPos sampleBlock(RandomSource random) {
/* 200 */     return new BlockPos(random
/* 201 */         .nextIntBetweenInclusive(this.min.getX(), this.max.getX()), random
/* 202 */         .nextIntBetweenInclusive(this.min.getY(), this.max.getY()), random
/* 203 */         .nextIntBetweenInclusive(this.min.getZ(), this.max.getZ()));
/*     */   }
/*     */ 
/*     */   
/*     */   public AABB asBox() {
/* 208 */     return new AABB(this.min
/* 209 */         .getX(), this.min.getY(), this.min.getZ(), this.max
/* 210 */         .getX() + 1.0D, this.max.getY() + 1.0D, this.max.getZ() + 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public CompoundTag serialize(CompoundTag root) {
/* 215 */     root.putIntArray("min", new int[] { this.min.getX(), this.min.getY(), this.min.getZ() });
/* 216 */     root.putIntArray("max", new int[] { this.max.getX(), this.max.getY(), this.max.getZ() });
/* 217 */     return root;
/*     */   }
/*     */   
/*     */   public static BlockBounds deserialize(CompoundTag root) {
/* 221 */     int[] minArray = root.getIntArray("min").orElseThrow();
/* 222 */     int[] maxArray = root.getIntArray("max").orElseThrow();
/* 223 */     return new BlockBounds(new BlockPos(minArray[0], minArray[1], minArray[2]), new BlockPos(maxArray[0], maxArray[1], maxArray[2]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BlockPos min(BlockPos a, BlockPos b) {
/* 234 */     return BlockPos.min(a, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BlockPos max(BlockPos a, BlockPos b) {
/* 242 */     return BlockPos.max(a, b);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\BlockBounds.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */