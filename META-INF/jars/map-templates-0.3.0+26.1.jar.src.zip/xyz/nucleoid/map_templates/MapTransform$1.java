/*    */ package xyz.nucleoid.map_templates;
/*    */ 
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.world.phys.Vec3;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements MapTransform
/*    */ {
/*    */   public BlockPos.MutableBlockPos transformPoint(BlockPos.MutableBlockPos mutablePos) {
/* 15 */     return mutablePos.move(x, y, z);
/*    */   }
/*    */ 
/*    */   
/*    */   public Vec3 transformedPoint(Vec3 pos) {
/* 20 */     return pos.add(x, y, z);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\MapTransform$1.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */