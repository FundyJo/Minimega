/*     */ package xyz.nucleoid.map_templates;
/*     */ 
/*     */ import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
/*     */ import it.unimi.dsi.fastutil.longs.Long2ObjectMaps;
/*     */ import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectIterator;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.core.HolderLookup;
/*     */ import net.minecraft.core.SectionPos;
/*     */ import net.minecraft.core.Vec3i;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.util.Mth;
/*     */ import net.minecraft.util.ProblemReporter;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.level.biome.Biome;
/*     */ import net.minecraft.world.level.biome.Biomes;
/*     */ import net.minecraft.world.level.block.Blocks;
/*     */ import net.minecraft.world.level.block.Mirror;
/*     */ import net.minecraft.world.level.block.Rotation;
/*     */ import net.minecraft.world.level.block.entity.BlockEntity;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.levelgen.Heightmap;
/*     */ import net.minecraft.world.level.storage.TagValueOutput;
/*     */ import net.minecraft.world.level.storage.ValueOutput;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MapTemplate
/*     */ {
/*  41 */   private static final Logger LOGGER = LoggerFactory.getLogger(MapTemplate.class);
/*     */   
/*  43 */   private static final BlockState AIR = Blocks.AIR.defaultBlockState();
/*     */   
/*  45 */   final Long2ObjectMap<MapChunk> chunks = (Long2ObjectMap<MapChunk>)new Long2ObjectOpenHashMap();
/*  46 */   final Long2ObjectMap<CompoundTag> blockEntities = (Long2ObjectMap<CompoundTag>)new Long2ObjectOpenHashMap();
/*     */   
/*  48 */   ResourceKey<Biome> biome = Biomes.THE_VOID;
/*     */   
/*  50 */   BlockBounds bounds = null;
/*  51 */   BlockBounds generatedBounds = null;
/*     */   
/*  53 */   MapTemplateMetadata metadata = new MapTemplateMetadata();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MapTemplate createEmpty() {
/*  59 */     return new MapTemplate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBiome(ResourceKey<Biome> biome) {
/*  68 */     this.biome = biome;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceKey<Biome> getBiome() {
/*  77 */     return this.biome;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapTemplateMetadata getMetadata() {
/*  87 */     return this.metadata;
/*     */   }
/*     */   
/*     */   public void setBlockState(BlockPos pos, BlockState state) {
/*  91 */     MapChunk chunk = getOrCreateChunk(chunkPos(pos));
/*  92 */     chunk.set(pos.getX() & 0xF, pos.getY() & 0xF, pos.getZ() & 0xF, state);
/*     */     
/*  94 */     this.generatedBounds = null;
/*     */     
/*  96 */     if (state.hasBlockEntity()) {
/*  97 */       CompoundTag nbt = new CompoundTag();
/*  98 */       nbt.putString("id", "DUMMY");
/*  99 */       nbt.putInt("x", pos.getX());
/* 100 */       nbt.putInt("y", pos.getY());
/* 101 */       nbt.putInt("z", pos.getZ());
/* 102 */       this.blockEntities.put(pos.asLong(), nbt);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setBlockEntity(BlockPos pos, @Nullable BlockEntity entity, HolderLookup.Provider registryLookup) {
/* 107 */     if (entity != null)
/* 108 */     { ProblemReporter.ScopedCollector errorReporter = new ProblemReporter.ScopedCollector(entity.problemPath(), LOGGER); 
/* 109 */       try { TagValueOutput view = TagValueOutput.createWithContext((ProblemReporter)errorReporter, registryLookup);
/* 110 */         entity.saveWithId((ValueOutput)view);
/*     */         
/* 112 */         setBlockEntityNbt(pos, view.buildResult());
/* 113 */         errorReporter.close(); } catch (Throwable throwable) { try { errorReporter.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*     */        }
/* 115 */     else { setBlockEntityNbt(pos, null); }
/*     */   
/*     */   }
/*     */   
/*     */   public void setBlockEntityNbt(BlockPos pos, @Nullable CompoundTag entityNbt) {
/* 120 */     if (entityNbt != null) {
/* 121 */       entityNbt.putInt("x", pos.getX());
/* 122 */       entityNbt.putInt("y", pos.getY());
/* 123 */       entityNbt.putInt("z", pos.getZ());
/*     */       
/* 125 */       this.blockEntities.put(pos.asLong(), entityNbt);
/*     */     } else {
/* 127 */       this.blockEntities.remove(pos.asLong());
/*     */     } 
/*     */   }
/*     */   
/*     */   public BlockState getBlockState(BlockPos pos) {
/* 132 */     MapChunk chunk = (MapChunk)this.chunks.get(chunkPos(pos));
/* 133 */     if (chunk != null) {
/* 134 */       return chunk.get(pos.getX() & 0xF, pos.getY() & 0xF, pos.getZ() & 0xF);
/*     */     }
/* 136 */     return AIR;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public CompoundTag getBlockEntityNbt(BlockPos localPos) {
/* 141 */     CompoundTag nbt = (CompoundTag)this.blockEntities.get(localPos.asLong());
/* 142 */     return (nbt != null) ? nbt.copy() : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public CompoundTag getBlockEntityNbt(BlockPos localPos, BlockPos worldPos) {
/* 147 */     CompoundTag nbt = getBlockEntityNbt(localPos);
/* 148 */     if (nbt != null) {
/* 149 */       nbt.putInt("x", worldPos.getX());
/* 150 */       nbt.putInt("y", worldPos.getY());
/* 151 */       nbt.putInt("z", worldPos.getZ());
/* 152 */       return nbt;
/*     */     } 
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEntity(Entity entity, Vec3 pos) {
/* 166 */     getOrCreateChunk(chunkPos(pos)).addEntity(entity, pos);
/*     */   }
/*     */   
/*     */   public void addEntity(MapEntity entity) {
/* 170 */     getOrCreateChunk(chunkPos(entity.position())).addEntity(entity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<MapEntity> getEntitiesInChunk(int chunkX, int chunkY, int chunkZ) {
/* 182 */     MapChunk chunk = (MapChunk)this.chunks.get(chunkPos(chunkX, chunkY, chunkZ));
/* 183 */     return (chunk != null) ? chunk.getEntities().stream() : Stream.<MapEntity>empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTopY(int x, int z, Heightmap.Types heightmap) {
/* 188 */     Predicate<BlockState> predicate = heightmap.isOpaque();
/*     */     
/* 190 */     BlockBounds bounds = getBounds();
/* 191 */     int minY = bounds.min().getY();
/* 192 */     int maxY = bounds.max().getY();
/*     */     
/* 194 */     BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos(x, 0, z);
/* 195 */     for (int y = maxY; y >= minY; y--) {
/* 196 */       mutablePos.setY(y);
/*     */       
/* 198 */       BlockState state = getBlockState((BlockPos)mutablePos);
/* 199 */       if (predicate.test(state)) {
/* 200 */         return y;
/*     */       }
/*     */     } 
/*     */     
/* 204 */     return 0;
/*     */   }
/*     */   
/*     */   public BlockPos getTopPos(int x, int z, Heightmap.Types heightmap) {
/* 208 */     int y = getTopY(x, z, heightmap);
/* 209 */     return new BlockPos(x, y, z);
/*     */   }
/*     */   
/*     */   public boolean containsBlock(BlockPos pos) {
/* 213 */     return (getBlockState(pos) != AIR);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public MapChunk getOrCreateChunk(long pos) {
/* 218 */     MapChunk chunk = (MapChunk)this.chunks.get(pos);
/* 219 */     if (chunk == null) {
/* 220 */       this.chunks.put(pos, chunk = new MapChunk(SectionPos.of(pos)));
/*     */     }
/* 222 */     return chunk;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public MapChunk getChunk(long pos) {
/* 227 */     return (MapChunk)this.chunks.get(pos);
/*     */   }
/*     */   
/*     */   public void setBounds(BlockBounds bounds) {
/* 231 */     this.bounds = bounds;
/* 232 */     this.generatedBounds = null;
/*     */   }
/*     */   
/*     */   public BlockBounds getBounds() {
/* 236 */     BlockBounds bounds = this.bounds;
/* 237 */     if (bounds != null) {
/* 238 */       return bounds;
/*     */     }
/*     */     
/* 241 */     BlockBounds generatedBounds = this.generatedBounds;
/* 242 */     if (generatedBounds == null) {
/* 243 */       this.generatedBounds = generatedBounds = computeBounds();
/*     */     }
/*     */     
/* 246 */     return generatedBounds;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private BlockBounds getBoundsOrNull() {
/* 251 */     BlockBounds bounds = this.bounds;
/* 252 */     return (bounds != null) ? bounds : this.generatedBounds;
/*     */   }
/*     */   
/*     */   private BlockBounds computeBounds() {
/* 256 */     int minChunkX = Integer.MAX_VALUE;
/* 257 */     int minChunkY = Integer.MAX_VALUE;
/* 258 */     int minChunkZ = Integer.MAX_VALUE;
/* 259 */     int maxChunkX = Integer.MIN_VALUE;
/* 260 */     int maxChunkY = Integer.MIN_VALUE;
/* 261 */     int maxChunkZ = Integer.MIN_VALUE;
/*     */     
/* 263 */     for (ObjectIterator<Long2ObjectMap.Entry<MapChunk>> objectIterator = Long2ObjectMaps.fastIterable(this.chunks).iterator(); objectIterator.hasNext(); ) { Long2ObjectMap.Entry<MapChunk> entry = objectIterator.next();
/* 264 */       long chunkPos = entry.getLongKey();
/* 265 */       int chunkX = SectionPos.x(chunkPos);
/* 266 */       int chunkY = SectionPos.y(chunkPos);
/* 267 */       int chunkZ = SectionPos.z(chunkPos);
/*     */       
/* 269 */       if (chunkX < minChunkX) minChunkX = chunkX; 
/* 270 */       if (chunkY < minChunkY) minChunkY = chunkY; 
/* 271 */       if (chunkZ < minChunkZ) minChunkZ = chunkZ;
/*     */       
/* 273 */       if (chunkX > maxChunkX) maxChunkX = chunkX; 
/* 274 */       if (chunkY > maxChunkY) maxChunkY = chunkY; 
/* 275 */       if (chunkZ > maxChunkZ) maxChunkZ = chunkZ;
/*     */        }
/*     */     
/* 278 */     return BlockBounds.of(minChunkX << 4, minChunkY << 4, minChunkZ << 4, (maxChunkX << 4) + 15, (maxChunkY << 4) + 15, (maxChunkZ << 4) + 15);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long chunkPos(BlockPos pos) {
/* 285 */     return chunkPos(pos.getX() >> 4, pos.getY() >> 4, pos.getZ() >> 4);
/*     */   }
/*     */   
/*     */   static long chunkPos(Vec3 pos) {
/* 289 */     return chunkPos(Mth.floor(pos.x()) >> 4, Mth.floor(pos.y()) >> 4, Mth.floor(pos.z()) >> 4);
/*     */   }
/*     */   
/*     */   static long chunkPos(int x, int y, int z) {
/* 293 */     return SectionPos.asLong(x, y, z);
/*     */   }
/*     */   
/*     */   public MapTemplate translated(int x, int y, int z) {
/* 297 */     return transformed(MapTransform.translation(x, y, z));
/*     */   }
/*     */   
/*     */   public MapTemplate rotateAround(BlockPos pivot, Rotation rotation, Mirror mirror) {
/* 301 */     return transformed(MapTransform.rotationAround(pivot, rotation, mirror));
/*     */   }
/*     */   
/*     */   public MapTemplate rotate(Rotation rotation, Mirror mirror) {
/* 305 */     return rotateAround(BlockPos.ZERO, rotation, mirror);
/*     */   }
/*     */   
/*     */   public MapTemplate rotate(Rotation rotation) {
/* 309 */     return rotate(rotation, Mirror.NONE);
/*     */   }
/*     */   
/*     */   public MapTemplate mirror(Mirror mirror) {
/* 313 */     return rotate(Rotation.NONE, mirror);
/*     */   }
/*     */   
/*     */   public MapTemplate transformed(MapTransform transform) {
/* 317 */     MapTemplate result = createEmpty();
/*     */     
/* 319 */     BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();
/*     */     ObjectIterator<MapChunk> objectIterator;
/* 321 */     for (objectIterator = this.chunks.values().iterator(); objectIterator.hasNext(); ) { MapChunk chunk = objectIterator.next();
/* 322 */       BlockPos minChunkPos = chunk.getPos().origin();
/*     */       
/* 324 */       for (int chunkZ = 0; chunkZ < 16; chunkZ++) {
/* 325 */         for (int chunkY = 0; chunkY < 16; chunkY++) {
/* 326 */           for (int chunkX = 0; chunkX < 16; chunkX++) {
/* 327 */             BlockState state = chunk.get(chunkX, chunkY, chunkZ);
/* 328 */             if (!state.isAir()) {
/* 329 */               state = transform.transformedBlock(state);
/*     */               
/* 331 */               mutablePos.setWithOffset((Vec3i)minChunkPos, chunkX, chunkY, chunkZ);
/* 332 */               result.setBlockState((BlockPos)transform.transformPoint(mutablePos), state);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 338 */       for (MapEntity entity : chunk.getEntities()) {
/* 339 */         result.addEntity(entity.transformed(transform));
/*     */       } }
/*     */ 
/*     */     
/* 343 */     for (objectIterator = Long2ObjectMaps.fastIterable(this.blockEntities).iterator(); objectIterator.hasNext(); ) { Long2ObjectMap.Entry<CompoundTag> blockEntity = (Long2ObjectMap.Entry<CompoundTag>)objectIterator.next();
/* 344 */       mutablePos.set(blockEntity.getLongKey());
/* 345 */       transform.transformPoint(mutablePos);
/*     */       
/* 347 */       CompoundTag nbt = ((CompoundTag)blockEntity.getValue()).copy();
/* 348 */       result.setBlockEntityNbt((BlockPos)mutablePos, nbt); }
/*     */ 
/*     */     
/* 351 */     result.biome = this.biome;
/*     */     
/* 353 */     result.metadata.data = this.metadata.data.copy();
/*     */     
/* 355 */     for (TemplateRegion sourceRegion : this.metadata.regions) {
/* 356 */       result.metadata.regions.add(new TemplateRegion(sourceRegion
/* 357 */             .getMarker(), transform
/* 358 */             .transformedBounds(sourceRegion.getBounds()), sourceRegion
/* 359 */             .getData().copy()));
/*     */     }
/*     */ 
/*     */     
/* 363 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MapTemplate merged(MapTemplate primary, MapTemplate secondary) {
/* 375 */     MapTemplate result = createEmpty();
/* 376 */     secondary.mergeInto(result);
/* 377 */     primary.mergeInto(result);
/* 378 */     return result;
/*     */   }
/*     */   
/*     */   public void mergeFrom(MapTemplate other) {
/* 382 */     other.mergeInto(this);
/*     */   }
/*     */   
/*     */   public void mergeInto(MapTemplate other) {
/* 386 */     for (ObjectIterator<Long2ObjectMap.Entry<MapChunk>> objectIterator = Long2ObjectMaps.fastIterable(this.chunks).iterator(); objectIterator.hasNext(); ) { Long2ObjectMap.Entry<MapChunk> entry = objectIterator.next();
/* 387 */       long chunkPos = entry.getLongKey();
/* 388 */       MapChunk chunk = (MapChunk)entry.getValue();
/* 389 */       MapChunk otherChunk = other.getOrCreateChunk(chunkPos);
/*     */       
/* 391 */       for (int chunkZ = 0; chunkZ < 16; chunkZ++) {
/* 392 */         for (int chunkY = 0; chunkY < 16; chunkY++) {
/* 393 */           for (int chunkX = 0; chunkX < 16; chunkX++) {
/* 394 */             BlockState state = chunk.get(chunkX, chunkY, chunkZ);
/* 395 */             if (!state.isAir()) {
/* 396 */               otherChunk.set(chunkX, chunkY, chunkZ, state);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 402 */       for (MapEntity entity : chunk.getEntities()) {
/* 403 */         otherChunk.addEntity(entity);
/*     */       } }
/*     */ 
/*     */     
/* 407 */     other.metadata.data.merge(this.metadata.data);
/*     */     
/* 409 */     for (TemplateRegion region : this.metadata.regions) {
/* 410 */       other.metadata.addRegion(region.copy());
/*     */     }
/*     */     
/* 413 */     other.bounds = getBounds().union(other.getBounds());
/* 414 */     other.biome = this.biome;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\MapTemplate.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */