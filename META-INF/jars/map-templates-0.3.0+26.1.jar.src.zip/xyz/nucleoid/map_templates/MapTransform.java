/*    */ package xyz.nucleoid.map_templates;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.core.Vec3i;
/*    */ import net.minecraft.world.level.block.Mirror;
/*    */ import net.minecraft.world.level.block.Rotation;
/*    */ import net.minecraft.world.level.block.state.BlockState;
/*    */ import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
/*    */ import net.minecraft.world.phys.Vec3;
/*    */ 
/*    */ public interface MapTransform {
/*    */   static MapTransform translation(final int x, final int y, final int z) {
/* 12 */     return new MapTransform()
/*    */       {
/*    */         public BlockPos.MutableBlockPos transformPoint(BlockPos.MutableBlockPos mutablePos) {
/* 15 */           return mutablePos.move(x, y, z);
/*    */         }
/*    */ 
/*    */         
/*    */         public Vec3 transformedPoint(Vec3 pos) {
/* 20 */           return pos.add(x, y, z);
/*    */         }
/*    */       };
/*    */   }
/*    */   
/*    */   static MapTransform rotationAround(final BlockPos pivot, final Rotation rotation, final Mirror mirror) {
/* 26 */     return new MapTransform()
/*    */       {
/*    */         public BlockPos.MutableBlockPos transformPoint(BlockPos.MutableBlockPos mutablePos) {
/* 29 */           BlockPos result = transformedPoint((BlockPos)mutablePos);
/* 30 */           mutablePos.set((Vec3i)result);
/* 31 */           return mutablePos;
/*    */         }
/*    */ 
/*    */         
/*    */         public BlockPos transformedPoint(BlockPos pos) {
/* 36 */           return StructureTemplate.transform(pos, mirror, rotation, pivot);
/*    */         }
/*    */ 
/*    */         
/*    */         public Vec3 transformedPoint(Vec3 pos) {
/* 41 */           return StructureTemplate.transform(pos, mirror, rotation, pivot);
/*    */         }
/*    */ 
/*    */         
/*    */         public BlockState transformedBlock(BlockState state) {
/* 46 */           return state.rotate(rotation).mirror(mirror);
/*    */         }
/*    */       };
/*    */   }
/*    */   
/*    */   BlockPos.MutableBlockPos transformPoint(BlockPos.MutableBlockPos paramMutableBlockPos);
/*    */   
/*    */   default BlockPos transformedPoint(BlockPos pos) {
/* 54 */     BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos(pos.getX(), pos.getY(), pos.getZ());
/* 55 */     transformPoint(mutablePos);
/* 56 */     return (BlockPos)mutablePos;
/*    */   }
/*    */   
/*    */   Vec3 transformedPoint(Vec3 paramVec3);
/*    */   
/*    */   default BlockBounds transformedBounds(BlockBounds bounds) {
/* 62 */     return BlockBounds.of(
/* 63 */         transformedPoint(bounds.min()), 
/* 64 */         transformedPoint(bounds.max()));
/*    */   }
/*    */ 
/*    */   
/*    */   default BlockState transformedBlock(BlockState state) {
/* 69 */     return state;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\MapTransform.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */