/*     */ package xyz.nucleoid.map_templates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MapTemplateMetadata
/*     */ {
/*  18 */   final List<TemplateRegion> regions = new ArrayList<>();
/*  19 */   CompoundTag data = new CompoundTag();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateRegion addRegion(String marker, BlockBounds bounds) {
/*  30 */     return addRegion(marker, bounds, new CompoundTag());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateRegion addRegion(String marker, BlockBounds bounds, CompoundTag nbt) {
/*  43 */     TemplateRegion region = new TemplateRegion(marker, bounds, nbt);
/*  44 */     this.regions.add(region);
/*  45 */     return region;
/*     */   }
/*     */   
/*     */   public void addRegion(TemplateRegion region) {
/*  49 */     this.regions.add(region);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<TemplateRegion> getRegions(String marker) {
/*  59 */     return this.regions.stream()
/*  60 */       .filter(region -> region.getMarker().equals(marker));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<BlockBounds> getRegionBounds(String marker) {
/*  70 */     return getRegions(marker)
/*  71 */       .map(TemplateRegion::getBounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TemplateRegion getFirstRegion(String marker) {
/*  83 */     return getRegions(marker).findFirst().orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BlockBounds getFirstRegionBounds(String marker) {
/*  95 */     return getRegionBounds(marker).findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public Collection<TemplateRegion> getRegions() {
/*  99 */     return this.regions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(CompoundTag data) {
/* 108 */     this.data = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompoundTag getData() {
/* 117 */     return this.data;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\map-templates-0.3.0+26.1.jar!\xyz\nucleoid\map_templates\MapTemplateMetadata.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */