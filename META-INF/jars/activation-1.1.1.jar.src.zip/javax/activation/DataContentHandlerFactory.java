package javax.activation;

public interface DataContentHandlerFactory {
  DataContentHandler createDataContentHandler(String paramString);
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\activation-1.1.1.jar!\javax\activation\DataContentHandlerFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */