/*     */ package com.siemens.ct.exi.grammars.persistency;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.GrammarContext;
/*     */ import com.siemens.ct.exi.core.context.GrammarUriContext;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.grammars.Grammars;
/*     */ import com.siemens.ct.exi.core.grammars.SchemaInformedGrammars;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrammarsPreperation
/*     */ {
/*  61 */   protected GrammarIdDispenser grsIdDispenser = new GrammarIdDispenser();
/*  62 */   protected List<Grammar> sortedGrammars = new ArrayList<>();
/*     */   protected int numberOfFirstStartTagGrammars;
/*     */   
/*     */   public void clear() {
/*  66 */     this.grsIdDispenser.clear();
/*  67 */     this.sortedGrammars.clear();
/*     */     
/*  69 */     this.numberOfFirstStartTagGrammars = 0;
/*  70 */     this.numberOfStartTagGrammars = 0;
/*  71 */     this.numberOfElementGrammars = 0;
/*     */   }
/*     */   protected int numberOfStartTagGrammars; protected int numberOfElementGrammars;
/*     */   public void prepareGrammars(Grammars grammar) throws IOException {
/*  75 */     clear();
/*     */ 
/*     */     
/*  78 */     Grammar doc = grammar.getDocumentGrammar();
/*  79 */     prepareGrammar(doc);
/*     */ 
/*     */     
/*  82 */     Grammar frag = grammar.getFragmentGrammar();
/*  83 */     prepareGrammar(frag);
/*     */ 
/*     */     
/*  86 */     if (grammar instanceof SchemaInformedGrammars) {
/*     */       
/*  88 */       SchemaInformedGrammar elFragGr = ((SchemaInformedGrammars)grammar).getSchemaInformedElementFragmentGrammar();
/*  89 */       prepareGrammar((Grammar)elFragGr);
/*     */     } 
/*     */ 
/*     */     
/*  93 */     GrammarContext gc = grammar.getGrammarContext();
/*  94 */     for (int uriId = 0; uriId < gc.getNumberOfGrammarUriContexts(); uriId++) {
/*  95 */       GrammarUriContext guc = gc.getGrammarUriContext(uriId);
/*  96 */       for (int qnId = 0; qnId < guc.getNumberOfQNames(); qnId++) {
/*  97 */         QNameContext qnc = guc.getQNameContext(qnId);
/*     */         
/*  99 */         SchemaInformedFirstStartTagGrammar typeGrammar = qnc.getTypeGrammar();
/* 100 */         if (typeGrammar != null) {
/* 101 */           prepareGrammar((Grammar)typeGrammar);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 106 */     this.sortedGrammars.clear();
/*     */ 
/*     */     
/* 109 */     for (int k = 0; k < 8; k++) {
/*     */ 
/*     */ 
/*     */       
/* 113 */       Iterator<Grammar> iterGrs = this.grsIdDispenser.getGrammarIterator();
/* 114 */       while (iterGrs.hasNext()) {
/* 115 */         Grammar r = iterGrs.next();
/* 116 */         switch (k) {
/*     */           
/*     */           case 0:
/* 119 */             if (r instanceof com.siemens.ct.exi.core.grammars.grammar.Document) {
/* 120 */               this.sortedGrammars.add(r);
/*     */             }
/*     */ 
/*     */           
/*     */           case 1:
/* 125 */             if (r instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedDocContent) {
/* 126 */               this.sortedGrammars.add(r);
/*     */             }
/*     */ 
/*     */           
/*     */           case 2:
/* 131 */             if (r instanceof com.siemens.ct.exi.core.grammars.grammar.DocEnd) {
/* 132 */               this.sortedGrammars.add(r);
/*     */             }
/*     */ 
/*     */           
/*     */           case 3:
/* 137 */             if (r instanceof com.siemens.ct.exi.core.grammars.grammar.Fragment) {
/* 138 */               this.sortedGrammars.add(r);
/*     */             }
/*     */ 
/*     */           
/*     */           case 4:
/* 143 */             if (r instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFragmentContent) {
/* 144 */               this.sortedGrammars.add(r);
/*     */             }
/*     */ 
/*     */           
/*     */           case 5:
/* 149 */             if (r instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTag) {
/* 150 */               this.numberOfFirstStartTagGrammars++;
/* 151 */               this.sortedGrammars.add(r);
/*     */             } 
/*     */ 
/*     */           
/*     */           case 6:
/* 156 */             if (r instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedStartTag && 
/* 157 */               !(r instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTag)) {
/* 158 */               this.numberOfStartTagGrammars++;
/* 159 */               this.sortedGrammars.add(r);
/*     */             } 
/*     */ 
/*     */ 
/*     */           
/*     */           case 7:
/* 165 */             if (r instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedElement) {
/* 166 */               this.numberOfElementGrammars++;
/* 167 */               this.sortedGrammars.add(r);
/*     */             } 
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 175 */     System.out.println("Sorted Grammars: " + this.sortedGrammars);
/*     */   }
/*     */ 
/*     */   
/*     */   void prepareGrammar(Grammar r) throws IOException {
/* 180 */     if (this.grsIdDispenser.isGrammarHandled(r)) {
/*     */       return;
/*     */     }
/*     */     
/* 184 */     this.grsIdDispenser.addHandledGrammar(r);
/*     */     
/* 186 */     int numberOfEvents = r.getNumberOfEvents();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     for (int eventCode = 0; eventCode < numberOfEvents; eventCode++) {
/* 192 */       StartElement se; Production ei = r.getProduction(eventCode);
/*     */       
/* 194 */       switch (ei.getEvent().getEventType()) {
/*     */         case START_ELEMENT:
/* 196 */           se = (StartElement)ei.getEvent();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 201 */           if (!this.grsIdDispenser.isGrammarHandled(se.getGrammar())) {
/* 202 */             prepareGrammar(se.getGrammar());
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 209 */       if (ei.getNextGrammar() != null) {
/* 210 */         prepareGrammar(ei.getNextGrammar());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 215 */     prepareGrammar(r.getElementContentGrammar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGrammarID(Grammar r) {
/* 222 */     int id1 = this.grsIdDispenser.getGrammarID(r);
/* 223 */     Grammar g1 = this.grsIdDispenser.getGrammar(id1);
/*     */     
/* 225 */     for (int i = 0; i < this.sortedGrammars.size(); i++) {
/* 226 */       Grammar g = this.sortedGrammars.get(i);
/* 227 */       if (g1 == g) {
/* 228 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 232 */     throw new RuntimeException("No grammar id found for: " + r);
/*     */   }
/*     */   
/*     */   public Grammar getGrammar(int id) {
/* 236 */     return this.sortedGrammars.get(id);
/*     */   }
/*     */   
/*     */   public int getNumberOfGrammars() {
/* 240 */     return this.sortedGrammars.size();
/*     */   }
/*     */   
/*     */   public int getNumberOfFirstStartTagGrammars() {
/* 244 */     return this.numberOfFirstStartTagGrammars;
/*     */   }
/*     */   
/*     */   public int getNumberOfStartTagGrammars() {
/* 248 */     return this.numberOfStartTagGrammars;
/*     */   }
/*     */   
/*     */   public int getNumberOfElementGrammars() {
/* 252 */     return this.numberOfElementGrammars;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\persistency\GrammarsPreperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */