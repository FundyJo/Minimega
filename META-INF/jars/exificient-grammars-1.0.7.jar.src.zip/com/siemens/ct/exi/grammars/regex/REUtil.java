/*     */ package com.siemens.ct.exi.grammars.regex;
/*     */ 
/*     */ import java.text.CharacterIterator;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class REUtil
/*     */ {
/*  38 */   private static final Logger LOGGER = LoggerFactory.getLogger(REUtil.class);
/*     */   
/*     */   static final int CACHESIZE = 20;
/*     */ 
/*     */   
/*     */   static final int composeFromSurrogates(int high, int low) {
/*  44 */     return 65536 + (high - 55296 << 10) + low - 56320;
/*     */   }
/*     */   
/*     */   static final boolean isLowSurrogate(int ch) {
/*  48 */     return ((ch & 0xFC00) == 56320);
/*     */   }
/*     */   
/*     */   static final boolean isHighSurrogate(int ch) {
/*  52 */     return ((ch & 0xFC00) == 55296);
/*     */   }
/*     */   
/*     */   static final String decomposeToSurrogates(int ch) {
/*  56 */     char[] chs = new char[2];
/*  57 */     ch -= 65536;
/*  58 */     chs[0] = (char)((ch >> 10) + 55296);
/*  59 */     chs[1] = (char)((ch & 0x3FF) + 56320);
/*  60 */     return new String(chs);
/*     */   }
/*     */   
/*     */   static final String substring(CharacterIterator iterator, int begin, int end) {
/*  64 */     char[] src = new char[end - begin];
/*  65 */     for (int i = 0; i < src.length; i++)
/*  66 */       src[i] = iterator.setIndex(i + begin); 
/*  67 */     return new String(src);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final int getOptionValue(int ch) {
/*  73 */     int ret = 0;
/*  74 */     switch (ch) {
/*     */       case 105:
/*  76 */         ret = 2;
/*     */         break;
/*     */       case 109:
/*  79 */         ret = 8;
/*     */         break;
/*     */       case 115:
/*  82 */         ret = 4;
/*     */         break;
/*     */       case 120:
/*  85 */         ret = 16;
/*     */         break;
/*     */       case 117:
/*  88 */         ret = 32;
/*     */         break;
/*     */       case 119:
/*  91 */         ret = 64;
/*     */         break;
/*     */       case 70:
/*  94 */         ret = 256;
/*     */         break;
/*     */       case 72:
/*  97 */         ret = 128;
/*     */         break;
/*     */       case 88:
/* 100 */         ret = 512;
/*     */         break;
/*     */       case 44:
/* 103 */         ret = 1024;
/*     */         break;
/*     */     } 
/*     */     
/* 107 */     return ret;
/*     */   }
/*     */   
/*     */   static final int parseOptions(String opts) throws ParseException {
/* 111 */     if (opts == null)
/* 112 */       return 0; 
/* 113 */     int options = 0;
/* 114 */     for (int i = 0; i < opts.length(); i++) {
/* 115 */       int v = getOptionValue(opts.charAt(i));
/* 116 */       if (v == 0)
/* 117 */         throw new ParseException("Unknown Option: " + opts
/* 118 */             .substring(i), -1); 
/* 119 */       options |= v;
/*     */     } 
/* 121 */     return options;
/*     */   }
/*     */   
/*     */   static final String createOptionString(int options) {
/* 125 */     StringBuffer sb = new StringBuffer(9);
/* 126 */     if ((options & 0x100) != 0)
/* 127 */       sb.append('F'); 
/* 128 */     if ((options & 0x80) != 0)
/* 129 */       sb.append('H'); 
/* 130 */     if ((options & 0x200) != 0)
/* 131 */       sb.append('X'); 
/* 132 */     if ((options & 0x2) != 0)
/* 133 */       sb.append('i'); 
/* 134 */     if ((options & 0x8) != 0)
/* 135 */       sb.append('m'); 
/* 136 */     if ((options & 0x4) != 0)
/* 137 */       sb.append('s'); 
/* 138 */     if ((options & 0x20) != 0)
/* 139 */       sb.append('u'); 
/* 140 */     if ((options & 0x40) != 0)
/* 141 */       sb.append('w'); 
/* 142 */     if ((options & 0x10) != 0)
/* 143 */       sb.append('x'); 
/* 144 */     if ((options & 0x400) != 0)
/* 145 */       sb.append(','); 
/* 146 */     return sb.toString().intern();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String stripExtendedComment(String regex) {
/* 152 */     int len = regex.length();
/* 153 */     StringBuffer buffer = new StringBuffer(len);
/* 154 */     int offset = 0;
/* 155 */     int charClass = 0;
/* 156 */     while (offset < len) {
/* 157 */       int ch = regex.charAt(offset++);
/*     */       
/* 159 */       if (ch == 9 || ch == 10 || ch == 12 || ch == 13 || ch == 32) {
/*     */ 
/*     */         
/* 162 */         if (charClass > 0) {
/* 163 */           buffer.append((char)ch);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 168 */       if (ch == 35) {
/* 169 */         while (offset < len) {
/* 170 */           ch = regex.charAt(offset++);
/* 171 */           if (ch == 13 || ch == 10) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 178 */       if (ch == 92 && offset < len) {
/* 179 */         int next; if ((next = regex.charAt(offset)) == 35 || next == 9 || next == 10 || next == 12 || next == 13 || next == 32) {
/*     */ 
/*     */           
/* 182 */           buffer.append((char)next);
/* 183 */           offset++; continue;
/*     */         } 
/* 185 */         buffer.append('\\');
/* 186 */         buffer.append((char)next);
/* 187 */         offset++; continue;
/*     */       } 
/* 189 */       if (ch == 91) {
/* 190 */         charClass++;
/* 191 */         buffer.append((char)ch);
/* 192 */         if (offset < len) {
/* 193 */           int next = regex.charAt(offset);
/* 194 */           if (next == 91 || next == 93) {
/* 195 */             buffer.append((char)next);
/* 196 */             offset++; continue;
/* 197 */           }  if (next == 94 && offset + 1 < len) {
/* 198 */             next = regex.charAt(offset + 1);
/* 199 */             if (next == 91 || next == 93) {
/* 200 */               buffer.append('^');
/* 201 */               buffer.append((char)next);
/* 202 */               offset += 2;
/*     */             } 
/*     */           } 
/*     */         }  continue;
/*     */       } 
/* 207 */       if (charClass > 0 && ch == 93) {
/* 208 */         charClass--;
/*     */       }
/* 210 */       buffer.append((char)ch);
/*     */     } 
/*     */     
/* 213 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] argv) {
/* 223 */     String pattern = null;
/*     */     try {
/* 225 */       String options = "";
/* 226 */       String target = null;
/* 227 */       if (argv.length == 0) {
/* 228 */         System.out
/* 229 */           .println("Error:Usage: java REUtil -i|-m|-s|-u|-w|-X regularExpression String");
/* 230 */         System.exit(0);
/*     */       } 
/* 232 */       for (int i = 0; i < argv.length; i++) {
/* 233 */         if (argv[i].length() == 0 || argv[i].charAt(0) != '-') {
/* 234 */           if (pattern == null)
/* 235 */           { pattern = argv[i]; }
/* 236 */           else if (target == null)
/* 237 */           { target = argv[i]; }
/*     */           else
/* 239 */           { LOGGER.warn("Unnecessary: {}", argv[i]); } 
/* 240 */         } else if (argv[i].equals("-i")) {
/* 241 */           options = options + "i";
/* 242 */         } else if (argv[i].equals("-m")) {
/* 243 */           options = options + "m";
/* 244 */         } else if (argv[i].equals("-s")) {
/* 245 */           options = options + "s";
/* 246 */         } else if (argv[i].equals("-u")) {
/* 247 */           options = options + "u";
/* 248 */         } else if (argv[i].equals("-w")) {
/* 249 */           options = options + "w";
/* 250 */         } else if (argv[i].equals("-X")) {
/* 251 */           options = options + "X";
/*     */         } else {
/* 253 */           LOGGER.warn("Unknown option: {}", argv[i]);
/*     */         } 
/*     */       } 
/* 256 */       RegularExpression reg = new RegularExpression(pattern, options);
/* 257 */       System.out.println("RegularExpression: " + reg);
/* 258 */       Match match = new Match();
/* 259 */       reg.matches(target, match);
/* 260 */       for (int j = 0; j < match.getNumberOfGroups(); j++) {
/* 261 */         if (j == 0) {
/* 262 */           System.out.print("Matched range for the whole pattern: ");
/*     */         } else {
/* 264 */           System.out.print("[" + j + "]: ");
/* 265 */         }  if (match.getBeginning(j) < 0) {
/* 266 */           System.out.println("-1");
/*     */         } else {
/* 268 */           System.out.print(match.getBeginning(j) + ", " + match
/* 269 */               .getEnd(j) + ", ");
/* 270 */           System.out.println("\"" + match.getCapturedText(j) + "\"");
/*     */         } 
/*     */       } 
/* 273 */     } catch (ParseException pe) {
/* 274 */       LOGGER.error("unexpected ParseException", pe);
/* 275 */     } catch (Exception e) {
/* 276 */       LOGGER.error("unexpected error", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 281 */   static final RegularExpression[] regexCache = new RegularExpression[20];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RegularExpression createRegex(String pattern, String options) throws ParseException {
/* 292 */     RegularExpression re = null;
/* 293 */     int intOptions = parseOptions(options);
/* 294 */     synchronized (regexCache) {
/*     */       int i;
/* 296 */       for (i = 0; i < 20; i++) {
/* 297 */         RegularExpression cached = regexCache[i];
/* 298 */         if (cached == null) {
/* 299 */           i = -1;
/*     */           break;
/*     */         } 
/* 302 */         if (cached.equals(pattern, intOptions)) {
/* 303 */           re = cached;
/*     */           break;
/*     */         } 
/*     */       } 
/* 307 */       if (re != null) {
/* 308 */         if (i != 0) {
/* 309 */           System.arraycopy(regexCache, 0, regexCache, 1, i);
/*     */           
/* 311 */           regexCache[0] = re;
/*     */         } 
/*     */       } else {
/* 314 */         re = new RegularExpression(pattern, options);
/* 315 */         System.arraycopy(regexCache, 0, regexCache, 1, 19);
/*     */         
/* 317 */         regexCache[0] = re;
/*     */       } 
/*     */     } 
/* 320 */     return re;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean matches(String regex, String target) throws ParseException {
/* 329 */     return createRegex(regex, null).matches(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean matches(String regex, String options, String target) throws ParseException {
/* 338 */     return createRegex(regex, options).matches(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quoteMeta(String literal) {
/* 347 */     int len = literal.length();
/* 348 */     StringBuffer buffer = null;
/* 349 */     for (int i = 0; i < len; i++) {
/* 350 */       int ch = literal.charAt(i);
/* 351 */       if (".*+?{[()|\\^$".indexOf(ch) >= 0) {
/* 352 */         if (buffer == null) {
/* 353 */           buffer = new StringBuffer(i + (len - i) * 2);
/* 354 */           if (i > 0)
/* 355 */             buffer.append(literal.substring(0, i)); 
/*     */         } 
/* 357 */         buffer.append('\\');
/* 358 */         buffer.append((char)ch);
/* 359 */       } else if (buffer != null) {
/* 360 */         buffer.append((char)ch);
/*     */       } 
/* 362 */     }  return (buffer != null) ? buffer.toString() : literal;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void dumpString(String v) {
/* 368 */     for (int i = 0; i < v.length(); i++) {
/* 369 */       System.out.print(Integer.toHexString(v.charAt(i)));
/* 370 */       System.out.print(" ");
/*     */     } 
/* 372 */     System.out.println();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\REUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */