/*     */ package com.siemens.ct.exi.grammars.regex;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RangeToken
/*     */   extends Token
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -553983121197679934L;
/*  37 */   private static final Logger LOGGER = LoggerFactory.getLogger(RangeToken.class);
/*     */   
/*     */   int[] ranges;
/*     */   boolean sorted;
/*     */   boolean compacted;
/*  42 */   RangeToken icaseCache = null;
/*  43 */   int[] map = null; int nonMapIndex;
/*     */   private static final int MAPSIZE = 256;
/*     */   
/*     */   RangeToken(int type) {
/*  47 */     super(type);
/*  48 */     setSorted(false);
/*     */   }
/*     */   
/*     */   protected void addRange(int start, int end) {
/*     */     int r1, r2;
/*  53 */     this.icaseCache = null;
/*     */ 
/*     */     
/*  56 */     if (start <= end) {
/*  57 */       r1 = start;
/*  58 */       r2 = end;
/*     */     } else {
/*  60 */       r1 = end;
/*  61 */       r2 = start;
/*     */     } 
/*     */     
/*  64 */     int pos = 0;
/*  65 */     if (this.ranges == null) {
/*  66 */       this.ranges = new int[2];
/*  67 */       this.ranges[0] = r1;
/*  68 */       this.ranges[1] = r2;
/*  69 */       setSorted(true);
/*     */     } else {
/*  71 */       pos = this.ranges.length;
/*  72 */       if (this.ranges[pos - 1] + 1 == r1) {
/*  73 */         this.ranges[pos - 1] = r2;
/*     */         return;
/*     */       } 
/*  76 */       int[] temp = new int[pos + 2];
/*  77 */       System.arraycopy(this.ranges, 0, temp, 0, pos);
/*  78 */       this.ranges = temp;
/*  79 */       if (this.ranges[pos - 1] >= r1)
/*  80 */         setSorted(false); 
/*  81 */       this.ranges[pos++] = r1;
/*  82 */       this.ranges[pos] = r2;
/*  83 */       if (!this.sorted)
/*  84 */         sortRanges(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final boolean isSorted() {
/*  89 */     return this.sorted;
/*     */   }
/*     */   
/*     */   private final void setSorted(boolean sort) {
/*  93 */     this.sorted = sort;
/*  94 */     if (!sort)
/*  95 */       this.compacted = false; 
/*     */   }
/*     */   
/*     */   private final boolean isCompacted() {
/*  99 */     return this.compacted;
/*     */   }
/*     */   
/*     */   private final void setCompacted() {
/* 103 */     this.compacted = true;
/*     */   }
/*     */   
/*     */   protected void sortRanges() {
/* 107 */     if (isSorted())
/*     */       return; 
/* 109 */     if (this.ranges == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     for (int i = this.ranges.length - 4; i >= 0; i -= 2) {
/* 117 */       for (int j = 0; j <= i; j += 2) {
/* 118 */         if (this.ranges[j] > this.ranges[j + 2] || (this.ranges[j] == this.ranges[j + 2] && this.ranges[j + 1] > this.ranges[j + 3])) {
/*     */ 
/*     */ 
/*     */           
/* 122 */           int tmp = this.ranges[j + 2];
/* 123 */           this.ranges[j + 2] = this.ranges[j];
/* 124 */           this.ranges[j] = tmp;
/* 125 */           tmp = this.ranges[j + 3];
/* 126 */           this.ranges[j + 3] = this.ranges[j + 1];
/* 127 */           this.ranges[j + 1] = tmp;
/*     */         } 
/*     */       } 
/*     */     } 
/* 131 */     setSorted(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void compactRanges() {
/* 138 */     if (this.ranges == null || this.ranges.length <= 2)
/*     */       return; 
/* 140 */     if (isCompacted())
/*     */       return; 
/* 142 */     int base = 0;
/* 143 */     int target = 0;
/*     */     
/* 145 */     while (target < this.ranges.length) {
/* 146 */       if (base != target) {
/* 147 */         this.ranges[base] = this.ranges[target++];
/* 148 */         this.ranges[base + 1] = this.ranges[target++];
/*     */       } else {
/* 150 */         target += 2;
/* 151 */       }  int baseend = this.ranges[base + 1];
/* 152 */       while (target < this.ranges.length && 
/* 153 */         baseend + 1 >= this.ranges[target]) {
/*     */         
/* 155 */         if (baseend + 1 == this.ranges[target]) {
/* 156 */           LOGGER.debug("Token#compactRanges(): Compaction: [{}, {}], [{}, {}] -> [{}, {}]", new Object[] {
/* 157 */                 Integer.valueOf(this.ranges[base]), 
/* 158 */                 Integer.valueOf(this.ranges[base + 1]), 
/* 159 */                 Integer.valueOf(this.ranges[target]), 
/* 160 */                 Integer.valueOf(this.ranges[target + 1]), 
/* 161 */                 Integer.valueOf(this.ranges[base]), 
/* 162 */                 Integer.valueOf(this.ranges[target + 1]) });
/* 163 */           this.ranges[base + 1] = this.ranges[target + 1];
/* 164 */           baseend = this.ranges[base + 1];
/* 165 */           target += 2; continue;
/* 166 */         }  if (baseend >= this.ranges[target + 1]) {
/* 167 */           LOGGER.debug("Token#compactRanges(): Compaction: [{}, {}], [{}, {}] -> [{}, {}]", new Object[] {
/* 168 */                 Integer.valueOf(this.ranges[base]), 
/* 169 */                 Integer.valueOf(this.ranges[base + 1]), 
/* 170 */                 Integer.valueOf(this.ranges[target]), 
/* 171 */                 Integer.valueOf(this.ranges[target + 1]), 
/* 172 */                 Integer.valueOf(this.ranges[base]), 
/* 173 */                 Integer.valueOf(this.ranges[base + 1]) });
/* 174 */           target += 2; continue;
/* 175 */         }  if (baseend < this.ranges[target + 1]) {
/* 176 */           LOGGER.debug("Token#compactRanges(): Compaction: [{}, {}], [{}, {}] -> [{}, {}]", new Object[] {
/* 177 */                 Integer.valueOf(this.ranges[base]), 
/* 178 */                 Integer.valueOf(this.ranges[base + 1]), 
/* 179 */                 Integer.valueOf(this.ranges[target]), 
/* 180 */                 Integer.valueOf(this.ranges[target + 1]), 
/* 181 */                 Integer.valueOf(this.ranges[base]), 
/* 182 */                 Integer.valueOf(this.ranges[target + 1]) });
/* 183 */           this.ranges[base + 1] = this.ranges[target + 1];
/* 184 */           baseend = this.ranges[base + 1];
/* 185 */           target += 2; continue;
/*     */         } 
/* 187 */         throw new RuntimeException("Token#compactRanges(): Internel Error: [" + this.ranges[base] + "," + this.ranges[base + 1] + "] [" + this.ranges[target] + "," + this.ranges[target + 1] + "]");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       base += 2;
/*     */     } 
/*     */     
/* 198 */     if (base != this.ranges.length) {
/* 199 */       int[] result = new int[base];
/* 200 */       System.arraycopy(this.ranges, 0, result, 0, base);
/* 201 */       this.ranges = result;
/*     */     } 
/* 203 */     setCompacted();
/*     */   }
/*     */   
/*     */   protected void mergeRanges(Token token) {
/* 207 */     RangeToken tok = (RangeToken)token;
/* 208 */     sortRanges();
/* 209 */     tok.sortRanges();
/* 210 */     if (tok.ranges == null)
/*     */       return; 
/* 212 */     this.icaseCache = null;
/* 213 */     setSorted(true);
/* 214 */     if (this.ranges == null) {
/* 215 */       this.ranges = new int[tok.ranges.length];
/* 216 */       System.arraycopy(tok.ranges, 0, this.ranges, 0, tok.ranges.length);
/*     */       return;
/*     */     } 
/* 219 */     int[] result = new int[this.ranges.length + tok.ranges.length];
/* 220 */     int i = 0, j = 0, k = 0;
/* 221 */     while (i < this.ranges.length || j < tok.ranges.length) {
/* 222 */       if (i >= this.ranges.length) {
/* 223 */         result[k++] = tok.ranges[j++];
/* 224 */         result[k++] = tok.ranges[j++]; continue;
/* 225 */       }  if (j >= tok.ranges.length) {
/* 226 */         result[k++] = this.ranges[i++];
/* 227 */         result[k++] = this.ranges[i++]; continue;
/* 228 */       }  if (tok.ranges[j] < this.ranges[i] || (tok.ranges[j] == this.ranges[i] && tok.ranges[j + 1] < this.ranges[i + 1])) {
/*     */ 
/*     */         
/* 231 */         result[k++] = tok.ranges[j++];
/* 232 */         result[k++] = tok.ranges[j++]; continue;
/*     */       } 
/* 234 */       result[k++] = this.ranges[i++];
/* 235 */       result[k++] = this.ranges[i++];
/*     */     } 
/*     */     
/* 238 */     this.ranges = result;
/*     */   }
/*     */   
/*     */   protected void subtractRanges(Token token) {
/* 242 */     if (token.type == 5) {
/* 243 */       intersectRanges(token);
/*     */       return;
/*     */     } 
/* 246 */     RangeToken tok = (RangeToken)token;
/* 247 */     if (tok.ranges == null || this.ranges == null)
/*     */       return; 
/* 249 */     this.icaseCache = null;
/* 250 */     sortRanges();
/* 251 */     compactRanges();
/* 252 */     tok.sortRanges();
/* 253 */     tok.compactRanges();
/*     */ 
/*     */ 
/*     */     
/* 257 */     int[] result = new int[this.ranges.length + tok.ranges.length];
/* 258 */     int wp = 0, src = 0, sub = 0;
/* 259 */     while (src < this.ranges.length && sub < tok.ranges.length) {
/* 260 */       int srcbegin = this.ranges[src];
/* 261 */       int srcend = this.ranges[src + 1];
/* 262 */       int subbegin = tok.ranges[sub];
/* 263 */       int subend = tok.ranges[sub + 1];
/* 264 */       if (srcend < subbegin) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 269 */         result[wp++] = this.ranges[src++];
/* 270 */         result[wp++] = this.ranges[src++]; continue;
/* 271 */       }  if (srcend >= subbegin && srcbegin <= subend) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 282 */         if (subbegin <= srcbegin && srcend <= subend) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 287 */           src += 2; continue;
/* 288 */         }  if (subbegin <= srcbegin) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 293 */           this.ranges[src] = subend + 1;
/* 294 */           sub += 2; continue;
/* 295 */         }  if (srcend <= subend) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 300 */           result[wp++] = srcbegin;
/* 301 */           result[wp++] = subbegin - 1;
/* 302 */           src += 2;
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 308 */         result[wp++] = srcbegin;
/* 309 */         result[wp++] = subbegin - 1;
/* 310 */         this.ranges[src] = subend + 1;
/* 311 */         sub += 2; continue;
/*     */       } 
/* 313 */       if (subend < srcbegin) {
/*     */ 
/*     */ 
/*     */         
/* 317 */         sub += 2; continue;
/*     */       } 
/* 319 */       throw new RuntimeException("Token#subtractRanges(): Internal Error: [" + this.ranges[src] + "," + this.ranges[src + 1] + "] - [" + tok.ranges[sub] + "," + tok.ranges[sub + 1] + "]");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 326 */     while (src < this.ranges.length) {
/* 327 */       result[wp++] = this.ranges[src++];
/* 328 */       result[wp++] = this.ranges[src++];
/*     */     } 
/* 330 */     this.ranges = new int[wp];
/* 331 */     System.arraycopy(result, 0, this.ranges, 0, wp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void intersectRanges(Token token) {
/* 340 */     RangeToken tok = (RangeToken)token;
/* 341 */     if (tok.ranges == null || this.ranges == null)
/*     */       return; 
/* 343 */     this.icaseCache = null;
/* 344 */     sortRanges();
/* 345 */     compactRanges();
/* 346 */     tok.sortRanges();
/* 347 */     tok.compactRanges();
/*     */     
/* 349 */     int[] result = new int[this.ranges.length + tok.ranges.length];
/* 350 */     int wp = 0, src1 = 0, src2 = 0;
/* 351 */     while (src1 < this.ranges.length && src2 < tok.ranges.length) {
/* 352 */       int src1begin = this.ranges[src1];
/* 353 */       int src1end = this.ranges[src1 + 1];
/* 354 */       int src2begin = tok.ranges[src2];
/* 355 */       int src2end = tok.ranges[src2 + 1];
/* 356 */       if (src1end < src2begin) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 361 */         src1 += 2; continue;
/* 362 */       }  if (src1end >= src2begin && src1begin <= src2end) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 373 */         if (src2begin <= src1begin && src1end <= src2end) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 378 */           result[wp++] = src1begin;
/* 379 */           result[wp++] = src1end;
/* 380 */           src1 += 2; continue;
/* 381 */         }  if (src2begin <= src1begin) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 386 */           result[wp++] = src1begin;
/* 387 */           result[wp++] = src2end;
/* 388 */           this.ranges[src1] = src2end + 1;
/* 389 */           src2 += 2; continue;
/* 390 */         }  if (src1end <= src2end) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 395 */           result[wp++] = src2begin;
/* 396 */           result[wp++] = src1end;
/* 397 */           src1 += 2;
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 403 */         result[wp++] = src2begin;
/* 404 */         result[wp++] = src2end;
/* 405 */         this.ranges[src1] = src2end + 1; continue;
/*     */       } 
/* 407 */       if (src2end < src1begin) {
/*     */ 
/*     */ 
/*     */         
/* 411 */         src2 += 2; continue;
/*     */       } 
/* 413 */       throw new RuntimeException("Token#intersectRanges(): Internal Error: [" + this.ranges[src1] + "," + this.ranges[src1 + 1] + "] & [" + tok.ranges[src2] + "," + tok.ranges[src2 + 1] + "]");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 421 */     while (src1 < this.ranges.length) {
/* 422 */       result[wp++] = this.ranges[src1++];
/* 423 */       result[wp++] = this.ranges[src1++];
/*     */     } 
/* 425 */     this.ranges = new int[wp];
/* 426 */     System.arraycopy(result, 0, this.ranges, 0, wp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Token complementRanges(Token token) {
/* 435 */     if (token.type != 4 && token.type != 5) {
/* 436 */       throw new IllegalArgumentException("Token#complementRanges(): must be RANGE: " + token.type);
/*     */     }
/* 438 */     RangeToken tok = (RangeToken)token;
/* 439 */     tok.sortRanges();
/* 440 */     tok.compactRanges();
/* 441 */     int len = tok.ranges.length + 2;
/* 442 */     if (tok.ranges[0] == 0)
/* 443 */       len -= 2; 
/* 444 */     int last = tok.ranges[tok.ranges.length - 1];
/* 445 */     if (last == 1114111)
/* 446 */       len -= 2; 
/* 447 */     RangeToken ret = Token.createRange();
/* 448 */     ret.ranges = new int[len];
/* 449 */     int wp = 0;
/* 450 */     if (tok.ranges[0] > 0) {
/* 451 */       ret.ranges[wp++] = 0;
/* 452 */       ret.ranges[wp++] = tok.ranges[0] - 1;
/*     */     } 
/* 454 */     for (int i = 1; i < tok.ranges.length - 2; i += 2) {
/* 455 */       ret.ranges[wp++] = tok.ranges[i] + 1;
/* 456 */       ret.ranges[wp++] = tok.ranges[i + 1] - 1;
/*     */     } 
/* 458 */     if (last != 1114111) {
/* 459 */       ret.ranges[wp++] = last + 1;
/* 460 */       ret.ranges[wp] = 1114111;
/*     */     } 
/* 462 */     ret.setCompacted();
/* 463 */     return ret;
/*     */   }
/*     */   
/*     */   synchronized RangeToken getCaseInsensitiveToken() {
/* 467 */     if (this.icaseCache != null) {
/* 468 */       return this.icaseCache;
/*     */     }
/*     */     
/* 471 */     RangeToken uppers = (this.type == 4) ? Token.createRange() : Token.createNRange();
/* 472 */     for (int i = 0; i < this.ranges.length; i += 2) {
/* 473 */       for (int ch = this.ranges[i]; ch <= this.ranges[i + 1]; ch++) {
/* 474 */         if (ch > 65535) {
/* 475 */           uppers.addRange(ch, ch);
/*     */         } else {
/* 477 */           char uch = Character.toUpperCase((char)ch);
/* 478 */           uppers.addRange(uch, uch);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 483 */     RangeToken lowers = (this.type == 4) ? Token.createRange() : Token.createNRange();
/* 484 */     for (int j = 0; j < uppers.ranges.length; j += 2) {
/* 485 */       for (int ch = uppers.ranges[j]; ch <= uppers.ranges[j + 1]; ch++) {
/* 486 */         if (ch > 65535) {
/* 487 */           lowers.addRange(ch, ch);
/*     */         } else {
/* 489 */           char uch = Character.toLowerCase((char)ch);
/* 490 */           lowers.addRange(uch, uch);
/*     */         } 
/*     */       } 
/*     */     } 
/* 494 */     lowers.mergeRanges(uppers);
/* 495 */     lowers.mergeRanges(this);
/* 496 */     lowers.compactRanges();
/*     */     
/* 498 */     this.icaseCache = lowers;
/* 499 */     return lowers;
/*     */   }
/*     */   boolean match(int ch) {
/*     */     boolean ret;
/* 503 */     if (this.map == null) {
/* 504 */       createMap();
/*     */     }
/* 506 */     if (this.type == 4) {
/* 507 */       if (ch < 256)
/* 508 */         return ((this.map[ch / 32] & 1 << (ch & 0x1F)) != 0); 
/* 509 */       ret = false;
/* 510 */       for (int i = this.nonMapIndex; i < this.ranges.length; i += 2) {
/* 511 */         if (this.ranges[i] <= ch && ch <= this.ranges[i + 1])
/* 512 */           return true; 
/*     */       } 
/*     */     } else {
/* 515 */       if (ch < 256)
/* 516 */         return ((this.map[ch / 32] & 1 << (ch & 0x1F)) == 0); 
/* 517 */       ret = true;
/* 518 */       for (int i = this.nonMapIndex; i < this.ranges.length; i += 2) {
/* 519 */         if (this.ranges[i] <= ch && ch <= this.ranges[i + 1])
/* 520 */           return false; 
/*     */       } 
/*     */     } 
/* 523 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void createMap() {
/* 529 */     int asize = 8;
/* 530 */     int[] map = new int[asize];
/* 531 */     int nonMapIndex = this.ranges.length; int i;
/* 532 */     for (i = 0; i < asize; i++) {
/* 533 */       map[i] = 0;
/*     */     }
/* 535 */     for (i = 0; i < this.ranges.length; i += 2) {
/* 536 */       int s = this.ranges[i];
/* 537 */       int e = this.ranges[i + 1];
/* 538 */       if (s < 256) {
/* 539 */         for (int j = s; j <= e && j < 256; j++) {
/* 540 */           map[j / 32] = map[j / 32] | 1 << (j & 0x1F);
/*     */         }
/*     */       } else {
/* 543 */         nonMapIndex = i;
/*     */         break;
/*     */       } 
/* 546 */       if (e >= 256) {
/* 547 */         nonMapIndex = i;
/*     */         break;
/*     */       } 
/*     */     } 
/* 551 */     this.map = map;
/* 552 */     this.nonMapIndex = nonMapIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(int options) {
/*     */     String ret;
/* 559 */     if (this.type == 4) {
/* 560 */       if (this == Token.token_dot) {
/* 561 */         ret = ".";
/* 562 */       } else if (this == Token.token_0to9) {
/* 563 */         ret = "\\d";
/* 564 */       } else if (this == Token.token_wordchars) {
/* 565 */         ret = "\\w";
/* 566 */       } else if (this == Token.token_spaces) {
/* 567 */         ret = "\\s";
/*     */       } else {
/* 569 */         StringBuffer sb = new StringBuffer();
/* 570 */         sb.append('[');
/* 571 */         for (int i = 0; i < this.ranges.length; i += 2) {
/* 572 */           if ((options & 0x400) != 0 && i > 0)
/*     */           {
/* 574 */             sb.append(','); } 
/* 575 */           if (this.ranges[i] == this.ranges[i + 1]) {
/* 576 */             sb.append(escapeCharInCharClass(this.ranges[i]));
/*     */           } else {
/* 578 */             sb.append(escapeCharInCharClass(this.ranges[i]));
/* 579 */             sb.append('-');
/* 580 */             sb.append(escapeCharInCharClass(this.ranges[i + 1]));
/*     */           } 
/*     */         } 
/* 583 */         sb.append(']');
/* 584 */         ret = sb.toString();
/*     */       }
/*     */     
/* 587 */     } else if (this == Token.token_not_0to9) {
/* 588 */       ret = "\\D";
/* 589 */     } else if (this == Token.token_not_wordchars) {
/* 590 */       ret = "\\W";
/* 591 */     } else if (this == Token.token_not_spaces) {
/* 592 */       ret = "\\S";
/*     */     } else {
/* 594 */       StringBuffer sb = new StringBuffer();
/* 595 */       sb.append("[^");
/* 596 */       for (int i = 0; i < this.ranges.length; i += 2) {
/* 597 */         if ((options & 0x400) != 0 && i > 0)
/*     */         {
/* 599 */           sb.append(','); } 
/* 600 */         if (this.ranges[i] == this.ranges[i + 1]) {
/* 601 */           sb.append(escapeCharInCharClass(this.ranges[i]));
/*     */         } else {
/* 603 */           sb.append(escapeCharInCharClass(this.ranges[i]));
/* 604 */           sb.append('-');
/* 605 */           sb.append(escapeCharInCharClass(this.ranges[i + 1]));
/*     */         } 
/*     */       } 
/* 608 */       sb.append(']');
/* 609 */       ret = sb.toString();
/*     */     } 
/*     */     
/* 612 */     return ret;
/*     */   }
/*     */   
/*     */   private static String escapeCharInCharClass(int ch) {
/*     */     String ret;
/* 617 */     switch (ch)
/*     */     { case 44:
/*     */       case 45:
/*     */       case 91:
/*     */       case 92:
/*     */       case 93:
/*     */       case 94:
/* 624 */         ret = "\\" + (char)ch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 652 */         return ret;case 12: ret = "\\f"; return ret;case 10: ret = "\\n"; return ret;case 13: ret = "\\r"; return ret;case 9: ret = "\\t"; return ret;case 27: ret = "\\e"; return ret; }  if (ch < 32) { String pre = "0" + Integer.toHexString(ch); ret = "\\x" + pre.substring(pre.length() - 2, pre.length()); } else if (ch >= 65536) { String pre = "0" + Integer.toHexString(ch); ret = "\\v" + pre.substring(pre.length() - 6, pre.length()); } else { ret = "" + (char)ch; }  return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\RangeToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */