/*     */ package com.siemens.ct.exi.grammars.regex;
/*     */ 
/*     */ import java.text.CharacterIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BMPattern
/*     */ {
/*     */   final char[] pattern;
/*     */   final int[] shiftTable;
/*     */   final boolean ignoreCase;
/*     */   
/*     */   public BMPattern(String pat, boolean ignoreCase) {
/*  37 */     this(pat, 256, ignoreCase);
/*     */   }
/*     */   
/*     */   public BMPattern(String pat, int tableSize, boolean ignoreCase) {
/*  41 */     this.pattern = pat.toCharArray();
/*  42 */     this.shiftTable = new int[tableSize];
/*  43 */     this.ignoreCase = ignoreCase;
/*     */     
/*  45 */     int length = this.pattern.length; int i;
/*  46 */     for (i = 0; i < this.shiftTable.length; i++) {
/*  47 */       this.shiftTable[i] = length;
/*     */     }
/*  49 */     for (i = 0; i < length; i++) {
/*  50 */       char ch = this.pattern[i];
/*  51 */       int diff = length - i - 1;
/*  52 */       int index = ch % this.shiftTable.length;
/*  53 */       if (diff < this.shiftTable[index])
/*  54 */         this.shiftTable[index] = diff; 
/*  55 */       if (this.ignoreCase) {
/*  56 */         ch = Character.toUpperCase(ch);
/*  57 */         index = ch % this.shiftTable.length;
/*  58 */         if (diff < this.shiftTable[index])
/*  59 */           this.shiftTable[index] = diff; 
/*  60 */         ch = Character.toLowerCase(ch);
/*  61 */         index = ch % this.shiftTable.length;
/*  62 */         if (diff < this.shiftTable[index]) {
/*  63 */           this.shiftTable[index] = diff;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int matches(CharacterIterator iterator, int start, int limit) {
/*  73 */     if (this.ignoreCase)
/*  74 */       return matchesIgnoreCase(iterator, start, limit); 
/*  75 */     int plength = this.pattern.length;
/*  76 */     if (plength == 0)
/*  77 */       return start; 
/*  78 */     int index = start + plength;
/*  79 */     while (index <= limit) {
/*  80 */       int pindex = plength;
/*  81 */       int nindex = index + 1;
/*     */       
/*     */       char ch;
/*  84 */       while ((ch = iterator.setIndex(--index)) == this.pattern[--pindex])
/*     */       
/*  86 */       { if (pindex == 0)
/*  87 */           return index; 
/*  88 */         if (pindex <= 0)
/*  89 */           break;  }  index += this.shiftTable[ch % this.shiftTable.length] + 1;
/*  90 */       if (index < nindex)
/*  91 */         index = nindex; 
/*     */     } 
/*  93 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int matches(String str, int start, int limit) {
/* 101 */     if (this.ignoreCase)
/* 102 */       return matchesIgnoreCase(str, start, limit); 
/* 103 */     int plength = this.pattern.length;
/* 104 */     if (plength == 0)
/* 105 */       return start; 
/* 106 */     int index = start + plength;
/* 107 */     while (index <= limit) {
/*     */       
/* 109 */       int pindex = plength;
/* 110 */       int nindex = index + 1;
/*     */       
/*     */       char ch;
/* 113 */       while ((ch = str.charAt(--index)) == this.pattern[--pindex])
/*     */       
/* 115 */       { if (pindex == 0)
/* 116 */           return index; 
/* 117 */         if (pindex <= 0)
/* 118 */           break;  }  index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 119 */       if (index < nindex)
/* 120 */         index = nindex; 
/*     */     } 
/* 122 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int matches(char[] chars, int start, int limit) {
/* 130 */     if (this.ignoreCase)
/* 131 */       return matchesIgnoreCase(chars, start, limit); 
/* 132 */     int plength = this.pattern.length;
/* 133 */     if (plength == 0)
/* 134 */       return start; 
/* 135 */     int index = start + plength;
/* 136 */     while (index <= limit) {
/*     */       
/* 138 */       int pindex = plength;
/* 139 */       int nindex = index + 1;
/*     */       
/*     */       char ch;
/* 142 */       while ((ch = chars[--index]) == this.pattern[--pindex])
/*     */       
/* 144 */       { if (pindex == 0)
/* 145 */           return index; 
/* 146 */         if (pindex <= 0)
/* 147 */           break;  }  index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 148 */       if (index < nindex)
/* 149 */         index = nindex; 
/*     */     } 
/* 151 */     return -1;
/*     */   }
/*     */   
/*     */   int matchesIgnoreCase(CharacterIterator iterator, int start, int limit) {
/* 155 */     int plength = this.pattern.length;
/* 156 */     if (plength == 0)
/* 157 */       return start; 
/* 158 */     int index = start + plength;
/* 159 */     while (index <= limit) {
/* 160 */       char ch; int pindex = plength;
/* 161 */       int nindex = index + 1;
/*     */       
/*     */       do {
/* 164 */         char ch1 = ch = iterator.setIndex(--index);
/* 165 */         char ch2 = this.pattern[--pindex];
/* 166 */         if (ch1 != ch2) {
/* 167 */           ch1 = Character.toUpperCase(ch1);
/* 168 */           ch2 = Character.toUpperCase(ch2);
/* 169 */           if (ch1 != ch2 && 
/* 170 */             Character.toLowerCase(ch1) != 
/* 171 */             Character.toLowerCase(ch2))
/*     */             break; 
/*     */         } 
/* 174 */         if (pindex == 0)
/* 175 */           return index; 
/* 176 */       } while (pindex > 0);
/* 177 */       index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 178 */       if (index < nindex)
/* 179 */         index = nindex; 
/*     */     } 
/* 181 */     return -1;
/*     */   }
/*     */   
/*     */   int matchesIgnoreCase(String text, int start, int limit) {
/* 185 */     int plength = this.pattern.length;
/* 186 */     if (plength == 0)
/* 187 */       return start; 
/* 188 */     int index = start + plength;
/* 189 */     while (index <= limit) {
/* 190 */       char ch; int pindex = plength;
/* 191 */       int nindex = index + 1;
/*     */       
/*     */       do {
/* 194 */         char ch1 = ch = text.charAt(--index);
/* 195 */         char ch2 = this.pattern[--pindex];
/* 196 */         if (ch1 != ch2) {
/* 197 */           ch1 = Character.toUpperCase(ch1);
/* 198 */           ch2 = Character.toUpperCase(ch2);
/* 199 */           if (ch1 != ch2 && 
/* 200 */             Character.toLowerCase(ch1) != 
/* 201 */             Character.toLowerCase(ch2))
/*     */             break; 
/*     */         } 
/* 204 */         if (pindex == 0)
/* 205 */           return index; 
/* 206 */       } while (pindex > 0);
/* 207 */       index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 208 */       if (index < nindex)
/* 209 */         index = nindex; 
/*     */     } 
/* 211 */     return -1;
/*     */   }
/*     */   
/*     */   int matchesIgnoreCase(char[] chars, int start, int limit) {
/* 215 */     int plength = this.pattern.length;
/* 216 */     if (plength == 0)
/* 217 */       return start; 
/* 218 */     int index = start + plength;
/* 219 */     while (index <= limit) {
/* 220 */       char ch; int pindex = plength;
/* 221 */       int nindex = index + 1;
/*     */       
/*     */       do {
/* 224 */         char ch1 = ch = chars[--index];
/* 225 */         char ch2 = this.pattern[--pindex];
/* 226 */         if (ch1 != ch2) {
/* 227 */           ch1 = Character.toUpperCase(ch1);
/* 228 */           ch2 = Character.toUpperCase(ch2);
/* 229 */           if (ch1 != ch2 && 
/* 230 */             Character.toLowerCase(ch1) != 
/* 231 */             Character.toLowerCase(ch2))
/*     */             break; 
/*     */         } 
/* 234 */         if (pindex == 0)
/* 235 */           return index; 
/* 236 */       } while (pindex > 0);
/* 237 */       index += this.shiftTable[ch % this.shiftTable.length] + 1;
/* 238 */       if (index < nindex)
/* 239 */         index = nindex; 
/*     */     } 
/* 241 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\BMPattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */