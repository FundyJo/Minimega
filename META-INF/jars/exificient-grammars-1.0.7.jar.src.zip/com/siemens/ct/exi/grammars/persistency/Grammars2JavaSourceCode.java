/*     */ package com.siemens.ct.exi.grammars.persistency;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.GrammarContext;
/*     */ import com.siemens.ct.exi.core.context.GrammarUriContext;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.DatetimeDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.EnumerationDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.ListDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.NBitUnsignedIntegerDatatype;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.Grammars;
/*     */ import com.siemens.ct.exi.core.grammars.SchemaInformedGrammars;
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.AttributeGeneric;
/*     */ import com.siemens.ct.exi.core.grammars.event.Characters;
/*     */ import com.siemens.ct.exi.core.grammars.event.CharactersGeneric;
/*     */ import com.siemens.ct.exi.core.grammars.event.EndDocument;
/*     */ import com.siemens.ct.exi.core.grammars.event.EndElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartDocument;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElementGeneric;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElementNS;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.GrammarType;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTag;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedStartTag;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import com.siemens.ct.exi.core.types.BuiltIn;
/*     */ import com.siemens.ct.exi.core.types.BuiltInType;
/*     */ import com.siemens.ct.exi.core.values.IntegerValue;
/*     */ import com.siemens.ct.exi.core.values.IntegerValueType;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import com.siemens.ct.exi.grammars.XSDGrammarsBuilder;
/*     */ import com.siemens.ct.exi.grammars.util.PrintfUtils;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringWriter;
/*     */ import java.math.BigInteger;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class Grammars2JavaSourceCode
/*     */ {
/*  53 */   private static final Logger LOGGER = LoggerFactory.getLogger(Grammars2JavaSourceCode.class);
/*     */   
/*     */   protected static final String TOKEN_GRAMMAR_CONTEXT_BEGIN = "/* BEGIN GrammarContext ----- */";
/*     */   
/*     */   protected static final String TOKEN_GRAMMAR_CONTEXT_END = "/* END GrammarContext ----- */";
/*     */   
/*     */   protected static final String TOKEN_GRAMMARS_BEGIN = "/* BEGIN Grammars ----- */";
/*     */   
/*     */   protected static final String TOKEN_GRAMMARS_END = "/* END Grammars ----- */";
/*     */   
/*     */   protected static final String TOKEN_GRAMMARS_WITH_ELEMENT_CONTENT_BEGIN = "/* BEGIN Grammars with element content ----- */";
/*     */   
/*     */   protected static final String TOKEN_GRAMMARS_WITH_ELEMENT_CONTENT_END = "/* END Grammars with element content ----- */";
/*     */   
/*     */   protected static final String TOKEN_GRAMMAR_EVENTS_BEGIN = "/* BEGIN Grammar Events ----- */";
/*     */   
/*     */   protected static final String TOKEN_GRAMMAR_EVENTS_END = "/* END Grammar Events ----- */";
/*     */   
/*     */   protected static final String TOKEN_GLOBALS_BEGIN = "/* BEGIN Globals ----- */";
/*     */   
/*     */   protected static final String TOKEN_GLOBALS_END = "/* END Globals ----- */";
/*     */   
/*     */   protected static final String TOKEN_SCHEMA_ID_BEGIN = "/* BEGIN SchemaId ----- */";
/*     */   
/*     */   protected static final String TOKEN_SCHEMA_ID_END = "/* END SchemaId ----- */";
/*     */   
/*     */   protected static final String TOKEN_GLOBAL_ELEMENTS_BEGIN = "/* BEGIN GlobalElements ----- */";
/*     */   
/*     */   protected static final String TOKEN_GLOBAL_ELEMENTS_END = "/* END GlobalElements ----- */";
/*     */   
/*     */   protected static final String TOKEN_GLOBAL_ATTRIBUTES_BEGIN = "/* BEGIN GlobalAttributes ----- */";
/*     */   protected static final String TOKEN_GLOBAL_ATTRIBUTES_END = "/* END GlobalAttributes ----- */";
/*     */   protected static final String TOKEN_TYPE_GRAMMAR_BEGIN = "/* BEGIN TypeGrammar ----- */";
/*     */   protected static final String TOKEN_TYPE_GRAMMAR_END = "/* END TypeGrammar ----- */";
/*     */   protected static final String TOKEN_FIRST_STARTTAG_GRAMMAR_BEGIN = "/* BEGIN FirstStartGrammar ----- */";
/*     */   protected static final String TOKEN_FIRST_STARTTAG_GRAMMAR_END = "/* END FirstStartGrammar ----- */";
/*     */   protected static final String TOKEN_DOCUMENT_GRAMMAR_BEGIN = "/* BEGIN Document Grammar ----- */";
/*     */   protected static final String TOKEN_DOCUMENT_GRAMMAR_END = "/* END Document Grammar ----- */";
/*     */   protected static final String TOKEN_FRAGMENT_GRAMMAR_BEGIN = "/* BEGIN Fragment Grammar ----- */";
/*     */   protected static final String TOKEN_FRAGMENT_GRAMMAR_END = "/* END Fragment Grammar ----- */";
/*     */   protected static final String TOKEN_SCHEMA_INFORMED_GRAMMARS_BEGIN = "/* BEGIN SchemaInformedGrammars ----- */";
/*     */   protected static final String TOKEN_SCHEMA_INFORMED_GRAMMARS_END = "/* END SchemaInformedGrammars ----- */";
/*  95 */   protected static final String TOKEN_PACKAGE = Grammars2JavaSourceCode.class
/*  96 */     .getPackage().toString();
/*     */   
/*     */   protected static final String TOKEN_CLASS_SUFFIX = "Template";
/*  99 */   protected static final String TOKEN_CLASS = "public class " + Grammars2JavaSourceCode.class
/* 100 */     .getSimpleName() + "Template";
/*     */   
/* 102 */   protected static final String TOKEN_CLASS_CONSTRUCTOR = "public " + Grammars2JavaSourceCode.class
/* 103 */     .getSimpleName() + "Template";
/*     */ 
/*     */   
/*     */   static final String STATIC_SAMPLE_GRAMMAR = "com/siemens/ct/exi/grammars/persistency/Grammars2JavaSourceCodeTemplate.java";
/*     */   
/* 108 */   GrammarsPreperation gpreps = new GrammarsPreperation();
/*     */   
/*     */   StringWriter swGC;
/*     */   
/*     */   StringWriter swGlobals;
/*     */   
/*     */   StringWriter swGlobalElements;
/*     */   
/*     */   StringWriter swGlobalAttributes;
/*     */   
/*     */   StringWriter swTypeGrammar;
/*     */   StringWriter swFirstStartGrammar;
/*     */   StringWriter swGrammars;
/*     */   StringWriter swGrammarsWithElementContent;
/*     */   StringWriter swEvents;
/*     */   int documentGrammarID;
/*     */   int fragmentGrammarID;
/*     */   String schemaId;
/*     */   SchemaInformedGrammars grammars;
/*     */   
/*     */   public Grammars2JavaSourceCode(SchemaInformedGrammars grammars) {
/* 129 */     this.grammars = grammars;
/*     */   }
/*     */   
/*     */   public void setSchemaId(String schemaId) {
/* 133 */     this.schemaId = schemaId;
/*     */   }
/*     */   
/*     */   protected int getQNameID(QNameContext qnc) {
/* 137 */     GrammarContext gc = this.grammars.getGrammarContext();
/*     */     
/* 139 */     int qnameID = 0;
/*     */     
/* 141 */     for (int i = 0; i < gc.getNumberOfGrammarUriContexts(); i++) {
/* 142 */       GrammarUriContext guc = gc.getGrammarUriContext(i);
/* 143 */       for (int k = 0; k < guc.getNumberOfQNames(); k++) {
/* 144 */         QNameContext qnX = guc.getQNameContext(k);
/*     */         
/* 146 */         if (qnc.equals(qnX)) {
/* 147 */           return qnameID;
/*     */         }
/*     */         
/* 150 */         qnameID++;
/*     */       } 
/*     */     } 
/*     */     
/* 154 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode() throws IOException {
/* 162 */     this.gpreps.prepareGrammars((Grammars)this.grammars);
/*     */     
/* 164 */     this.documentGrammarID = -1;
/* 165 */     this.fragmentGrammarID = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     this.swGlobals = new StringWriter();
/* 171 */     this.swGlobalElements = new StringWriter();
/* 172 */     this.swGlobalAttributes = new StringWriter();
/* 173 */     this.swTypeGrammar = new StringWriter();
/* 174 */     this.swFirstStartGrammar = new StringWriter();
/*     */     
/* 176 */     PrintfUtils.printfIndLn(this.swGlobalElements, 1, "%s", new Object[] { "/* BEGIN GlobalElements ----- */" });
/*     */     
/* 178 */     PrintfUtils.printfIndLn(this.swGlobalAttributes, 1, "%s", new Object[] { "/* BEGIN GlobalAttributes ----- */" });
/*     */     
/* 180 */     PrintfUtils.printfIndLn(this.swTypeGrammar, 1, "%s", new Object[] { "/* BEGIN TypeGrammar ----- */" });
/*     */     
/* 182 */     PrintfUtils.printfIndLn(this.swFirstStartGrammar, 1, "%s", new Object[] { "/* BEGIN FirstStartGrammar ----- */" });
/*     */ 
/*     */     
/* 185 */     this.swGC = new StringWriter();
/*     */     
/* 187 */     PrintfUtils.printfIndLn(this.swGC, 1, "%s", new Object[] { "/* BEGIN GrammarContext ----- */" });
/*     */     
/* 189 */     GrammarContext gc = this.grammars.getGrammarContext();
/*     */     
/* 191 */     StringBuilder sbUriContexts = new StringBuilder();
/*     */     
/* 193 */     int qnameID = 0;
/*     */     int i;
/* 195 */     for (i = 0; i < gc.getNumberOfGrammarUriContexts(); i++) {
/* 196 */       GrammarUriContext guc = gc.getGrammarUriContext(i);
/*     */       
/* 198 */       PrintfUtils.printfIndLn(this.swGC, 1, "final String ns%d = \"%s\";", new Object[] { Integer.valueOf(i), guc
/* 199 */             .getNamespaceUri() });
/*     */       
/* 201 */       StringBuilder sbQnames = new StringBuilder();
/*     */       
/* 203 */       for (int k = 0; k < guc.getNumberOfQNames(); k++) {
/* 204 */         QNameContext qnc = guc.getQNameContext(k);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 209 */         PrintfUtils.printfIndLn(this.swGC, 1, "final QNameContext qnc%d = new QNameContext(%d, %d, new QName(ns%d, \"%s\"));", new Object[] {
/*     */ 
/*     */ 
/*     */               
/* 213 */               Integer.valueOf(qnameID), Integer.valueOf(qnc.getNamespaceUriID()), 
/* 214 */               Integer.valueOf(qnc.getLocalNameID()), Integer.valueOf(i), qnc.getLocalName() });
/* 215 */         sbQnames.append("qnc");
/* 216 */         sbQnames.append(qnameID);
/* 217 */         if (k != guc.getNumberOfQNames() - 1) {
/* 218 */           sbQnames.append(", ");
/*     */         }
/*     */         
/* 221 */         assert qnameID == getQNameID(qnc);
/*     */ 
/*     */         
/* 224 */         if (qnc.getGlobalStartElement() != null) {
/* 225 */           StartElement g = qnc.getGlobalStartElement();
/* 226 */           int globalIdID = this.gpreps.getGrammarID(g.getGrammar());
/* 227 */           PrintfUtils.printfIndLn(this.swGlobals, 1, StartElement.class
/* 228 */               .getName() + " globalSE%d = new " + StartElement.class
/* 229 */               .getName() + "(qnc" + qnameID + ", g" + globalIdID + ");", new Object[] {
/*     */                 
/* 231 */                 Integer.valueOf(qnameID) });
/* 232 */           PrintfUtils.printfIndLn(this.swGlobalElements, 1, "qnc%d.setGlobalStartElement(globalSE%d);", new Object[] {
/*     */                 
/* 234 */                 Integer.valueOf(qnameID), Integer.valueOf(qnameID)
/*     */               });
/*     */         } 
/*     */         
/* 238 */         if (qnc.getGlobalAttribute() != null) {
/* 239 */           Attribute a = qnc.getGlobalAttribute();
/* 240 */           PrintfUtils.printfIndLn(this.swGlobals, 1, Attribute.class
/*     */ 
/*     */               
/* 243 */               .getName() + " globalAT%d = new " + Attribute.class
/* 244 */               .getName() + "(qnc" + qnameID + ", " + 
/*     */               
/* 246 */               getDatatypeConstructor(a.getDatatype()) + ");", new Object[] {
/* 247 */                 Integer.valueOf(qnameID) });
/* 248 */           PrintfUtils.printfIndLn(this.swGlobalAttributes, 1, "qnc%d.setGlobalAttribute(globalAT%d);", new Object[] {
/* 249 */                 Integer.valueOf(qnameID), 
/* 250 */                 Integer.valueOf(qnameID)
/*     */               });
/*     */         } 
/*     */         
/* 254 */         if (qnc.getTypeGrammar() != null) {
/*     */           
/* 256 */           SchemaInformedFirstStartTagGrammar sifstg = qnc.getTypeGrammar();
/* 257 */           int grID = this.gpreps.getGrammarID((Grammar)sifstg);
/* 258 */           PrintfUtils.printfIndLn(this.swTypeGrammar, 1, "qnc%d.setTypeGrammar(g%d);", new Object[] {
/* 259 */                 Integer.valueOf(qnameID), Integer.valueOf(grID)
/*     */               });
/*     */         } 
/* 262 */         qnameID++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 267 */       PrintfUtils.printfIndLn(this.swGC, 1, "final QNameContext[] grammarQNames%d = {%s};", new Object[] {
/* 268 */             Integer.valueOf(i), sbQnames
/*     */           });
/*     */ 
/*     */       
/* 272 */       StringBuilder sbPrefixes = new StringBuilder();
/* 273 */       for (int j = 0; j < guc.getNumberOfPrefixes(); j++) {
/* 274 */         sbPrefixes.append("\"");
/* 275 */         sbPrefixes.append(guc.getPrefix(j));
/* 276 */         sbPrefixes.append("\"");
/* 277 */         if (j != guc.getNumberOfPrefixes() - 1) {
/* 278 */           sbPrefixes.append(", ");
/*     */         }
/*     */       } 
/* 281 */       PrintfUtils.printfIndLn(this.swGC, 1, "final String[] grammarPrefixes%d = {%s};", new Object[] {
/* 282 */             Integer.valueOf(i), sbPrefixes
/*     */           });
/*     */ 
/*     */ 
/*     */       
/* 287 */       PrintfUtils.printfIndLn(this.swGC, 1, "final GrammarUriContext guc%d = new GrammarUriContext(%d, ns%d, grammarQNames%d, grammarPrefixes%d);", new Object[] {
/*     */ 
/*     */ 
/*     */             
/* 291 */             Integer.valueOf(i), Integer.valueOf(i), Integer.valueOf(i), Integer.valueOf(i), Integer.valueOf(i)
/*     */           });
/* 293 */       sbUriContexts.append("guc");
/* 294 */       sbUriContexts.append(i);
/* 295 */       if (i != gc.getNumberOfGrammarUriContexts() - 1) {
/* 296 */         sbUriContexts.append(", ");
/*     */       }
/*     */       
/* 299 */       PrintfUtils.printfIndLn(this.swGC, 1, "", new Object[0]);
/*     */     } 
/*     */ 
/*     */     
/* 303 */     PrintfUtils.printfIndLn(this.swGC, 1, "final GrammarUriContext[] grammarUriContexts = {%s};", new Object[] { sbUriContexts });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     PrintfUtils.printfIndLn(this.swGC, 1, "final GrammarContext gc = new GrammarContext(grammarUriContexts, %d);", new Object[] {
/*     */ 
/*     */ 
/*     */           
/* 313 */           Integer.valueOf(gc.getNumberOfGrammarQNameContexts())
/*     */         });
/* 315 */     PrintfUtils.printfIndLn(this.swGC, 1, "%s", new Object[] { "/* END GrammarContext ----- */" });
/* 316 */     PrintfUtils.printfIndLn(this.swGlobalElements, 1, "%s", new Object[] { "/* END GlobalElements ----- */" });
/*     */     
/* 318 */     PrintfUtils.printfIndLn(this.swGlobalAttributes, 1, "%s", new Object[] { "/* END GlobalAttributes ----- */" });
/*     */     
/* 320 */     PrintfUtils.printfIndLn(this.swTypeGrammar, 1, "%s", new Object[] { "/* END TypeGrammar ----- */" });
/*     */     
/* 322 */     this.swGrammars = new StringWriter();
/* 323 */     this.swGrammarsWithElementContent = new StringWriter();
/* 324 */     this.swEvents = new StringWriter();
/*     */     
/* 326 */     PrintfUtils.printfIndLn(this.swGrammars, 1, "%s", new Object[] { "/* BEGIN Grammars ----- */" });
/* 327 */     PrintfUtils.printfIndLn(this.swGrammarsWithElementContent, 1, "%s", new Object[] { "/* BEGIN Grammars with element content ----- */" });
/*     */     
/* 329 */     PrintfUtils.printfIndLn(this.swEvents, 1, "%s", new Object[] { "/* BEGIN Grammar Events ----- */" });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 334 */     for (i = 0; i < this.gpreps.getNumberOfGrammars(); i++) {
/*     */       SchemaInformedFirstStartTag sifst; SchemaInformedStartTag sist;
/*     */       Grammar elementContentGrammar;
/*     */       int elementContentGrammarID;
/* 338 */       Grammar r = this.gpreps.getGrammar(i);
/*     */       
/* 340 */       int currentID = this.gpreps.getGrammarID(r);
/* 341 */       int numberOfEvents = r.getNumberOfEvents();
/*     */       
/* 343 */       String sConstructor = "null";
/*     */       
/* 345 */       switch (r.getGrammarType()) {
/*     */         
/*     */         case INT:
/* 348 */           this.documentGrammarID = currentID;
/* 349 */           PrintfUtils.printfIndLn(this.swGrammars, 1, "%s g%d = new %s();", new Object[] { r
/* 350 */                 .getClass().getName(), Integer.valueOf(currentID), r.getClass()
/* 351 */                 .getName() });
/*     */           break;
/*     */         case LONG:
/* 354 */           this.fragmentGrammarID = currentID;
/* 355 */           PrintfUtils.printfIndLn(this.swGrammars, 1, "%s g%d = new %s();", new Object[] { r
/* 356 */                 .getClass().getName(), Integer.valueOf(currentID), r.getClass()
/* 357 */                 .getName() });
/*     */           break;
/*     */         
/*     */         case BIG:
/*     */         case null:
/*     */         case null:
/*     */         case null:
/* 364 */           PrintfUtils.printfIndLn(this.swGrammars, 1, "%s g%d = new %s();", new Object[] { r
/* 365 */                 .getClass().getName(), Integer.valueOf(currentID), r.getClass()
/* 366 */                 .getName() });
/*     */           break;
/*     */         
/*     */         case null:
/* 370 */           sifst = (SchemaInformedFirstStartTag)r;
/*     */           
/* 372 */           elementContentGrammar = sifst.getElementContentGrammar();
/*     */           
/* 374 */           elementContentGrammarID = this.gpreps.getGrammarID(elementContentGrammar);
/* 375 */           PrintfUtils.printfIndLn(this.swGrammarsWithElementContent, 1, "%s g%d = new %s(g%d);", new Object[] { r
/* 376 */                 .getClass().getName(), 
/* 377 */                 Integer.valueOf(currentID), r.getClass().getName(), 
/* 378 */                 Integer.valueOf(elementContentGrammarID) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 384 */           PrintfUtils.printfIndLn(this.swFirstStartGrammar, 1, "g%d.setElementContentGrammar(%s);", new Object[] {
/*     */ 
/*     */ 
/*     */                 
/* 388 */                 Integer.valueOf(currentID), "g" + this.gpreps
/*     */                 
/* 390 */                 .getGrammarID(sifst
/* 391 */                   .getElementContentGrammar()) });
/* 392 */           if (sifst.isTypeCastable())
/* 393 */             PrintfUtils.printfIndLn(this.swFirstStartGrammar, 1, "g%d.setTypeCastable(%s);", new Object[] {
/* 394 */                   Integer.valueOf(currentID), 
/* 395 */                   Boolean.valueOf(sifst.isTypeCastable())
/*     */                 }); 
/* 397 */           if (sifst.isNillable()) {
/* 398 */             PrintfUtils.printfIndLn(this.swFirstStartGrammar, 1, "g%d.setNillable(%s);", new Object[] {
/* 399 */                   Integer.valueOf(currentID), 
/* 400 */                   Boolean.valueOf(sifst.isNillable())
/*     */                 });
/*     */           }
/*     */           break;
/*     */         case null:
/* 405 */           sist = (SchemaInformedStartTag)r;
/* 406 */           elementContentGrammar = sist.getElementContentGrammar();
/* 407 */           if (elementContentGrammar instanceof SchemaInformedStartTag) {
/* 408 */             LOGGER.error("Error for {} and {}", sist, elementContentGrammar);
/*     */           }
/*     */           
/* 411 */           elementContentGrammarID = this.gpreps.getGrammarID(elementContentGrammar);
/* 412 */           PrintfUtils.printfIndLn(this.swGrammarsWithElementContent, 1, "%s g%d = new %s(g%d);", new Object[] { r
/* 413 */                 .getClass().getName(), 
/* 414 */                 Integer.valueOf(currentID), r.getClass().getName(), 
/* 415 */                 Integer.valueOf(elementContentGrammarID) });
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case null:
/*     */         case null:
/*     */         case null:
/*     */         case null:
/* 424 */           throw new RuntimeException("Unsupported GrammarType " + r
/* 425 */               .getGrammarType());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 432 */       for (int eventCode = 0; eventCode < numberOfEvents; eventCode++) {
/* 433 */         StartElement se; StartElementNS seNS; StartElementGeneric seGen; Characters ch; Attribute at; Production ei = r.getProduction(eventCode);
/* 434 */         int nextID = this.gpreps.getGrammarID(ei.getNextGrammar());
/*     */         
/* 436 */         switch (ei.getEvent().getEventType()) {
/*     */           
/*     */           case INT:
/* 439 */             sConstructor = "new " + StartDocument.class.getName() + "()";
/*     */             break;
/*     */           
/*     */           case LONG:
/* 443 */             sConstructor = "new " + EndDocument.class.getName() + "()";
/*     */             break;
/*     */           case BIG:
/* 446 */             se = (StartElement)ei.getEvent();
/* 447 */             if (se.getQNameContext().getGlobalStartElement() == se) {
/*     */               
/* 449 */               sConstructor = "globalSE" + getQNameID(se.getQNameContext());
/*     */               
/*     */               break;
/*     */             } 
/* 453 */             sConstructor = "new " + StartElement.class.getName() + "(qnc" + getQNameID(se.getQNameContext()) + ", g" + this.gpreps.getGrammarID(se.getGrammar()) + ")";
/*     */             break;
/*     */ 
/*     */           
/*     */           case null:
/* 458 */             seNS = (StartElementNS)ei.getEvent();
/*     */ 
/*     */             
/* 461 */             sConstructor = "new " + StartElementNS.class.getName() + "(" + seNS.getNamespaceUriID() + ", \"" + seNS.getNamespaceURI() + "\")";
/*     */             break;
/*     */ 
/*     */           
/*     */           case null:
/* 466 */             seGen = (StartElementGeneric)ei.getEvent();
/* 467 */             sConstructor = "new " + StartElementGeneric.class.getName() + "()";
/*     */             break;
/*     */           
/*     */           case null:
/* 471 */             sConstructor = "new " + EndElement.class.getName() + "()";
/*     */             break;
/*     */           case null:
/* 474 */             ch = (Characters)ei.getEvent();
/*     */             
/* 476 */             sConstructor = "new " + Characters.class.getName() + "(" + getDatatypeConstructor(ch.getDatatype()) + ")";
/*     */             break;
/*     */ 
/*     */           
/*     */           case null:
/* 481 */             sConstructor = "new " + CharactersGeneric.class.getName() + "()";
/*     */             break;
/*     */           
/*     */           case null:
/* 485 */             at = (Attribute)ei.getEvent();
/*     */             
/* 487 */             if (at.getQNameContext().getGlobalAttribute() == at) {
/*     */               
/* 489 */               sConstructor = "globalAT" + getQNameID(at.getQNameContext());
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/* 494 */             sConstructor = "new " + Attribute.class.getName() + "(qnc" + getQNameID(at.getQNameContext()) + ", " + getDatatypeConstructor(at.getDatatype()) + ")";
/*     */             break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case null:
/* 503 */             sConstructor = "new " + AttributeGeneric.class.getName() + "()";
/*     */             break;
/*     */           
/*     */           default:
/* 507 */             throw new RuntimeException("Unsupported Event = " + ei
/* 508 */                 .getEvent());
/*     */         } 
/*     */         
/* 511 */         PrintfUtils.printfIndLn(this.swEvents, 1, "g%d.addProduction(%s, g%d);", new Object[] {
/* 512 */               Integer.valueOf(currentID), sConstructor, 
/* 513 */               Integer.valueOf(nextID)
/*     */             });
/*     */       } 
/*     */     } 
/* 517 */     PrintfUtils.printfIndLn(this.swEvents, 1, "%s", new Object[] { "/* END Grammar Events ----- */" });
/* 518 */     PrintfUtils.printfIndLn(this.swGrammars, 1, "%s", new Object[] { "/* END Grammars ----- */" });
/* 519 */     PrintfUtils.printfIndLn(this.swFirstStartGrammar, 1, "%s", new Object[] { "/* END FirstStartGrammar ----- */" });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String readFileToString(File file) throws IOException {
/* 525 */     BufferedReader reader = new BufferedReader(new FileReader(file));
/* 526 */     StringWriter sFile = new StringWriter();
/*     */     
/*     */     int c;
/* 529 */     while ((c = reader.read()) != -1) {
/* 530 */       sFile.append((char)c);
/*     */     }
/* 532 */     reader.close();
/*     */     
/* 534 */     return sFile.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getGrammars(String packageName, String className) throws IOException {
/* 541 */     packageName = packageName.trim();
/* 542 */     if (packageName.length() > 0 && !packageName.startsWith("package ")) {
/* 543 */       packageName = "package " + packageName;
/*     */     }
/*     */ 
/*     */     
/* 547 */     ClassLoader classLoader = getClass().getClassLoader();
/*     */     
/* 549 */     InputStream inputStream = classLoader.getResource("com/siemens/ct/exi/grammars/persistency/Grammars2JavaSourceCodeTemplate.java").openStream();
/*     */     
/* 551 */     BufferedInputStream bis = new BufferedInputStream(inputStream);
/* 552 */     ByteArrayOutputStream buf = new ByteArrayOutputStream();
/* 553 */     int result = bis.read();
/* 554 */     while (result != -1) {
/* 555 */       buf.write((byte)result);
/* 556 */       result = bis.read();
/*     */     } 
/*     */ 
/*     */     
/* 560 */     StringBuilder sStaticSimpleGrammar = new StringBuilder(buf.toString("UTF-8"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 571 */     replace(sStaticSimpleGrammar, "/* BEGIN GrammarContext ----- */", "/* END GrammarContext ----- */", this.swGC
/* 572 */         .toString());
/*     */     
/* 574 */     replace(sStaticSimpleGrammar, "/* BEGIN Grammars ----- */", "/* END Grammars ----- */", this.swGrammars
/* 575 */         .toString());
/*     */     
/* 577 */     replace(sStaticSimpleGrammar, "/* BEGIN Grammars with element content ----- */", "/* END Grammars with element content ----- */", this.swGrammarsWithElementContent
/*     */ 
/*     */         
/* 580 */         .toString());
/*     */     
/* 582 */     replace(sStaticSimpleGrammar, "/* BEGIN Globals ----- */", "/* END Globals ----- */", this.swGlobals
/* 583 */         .toString());
/*     */     
/* 585 */     if (this.schemaId != null) {
/* 586 */       replace(sStaticSimpleGrammar, "/* BEGIN SchemaId ----- */", "/* END SchemaId ----- */", "protected String schemaId = \"" + this.schemaId + "\";");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 591 */     replace(sStaticSimpleGrammar, "/* BEGIN GlobalElements ----- */", "/* END GlobalElements ----- */", this.swGlobalElements
/* 592 */         .toString());
/*     */     
/* 594 */     replace(sStaticSimpleGrammar, "/* BEGIN GlobalAttributes ----- */", "/* END GlobalAttributes ----- */", this.swGlobalAttributes
/* 595 */         .toString());
/*     */     
/* 597 */     replace(sStaticSimpleGrammar, "/* BEGIN TypeGrammar ----- */", "/* END TypeGrammar ----- */", this.swTypeGrammar
/* 598 */         .toString());
/*     */     
/* 600 */     replace(sStaticSimpleGrammar, "/* BEGIN Grammar Events ----- */", "/* END Grammar Events ----- */", this.swEvents
/* 601 */         .toString());
/*     */     
/* 603 */     replace(sStaticSimpleGrammar, "/* BEGIN FirstStartGrammar ----- */", "/* END FirstStartGrammar ----- */", this.swFirstStartGrammar
/*     */         
/* 605 */         .toString());
/*     */     
/* 607 */     assert this.documentGrammarID != -1;
/* 608 */     replace(sStaticSimpleGrammar, "/* BEGIN Document Grammar ----- */", "/* END Document Grammar ----- */", "return g" + this.documentGrammarID + ";");
/*     */ 
/*     */ 
/*     */     
/* 612 */     assert this.fragmentGrammarID != -1;
/* 613 */     replace(sStaticSimpleGrammar, "/* BEGIN Fragment Grammar ----- */", "/* END Fragment Grammar ----- */", "return g" + this.fragmentGrammarID + ";");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 620 */     replace(sStaticSimpleGrammar, TOKEN_PACKAGE, TOKEN_PACKAGE, packageName);
/*     */ 
/*     */ 
/*     */     
/* 624 */     replace(sStaticSimpleGrammar, TOKEN_CLASS, TOKEN_CLASS, "public class " + className);
/*     */     
/* 626 */     replace(sStaticSimpleGrammar, TOKEN_CLASS_CONSTRUCTOR, TOKEN_CLASS_CONSTRUCTOR, "public " + className);
/*     */ 
/*     */     
/* 629 */     int siefGrammarID = this.gpreps.getGrammarID((Grammar)this.grammars
/* 630 */         .getSchemaInformedElementFragmentGrammar());
/* 631 */     replace(sStaticSimpleGrammar, "/* BEGIN SchemaInformedGrammars ----- */", "/* END SchemaInformedGrammars ----- */", "SchemaInformedGrammars grammars = new SchemaInformedGrammars(gc, g" + this.documentGrammarID + ", g" + this.fragmentGrammarID + ", g" + siefGrammarID + ");");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 638 */     return sStaticSimpleGrammar.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   void replace(StringBuilder sb, String tokenBegin, String tokenEnd, String newToken) {
/* 643 */     int ib = sb.indexOf(tokenBegin);
/* 644 */     int iE = sb.indexOf(tokenEnd);
/* 645 */     if (ib == -1 || iE == -1 || ib > iE) {
/* 646 */       throw new RuntimeException("Could not find the token BEGIN/END");
/*     */     }
/* 648 */     iE += tokenEnd.length();
/* 649 */     sb.replace(ib, iE, newToken);
/*     */   }
/*     */   
/*     */   private String getDatatypeConstructor(Datatype dt) {
/* 653 */     String s, addP = "";
/* 654 */     if (dt.getBuiltInType() == BuiltInType.DATETIME) {
/* 655 */       DatetimeDatatype dtt = (DatetimeDatatype)dt;
/*     */       
/* 657 */       addP = dtt.getDatetimeType().getClass().getName() + "." + dtt.getDatetimeType().name() + ", ";
/* 658 */     } else if (dt.getBuiltInType() == BuiltInType.NBIT_UNSIGNED_INTEGER) {
/* 659 */       NBitUnsignedIntegerDatatype nbDT = (NBitUnsignedIntegerDatatype)dt;
/* 660 */       IntegerValue lb = nbDT.getLowerBound();
/* 661 */       IntegerValue ub = nbDT.getUpperBound();
/* 662 */       addP = getIntegerValue(lb) + ", " + getIntegerValue(ub) + ", ";
/* 663 */     } else if (dt.getBuiltInType() == BuiltInType.LIST) {
/* 664 */       ListDatatype ldt = (ListDatatype)dt;
/* 665 */       addP = getDatatypeConstructor(ldt.getListDatatype()) + ", ";
/* 666 */     } else if (dt.getBuiltInType() == BuiltInType.ENUMERATION) {
/* 667 */       EnumerationDatatype edt = (EnumerationDatatype)dt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 673 */       StringBuilder sv = new StringBuilder("new " + Value.class.getName() + "[] {");
/*     */       
/* 675 */       for (int i = 0; i < edt.getEnumerationSize(); i++) {
/* 676 */         Value v = edt.getEnumValue(i);
/* 677 */         sv.append("new " + v.getClass().getName() + "(");
/* 678 */         if (v instanceof com.siemens.ct.exi.core.values.StringValue) {
/* 679 */           sv.append("\"" + v.toString() + "\"");
/*     */         }
/*     */ 
/*     */         
/* 683 */         sv.append(")");
/* 684 */         if (i < edt.getEnumerationSize() - 1) {
/* 685 */           sv.append(", ");
/*     */         }
/*     */       } 
/* 688 */       sv.append("}");
/*     */ 
/*     */       
/* 691 */       String sdt = getDatatypeConstructor(edt.getEnumValueDatatype());
/*     */       
/* 693 */       addP = sv + ", " + sdt + ", ";
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 702 */     int qnameID = getQNameID(dt.getSchemaType());
/*     */     
/* 704 */     if (qnameID < 0) {
/* 705 */       s = BuiltIn.class.getName() + ".getDefaultDatatype()";
/*     */     } else {
/* 707 */       s = "new " + dt.getClass().getName() + "(" + addP + "qnc" + qnameID + ")";
/*     */     } 
/*     */ 
/*     */     
/* 711 */     return s;
/*     */   }
/*     */   
/*     */   private String getIntegerValue(IntegerValue iv) {
/*     */     String s;
/* 716 */     switch (iv.getIntegerValueType()) {
/*     */       case INT:
/* 718 */         s = IntegerValue.class.getName() + ".valueOf(" + iv.intValue() + ")";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 734 */         return s;case LONG: s = IntegerValue.class.getName() + ".valueOf(" + iv.longValue() + "l)"; return s;case BIG: s = IntegerValue.class.getName() + ".valueOf(new " + BigInteger.class.getName() + "(" + iv.bigIntegerValue() + "))"; return s;
/*     */     } 
/*     */     throw new RuntimeException("Unsupported IntegerType " + iv);
/*     */   } public static void main(String[] args) throws EXIException, IOException {
/* 738 */     String className = "GrammarsForGrammars";
/* 739 */     String xsd = "./src/main/resources/SchemaForGrammars.xsd";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 747 */     XSDGrammarsBuilder grammarBuilder = XSDGrammarsBuilder.newInstance();
/*     */     
/* 749 */     grammarBuilder.loadGrammars(xsd);
/*     */     
/* 751 */     SchemaInformedGrammars grammarIn = grammarBuilder.toGrammars();
/*     */     
/* 753 */     Grammars2JavaSourceCode grammar2Java = new Grammars2JavaSourceCode(grammarIn);
/*     */     
/* 755 */     grammar2Java
/* 756 */       .setSchemaId("http://www.ct.siemens.com/exi/2017/SchemaForGrammars");
/* 757 */     grammar2Java.generateCode();
/*     */     
/* 759 */     String sf = grammar2Java.getGrammars(Grammars2JavaSourceCode.class
/* 760 */         .getPackage().toString(), className);
/* 761 */     System.out.println(sf);
/*     */ 
/*     */     
/* 764 */     File f = File.createTempFile(className, ".java");
/* 765 */     FileOutputStream fos = new FileOutputStream(f);
/* 766 */     fos.write(sf.getBytes());
/* 767 */     fos.close();
/* 768 */     System.out.println("Written to file: " + f);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\persistency\Grammars2JavaSourceCode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */