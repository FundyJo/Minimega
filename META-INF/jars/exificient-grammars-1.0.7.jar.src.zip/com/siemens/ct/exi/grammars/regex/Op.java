/*     */ package com.siemens.ct.exi.grammars.regex;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Op
/*     */ {
/*     */   static final int DOT = 0;
/*     */   static final int CHAR = 1;
/*     */   static final int RANGE = 3;
/*     */   static final int NRANGE = 4;
/*     */   static final int ANCHOR = 5;
/*     */   static final int STRING = 6;
/*     */   static final int CLOSURE = 7;
/*     */   static final int NONGREEDYCLOSURE = 8;
/*     */   static final int QUESTION = 9;
/*     */   static final int NONGREEDYQUESTION = 10;
/*     */   static final int UNION = 11;
/*     */   static final int CAPTURE = 15;
/*     */   static final int BACKREFERENCE = 16;
/*     */   static final int LOOKAHEAD = 20;
/*     */   static final int NEGATIVELOOKAHEAD = 21;
/*     */   static final int LOOKBEHIND = 22;
/*     */   static final int NEGATIVELOOKBEHIND = 23;
/*     */   static final int INDEPENDENT = 24;
/*     */   static final int MODIFIER = 25;
/*     */   static final int CONDITION = 26;
/*  51 */   static int nofinstances = 0;
/*     */   
/*     */   static final boolean COUNT = false;
/*     */   final int type;
/*     */   
/*     */   static Op createDot() {
/*  57 */     return new Op(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static CharOp createChar(int data) {
/*  63 */     return new CharOp(1, data);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static CharOp createAnchor(int data) {
/*  69 */     return new CharOp(5, data);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static CharOp createCapture(int number, Op next) {
/*  75 */     CharOp op = new CharOp(15, number);
/*  76 */     op.next = next;
/*  77 */     return op;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static UnionOp createUnion(int size) {
/*  84 */     return new UnionOp(11, size);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ChildOp createClosure(int id) {
/*  90 */     return new ModifierOp(7, id, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ChildOp createNonGreedyClosure() {
/*  96 */     return new ChildOp(8);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ChildOp createQuestion(boolean nongreedy) {
/* 102 */     return new ChildOp(nongreedy ? 10 : 9);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static RangeOp createRange(Token tok) {
/* 108 */     return new RangeOp(3, tok);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ChildOp createLook(int type, Op next, Op branch) {
/* 114 */     ChildOp op = new ChildOp(type);
/* 115 */     op.setChild(branch);
/* 116 */     op.next = next;
/* 117 */     return op;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static CharOp createBackReference(int refno) {
/* 123 */     return new CharOp(16, refno);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static StringOp createString(String literal) {
/* 129 */     return new StringOp(6, literal);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ChildOp createIndependent(Op next, Op branch) {
/* 135 */     ChildOp op = new ChildOp(24);
/* 136 */     op.setChild(branch);
/* 137 */     op.next = next;
/* 138 */     return op;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ModifierOp createModifier(Op next, Op branch, int add, int mask) {
/* 144 */     ModifierOp op = new ModifierOp(25, add, mask);
/* 145 */     op.setChild(branch);
/* 146 */     op.next = next;
/* 147 */     return op;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ConditionOp createCondition(Op next, int ref, Op conditionflow, Op yesflow, Op noflow) {
/* 154 */     ConditionOp op = new ConditionOp(26, ref, conditionflow, yesflow, noflow);
/*     */     
/* 156 */     op.next = next;
/* 157 */     return op;
/*     */   }
/*     */ 
/*     */   
/* 161 */   Op next = null;
/*     */   
/*     */   protected Op(int type) {
/* 164 */     this.type = type;
/*     */   }
/*     */   
/*     */   int size() {
/* 168 */     return 0;
/*     */   }
/*     */   
/*     */   Op elementAt(int index) {
/* 172 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   
/*     */   Op getChild() {
/* 176 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */ 
/*     */   
/*     */   int getData() {
/* 181 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   
/*     */   int getData2() {
/* 185 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   
/*     */   RangeToken getToken() {
/* 189 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   
/*     */   String getString() {
/* 193 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   
/*     */   static class CharOp
/*     */     extends Op {
/*     */     final int charData;
/*     */     
/*     */     CharOp(int type, int data) {
/* 201 */       super(type);
/* 202 */       this.charData = data;
/*     */     }
/*     */     
/*     */     int getData() {
/* 206 */       return this.charData;
/*     */     }
/*     */   }
/*     */   
/*     */   static class UnionOp
/*     */     extends Op {
/*     */     final Vector branches;
/*     */     
/*     */     UnionOp(int type, int size) {
/* 215 */       super(type);
/* 216 */       this.branches = new Vector(size);
/*     */     }
/*     */     
/*     */     void addElement(Op op) {
/* 220 */       this.branches.addElement(op);
/*     */     }
/*     */     
/*     */     int size() {
/* 224 */       return this.branches.size();
/*     */     }
/*     */     
/*     */     Op elementAt(int index) {
/* 228 */       return this.branches.elementAt(index);
/*     */     }
/*     */   }
/*     */   
/*     */   static class ChildOp
/*     */     extends Op {
/*     */     Op child;
/*     */     
/*     */     ChildOp(int type) {
/* 237 */       super(type);
/*     */     }
/*     */     
/*     */     void setChild(Op child) {
/* 241 */       this.child = child;
/*     */     }
/*     */     
/*     */     Op getChild() {
/* 245 */       return this.child;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ModifierOp
/*     */     extends ChildOp {
/*     */     final int v1;
/*     */     final int v2;
/*     */     
/*     */     ModifierOp(int type, int v1, int v2) {
/* 255 */       super(type);
/* 256 */       this.v1 = v1;
/* 257 */       this.v2 = v2;
/*     */     }
/*     */     
/*     */     int getData() {
/* 261 */       return this.v1;
/*     */     }
/*     */     
/*     */     int getData2() {
/* 265 */       return this.v2;
/*     */     }
/*     */   }
/*     */   
/*     */   static class RangeOp
/*     */     extends Op {
/*     */     final Token tok;
/*     */     
/*     */     RangeOp(int type, Token tok) {
/* 274 */       super(type);
/* 275 */       this.tok = tok;
/*     */     }
/*     */     
/*     */     RangeToken getToken() {
/* 279 */       return (RangeToken)this.tok;
/*     */     }
/*     */   }
/*     */   
/*     */   static class StringOp
/*     */     extends Op {
/*     */     final String string;
/*     */     
/*     */     StringOp(int type, String literal) {
/* 288 */       super(type);
/* 289 */       this.string = literal;
/*     */     }
/*     */     
/*     */     String getString() {
/* 293 */       return this.string;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ConditionOp
/*     */     extends Op {
/*     */     final int refNumber;
/*     */     final Op condition;
/*     */     final Op yes;
/*     */     final Op no;
/*     */     
/*     */     ConditionOp(int type, int refno, Op conditionflow, Op yesflow, Op noflow) {
/* 305 */       super(type);
/* 306 */       this.refNumber = refno;
/* 307 */       this.condition = conditionflow;
/* 308 */       this.yes = yesflow;
/* 309 */       this.no = noflow;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\Op.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */