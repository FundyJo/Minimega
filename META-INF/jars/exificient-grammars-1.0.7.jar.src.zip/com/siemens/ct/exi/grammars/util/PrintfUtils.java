/*    */ package com.siemens.ct.exi.grammars.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrintfUtils
/*    */ {
/*    */   public static void printfIndLn(Writer w, int indentation, String format, Object... args) throws IOException {
/* 33 */     printfInd(w, indentation, format, args);
/* 34 */     w.append("\n");
/*    */   }
/*    */ 
/*    */   
/*    */   public static void printf(Writer w, String format, Object... args) throws IOException {
/* 39 */     w.write(String.format(format, args));
/*    */   }
/*    */ 
/*    */   
/*    */   public static void printfLn(Writer w, String format, Object... args) throws IOException {
/* 44 */     printf(w, format, args);
/* 45 */     w.append("\n");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void printfInd(Writer w, int indentation, String format, Object... args) throws IOException {
/* 51 */     for (int i = 0; i < indentation; i++) {
/* 52 */       w.write("\t");
/*    */     }
/* 54 */     printf(w, format, args);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammar\\util\PrintfUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */