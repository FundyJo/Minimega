/*      */ package com.siemens.ct.exi.grammars;
/*      */ 
/*      */ import com.siemens.ct.exi.core.Constants;
/*      */ import com.siemens.ct.exi.core.context.GrammarContext;
/*      */ import com.siemens.ct.exi.core.context.GrammarUriContext;
/*      */ import com.siemens.ct.exi.core.context.QNameContext;
/*      */ import com.siemens.ct.exi.core.datatype.BinaryBase64Datatype;
/*      */ import com.siemens.ct.exi.core.datatype.BinaryHexDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.BooleanDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.BooleanFacetDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.Datatype;
/*      */ import com.siemens.ct.exi.core.datatype.DatetimeDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.DecimalDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.EnumDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.EnumerationDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.FloatDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.IntegerDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.ListDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.NBitUnsignedIntegerDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.RestrictedCharacterSetDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.StringDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.UnsignedIntegerDatatype;
/*      */ import com.siemens.ct.exi.core.datatype.WhiteSpace;
/*      */ import com.siemens.ct.exi.core.datatype.charset.CodePointCharacterSet;
/*      */ import com.siemens.ct.exi.core.datatype.charset.RestrictedCharacterSet;
/*      */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*      */ import com.siemens.ct.exi.core.grammars.Grammars;
/*      */ import com.siemens.ct.exi.core.grammars.SchemaInformedGrammars;
/*      */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*      */ import com.siemens.ct.exi.core.grammars.event.AttributeNS;
/*      */ import com.siemens.ct.exi.core.grammars.event.Characters;
/*      */ import com.siemens.ct.exi.core.grammars.event.DatatypeEvent;
/*      */ import com.siemens.ct.exi.core.grammars.event.EndDocument;
/*      */ import com.siemens.ct.exi.core.grammars.event.Event;
/*      */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*      */ import com.siemens.ct.exi.core.grammars.event.StartDocument;
/*      */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*      */ import com.siemens.ct.exi.core.grammars.event.StartElementNS;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.DocEnd;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.Document;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.Fragment;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedDocContent;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedElement;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTag;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFragmentContent;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedGrammar;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedStartTag;
/*      */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedStartTagGrammar;
/*      */ import com.siemens.ct.exi.core.grammars.production.Production;
/*      */ import com.siemens.ct.exi.core.types.BuiltIn;
/*      */ import com.siemens.ct.exi.core.types.BuiltInType;
/*      */ import com.siemens.ct.exi.core.types.DateTimeType;
/*      */ import com.siemens.ct.exi.core.types.IntegerType;
/*      */ import com.siemens.ct.exi.core.types.TypedTypeEncoder;
/*      */ import com.siemens.ct.exi.core.values.BinaryBase64Value;
/*      */ import com.siemens.ct.exi.core.values.BinaryHexValue;
/*      */ import com.siemens.ct.exi.core.values.BooleanValue;
/*      */ import com.siemens.ct.exi.core.values.DateTimeValue;
/*      */ import com.siemens.ct.exi.core.values.DecimalValue;
/*      */ import com.siemens.ct.exi.core.values.FloatValue;
/*      */ import com.siemens.ct.exi.core.values.IntegerValue;
/*      */ import com.siemens.ct.exi.core.values.StringValue;
/*      */ import com.siemens.ct.exi.core.values.Value;
/*      */ import com.siemens.ct.exi.grammars.regex.EXIRegularExpression;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xerces.xs.StringList;
/*      */ import org.apache.xerces.xs.XSAnnotation;
/*      */ import org.apache.xerces.xs.XSAttributeDeclaration;
/*      */ import org.apache.xerces.xs.XSAttributeUse;
/*      */ import org.apache.xerces.xs.XSComplexTypeDefinition;
/*      */ import org.apache.xerces.xs.XSElementDeclaration;
/*      */ import org.apache.xerces.xs.XSFacet;
/*      */ import org.apache.xerces.xs.XSModel;
/*      */ import org.apache.xerces.xs.XSModelGroup;
/*      */ import org.apache.xerces.xs.XSMultiValueFacet;
/*      */ import org.apache.xerces.xs.XSNamedMap;
/*      */ import org.apache.xerces.xs.XSObject;
/*      */ import org.apache.xerces.xs.XSObjectList;
/*      */ import org.apache.xerces.xs.XSParticle;
/*      */ import org.apache.xerces.xs.XSSimpleTypeDefinition;
/*      */ import org.apache.xerces.xs.XSTerm;
/*      */ import org.apache.xerces.xs.XSTypeDefinition;
/*      */ import org.apache.xerces.xs.XSWildcard;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.XMLReader;
/*      */ import org.xml.sax.helpers.XMLReaderFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XSDGrammarsBuilder
/*      */   extends EXIContentModelBuilder
/*      */ {
/*      */   public static final int MAX_BOUNDED_NBIT_INTEGER_RANGE = 4096;
/*      */   protected final SchemaInformedGrammar SIMPLE_END_ELEMENT_RULE;
/*      */   protected final SchemaInformedFirstStartTagGrammar SIMPLE_END_ELEMENT_EMPTY_RULE;
/*      */   protected final SchemaInformedFirstStartTagGrammar SIMPLE_END_ELEMENT_EMPTY_RULE_TYPABLE;
/*      */   protected Map<QName, SchemaInformedFirstStartTagGrammar> grammarTypes;
/*      */   protected Map<String, List<String>> schemaLocalNames;
/*      */   protected Map<XSAttributeDeclaration, Attribute> attributePool;
/*      */   protected Map<XSSimpleTypeDefinition, Datatype> datatypePool;
/*      */   protected Map<QName, List<XSElementDeclaration>> uniqueNamedElements;
/*      */   protected SchemaInformedFirstStartTagGrammar elementFragment0;
/*      */   protected Map<QName, QName> datatypeMapping;
/*      */   GrammarUriContext[] grammarUriContexts;
/*      */   
/*      */   protected XSDGrammarsBuilder() {
/*  176 */     this.SIMPLE_END_ELEMENT_RULE = (SchemaInformedGrammar)new SchemaInformedElement();
/*  177 */     this.SIMPLE_END_ELEMENT_RULE.addTerminalProduction(END_ELEMENT);
/*      */     
/*  179 */     this.SIMPLE_END_ELEMENT_EMPTY_RULE = (SchemaInformedFirstStartTagGrammar)new SchemaInformedFirstStartTag(this.SIMPLE_END_ELEMENT_RULE);
/*      */     
/*  181 */     this.SIMPLE_END_ELEMENT_EMPTY_RULE.addTerminalProduction(END_ELEMENT);
/*  182 */     this.SIMPLE_END_ELEMENT_EMPTY_RULE_TYPABLE = (SchemaInformedFirstStartTagGrammar)new SchemaInformedFirstStartTag(this.SIMPLE_END_ELEMENT_RULE);
/*      */ 
/*      */     
/*  185 */     this.SIMPLE_END_ELEMENT_EMPTY_RULE_TYPABLE
/*  186 */       .addTerminalProduction(END_ELEMENT);
/*  187 */     this.SIMPLE_END_ELEMENT_EMPTY_RULE_TYPABLE.setTypeCastable(true);
/*      */     
/*  189 */     initOnce();
/*      */   }
/*      */   
/*      */   public static XSDGrammarsBuilder newInstance() {
/*  193 */     return new XSDGrammarsBuilder();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initOnce() {
/*  198 */     super.initOnce();
/*      */     
/*  200 */     this.grammarTypes = new HashMap<>();
/*  201 */     this.schemaLocalNames = new HashMap<>();
/*  202 */     this.attributePool = new HashMap<>();
/*  203 */     this.datatypePool = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  208 */     this.datatypeMapping = new HashMap<>();
/*      */     
/*  210 */     this.datatypeMapping.put(BuiltIn.XSD_BASE64BINARY, BuiltIn.XSD_BASE64BINARY);
/*  211 */     this.datatypeMapping.put(BuiltIn.XSD_HEXBINARY, BuiltIn.XSD_HEXBINARY);
/*      */     
/*  213 */     this.datatypeMapping.put(BuiltIn.XSD_BOOLEAN, BuiltIn.XSD_BOOLEAN);
/*      */     
/*  215 */     this.datatypeMapping.put(BuiltIn.XSD_DATETIME, BuiltIn.XSD_DATETIME);
/*  216 */     this.datatypeMapping.put(BuiltIn.XSD_TIME, BuiltIn.XSD_DATETIME);
/*  217 */     this.datatypeMapping.put(BuiltIn.XSD_DATE, BuiltIn.XSD_DATETIME);
/*  218 */     this.datatypeMapping.put(BuiltIn.XSD_GYEARMONTH, BuiltIn.XSD_DATETIME);
/*  219 */     this.datatypeMapping.put(BuiltIn.XSD_GYEAR, BuiltIn.XSD_DATETIME);
/*  220 */     this.datatypeMapping.put(BuiltIn.XSD_GMONTHDAY, BuiltIn.XSD_DATETIME);
/*  221 */     this.datatypeMapping.put(BuiltIn.XSD_GDAY, BuiltIn.XSD_DATETIME);
/*  222 */     this.datatypeMapping.put(BuiltIn.XSD_GMONTH, BuiltIn.XSD_DATETIME);
/*      */     
/*  224 */     this.datatypeMapping.put(BuiltIn.XSD_DECIMAL, BuiltIn.XSD_DECIMAL);
/*      */     
/*  226 */     this.datatypeMapping.put(BuiltIn.XSD_FLOAT, BuiltIn.XSD_FLOAT);
/*  227 */     this.datatypeMapping.put(BuiltIn.XSD_DOUBLE, BuiltIn.XSD_DOUBLE);
/*      */     
/*  229 */     this.datatypeMapping.put(BuiltIn.XSD_INTEGER, BuiltIn.XSD_INTEGER);
/*      */     
/*  231 */     this.datatypeMapping.put(BuiltIn.XSD_STRING, BuiltIn.XSD_STRING);
/*      */     
/*  233 */     this.datatypeMapping.put(BuiltIn.XSD_ANY_SIMPLE_TYPE, BuiltIn.XSD_STRING);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initEachRun() {
/*  238 */     super.initEachRun();
/*      */     
/*  240 */     this.grammarTypes.clear();
/*  241 */     this.schemaLocalNames.clear();
/*  242 */     this.attributePool.clear();
/*  243 */     this.datatypePool.clear();
/*      */     
/*  245 */     this.uniqueNamedElements = null;
/*  246 */     this.elementFragment0 = null;
/*      */     
/*      */     int i;
/*  249 */     for (i = 0; i < Constants.LOCAL_NAMES_EMPTY.length; i++) {
/*  250 */       String localName = Constants.LOCAL_NAMES_EMPTY[i];
/*  251 */       addLocalNameStringEntry("", localName);
/*      */     } 
/*      */     
/*  254 */     for (i = 0; i < Constants.LOCAL_NAMES_XML.length; i++) {
/*  255 */       String localName = Constants.LOCAL_NAMES_XML[i];
/*  256 */       addLocalNameStringEntry("http://www.w3.org/XML/1998/namespace", localName);
/*      */     } 
/*      */     
/*  259 */     for (i = 0; i < Constants.LOCAL_NAMES_XSI.length; i++) {
/*  260 */       String localName = Constants.LOCAL_NAMES_XSI[i];
/*  261 */       addLocalNameStringEntry("http://www.w3.org/2001/XMLSchema-instance", localName);
/*      */     } 
/*      */ 
/*      */     
/*  265 */     for (i = 0; i < Constants.LOCAL_NAMES_XSD.length; i++) {
/*  266 */       String localName = Constants.LOCAL_NAMES_XSD[i];
/*  267 */       addLocalNameStringEntry("http://www.w3.org/2001/XMLSchema", localName);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected StartElement createStartElement(QName qname) {
/*  272 */     QNameContext qnameContext = getQNameContext(qname.getNamespaceURI(), qname
/*  273 */         .getLocalPart(), this.grammarUriContexts);
/*  274 */     StartElement se = new StartElement(qnameContext);
/*  275 */     return se;
/*      */   }
/*      */   
/*      */   protected StartElementNS createStartElementNS(String uri) {
/*  279 */     GrammarUriContext uriContext = getUriContext(uri, this.grammarUriContexts);
/*      */     
/*  281 */     StartElementNS seNS = new StartElementNS(uriContext.getNamespaceUriID(), uriContext.getNamespaceUri());
/*  282 */     return seNS;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static QNameContext getQNameContext(String namespaceUri, String localName, GrammarUriContext[] grammarUriContexts) {
/*  288 */     namespaceUri = (namespaceUri == null) ? "" : namespaceUri;
/*      */     
/*  290 */     GrammarUriContext grammarUriContext = getUriContext(namespaceUri, grammarUriContexts);
/*      */     
/*  292 */     if (grammarUriContext == null) {
/*  293 */       throw new RuntimeException("No known uri : " + namespaceUri);
/*      */     }
/*      */     
/*  296 */     QNameContext qnameContext = grammarUriContext.getQNameContext(localName);
/*  297 */     if (qnameContext == null) {
/*  298 */       throw new RuntimeException("No known qname local-name: " + localName);
/*      */     }
/*      */     
/*  301 */     return qnameContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static GrammarUriContext getUriContext(String namespaceUri, GrammarUriContext[] grammarUriContexts) {
/*  309 */     namespaceUri = (namespaceUri == null) ? "" : namespaceUri;
/*  310 */     assert grammarUriContexts != null;
/*      */     
/*  312 */     for (int i = 0; i < grammarUriContexts.length; i++) {
/*  313 */       GrammarUriContext guc = grammarUriContexts[i];
/*  314 */       if (guc.getNamespaceUri().equals(namespaceUri)) {
/*  315 */         return guc;
/*      */       }
/*      */     } 
/*      */     
/*  319 */     throw new RuntimeException("No known uri context for: " + namespaceUri);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Attribute createAttribute(QName qname, Datatype datatype) {
/*  324 */     QNameContext qnameContext = getQNameContext(qname.getNamespaceURI(), qname
/*  325 */         .getLocalPart(), this.grammarUriContexts);
/*  326 */     Attribute at = new Attribute(qnameContext, datatype);
/*      */     
/*  328 */     return at;
/*      */   }
/*      */   
/*      */   protected AttributeNS createAttributeNS(String uri) {
/*  332 */     GrammarUriContext uriContext = getUriContext(uri, this.grammarUriContexts);
/*      */     
/*  334 */     AttributeNS atNS = new AttributeNS(uriContext.getNamespaceUriID(), uriContext.getNamespaceUri());
/*  335 */     return atNS;
/*      */   }
/*      */   
/*      */   protected boolean isSameElementGrammar(List<XSElementDeclaration> elements) {
/*  339 */     assert elements.size() > 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  345 */     for (int i = 1; i < elements.size(); i++) {
/*  346 */       XSElementDeclaration e0 = elements.get(0);
/*  347 */       XSTypeDefinition t0 = e0.getTypeDefinition();
/*  348 */       XSElementDeclaration e1 = elements.get(i);
/*  349 */       XSTypeDefinition t1 = e1.getTypeDefinition();
/*  350 */       if (t0.getAnonymous() || t1.getAnonymous())
/*      */       {
/*  352 */         return false;
/*      */       }
/*      */       
/*  355 */       if (!t0.getName().equals(t1.getName()) || t0
/*  356 */         .getNamespace() != t1.getNamespace() || e0
/*  357 */         .getNillable() != e1.getNillable()) {
/*  358 */         return false;
/*      */       }
/*      */     } 
/*      */     
/*  362 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isSameAttributeGrammar(List<XSAttributeDeclaration> attributes) {
/*  367 */     assert attributes.size() > 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  373 */     for (int i = 1; i < attributes.size(); i++) {
/*  374 */       XSAttributeDeclaration e0 = attributes.get(0);
/*  375 */       XSAttributeDeclaration ei = attributes.get(i);
/*  376 */       if (e0.getTypeDefinition() != ei.getTypeDefinition()) {
/*  377 */         return false;
/*      */       }
/*      */     } 
/*      */     
/*  381 */     return true;
/*      */   }
/*      */   
/*      */   protected Map<QName, List<XSElementDeclaration>> getUniqueNamedElements() {
/*  385 */     if (this.uniqueNamedElements != null) {
/*  386 */       return this.uniqueNamedElements;
/*      */     }
/*      */ 
/*      */     
/*  390 */     this.uniqueNamedElements = new HashMap<>();
/*  391 */     for (XSElementDeclaration elDecl : this.elementPool.keySet()) {
/*  392 */       QName en = new QName(elDecl.getNamespace(), elDecl.getName());
/*  393 */       if (this.uniqueNamedElements.containsKey(en)) {
/*  394 */         ((List<XSElementDeclaration>)this.uniqueNamedElements.get(en)).add(elDecl); continue;
/*      */       } 
/*  396 */       List<XSElementDeclaration> list = new ArrayList<>();
/*  397 */       list.add(elDecl);
/*  398 */       this.uniqueNamedElements.put(en, list);
/*      */     } 
/*      */ 
/*      */     
/*  402 */     return this.uniqueNamedElements;
/*      */   }
/*      */   
/*      */   protected List<StartElement> getFragmentElements() throws EXIException {
/*  406 */     List<StartElement> fragmentElements = new ArrayList<>();
/*      */ 
/*      */     
/*  409 */     Map<QName, List<XSElementDeclaration>> uniqueNamedElements = getUniqueNamedElements();
/*      */ 
/*      */     
/*  412 */     Iterator<Map.Entry<QName, List<XSElementDeclaration>>> iter = uniqueNamedElements.entrySet().iterator();
/*  413 */     while (iter.hasNext()) {
/*  414 */       Map.Entry<QName, List<XSElementDeclaration>> e = iter.next();
/*  415 */       QName qname = e.getKey();
/*  416 */       List<XSElementDeclaration> elements = e.getValue();
/*      */ 
/*      */       
/*  419 */       assert elements.size() >= 1;
/*  420 */       if (elements.size() == 1) {
/*      */ 
/*      */         
/*  423 */         StartElement startElement = translatElementDeclarationToFSA(elements
/*  424 */             .get(0));
/*  425 */         fragmentElements.add(startElement);
/*      */         continue;
/*      */       } 
/*  428 */       if (isSameElementGrammar(elements)) {
/*      */         
/*  430 */         StartElement startElement = translatElementDeclarationToFSA(elements
/*  431 */             .get(0));
/*  432 */         fragmentElements.add(startElement); continue;
/*      */       } 
/*  434 */       StartElement se = createStartElement(qname);
/*      */       
/*  436 */       SchemaInformedGrammar schemaInformedGrammar = getSchemaInformedElementFragmentGrammar();
/*  437 */       se.setGrammar((Grammar)schemaInformedGrammar);
/*  438 */       fragmentElements.add(se);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  445 */     return fragmentElements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SchemaInformedGrammar getSchemaInformedElementFragmentGrammar() throws EXIException {
/*  453 */     Map<QName, List<XSElementDeclaration>> uniqueNamedElements = getUniqueNamedElements();
/*      */     
/*  455 */     if (this.elementFragment0 != null) {
/*  456 */       return (SchemaInformedGrammar)this.elementFragment0;
/*      */     }
/*      */ 
/*      */     
/*  460 */     SchemaInformedElement schemaInformedElement1 = new SchemaInformedElement();
/*  461 */     this.elementFragment0 = (SchemaInformedFirstStartTagGrammar)new SchemaInformedFirstStartTag((SchemaInformedGrammar)schemaInformedElement1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  484 */     List<QName> uniqueNamedElementsList = new ArrayList<>();
/*  485 */     Iterator<QName> iter = uniqueNamedElements.keySet().iterator();
/*  486 */     while (iter.hasNext()) {
/*  487 */       uniqueNamedElementsList.add(iter.next());
/*      */     }
/*  489 */     Collections.sort(uniqueNamedElementsList, (Comparator<? super QName>)qnameSort);
/*      */     
/*  491 */     for (int i = 0; i < uniqueNamedElementsList.size(); i++) {
/*  492 */       StartElement se; QName fm = uniqueNamedElementsList.get(i);
/*      */       
/*  494 */       List<XSElementDeclaration> elements = uniqueNamedElements.get(fm);
/*  495 */       if (elements.size() == 1 || isSameElementGrammar(elements)) {
/*      */         
/*  497 */         se = translatElementDeclarationToFSA(elements.get(0));
/*      */       }
/*      */       else {
/*      */         
/*  501 */         se = createStartElement(fm);
/*  502 */         se.setGrammar((Grammar)this.elementFragment0);
/*      */       } 
/*  504 */       schemaInformedElement1.addProduction((Event)se, (Grammar)schemaInformedElement1);
/*      */     } 
/*      */ 
/*      */     
/*  508 */     schemaInformedElement1.addProduction(START_ELEMENT_GENERIC, (Grammar)schemaInformedElement1);
/*      */     
/*  510 */     schemaInformedElement1.addTerminalProduction(END_ELEMENT);
/*      */     
/*  512 */     schemaInformedElement1.addProduction(CHARACTERS_GENERIC, (Grammar)schemaInformedElement1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  539 */     List<QName> uniqueNamedAttributeList = new ArrayList<>();
/*      */ 
/*      */     
/*  542 */     Map<QName, List<XSAttributeDeclaration>> uniqueNamedAttributes = new HashMap<>();
/*      */     
/*  544 */     Iterator<XSAttributeDeclaration> atts = this.attributePool.keySet().iterator();
/*  545 */     while (atts.hasNext()) {
/*  546 */       XSAttributeDeclaration atDecl = atts.next();
/*  547 */       QName atQname = new QName(atDecl.getNamespace(), atDecl.getName());
/*  548 */       if (uniqueNamedAttributes.containsKey(atQname)) {
/*  549 */         ((List<XSAttributeDeclaration>)uniqueNamedAttributes.get(atQname)).add(atDecl); continue;
/*      */       } 
/*  551 */       List<XSAttributeDeclaration> list = new ArrayList<>();
/*  552 */       list.add(atDecl);
/*  553 */       uniqueNamedAttributes.put(atQname, list);
/*  554 */       uniqueNamedAttributeList.add(atQname);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  559 */     XSNamedMap nm = this.xsModel.getComponents((short)1); int j;
/*  560 */     for (j = 0; j < nm.getLength(); j++) {
/*  561 */       XSAttributeDeclaration atDecl = (XSAttributeDeclaration)nm.item(j);
/*  562 */       QName atQname = new QName(atDecl.getNamespace(), atDecl.getName());
/*  563 */       if (uniqueNamedAttributes.containsKey(atQname)) {
/*  564 */         ((List<XSAttributeDeclaration>)uniqueNamedAttributes.get(atQname)).add(atDecl);
/*      */       } else {
/*  566 */         List<XSAttributeDeclaration> list = new ArrayList<>();
/*  567 */         list.add(atDecl);
/*  568 */         uniqueNamedAttributes.put(atQname, list);
/*  569 */         uniqueNamedAttributeList.add(atQname);
/*      */       } 
/*      */     } 
/*      */     
/*  573 */     Collections.sort(uniqueNamedAttributeList, (Comparator<? super QName>)qnameSort);
/*      */     
/*  575 */     for (j = 0; j < uniqueNamedAttributeList.size(); j++) {
/*  576 */       Attribute at; QName an = uniqueNamedAttributeList.get(j);
/*      */ 
/*      */       
/*  579 */       List<XSAttributeDeclaration> attributes = uniqueNamedAttributes.get(an);
/*  580 */       if (attributes.size() == 1 || isSameAttributeGrammar(attributes)) {
/*  581 */         at = getAttribute(attributes.get(0));
/*      */       }
/*      */       else {
/*      */         
/*  585 */         at = createAttribute(an, BuiltIn.getDefaultDatatype());
/*      */       } 
/*  587 */       this.elementFragment0.addProduction((Event)at, (Grammar)this.elementFragment0);
/*      */     } 
/*      */     
/*  590 */     this.elementFragment0.addProduction(ATTRIBUTE_GENERIC, (Grammar)this.elementFragment0);
/*      */ 
/*      */ 
/*      */     
/*  594 */     for (j = 0; j < uniqueNamedElementsList.size(); j++) {
/*  595 */       StartElement se; QName fm = uniqueNamedElementsList.get(j);
/*      */       
/*  597 */       List<XSElementDeclaration> elements = uniqueNamedElements.get(fm);
/*  598 */       if (elements.size() == 1 || isSameElementGrammar(elements)) {
/*      */         
/*  600 */         se = translatElementDeclarationToFSA(elements.get(0));
/*      */       }
/*      */       else {
/*      */         
/*  604 */         se = createStartElement(fm);
/*  605 */         se.setGrammar((Grammar)this.elementFragment0);
/*      */       } 
/*  607 */       this.elementFragment0.addProduction((Event)se, (Grammar)schemaInformedElement1);
/*      */     } 
/*      */ 
/*      */     
/*  611 */     this.elementFragment0.addProduction(START_ELEMENT_GENERIC, (Grammar)schemaInformedElement1);
/*      */     
/*  613 */     this.elementFragment0.addTerminalProduction(END_ELEMENT);
/*      */     
/*  615 */     this.elementFragment0.addProduction(CHARACTERS_GENERIC, (Grammar)schemaInformedElement1);
/*      */     
/*  617 */     SchemaInformedElement schemaInformedElement2 = new SchemaInformedElement();
/*  618 */     SchemaInformedFirstStartTag schemaInformedFirstStartTag = new SchemaInformedFirstStartTag((SchemaInformedGrammar)schemaInformedElement2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  628 */     for (int k = 0; k < uniqueNamedAttributeList.size(); k++) {
/*  629 */       Attribute at; QName an = uniqueNamedAttributeList.get(k);
/*      */ 
/*      */       
/*  632 */       List<XSAttributeDeclaration> attributes = uniqueNamedAttributes.get(an);
/*  633 */       if (attributes.size() == 1 || isSameAttributeGrammar(attributes)) {
/*  634 */         at = getAttribute(attributes.get(0));
/*      */       }
/*      */       else {
/*      */         
/*  638 */         at = createAttribute(an, BuiltIn.getDefaultDatatype());
/*      */       } 
/*  640 */       schemaInformedFirstStartTag.addProduction((Event)at, (Grammar)schemaInformedFirstStartTag);
/*      */     } 
/*  642 */     schemaInformedFirstStartTag.addProduction(ATTRIBUTE_GENERIC, (Grammar)schemaInformedFirstStartTag);
/*      */     
/*  644 */     schemaInformedFirstStartTag.addTerminalProduction(END_ELEMENT);
/*      */ 
/*      */ 
/*      */     
/*  648 */     schemaInformedElement2.addTerminalProduction(END_ELEMENT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  662 */     this.elementFragment0.setNillable(true);
/*  663 */     this.elementFragment0.setTypeEmpty((SchemaInformedFirstStartTagGrammar)schemaInformedFirstStartTag);
/*  664 */     this.elementFragment0.setTypeCastable(true);
/*      */     
/*  666 */     return (SchemaInformedGrammar)this.elementFragment0;
/*      */   }
/*      */   
/*      */   static class NamespaceUriEntry implements Comparable<NamespaceUriEntry> {
/*      */     public final String namespaceUri;
/*      */     public final List<String> localNames;
/*      */     
/*      */     public NamespaceUriEntry(String namespaceUri) {
/*  674 */       this.namespaceUri = namespaceUri;
/*  675 */       this.localNames = new ArrayList<>();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int compareTo(NamespaceUriEntry o) {
/*  684 */       if ("".equals(this.namespaceUri))
/*  685 */         return -1; 
/*  686 */       if ("".equals(o.namespaceUri))
/*  687 */         return 1; 
/*  688 */       if ("http://www.w3.org/XML/1998/namespace".equals(this.namespaceUri))
/*  689 */         return -1; 
/*  690 */       if ("http://www.w3.org/XML/1998/namespace".equals(o.namespaceUri))
/*  691 */         return 1; 
/*  692 */       if ("http://www.w3.org/2001/XMLSchema-instance"
/*  693 */         .equals(this.namespaceUri))
/*  694 */         return -1; 
/*  695 */       if ("http://www.w3.org/2001/XMLSchema-instance"
/*  696 */         .equals(o.namespaceUri))
/*  697 */         return 1; 
/*  698 */       if ("http://www.w3.org/2001/XMLSchema".equals(this.namespaceUri))
/*  699 */         return -1; 
/*  700 */       if ("http://www.w3.org/2001/XMLSchema".equals(o.namespaceUri)) {
/*  701 */         return 1;
/*      */       }
/*  703 */       return this.namespaceUri.compareTo(o.namespaceUri);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class StringTableEntries
/*      */     extends ArrayList<NamespaceUriEntry>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final XSModel xsModel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Set<XSComplexTypeDefinition> cTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void initializeEntries() {
/*      */       StringList nss = this.xsModel.getNamespaces();
/*      */       for (int i = 0; i < nss.size(); i++) {
/*      */         String ns = (String)nss.get(i);
/*      */         checkNamespaceUriEntry(ns);
/*      */       } 
/*      */       XSNamedMap nm = this.xsModel.getComponents((short)16);
/*      */       int k;
/*      */       for (k = 0; k < nm.size(); k++) {
/*      */         XSSimpleTypeDefinition std = (XSSimpleTypeDefinition)nm.item(k);
/*      */         handleSimpleType(std);
/*      */       } 
/*      */       nm = this.xsModel.getComponents((short)15);
/*      */       for (k = 0; k < nm.size(); k++) {
/*      */         XSComplexTypeDefinition ctd = (XSComplexTypeDefinition)nm.item(k);
/*      */         handleComplexType(ctd);
/*      */       } 
/*      */       nm = this.xsModel.getComponents((short)2);
/*      */       for (k = 0; k < nm.size(); k++) {
/*      */         XSElementDeclaration it = (XSElementDeclaration)nm.item(k);
/*      */         handleElementDeclaration(it);
/*      */       } 
/*      */       nm = this.xsModel.getComponents((short)1);
/*      */       for (k = 0; k < nm.size(); k++) {
/*      */         XSAttributeDeclaration it = (XSAttributeDeclaration)nm.item(k);
/*      */         handleAttributeDeclaration(it);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private XSDGrammarsBuilder.NamespaceUriEntry checkNamespaceUriEntry(String namespaceUri) {
/*      */       namespaceUri = (namespaceUri == null) ? "" : namespaceUri;
/*      */       for (int i = 0; i < size(); i++) {
/*      */         XSDGrammarsBuilder.NamespaceUriEntry namespaceUriEntry = get(i);
/*      */         if (namespaceUriEntry.namespaceUri.equals(namespaceUri)) {
/*      */           return namespaceUriEntry;
/*      */         }
/*      */       } 
/*      */       XSDGrammarsBuilder.NamespaceUriEntry nsue = new XSDGrammarsBuilder.NamespaceUriEntry(namespaceUri);
/*      */       add(nsue);
/*      */       return nsue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public StringTableEntries(XSModel xsModel) {
/*  892 */       this.cTypes = new HashSet<>(); this.xsModel = xsModel; add(new XSDGrammarsBuilder.NamespaceUriEntry("")); XSDGrammarsBuilder.NamespaceUriEntry nsue1 = new XSDGrammarsBuilder.NamespaceUriEntry("http://www.w3.org/XML/1998/namespace"); nsue1.localNames.add("base"); nsue1.localNames.add("id"); nsue1.localNames.add("lang"); nsue1.localNames.add("space"); add(nsue1); XSDGrammarsBuilder.NamespaceUriEntry nsue2 = new XSDGrammarsBuilder.NamespaceUriEntry("http://www.w3.org/2001/XMLSchema-instance"); nsue2.localNames.add("nil"); nsue2.localNames.add("type"); add(nsue2); add(new XSDGrammarsBuilder.NamespaceUriEntry("http://www.w3.org/2001/XMLSchema")); initializeEntries(); Collections.sort(this); for (int i = 0; i < size(); i++) { XSDGrammarsBuilder.NamespaceUriEntry nsue = get(i); Collections.sort(nsue.localNames); } 
/*      */     }
/*      */     private void checkEntry(String namespaceUri, String localName) { XSDGrammarsBuilder.NamespaceUriEntry nsue = checkNamespaceUriEntry(namespaceUri); assert localName != null; if (!nsue.localNames.contains(localName)) nsue.localNames.add(localName);  }
/*      */     private void handleAttributeDeclaration(XSAttributeDeclaration ad) { checkEntry(ad.getNamespace(), ad.getName()); handleType((XSTypeDefinition)ad.getTypeDefinition()); }
/*  896 */     private void handleElementDeclaration(XSElementDeclaration ed) { checkEntry(ed.getNamespace(), ed.getName()); handleType(ed.getTypeDefinition()); XSNamedMap globalElements = this.xsModel.getComponents((short)2); if (globalElements != null && globalElements.size() > 0) { XSObjectList subs = this.xsModel.getSubstitutionGroup(ed); if (subs != null) for (int s = 0; s < subs.getLength(); s++) { XSElementDeclaration sub = (XSElementDeclaration)subs.get(s); checkEntry(sub.getNamespace(), sub.getName()); handleType(sub.getTypeDefinition()); }   }  } private void handleType(XSTypeDefinition td) { if (td.getTypeCategory() == 15) { handleComplexType((XSComplexTypeDefinition)td); } else { handleSimpleType((XSSimpleTypeDefinition)td); }  } private void handleSimpleType(XSSimpleTypeDefinition std) { if (!std.getAnonymous()) checkEntry(std.getNamespace(), std.getName());  } private void handleComplexType(XSComplexTypeDefinition ctd) { if (this.cTypes.contains(ctd)) {
/*      */         return;
/*      */       }
/*      */       
/*  900 */       this.cTypes.add(ctd);
/*      */ 
/*      */       
/*  903 */       if (!ctd.getAnonymous()) {
/*  904 */         checkEntry(ctd.getNamespace(), ctd.getName());
/*      */       }
/*      */ 
/*      */       
/*  908 */       XSObjectList attributes = ctd.getAttributeUses();
/*  909 */       for (int i = 0; i < attributes.getLength(); i++) {
/*  910 */         XSAttributeUse at = (XSAttributeUse)attributes.get(i);
/*  911 */         XSAttributeDeclaration atd = at.getAttrDeclaration();
/*  912 */         checkEntry(atd.getNamespace(), atd.getName());
/*      */       } 
/*      */ 
/*      */       
/*  916 */       XSWildcard attributeWC = ctd.getAttributeWildcard();
/*  917 */       handleWildcard(attributeWC);
/*      */ 
/*      */       
/*  920 */       XSParticle particle = ctd.getParticle();
/*  921 */       if (particle != null)
/*  922 */       { XSTerm t = particle.getTerm();
/*  923 */         handleTerm(t); }  }
/*      */     private void handleTerm(XSTerm t) { XSElementDeclaration ed; XSModelGroup mg; XSObjectList particles; int l; switch (t.getType()) { case 2: ed = (XSElementDeclaration)t; handleElementDeclaration(ed); return;
/*      */         case 7:
/*      */           mg = (XSModelGroup)t; particles = mg.getParticles(); for (l = 0; l < particles.getLength(); l++) { XSParticle part = (XSParticle)particles.get(l); XSTerm tt = part.getTerm(); handleTerm(tt); }  return;
/*      */         case 9:
/*      */           handleWildcard((XSWildcard)t); return; }  throw new RuntimeException("Unexpected term"); } private void handleWildcard(XSWildcard wc) { if (wc != null) { StringList sl; int k; switch (wc.getConstraintType()) { case 3:
/*      */             sl = wc.getNsConstraintList(); for (k = 0; k < sl.getLength(); k++) { String namespace = sl.item(k); checkNamespaceUriEntry(namespace); }  break; }  }  }
/*  930 */   } public SchemaInformedGrammars toGrammars() throws EXIException { if (this.xsModel == null || this.schemaParsingErrors.size() > 0) {
/*  931 */       StringBuilder sb = new StringBuilder("Problem occured while building XML Schema Model (XSModel)!");
/*      */ 
/*      */       
/*  934 */       for (int m = 0; m < this.schemaParsingErrors.size(); m++) {
/*  935 */         sb.append("\n. " + (String)this.schemaParsingErrors.get(m));
/*      */       }
/*      */       
/*  938 */       throw new EXIException(sb.toString());
/*      */     } 
/*      */ 
/*      */     
/*  942 */     StringTableEntries ste = new StringTableEntries(this.xsModel);
/*      */     
/*  944 */     this.grammarUriContexts = new GrammarUriContext[ste.size()];
/*  945 */     int qNameID = 0; int i;
/*  946 */     for (i = 0; i < ste.size(); i++) {
/*  947 */       String[] prefixes; NamespaceUriEntry nsue = ste.get(i);
/*  948 */       String namespaceUri = nsue.namespaceUri;
/*      */ 
/*      */       
/*  951 */       if ("".equals(namespaceUri)) {
/*  952 */         prefixes = Constants.PREFIXES_EMPTY;
/*  953 */       } else if ("http://www.w3.org/XML/1998/namespace".equals(namespaceUri)) {
/*  954 */         prefixes = Constants.PREFIXES_XML;
/*  955 */       } else if ("http://www.w3.org/2001/XMLSchema-instance"
/*  956 */         .equals(namespaceUri)) {
/*  957 */         prefixes = Constants.PREFIXES_XSI;
/*      */       } else {
/*  959 */         prefixes = GrammarUriContext.EMPTY_PREFIXES;
/*      */       } 
/*      */ 
/*      */       
/*  963 */       List<String> localNames = nsue.localNames;
/*      */       
/*  965 */       QNameContext[] grammarLocalNames = new QNameContext[localNames.size()];
/*      */       
/*  967 */       for (int m = 0; m < localNames.size(); m++) {
/*  968 */         String localName = localNames.get(m);
/*      */         
/*  970 */         QName qname = new QName(namespaceUri, localName);
/*  971 */         grammarLocalNames[m] = new QNameContext(i, m, qname);
/*  972 */         qNameID++;
/*      */       } 
/*      */ 
/*      */       
/*  976 */       this.grammarUriContexts[i] = new GrammarUriContext(i, namespaceUri, grammarLocalNames, prefixes);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  982 */     for (i = 0; i < this.grammarUriContexts.length; i++) {
/*  983 */       GrammarUriContext guc = this.grammarUriContexts[i];
/*  984 */       for (int m = 0; m < guc.getNumberOfQNames(); m++) {
/*  985 */         QNameContext qnc = guc.getQNameContext(m);
/*  986 */         String localName = qnc.getLocalName();
/*  987 */         String namespace = guc.getNamespaceUri();
/*      */ 
/*      */ 
/*      */         
/*  991 */         XSElementDeclaration globalElementDecl = this.xsModel.getElementDeclaration(localName, namespace);
/*  992 */         if (globalElementDecl != null) {
/*  993 */           StartElement grammarGlobalElement = translatElementDeclarationToFSA(globalElementDecl);
/*  994 */           qnc.setGlobalStartElement(grammarGlobalElement);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  999 */         XSAttributeDeclaration globalAttributeDecl = this.xsModel.getAttributeDeclaration(localName, namespace);
/* 1000 */         if (globalAttributeDecl != null) {
/*      */           
/* 1002 */           Attribute grammarGlobalAttribute = getAttribute(globalAttributeDecl);
/* 1003 */           qnc.setGlobalAttribute(grammarGlobalAttribute);
/*      */         } 
/*      */ 
/*      */         
/* 1007 */         XSTypeDefinition typeDef = this.xsModel.getTypeDefinition(localName, namespace);
/*      */         
/* 1009 */         if (typeDef != null) {
/*      */           
/* 1011 */           SchemaInformedFirstStartTagGrammar fstr = translateTypeDefinitionToFSA(typeDef);
/* 1012 */           qnc.setTypeGrammar(fstr);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1089 */     List<StartElement> globalElements = initGrammars();
/*      */ 
/*      */     
/* 1092 */     List<StartElement> fragmentElements = getFragmentElements();
/*      */ 
/*      */     
/* 1095 */     Collections.sort(globalElements, (Comparator<? super StartElement>)startElementSort);
/* 1096 */     Collections.sort(fragmentElements, (Comparator<? super StartElement>)startElementSort);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1104 */     DocEnd builtInDocEndGrammar = new DocEnd("DocEnd");
/* 1105 */     builtInDocEndGrammar.addTerminalProduction((Event)new EndDocument());
/*      */     
/* 1107 */     SchemaInformedDocContent schemaInformedDocContent = new SchemaInformedDocContent("DocContent");
/*      */     
/* 1109 */     schemaInformedDocContent.addProduction(START_ELEMENT_GENERIC, (Grammar)builtInDocEndGrammar);
/*      */ 
/*      */ 
/*      */     
/* 1113 */     for (int j = 0; j < globalElements.size(); j++) {
/* 1114 */       StartElement globalElement = globalElements.get(j);
/* 1115 */       schemaInformedDocContent.addProduction((Event)globalElement, (Grammar)builtInDocEndGrammar);
/*      */     } 
/*      */ 
/*      */     
/* 1119 */     Document documentGrammar = new Document("Document");
/* 1120 */     documentGrammar.addProduction((Event)new StartDocument(), (Grammar)schemaInformedDocContent);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1130 */     SchemaInformedFragmentContent schemaInformedFragmentContent = new SchemaInformedFragmentContent("FragmentContent");
/*      */ 
/*      */     
/* 1133 */     schemaInformedFragmentContent.addProduction(START_ELEMENT_GENERIC, (Grammar)schemaInformedFragmentContent);
/*      */ 
/*      */     
/* 1136 */     schemaInformedFragmentContent.addTerminalProduction((Event)new EndDocument());
/*      */     
/* 1138 */     for (int k = 0; k < fragmentElements.size(); k++) {
/* 1139 */       StartElement fragmentElement = fragmentElements.get(k);
/* 1140 */       schemaInformedFragmentContent.addProduction((Event)fragmentElement, (Grammar)schemaInformedFragmentContent);
/*      */     } 
/*      */ 
/*      */     
/* 1144 */     Fragment fragmentGrammar = new Fragment("Fragment");
/* 1145 */     fragmentGrammar.addProduction((Event)new StartDocument(), (Grammar)schemaInformedFragmentContent);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1151 */     GrammarContext grammarContext = new GrammarContext(this.grammarUriContexts, qNameID);
/*      */ 
/*      */ 
/*      */     
/* 1155 */     SchemaInformedGrammars sig = new SchemaInformedGrammars(grammarContext, documentGrammar, fragmentGrammar, getSchemaInformedElementFragmentGrammar());
/*      */     
/* 1157 */     return sig; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean isAdditionalNamespace(String namespaceURI) {
/* 1166 */     assert namespaceURI != null;
/* 1167 */     if (namespaceURI.equals("") || namespaceURI
/* 1168 */       .equals("http://www.w3.org/XML/1998/namespace") || namespaceURI
/* 1169 */       .equals("http://www.w3.org/2001/XMLSchema-instance") || namespaceURI
/* 1170 */       .equals("http://www.w3.org/2001/XMLSchema")) {
/* 1171 */       return false;
/*      */     }
/* 1173 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected String[] getURITableEntries() {
/* 1178 */     StringList namespaces = this.xsModel.getNamespaces();
/* 1179 */     TreeSet<String> sortedURIs = new TreeSet<>();
/*      */     
/* 1181 */     for (int i = 0; i < namespaces.getLength(); i++) {
/*      */       
/* 1183 */       String uri = (namespaces.item(i) == null) ? "" : namespaces.item(i);
/* 1184 */       if (isAdditionalNamespace(uri)) {
/* 1185 */         sortedURIs.add(uri);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1190 */     Iterator<String> iterUris = this.schemaLocalNames.keySet().iterator();
/* 1191 */     while (iterUris.hasNext()) {
/* 1192 */       String uri = iterUris.next();
/* 1193 */       if (isAdditionalNamespace(uri)) {
/* 1194 */         sortedURIs.add(uri);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1199 */     String[] uris = new String[4 + sortedURIs.size()];
/* 1200 */     uris[0] = "";
/* 1201 */     uris[1] = "http://www.w3.org/XML/1998/namespace";
/* 1202 */     uris[2] = "http://www.w3.org/2001/XMLSchema-instance";
/* 1203 */     uris[3] = "http://www.w3.org/2001/XMLSchema";
/* 1204 */     int compactID = 4;
/* 1205 */     for (String addUri : sortedURIs) {
/* 1206 */       uris[compactID] = addUri;
/* 1207 */       compactID++;
/*      */     } 
/*      */     
/* 1210 */     return uris;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addLocalNameStringEntry(String namespaceURI, String localName) {
/* 1221 */     List<String> localNameList = addNamespaceStringEntry(namespaceURI);
/*      */ 
/*      */     
/* 1224 */     if (!localNameList.contains(localName))
/* 1225 */       localNameList.add(localName); 
/*      */   }
/*      */   
/*      */   protected List<String> addNamespaceStringEntry(String namespaceURI) {
/*      */     List<String> localNameList;
/* 1230 */     if (namespaceURI == null) {
/* 1231 */       namespaceURI = "";
/*      */     }
/*      */ 
/*      */     
/* 1235 */     if (this.schemaLocalNames.containsKey(namespaceURI)) {
/* 1236 */       localNameList = this.schemaLocalNames.get(namespaceURI);
/*      */     } else {
/* 1238 */       localNameList = new ArrayList<>();
/* 1239 */       this.schemaLocalNames.put(namespaceURI, localNameList);
/*      */     } 
/*      */     
/* 1242 */     return localNameList;
/*      */   }
/*      */   
/*      */   protected List<StartElement> initGrammars() throws EXIException {
/* 1246 */     List<StartElement> globalElements = new ArrayList<>();
/*      */ 
/*      */     
/* 1249 */     XSNamedMap types = this.xsModel.getComponents((short)3);
/* 1250 */     for (int i = 0; i < types.getLength(); i++) {
/* 1251 */       XSTypeDefinition td = (XSTypeDefinition)types.item(i);
/*      */ 
/*      */       
/* 1254 */       SchemaInformedFirstStartTagGrammar sir = translateTypeDefinitionToFSA(td);
/*      */       
/* 1256 */       assert !sir.isNillable();
/* 1257 */       assert !sir.isTypeCastable();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1262 */     XSNamedMap xsGlobalElements = this.xsModel.getComponents((short)2);
/* 1263 */     for (int j = 0; j < xsGlobalElements.getLength(); j++) {
/*      */       
/* 1265 */       XSElementDeclaration globalElementDecl = (XSElementDeclaration)xsGlobalElements.item(j);
/*      */       
/* 1267 */       StartElement seGlobalElement = translatElementDeclarationToFSA(globalElementDecl);
/*      */ 
/*      */       
/* 1270 */       globalElements.add(seGlobalElement);
/*      */     } 
/*      */     
/* 1273 */     return globalElements;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Attribute getAttribute(XSAttributeDeclaration attrDecl) throws EXIException {
/*      */     Attribute at;
/* 1279 */     addLocalNameStringEntry(attrDecl.getNamespace(), attrDecl.getName());
/*      */ 
/*      */     
/* 1282 */     if (this.attributePool.containsKey(attrDecl)) {
/* 1283 */       at = this.attributePool.get(attrDecl);
/*      */     } else {
/*      */       
/* 1286 */       XSSimpleTypeDefinition std = attrDecl.getTypeDefinition();
/*      */ 
/*      */       
/* 1289 */       QName qname = new QName(attrDecl.getNamespace(), attrDecl.getName());
/* 1290 */       at = createAttribute(qname, getDatatype(std));
/*      */ 
/*      */ 
/*      */       
/* 1294 */       this.attributePool.put(attrDecl, at);
/*      */     } 
/*      */     
/* 1297 */     return at;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected XSTypeDefinition getBaseType(XSTypeDefinition td) {
/* 1304 */     if (td.getTypeCategory() == 16) {
/* 1305 */       if ("negativeInteger".equals(td.getName()) && "http://www.w3.org/2001/XMLSchema"
/* 1306 */         .equals(td.getNamespace())) {
/* 1307 */         XSTypeDefinition td2 = this.xsModel.getTypeDefinition("nonPositiveInteger", "http://www.w3.org/2001/XMLSchema");
/*      */         
/* 1309 */         return td2;
/*      */       } 
/* 1311 */       return td.getBaseType();
/*      */     } 
/*      */     
/* 1314 */     return td.getBaseType();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected QName getValueType(XSTypeDefinition typeDefinition) {
/* 1320 */     while (typeDefinition.getAnonymous()) {
/* 1321 */       typeDefinition = getBaseType(typeDefinition);
/*      */     }
/*      */ 
/*      */     
/* 1325 */     QName valueType = new QName(typeDefinition.getNamespace(), typeDefinition.getName());
/* 1326 */     return valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SchemaInformedStartTagGrammar handleAttributes(SchemaInformedGrammar ruleContent, SchemaInformedGrammar ruleContent2, XSObjectList attributes, XSWildcard attributeWC) throws EXIException {
/* 1337 */     SchemaInformedStartTag schemaInformedStartTag = new SchemaInformedStartTag(ruleContent2);
/*      */ 
/*      */     
/* 1340 */     for (int i = 0; i < ruleContent.getNumberOfEvents(); i++) {
/* 1341 */       Production ei = ruleContent.getProduction(i);
/* 1342 */       schemaInformedStartTag.addProduction(ei.getEvent(), ei.getNextGrammar());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1349 */     if (attributeWC != null)
/*      */     {
/* 1351 */       handleAttributeWildCard(attributeWC, (SchemaInformedGrammar)schemaInformedStartTag);
/*      */     }
/*      */     
/* 1354 */     if (attributes != null && attributes.getLength() > 0) {
/*      */       
/* 1356 */       List<XSAttributeUse> vSortedAttributes = new ArrayList<>(); int j;
/* 1357 */       for (j = 0; j < attributes.getLength(); j++) {
/* 1358 */         assert attributes.item(j).getType() == 4;
/* 1359 */         XSAttributeUse attrUse = (XSAttributeUse)attributes.item(j);
/* 1360 */         vSortedAttributes.add(attrUse);
/*      */       } 
/* 1362 */       Collections.sort(vSortedAttributes, attributeUseSort);
/*      */ 
/*      */       
/* 1365 */       for (j = vSortedAttributes.size() - 1; j >= 0; j--) {
/* 1366 */         XSAttributeUse attrUse = vSortedAttributes.get(j);
/*      */         
/* 1368 */         Attribute at = getAttribute(attrUse.getAttrDeclaration());
/*      */         
/* 1370 */         SchemaInformedStartTag schemaInformedStartTag1 = new SchemaInformedStartTag(ruleContent2);
/*      */         
/* 1372 */         schemaInformedStartTag1.addProduction((Event)at, (Grammar)schemaInformedStartTag);
/*      */ 
/*      */ 
/*      */         
/* 1376 */         if (attributeWC != null) {
/* 1377 */           handleAttributeWildCard(attributeWC, (SchemaInformedGrammar)schemaInformedStartTag1);
/*      */         }
/*      */ 
/*      */         
/* 1381 */         if (!attrUse.getRequired())
/*      */         {
/* 1383 */           for (int k = 0; k < schemaInformedStartTag.getNumberOfEvents(); k++) {
/* 1384 */             Production ei = schemaInformedStartTag.getProduction(k);
/* 1385 */             if (!ei.getEvent().isEventType(EventType.ATTRIBUTE_GENERIC) && 
/*      */               
/* 1387 */               !ei.getEvent().isEventType(EventType.ATTRIBUTE_NS))
/*      */             {
/*      */ 
/*      */               
/* 1391 */               schemaInformedStartTag1.addProduction(ei.getEvent(), ei
/* 1392 */                   .getNextGrammar());
/*      */             }
/*      */           } 
/*      */         }
/* 1396 */         schemaInformedStartTag = schemaInformedStartTag1;
/*      */       } 
/*      */     } 
/*      */     
/* 1400 */     return (SchemaInformedStartTagGrammar)schemaInformedStartTag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleAttributeWildCard(XSWildcard attributeWC, SchemaInformedGrammar rule) {
/* 1407 */     short constraintType = attributeWC.getConstraintType();
/* 1408 */     if (constraintType == 1 || constraintType == 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1418 */       rule.addProduction(ATTRIBUTE_GENERIC, (Grammar)rule);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1428 */       StringList sl = attributeWC.getNsConstraintList();
/* 1429 */       for (int k = 0; k < sl.getLength(); k++) {
/* 1430 */         String namespace = sl.item(k);
/*      */         
/* 1432 */         rule.addProduction((Event)createAttributeNS(namespace), (Grammar)rule);
/*      */         
/* 1434 */         addNamespaceStringEntry(namespace);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SchemaInformedFirstStartTagGrammar getTypeGrammar(String namespaceURI, String name) {
/* 1444 */     QName en = new QName(namespaceURI, name);
/* 1445 */     return this.grammarTypes.get(en);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected StartElement translatElementDeclarationToFSA(XSElementDeclaration xsElementDeclaration) throws EXIException {
/* 1451 */     StartElement se = null;
/*      */ 
/*      */     
/* 1454 */     if (this.elementPool.containsKey(xsElementDeclaration)) {
/* 1455 */       return this.elementPool.get(xsElementDeclaration);
/*      */     }
/* 1457 */     String namespaceURI = xsElementDeclaration.getNamespace();
/* 1458 */     String localName = xsElementDeclaration.getName();
/* 1459 */     QName qname = new QName(namespaceURI, localName);
/*      */     
/* 1461 */     se = createStartElement(qname);
/* 1462 */     addLocalNameStringEntry(namespaceURI, localName);
/* 1463 */     this.elementPool.put(xsElementDeclaration, se);
/*      */ 
/*      */ 
/*      */     
/* 1467 */     addLocalNameStringEntry(xsElementDeclaration.getNamespace(), xsElementDeclaration
/* 1468 */         .getName());
/*      */ 
/*      */     
/* 1471 */     XSTypeDefinition td = xsElementDeclaration.getTypeDefinition();
/* 1472 */     SchemaInformedFirstStartTagGrammar type = translateTypeDefinitionToFSA(td);
/*      */     
/* 1474 */     if (type.isNillable() || type.isTypeCastable()) {
/* 1475 */       throw new RuntimeException("Type grammar is nillable or typable, " + type + "\t" + td);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1480 */     if (td.getAnonymous()) {
/*      */       
/* 1482 */       type.setNillable(xsElementDeclaration.getNillable());
/* 1483 */       type.setTypeCastable(isTypeCastable(td));
/* 1484 */       se.setGrammar((Grammar)type);
/*      */ 
/*      */     
/*      */     }
/* 1488 */     else if (xsElementDeclaration.getNillable() || isTypeCastable(td)) {
/*      */ 
/*      */       
/* 1491 */       SchemaInformedFirstStartTagGrammar element = (SchemaInformedFirstStartTagGrammar)type.duplicate();
/* 1492 */       element.setNillable(xsElementDeclaration.getNillable());
/* 1493 */       element.setTypeCastable(isTypeCastable(td));
/* 1494 */       se.setGrammar((Grammar)element);
/*      */     } else {
/*      */       
/* 1497 */       se.setGrammar((Grammar)type);
/*      */     } 
/*      */ 
/*      */     
/* 1501 */     return se;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isTypeCastable(XSTypeDefinition td) {
/* 1560 */     boolean isTypeCastable = false;
/*      */ 
/*      */ 
/*      */     
/* 1564 */     XSNamedMap types = this.xsModel.getComponents((short)3);
/* 1565 */     for (int i = 0; i < types.getLength(); i++) {
/* 1566 */       XSTypeDefinition td2 = (XSTypeDefinition)types.item(i);
/*      */ 
/*      */       
/* 1569 */       if (td.equals(getBaseType(td2))) {
/* 1570 */         isTypeCastable = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1575 */     if (!isTypeCastable && td
/* 1576 */       .getTypeCategory() == 16) {
/* 1577 */       XSSimpleTypeDefinition std = (XSSimpleTypeDefinition)td;
/* 1578 */       isTypeCastable = (std.getVariety() == 3);
/*      */     } 
/*      */     
/* 1581 */     return isTypeCastable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SchemaInformedFirstStartTagGrammar translateTypeDefinitionToFSA(XSTypeDefinition td) throws EXIException {
/* 1599 */     SchemaInformedFirstStartTagGrammar type_i = null;
/* 1600 */     QName typeName = null;
/*      */ 
/*      */ 
/*      */     
/* 1604 */     typeName = new QName(td.getNamespace(), td.getName());
/* 1605 */     if (!td.getAnonymous() && (type_i = this.grammarTypes.get(typeName)) != null) {
/* 1606 */       return type_i;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1611 */     if (td.getTypeCategory() == 15) {
/* 1612 */       XSComplexTypeDefinition ctd = (XSComplexTypeDefinition)td;
/* 1613 */       type_i = translateComplexTypeDefinitionToFSA(ctd);
/*      */     } else {
/* 1615 */       assert td.getTypeCategory() == 16;
/* 1616 */       XSSimpleTypeDefinition std = (XSSimpleTypeDefinition)td;
/* 1617 */       type_i = translateSimpleTypeDefinitionToFSA(std);
/*      */     } 
/*      */     
/* 1620 */     if (!td.getAnonymous()) {
/*      */       
/* 1622 */       addLocalNameStringEntry(td.getNamespace(), td.getName());
/*      */       
/* 1624 */       this.grammarTypes.put(typeName, type_i);
/*      */     } 
/*      */     
/* 1627 */     return type_i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SchemaInformedFirstStartTagGrammar translateComplexTypeDefinitionToFSA(XSComplexTypeDefinition ctd) throws EXIException {
/*      */     SchemaInformedElement schemaInformedElement1;
/*      */     SchemaInformedFirstStartTagGrammar schemaInformedFirstStartTagGrammar;
/*      */     SchemaInformedGrammar schemaInformedGrammar1;
/*      */     XSSimpleTypeDefinition std;
/*      */     SchemaInformedElement schemaInformedElement2;
/*      */     boolean isMixedContent;
/* 1660 */     SchemaInformedGrammar ruleContent = null;
/*      */     
/* 1662 */     switch (ctd.getContentType()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/* 1669 */         schemaInformedElement1 = new SchemaInformedElement();
/* 1670 */         schemaInformedElement1.addTerminalProduction(END_ELEMENT);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/* 1676 */         std = ctd.getSimpleType();
/* 1677 */         schemaInformedFirstStartTagGrammar = translateSimpleTypeDefinitionToFSA(std);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/* 1686 */         isMixedContent = false;
/* 1687 */         schemaInformedGrammar1 = handleParticle(ctd, isMixedContent);
/*      */         break;
/*      */       default:
/* 1690 */         assert ctd.getContentType() == 3;
/*      */ 
/*      */ 
/*      */         
/* 1694 */         isMixedContent = true;
/* 1695 */         schemaInformedGrammar1 = handleParticle(ctd, isMixedContent);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1703 */     SchemaInformedGrammar ruleContent2 = schemaInformedGrammar1.duplicate();
/* 1704 */     if (ruleContent2 instanceof SchemaInformedStartTagGrammar) {
/*      */       
/* 1706 */       SchemaInformedElement sie = new SchemaInformedElement();
/* 1707 */       for (int i = 0; i < ruleContent2.getNumberOfEvents(); i++) {
/* 1708 */         Production p = ruleContent2.getProduction(i);
/* 1709 */         sie.addProduction(p.getEvent(), p.getNextGrammar());
/*      */       } 
/* 1711 */       schemaInformedElement2 = sie;
/*      */     } 
/*      */ 
/*      */     
/* 1715 */     XSObjectList attributes = ctd.getAttributeUses();
/* 1716 */     XSWildcard attributeWC = ctd.getAttributeWildcard();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1721 */     SchemaInformedStartTagGrammar sistr = handleAttributes(schemaInformedGrammar1, (SchemaInformedGrammar)schemaInformedElement2, attributes, attributeWC);
/*      */     
/* 1723 */     SchemaInformedFirstStartTag schemaInformedFirstStartTag1 = new SchemaInformedFirstStartTag(sistr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1728 */     SchemaInformedElement schemaInformedElement3 = new SchemaInformedElement();
/* 1729 */     schemaInformedElement3.addTerminalProduction(END_ELEMENT);
/*      */     
/* 1731 */     SchemaInformedFirstStartTag schemaInformedFirstStartTag2 = new SchemaInformedFirstStartTag(handleAttributes((SchemaInformedGrammar)schemaInformedElement3, (SchemaInformedGrammar)schemaInformedElement3, attributes, attributeWC));
/*      */     
/* 1733 */     schemaInformedFirstStartTag1.setTypeEmpty((SchemaInformedFirstStartTagGrammar)schemaInformedFirstStartTag2);
/*      */     
/* 1735 */     return (SchemaInformedFirstStartTagGrammar)schemaInformedFirstStartTag1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SchemaInformedFirstStartTagGrammar translateSimpleTypeDefinitionToFSA(XSSimpleTypeDefinition std) throws EXIException {
/* 1760 */     Characters chSchemaValid = new Characters(getDatatype(std));
/*      */     
/* 1762 */     SchemaInformedGrammar simpleContentEnd = this.SIMPLE_END_ELEMENT_RULE;
/*      */     
/* 1764 */     SchemaInformedElement simpleContent = new SchemaInformedElement();
/* 1765 */     simpleContent.addProduction((Event)chSchemaValid, (Grammar)simpleContentEnd);
/*      */ 
/*      */ 
/*      */     
/* 1769 */     SchemaInformedFirstStartTag schemaInformedFirstStartTag = new SchemaInformedFirstStartTag(handleAttributes((SchemaInformedGrammar)simpleContent, (SchemaInformedGrammar)simpleContent, (XSObjectList)null, (XSWildcard)null));
/*      */     
/* 1771 */     schemaInformedFirstStartTag.setTypeEmpty(this.SIMPLE_END_ELEMENT_EMPTY_RULE);
/*      */     
/* 1773 */     return (SchemaInformedFirstStartTagGrammar)schemaInformedFirstStartTag;
/*      */   }
/*      */   
/*      */   public Datatype getDatatype(XSSimpleTypeDefinition std) throws EXIException {
/* 1777 */     Datatype datatype = this.datatypePool.get(std);
/*      */     
/* 1779 */     if (datatype != null) {
/* 1780 */       return datatype;
/*      */     }
/*      */ 
/*      */     
/* 1784 */     QName schemaType = getSchemaType(std);
/* 1785 */     QNameContext qncSchemaType = getQNameContext(schemaType
/* 1786 */         .getNamespaceURI(), schemaType.getLocalPart(), this.grammarUriContexts);
/*      */ 
/*      */ 
/*      */     
/* 1790 */     if (std.isDefinedFacet((short)2048)) {
/*      */       
/* 1792 */       XSObjectList facetList = std.getMultiValueFacets();
/* 1793 */       for (int i = 0; i < facetList.getLength(); i++) {
/* 1794 */         XSObject facet = facetList.item(i);
/* 1795 */         if (facet.getType() == 14) {
/* 1796 */           XSMultiValueFacet enumer = (XSMultiValueFacet)facet;
/* 1797 */           if (enumer.getFacetKind() == 2048) {
/* 1798 */             StringList enumList = enumer.getLexicalFacetValues();
/*      */ 
/*      */             
/* 1801 */             XSSimpleTypeDefinition stdEnum = (XSSimpleTypeDefinition)std.getBaseType();
/* 1802 */             while (getDatatype(stdEnum).getBuiltInType() == BuiltInType.ENUMERATION)
/*      */             {
/* 1804 */               stdEnum = (XSSimpleTypeDefinition)stdEnum.getBaseType();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1814 */             if (stdEnum.getVariety() == 3) {
/* 1815 */               StringDatatype stringDatatype = new StringDatatype(qncSchemaType, true);
/* 1816 */             } else if (BuiltIn.XSD_QNAME
/* 1817 */               .equals(getSchemaType(stdEnum)) || BuiltIn.XSD_NOTATION
/*      */               
/* 1819 */               .equals(getSchemaType(stdEnum))) {
/*      */               
/* 1821 */               StringDatatype stringDatatype = new StringDatatype(qncSchemaType, getWhiteSpaceFacet(stdEnum));
/*      */             } else {
/* 1823 */               Datatype dtEnumValues = getDatatype(stdEnum);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1905 */               Value[] values = new Value[enumList.getLength()];
/*      */               
/* 1907 */               BuiltInType enumBIT = dtEnumValues.getBuiltInType();
/*      */ 
/*      */               
/* 1910 */               if (enumBIT == BuiltInType.LIST) {
/* 1911 */                 ListDatatype listDT = (ListDatatype)dtEnumValues;
/* 1912 */                 Datatype dtL = listDT.getListDatatype();
/* 1913 */                 ListDatatype listDatatype1 = new ListDatatype(dtL, qncSchemaType);
/*      */               } else {
/* 1915 */                 for (int k = 0; k < enumList.getLength(); k++) {
/* 1916 */                   BinaryBase64Value binaryBase64Value; BinaryHexValue binaryHexValue; BooleanValue booleanValue; DecimalValue decimalValue; FloatValue floatValue; IntegerValue integerValue; DateTimeValue dateTimeValue; StringValue stringValue; DatetimeDatatype datetimeDT; String tok = enumList.item(k);
/*      */ 
/*      */                   
/* 1919 */                   switch (enumBIT) {
/*      */ 
/*      */                     
/*      */                     case UNSIGNED_INTEGER_BIG:
/* 1923 */                       binaryBase64Value = BinaryBase64Value.parse(tok);
/*      */                       break;
/*      */                     case UNSIGNED_INTEGER_64:
/* 1926 */                       binaryHexValue = BinaryHexValue.parse(tok);
/*      */                       break;
/*      */ 
/*      */                     
/*      */                     case UNSIGNED_INTEGER_32:
/* 1931 */                       booleanValue = BooleanValue.parse(tok);
/*      */                       break;
/*      */                     
/*      */                     case UNSIGNED_INTEGER_16:
/* 1935 */                       decimalValue = DecimalValue.parse(tok);
/*      */                       break;
/*      */                     
/*      */                     case UNSIGNED_INTEGER_8:
/* 1939 */                       floatValue = FloatValue.parse(tok);
/*      */                       break;
/*      */                     
/*      */                     case INTEGER_BIG:
/*      */                     case INTEGER_64:
/*      */                     case INTEGER_32:
/* 1945 */                       integerValue = IntegerValue.parse(tok);
/*      */                       break;
/*      */                     
/*      */                     case INTEGER_16:
/* 1949 */                       datetimeDT = (DatetimeDatatype)dtEnumValues;
/* 1950 */                       dateTimeValue = DateTimeValue.parse(tok, datetimeDT
/* 1951 */                           .getDatetimeType());
/*      */                       break;
/*      */ 
/*      */                     
/*      */                     case INTEGER_8:
/* 1956 */                       throw new RuntimeException("Enumerated values not possible as part of a list");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*      */                     default:
/* 1964 */                       stringValue = new StringValue(tok);
/* 1965 */                       enumBIT = BuiltInType.STRING;
/*      */                       break;
/*      */                   } 
/* 1968 */                   if (stringValue == null) {
/* 1969 */                     throw new RuntimeException("Enum value cannot be parsed properly, " + stringValue + "', " + stdEnum);
/*      */                   }
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 1975 */                   TypedTypeEncoder typedTypeEncoder = new TypedTypeEncoder();
/* 1976 */                   boolean valid = typedTypeEncoder.isValid(dtEnumValues, (Value)stringValue);
/*      */                   
/* 1978 */                   if (!valid) {
/* 1979 */                     throw new RuntimeException("No valid enumeration value '" + stringValue + "', " + stdEnum);
/*      */                   }
/*      */ 
/*      */ 
/*      */                   
/* 1984 */                   values[k] = (Value)stringValue;
/*      */                 } 
/*      */                 
/* 1987 */                 EnumerationDatatype enumerationDatatype = new EnumerationDatatype(values, dtEnumValues, qncSchemaType);
/*      */               }
/*      */             
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/* 1996 */     } else if (std.getVariety() == 2) {
/* 1997 */       XSSimpleTypeDefinition listSTD = std.getItemType();
/*      */       
/* 1999 */       Datatype dtList = getDatatype(listSTD);
/*      */       
/* 2001 */       ListDatatype listDatatype = new ListDatatype(dtList, qncSchemaType);
/*      */     }
/* 2003 */     else if (std.getVariety() == 3) {
/* 2004 */       StringDatatype stringDatatype = new StringDatatype(qncSchemaType, true);
/*      */     } else {
/* 2006 */       datatype = getDatatypeOfType(std, schemaType);
/*      */     } 
/*      */ 
/*      */     
/* 2010 */     XSTypeDefinition baseType = getBaseType((XSTypeDefinition)std);
/* 2011 */     if (baseType != null && baseType
/* 2012 */       .getTypeCategory() == 16) {
/* 2013 */       XSSimpleTypeDefinition stdBaseType = (XSSimpleTypeDefinition)baseType;
/* 2014 */       datatype.setBaseDatatype(getDatatype(stdBaseType));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2026 */     XSObjectList anns = std.getAnnotations();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2040 */     if (anns != null && anns.getLength() > 0) {
/*      */       try {
/* 2042 */         for (int i = 0; i < anns.getLength(); i++) {
/* 2043 */           XSAnnotation ann = (XSAnnotation)anns.get(i);
/* 2044 */           String as = ann.getAnnotationString();
/*      */           
/* 2046 */           XMLReader reader = XMLReaderFactory.createXMLReader();
/* 2047 */           ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*      */           
/* 2049 */           String enumTypeName = "grammarEnumerationType";
/*      */           
/* 2051 */           GrammarAnnotationFilter xmlS = new GrammarAnnotationFilter(baos, enumTypeName);
/*      */           
/* 2053 */           reader.setContentHandler(xmlS);
/*      */           
/* 2055 */           reader.parse(new InputSource(new ByteArrayInputStream(as
/* 2056 */                   .getBytes())));
/*      */           
/* 2058 */           Grammars grs = GrammarFactory.newInstance().createGrammars(new ByteArrayInputStream(baos
/* 2059 */                 .toByteArray()));
/*      */ 
/*      */           
/* 2062 */           SchemaInformedFirstStartTagGrammar tg = grs.getGrammarContext().getGrammarUriContext("").getQNameContext(enumTypeName).getTypeGrammar();
/* 2063 */           Event ev = tg.getProduction(0).getEvent();
/* 2064 */           DatatypeEvent dev = (DatatypeEvent)ev;
/* 2065 */           Datatype dt = dev.getDatatype();
/* 2066 */           if (dt.getBuiltInType() == BuiltInType.ENUMERATION) {
/* 2067 */             EnumerationDatatype edt = (EnumerationDatatype)dt;
/* 2068 */             datatype.setGrammarEnumeration((EnumDatatype)edt);
/*      */           } 
/*      */         } 
/* 2071 */       } catch (Exception exception) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2076 */     this.datatypePool.put(std, datatype);
/*      */     
/* 2078 */     return datatype;
/*      */   }
/*      */ 
/*      */   
/*      */   private QName getXMLSchemaDatatype(XSSimpleTypeDefinition std) {
/* 2083 */     QName exiDatatypeID, primitive = getPrimitive(std);
/*      */ 
/*      */ 
/*      */     
/* 2087 */     if (primitive.equals(BuiltIn.XSD_DECIMAL)) {
/*      */       XSTypeDefinition xSTypeDefinition;
/*      */       
/* 2090 */       XSSimpleTypeDefinition xSSimpleTypeDefinition = std;
/*      */       
/* 2092 */       while (xSSimpleTypeDefinition != null && (xSSimpleTypeDefinition
/* 2093 */         .getName() == null || (
/* 2094 */         !BuiltIn.XSD_INTEGER.equals(getName((XSTypeDefinition)xSSimpleTypeDefinition)) && 
/* 2095 */         !BuiltIn.XSD_NON_NEGATIVE_INTEGER.equals(getName((XSTypeDefinition)xSSimpleTypeDefinition))))) {
/* 2096 */         xSTypeDefinition = xSSimpleTypeDefinition.getBaseType();
/*      */       }
/*      */       
/* 2099 */       if (xSTypeDefinition == null) {
/*      */         
/* 2101 */         exiDatatypeID = BuiltIn.XSD_DECIMAL;
/*      */       } else {
/*      */         
/* 2104 */         exiDatatypeID = BuiltIn.XSD_INTEGER;
/*      */       } 
/*      */     } else {
/* 2107 */       exiDatatypeID = getBuiltInOfPrimitiveMapping(primitive);
/*      */     } 
/*      */     
/* 2110 */     return exiDatatypeID;
/*      */   }
/*      */ 
/*      */   
/*      */   private QName getSchemaType(XSSimpleTypeDefinition std) {
/*      */     String name;
/*      */     String uri;
/* 2117 */     if (std.getAnonymous()) {
/* 2118 */       XSSimpleTypeDefinition xSSimpleTypeDefinition = std; XSTypeDefinition xSTypeDefinition;
/* 2119 */       while ((xSTypeDefinition = xSSimpleTypeDefinition.getBaseType()).getAnonymous());
/*      */       
/* 2121 */       uri = xSTypeDefinition.getNamespace();
/* 2122 */       name = xSTypeDefinition.getName();
/*      */     } else {
/* 2124 */       uri = std.getNamespace();
/* 2125 */       name = std.getName();
/*      */     } 
/*      */     
/* 2128 */     return new QName(uri, name);
/*      */   }
/*      */   private Datatype getIntegerDatatype(XSSimpleTypeDefinition std, QName schemaType) {
/*      */     XSTypeDefinition xSTypeDefinition;
/*      */     IntegerType intType;
/* 2133 */     QNameContext qncSchemaType = getQNameContext(schemaType
/* 2134 */         .getNamespaceURI(), schemaType.getLocalPart(), this.grammarUriContexts);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2140 */     XSSimpleTypeDefinition xSSimpleTypeDefinition = std;
/* 2141 */     while (!"http://www.w3.org/2001/XMLSchema".equals(xSSimpleTypeDefinition.getNamespace())) {
/* 2142 */       xSTypeDefinition = xSSimpleTypeDefinition.getBaseType();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2149 */     if (xSTypeDefinition.getName().equals("integer") || xSTypeDefinition
/* 2150 */       .getName().equals("nonPositiveInteger") || xSTypeDefinition
/* 2151 */       .getName().equals("negativeInteger")) {
/* 2152 */       intType = IntegerType.INTEGER_BIG;
/*      */     
/*      */     }
/* 2155 */     else if (xSTypeDefinition.getName().equals("nonNegativeInteger") || xSTypeDefinition
/* 2156 */       .getName().equals("positiveInteger")) {
/* 2157 */       intType = IntegerType.UNSIGNED_INTEGER_BIG;
/*      */     
/*      */     }
/* 2160 */     else if (xSTypeDefinition.getName().equals("long")) {
/* 2161 */       intType = IntegerType.INTEGER_64;
/*      */     
/*      */     }
/* 2164 */     else if (xSTypeDefinition.getName().equals("unsignedLong")) {
/* 2165 */       intType = IntegerType.UNSIGNED_INTEGER_64;
/*      */     
/*      */     }
/* 2168 */     else if (xSTypeDefinition.getName().equals("int")) {
/* 2169 */       intType = IntegerType.INTEGER_32;
/*      */     
/*      */     }
/* 2172 */     else if (xSTypeDefinition.getName().equals("unsignedInt")) {
/* 2173 */       intType = IntegerType.UNSIGNED_INTEGER_32;
/*      */     
/*      */     }
/* 2176 */     else if (xSTypeDefinition.getName().equals("short")) {
/* 2177 */       intType = IntegerType.INTEGER_16;
/*      */     
/*      */     }
/* 2180 */     else if (xSTypeDefinition.getName().equals("unsignedShort")) {
/* 2181 */       intType = IntegerType.UNSIGNED_INTEGER_16;
/*      */     
/*      */     }
/* 2184 */     else if (xSTypeDefinition.getName().equals("byte")) {
/* 2185 */       intType = IntegerType.INTEGER_8;
/*      */     
/*      */     }
/* 2188 */     else if (xSTypeDefinition.getName().equals("unsignedByte")) {
/* 2189 */       intType = IntegerType.UNSIGNED_INTEGER_8;
/*      */     }
/*      */     else {
/*      */       
/* 2193 */       throw new RuntimeException("Unexpected Integer Type: " + xSTypeDefinition);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2199 */     BigInteger min = new BigInteger("-9999999999999999999999999999999999999999");
/*      */     
/* 2201 */     BigInteger max = new BigInteger("9999999999999999999999999999999999999999");
/*      */ 
/*      */     
/* 2204 */     if (std.isDefinedFacet((short)256)) {
/*      */       
/* 2206 */       String sMinInclusive = std.getLexicalFacetValue((short)256);
/* 2207 */       min = min.max(new BigInteger(sMinInclusive));
/*      */     } 
/* 2209 */     if (std.isDefinedFacet((short)128)) {
/*      */       
/* 2211 */       String sMinExclusive = std.getLexicalFacetValue((short)128);
/* 2212 */       min = min.max((new BigInteger(sMinExclusive)).add(BigInteger.ONE));
/*      */     } 
/*      */     
/* 2215 */     if (std.isDefinedFacet((short)32)) {
/*      */       
/* 2217 */       String sMaxInclusive = std.getLexicalFacetValue((short)32);
/* 2218 */       max = max.min(new BigInteger(sMaxInclusive));
/*      */     } 
/* 2220 */     if (std.isDefinedFacet((short)64)) {
/*      */       
/* 2222 */       String sMaxExclusive = std.getLexicalFacetValue((short)64);
/* 2223 */       max = max.min((new BigInteger(sMaxExclusive))
/* 2224 */           .subtract(BigInteger.ONE));
/*      */     } 
/*      */     
/* 2227 */     assert max.compareTo(min) >= 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2233 */     BigInteger boundedRange = max.subtract(min).add(BigInteger.ONE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2240 */     if (boundedRange.compareTo(
/* 2241 */         BigInteger.valueOf(4096L)) <= 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2248 */       switch (intType) {
/*      */         case UNSIGNED_INTEGER_BIG:
/*      */         case UNSIGNED_INTEGER_64:
/*      */         case UNSIGNED_INTEGER_32:
/*      */         case UNSIGNED_INTEGER_16:
/*      */         case UNSIGNED_INTEGER_8:
/*      */         case INTEGER_BIG:
/*      */         case INTEGER_64:
/*      */         case INTEGER_32:
/*      */         case INTEGER_16:
/*      */         case INTEGER_8:
/* 2259 */           return (Datatype)new NBitUnsignedIntegerDatatype(
/* 2260 */               IntegerValue.valueOf(min), IntegerValue.valueOf(max), qncSchemaType);
/*      */       } 
/*      */ 
/*      */       
/* 2264 */       throw new RuntimeException("Unexpected n-Bit Integer Type: " + intType);
/*      */     } 
/*      */     
/* 2267 */     if (min.signum() >= 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2281 */       switch (intType) {
/*      */         case INTEGER_BIG:
/* 2283 */           intType = IntegerType.UNSIGNED_INTEGER_BIG;
/*      */           break;
/*      */         case INTEGER_64:
/* 2286 */           intType = IntegerType.UNSIGNED_INTEGER_64;
/*      */           break;
/*      */         case INTEGER_32:
/* 2289 */           intType = IntegerType.UNSIGNED_INTEGER_32;
/*      */           break;
/*      */         case INTEGER_16:
/* 2292 */           intType = IntegerType.UNSIGNED_INTEGER_16;
/*      */           break;
/*      */         case INTEGER_8:
/* 2295 */           intType = IntegerType.UNSIGNED_INTEGER_8;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2301 */       switch (intType) {
/*      */         case UNSIGNED_INTEGER_BIG:
/*      */         case UNSIGNED_INTEGER_64:
/*      */         case UNSIGNED_INTEGER_32:
/*      */         case UNSIGNED_INTEGER_16:
/*      */         case UNSIGNED_INTEGER_8:
/* 2307 */           return (Datatype)new UnsignedIntegerDatatype(qncSchemaType);
/*      */       } 
/*      */       
/* 2310 */       throw new RuntimeException("Unexpected Unsigned Integer Type: " + intType);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2317 */     switch (intType) {
/*      */       case INTEGER_BIG:
/*      */       case INTEGER_64:
/*      */       case INTEGER_32:
/*      */       case INTEGER_16:
/*      */       case INTEGER_8:
/* 2323 */         return (Datatype)new IntegerDatatype(qncSchemaType);
/*      */     } 
/*      */     
/* 2326 */     throw new RuntimeException("Unexpected Integer Type: " + intType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private QName getName(XSTypeDefinition type) {
/* 2335 */     return new QName(type.getNamespace(), type.getName());
/*      */   }
/*      */   
/*      */   private Datatype getDatatypeOfType(XSSimpleTypeDefinition std, QName schemaType) {
/*      */     StringDatatype stringDatatype;
/* 2340 */     QNameContext qncSchemaType = getQNameContext(schemaType
/* 2341 */         .getNamespaceURI(), schemaType.getLocalPart(), this.grammarUriContexts);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2346 */     QName schemaDatatype = getXMLSchemaDatatype(std);
/*      */     
/* 2348 */     if (BuiltIn.XSD_BASE64BINARY.equals(schemaDatatype)) {
/* 2349 */       BinaryBase64Datatype binaryBase64Datatype = new BinaryBase64Datatype(qncSchemaType);
/* 2350 */     } else if (BuiltIn.XSD_HEXBINARY.equals(schemaDatatype)) {
/* 2351 */       BinaryHexDatatype binaryHexDatatype = new BinaryHexDatatype(qncSchemaType);
/* 2352 */     } else if (BuiltIn.XSD_BOOLEAN.equals(schemaDatatype)) {
/* 2353 */       if (std.isDefinedFacet((short)8)) {
/* 2354 */         BooleanFacetDatatype booleanFacetDatatype = new BooleanFacetDatatype(qncSchemaType);
/*      */       } else {
/* 2356 */         BooleanDatatype booleanDatatype = new BooleanDatatype(qncSchemaType);
/*      */       } 
/* 2358 */     } else if (BuiltIn.XSD_DATETIME.equals(schemaDatatype)) {
/* 2359 */       QName primitive = getPrimitive(std);
/*      */       
/* 2361 */       if (BuiltIn.XSD_DATETIME.equals(primitive)) {
/* 2362 */         DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.dateTime, qncSchemaType);
/*      */       }
/* 2364 */       else if (BuiltIn.XSD_TIME.equals(primitive)) {
/* 2365 */         DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.time, qncSchemaType);
/*      */       }
/* 2367 */       else if (BuiltIn.XSD_DATE.equals(primitive)) {
/* 2368 */         DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.date, qncSchemaType);
/*      */       }
/* 2370 */       else if (BuiltIn.XSD_GYEARMONTH.equals(primitive)) {
/* 2371 */         DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gYearMonth, qncSchemaType);
/*      */       }
/* 2373 */       else if (BuiltIn.XSD_GYEAR.equals(primitive)) {
/* 2374 */         DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gYear, qncSchemaType);
/*      */       }
/* 2376 */       else if (BuiltIn.XSD_GMONTHDAY.equals(primitive)) {
/* 2377 */         DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gMonthDay, qncSchemaType);
/*      */       }
/* 2379 */       else if (BuiltIn.XSD_GDAY.equals(primitive)) {
/* 2380 */         DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gDay, qncSchemaType);
/*      */       }
/* 2382 */       else if (BuiltIn.XSD_GMONTH.equals(primitive)) {
/* 2383 */         DatetimeDatatype datetimeDatatype = new DatetimeDatatype(DateTimeType.gMonth, qncSchemaType);
/*      */       } else {
/*      */         
/* 2386 */         throw new RuntimeException();
/*      */       } 
/* 2388 */     } else if (BuiltIn.XSD_DECIMAL.equals(schemaDatatype)) {
/* 2389 */       DecimalDatatype decimalDatatype = new DecimalDatatype(qncSchemaType);
/* 2390 */     } else if (BuiltIn.XSD_FLOAT.equals(schemaDatatype) || BuiltIn.XSD_DOUBLE
/* 2391 */       .equals(schemaDatatype)) {
/* 2392 */       FloatDatatype floatDatatype = new FloatDatatype(qncSchemaType);
/* 2393 */     } else if (BuiltIn.XSD_INTEGER.equals(schemaDatatype)) {
/*      */       
/* 2395 */       Datatype datatype = getIntegerDatatype(std, schemaType);
/*      */     
/*      */     }
/* 2398 */     else if (std.isDefinedFacet((short)8)) {
/* 2399 */       StringList sl = std.getLexicalPattern();
/*      */       
/* 2401 */       if (isBuiltInTypeFacet(std, sl.getLength())) {
/*      */ 
/*      */         
/* 2404 */         stringDatatype = new StringDatatype(qncSchemaType, getWhiteSpaceFacet(std));
/*      */       } else {
/*      */         
/* 2407 */         String regexPattern = sl.item(0);
/* 2408 */         EXIRegularExpression re = new EXIRegularExpression(regexPattern);
/*      */ 
/*      */         
/* 2411 */         if (re.isEntireSetOfXMLCharacters()) {
/*      */ 
/*      */           
/* 2414 */           stringDatatype = new StringDatatype(qncSchemaType, getWhiteSpaceFacet(std));
/*      */         }
/*      */         else {
/*      */           
/* 2418 */           CodePointCharacterSet codePointCharacterSet = new CodePointCharacterSet(re.getCodePoints());
/*      */           
/* 2420 */           RestrictedCharacterSetDatatype restrictedCharacterSetDatatype = new RestrictedCharacterSetDatatype((RestrictedCharacterSet)codePointCharacterSet, qncSchemaType, getWhiteSpaceFacet(std));
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 2425 */       stringDatatype = new StringDatatype(qncSchemaType, getWhiteSpaceFacet(std));
/*      */     } 
/*      */ 
/*      */     
/* 2429 */     return (Datatype)stringDatatype;
/*      */   }
/*      */ 
/*      */   
/*      */   private WhiteSpace getWhiteSpaceFacet(XSSimpleTypeDefinition std) {
/* 2434 */     WhiteSpace whiteSpace = WhiteSpace.preserve;
/*      */     
/* 2436 */     boolean hasWSF = std.isDefinedFacet((short)16);
/* 2437 */     if (hasWSF) {
/*      */       
/* 2439 */       XSObject o = std.getFacet(16);
/* 2440 */       XSFacet fac = (XSFacet)o;
/* 2441 */       String fv = fac.getLexicalFacetValue();
/*      */       
/* 2443 */       if ("preserve".equals(fv)) {
/* 2444 */         whiteSpace = WhiteSpace.preserve;
/* 2445 */       } else if ("replace".equals(fv)) {
/* 2446 */         whiteSpace = WhiteSpace.replace;
/* 2447 */       } else if ("collapse".equals(fv)) {
/* 2448 */         whiteSpace = WhiteSpace.collapse;
/*      */       } else {
/* 2450 */         throw new RuntimeException("Unexpected WhiteSpace facet value: " + fv);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2455 */     return whiteSpace;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isBuiltInTypeFacet(XSSimpleTypeDefinition std, int patternListLength) {
/*      */     boolean isBuiltInTypeFacet;
/* 2462 */     XSSimpleTypeDefinition baseType = (XSSimpleTypeDefinition)std.getBaseType();
/*      */ 
/*      */     
/* 2465 */     if (baseType == null || 
/*      */       
/* 2467 */       !baseType.isDefinedFacet((short)8)) {
/*      */       
/* 2469 */       isBuiltInTypeFacet = "http://www.w3.org/2001/XMLSchema".equals(std
/* 2470 */           .getNamespace());
/*      */     }
/* 2472 */     else if (baseType.getLexicalPattern().getLength() < patternListLength) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2477 */       isBuiltInTypeFacet = "http://www.w3.org/2001/XMLSchema".equals(std
/* 2478 */           .getNamespace());
/*      */     } else {
/*      */       
/* 2481 */       isBuiltInTypeFacet = isBuiltInTypeFacet(baseType, patternListLength);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2486 */     return isBuiltInTypeFacet;
/*      */   }
/*      */   
/*      */   private QName getPrimitive(XSSimpleTypeDefinition std) {
/*      */     QName primitiveQName;
/* 2491 */     XSSimpleTypeDefinition primitiveType = std.getPrimitiveType();
/*      */     
/* 2493 */     if (primitiveType == null) {
/*      */       
/* 2495 */       primitiveQName = BuiltIn.XSD_ANY_SIMPLE_TYPE;
/*      */     } else {
/*      */       
/* 2498 */       primitiveQName = new QName(primitiveType.getNamespace(), primitiveType.getName());
/*      */     } 
/*      */     
/* 2501 */     return primitiveQName;
/*      */   }
/*      */   
/*      */   private QName getBuiltInOfPrimitiveMapping(QName qnamePrimitive) {
/* 2505 */     if (this.datatypeMapping.containsKey(qnamePrimitive)) {
/* 2506 */       return this.datatypeMapping.get(qnamePrimitive);
/*      */     }
/* 2508 */     return BuiltIn.DEFAULT_VALUE_NAME;
/*      */   }
/*      */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\XSDGrammarsBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */