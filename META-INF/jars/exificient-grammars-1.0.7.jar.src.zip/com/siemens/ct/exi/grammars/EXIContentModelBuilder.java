/*     */ package com.siemens.ct.exi.grammars;
/*     */ 
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.event.AttributeGeneric;
/*     */ import com.siemens.ct.exi.core.grammars.event.CharactersGeneric;
/*     */ import com.siemens.ct.exi.core.grammars.event.EndElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElementGeneric;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElementNS;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedElement;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedGrammar;
/*     */ import com.siemens.ct.exi.core.util.sort.QNameSort;
/*     */ import com.siemens.ct.exi.core.util.sort.StartElementSort;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.xerces.impl.xs.SchemaGrammar;
/*     */ import org.apache.xerces.impl.xs.SubstitutionGroupHandler;
/*     */ import org.apache.xerces.impl.xs.XMLSchemaLoader;
/*     */ import org.apache.xerces.impl.xs.XSComplexTypeDecl;
/*     */ import org.apache.xerces.impl.xs.XSElementDeclHelper;
/*     */ import org.apache.xerces.impl.xs.models.CMBuilder;
/*     */ import org.apache.xerces.impl.xs.models.CMNodeFactory;
/*     */ import org.apache.xerces.impl.xs.models.XSCMValidator;
/*     */ import org.apache.xerces.util.XMLResourceIdentifierImpl;
/*     */ import org.apache.xerces.xni.QName;
/*     */ import org.apache.xerces.xni.XMLResourceIdentifier;
/*     */ import org.apache.xerces.xni.XNIException;
/*     */ import org.apache.xerces.xni.parser.XMLEntityResolver;
/*     */ import org.apache.xerces.xni.parser.XMLErrorHandler;
/*     */ import org.apache.xerces.xni.parser.XMLInputSource;
/*     */ import org.apache.xerces.xni.parser.XMLParseException;
/*     */ import org.apache.xerces.xs.StringList;
/*     */ import org.apache.xerces.xs.XSAttributeDeclaration;
/*     */ import org.apache.xerces.xs.XSAttributeUse;
/*     */ import org.apache.xerces.xs.XSComplexTypeDefinition;
/*     */ import org.apache.xerces.xs.XSElementDeclaration;
/*     */ import org.apache.xerces.xs.XSModel;
/*     */ import org.apache.xerces.xs.XSModelGroup;
/*     */ import org.apache.xerces.xs.XSNamedMap;
/*     */ import org.apache.xerces.xs.XSObject;
/*     */ import org.apache.xerces.xs.XSObjectList;
/*     */ import org.apache.xerces.xs.XSParticle;
/*     */ import org.apache.xerces.xs.XSTerm;
/*     */ import org.apache.xerces.xs.XSWildcard;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EXIContentModelBuilder
/*     */   extends CMBuilder
/*     */   implements XMLErrorHandler
/*     */ {
/*  92 */   private static final Logger LOGGER = LoggerFactory.getLogger(EXIContentModelBuilder.class);
/*     */   
/*  94 */   protected static final Event END_ELEMENT = (Event)new EndElement();
/*  95 */   protected static final Event START_ELEMENT_GENERIC = (Event)new StartElementGeneric();
/*  96 */   protected static final Event ATTRIBUTE_GENERIC = (Event)new AttributeGeneric();
/*  97 */   protected static final Event CHARACTERS_GENERIC = (Event)new CharactersGeneric();
/*     */   
/*     */   protected static final boolean forUPA = false;
/*     */   
/* 101 */   protected static final XSElementDeclarationSort elementDeclSort = new XSElementDeclarationSort();
/* 102 */   protected static final XSAttributeDeclarationSort attributeDeclSort = new XSAttributeDeclarationSort();
/* 103 */   protected static final XSAttributeUseSort attributeUseSort = new XSAttributeUseSort();
/* 104 */   protected static final StartElementSort startElementSort = new StartElementSort();
/*     */   
/* 106 */   protected static final QNameSort qnameSort = new QNameSort();
/*     */ 
/*     */   
/*     */   protected SubstitutionGroupHandler subGroupHandler;
/*     */   
/*     */   protected XSModel xsModel;
/*     */   
/*     */   protected List<String> schemaParsingErrors;
/*     */   
/*     */   protected Map<XSElementDeclaration, StartElement> elementPool;
/*     */ 
/*     */   
/*     */   public EXIContentModelBuilder() {
/* 119 */     super(new CMNodeFactory());
/*     */   }
/*     */   
/*     */   protected void initOnce() {
/* 123 */     this.elementPool = new HashMap<>();
/* 124 */     this.schemaParsingErrors = new ArrayList<>();
/*     */   }
/*     */   
/*     */   protected void initEachRun() {
/* 128 */     this.elementPool.clear();
/* 129 */     this.schemaParsingErrors.clear();
/*     */   }
/*     */   
/*     */   public void loadGrammars(XMLInputSource xsdSource) throws EXIException {
/* 133 */     loadGrammars(xsdSource, (XMLEntityResolver)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadGrammars(XMLInputSource xsdSource, XMLEntityResolver entityResolver) throws EXIException {
/*     */     try {
/* 139 */       initEachRun();
/*     */ 
/*     */       
/* 142 */       XMLSchemaLoader sl = new XMLSchemaLoader();
/* 143 */       if (entityResolver != null) {
/* 144 */         sl.setEntityResolver(entityResolver);
/*     */       }
/* 146 */       sl.setErrorHandler(this);
/*     */       
/* 148 */       SchemaGrammar g = (SchemaGrammar)sl.loadGrammar(xsdSource);
/*     */ 
/*     */       
/* 151 */       this.xsModel = g.toXSModel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 161 */       this.subGroupHandler = new SubstitutionGroupHandler((XSElementDeclHelper)sl);
/* 162 */     } catch (Exception e) {
/* 163 */       throw new EXIException("XML Schema document (" + xsdSource
/* 164 */           .getSystemId() + ") not found.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void loadXSDTypesOnlyGrammars() throws EXIException {
/* 169 */     String emptySchema = "<schema xmlns='http://www.w3.org/2001/XMLSchema' /> ";
/* 170 */     Reader r = new StringReader(emptySchema);
/*     */ 
/*     */     
/* 173 */     XMLInputSource is = new XMLInputSource(null, null, null, r, null);
/* 174 */     loadGrammars(is, (XMLEntityResolver)null);
/*     */   }
/*     */   
/*     */   public void loadGrammars(String xsdLocation) throws EXIException {
/* 178 */     loadGrammars(xsdLocation, (XMLEntityResolver)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadGrammars(String xsdLocation, XMLEntityResolver entityResolver) throws EXIException {
/* 183 */     XMLInputSource xsdSource = null;
/*     */     
/* 185 */     if (entityResolver != null) {
/* 186 */       XMLResourceIdentifierImpl xMLResourceIdentifierImpl = new XMLResourceIdentifierImpl();
/* 187 */       xMLResourceIdentifierImpl.setLiteralSystemId(xsdLocation);
/*     */       try {
/* 189 */         xsdSource = entityResolver.resolveEntity((XMLResourceIdentifier)xMLResourceIdentifierImpl);
/* 190 */       } catch (Exception exception) {}
/*     */     } 
/*     */     
/* 193 */     if (xsdSource == null) {
/* 194 */       String systemId = xsdLocation;
/* 195 */       String publicId = null;
/* 196 */       String baseSystemId = null;
/* 197 */       xsdSource = new XMLInputSource(publicId, systemId, baseSystemId);
/*     */     } 
/*     */     
/* 200 */     loadGrammars(xsdSource, entityResolver);
/*     */   }
/*     */   
/*     */   public void loadGrammars(InputStream xsdInputStream) throws EXIException {
/* 204 */     loadGrammars(xsdInputStream, (XMLEntityResolver)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadGrammars(InputStream xsdInputStream, XMLEntityResolver entityResolver) throws EXIException {
/* 210 */     String publicId = null;
/* 211 */     String systemId = null;
/* 212 */     String baseSystemId = null;
/* 213 */     String encoding = null;
/* 214 */     XMLInputSource xsdSource = new XMLInputSource(publicId, systemId, baseSystemId, xsdInputStream, encoding);
/*     */     
/* 216 */     loadGrammars(xsdSource, entityResolver);
/*     */   }
/*     */   
/*     */   public XSModel getXSModel() {
/* 220 */     return this.xsModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SchemaInformedGrammar addNewState(Map<CMState, SchemaInformedGrammar> states, CMState key, boolean isMixedContent) {
/* 239 */     SchemaInformedElement schemaInformedElement = new SchemaInformedElement();
/*     */     
/* 241 */     if (key.end) {
/* 242 */       schemaInformedElement.addTerminalProduction(END_ELEMENT);
/*     */     }
/*     */     
/* 245 */     if (isMixedContent) {
/* 246 */       schemaInformedElement.addProduction(CHARACTERS_GENERIC, (Grammar)schemaInformedElement);
/*     */     }
/* 248 */     states.put(key, schemaInformedElement);
/*     */     
/* 250 */     return (SchemaInformedGrammar)schemaInformedElement;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void getMaxOccursUnboundedElements(List<XSElementDeclaration> elementsMaxOccursUnbounded, XSParticle xsParticle) {
/* 256 */     getMaxOccursUnboundedElements(elementsMaxOccursUnbounded, xsParticle, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getMaxOccursUnboundedElements(List<XSElementDeclaration> elementsMaxOccursUnbounded, XSParticle xsParticle, boolean outerUnbounded) {
/* 263 */     XSTerm xsTerm = xsParticle.getTerm();
/*     */     
/* 265 */     if (xsTerm instanceof XSElementDeclaration) {
/* 266 */       XSElementDeclaration xse = (XSElementDeclaration)xsTerm;
/* 267 */       if ((outerUnbounded || xsParticle.getMaxOccursUnbounded()) && 
/* 268 */         !elementsMaxOccursUnbounded.contains(xse)) {
/* 269 */         elementsMaxOccursUnbounded.add(xse);
/*     */       }
/* 271 */     } else if (xsTerm instanceof XSModelGroup) {
/* 272 */       XSModelGroup smg = (XSModelGroup)xsTerm;
/* 273 */       XSObjectList particles = smg.getParticles();
/* 274 */       for (int i = 0; i < particles.getLength(); i++) {
/* 275 */         XSParticle xsp = (XSParticle)particles.item(i);
/* 276 */         getMaxOccursUnboundedElements(elementsMaxOccursUnbounded, xsp, xsParticle
/* 277 */             .getMaxOccursUnbounded());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SchemaInformedGrammar handleParticle(XSComplexTypeDefinition ctd, boolean isMixedContent) throws EXIException {
/* 287 */     XSParticle xsParticle = ctd.getParticle();
/* 288 */     XSTerm xsTerm = xsParticle.getTerm();
/*     */     
/*     */     XSModelGroup mg;
/* 291 */     if (xsTerm instanceof XSModelGroup && (mg = (XSModelGroup)xsTerm)
/* 292 */       .getCompositor() == 3) {
/*     */ 
/*     */ 
/*     */       
/* 296 */       SchemaInformedElement schemaInformedElement = new SchemaInformedElement();
/*     */       
/* 298 */       schemaInformedElement.addTerminalProduction(END_ELEMENT);
/*     */       
/* 300 */       XSObjectList allParticles = mg.getParticles();
/* 301 */       for (int i = 0; i < allParticles.getLength(); i++) {
/* 302 */         XSObject o = allParticles.item(i);
/* 303 */         assert o instanceof XSParticle;
/* 304 */         XSParticle xsp = (XSParticle)o;
/* 305 */         XSTerm tt = xsp.getTerm();
/*     */         
/* 307 */         if (2 == tt.getType()) {
/* 308 */           XSElementDeclaration el = (XSElementDeclaration)tt;
/*     */           
/* 310 */           StartElement se = translatElementDeclarationToFSA(el);
/* 311 */           schemaInformedElement.addProduction((Event)se, (Grammar)schemaInformedElement);
/*     */         } else {
/* 313 */           throw new RuntimeException("No XSElementDeclaration for xsd:all particle, " + tt);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 319 */       return (SchemaInformedGrammar)schemaInformedElement;
/*     */     } 
/*     */     
/* 322 */     XSCMValidator xscmVal = getContentModel((XSComplexTypeDecl)ctd, false);
/*     */ 
/*     */     
/* 325 */     int[] state = xscmVal.startContentModel();
/*     */     
/* 327 */     List<XSObject> possibleElements = xscmVal.whatCanGoHere(state);
/*     */ 
/*     */     
/* 330 */     List<XSElementDeclaration> elementsMaxOccursUnbounded = new ArrayList<>();
/* 331 */     getMaxOccursUnboundedElements(elementsMaxOccursUnbounded, xsParticle);
/*     */ 
/*     */     
/* 334 */     boolean isEnd = xscmVal.endContentModel(state);
/* 335 */     int[] occurenceInfo = xscmVal.occurenceInfo(state);
/*     */     
/* 337 */     CMState startState = new CMState(possibleElements, isEnd, state, elementsMaxOccursUnbounded, occurenceInfo);
/*     */     
/* 339 */     LOGGER.debug("Start = {}", startState);
/*     */     
/* 341 */     Map<CMState, SchemaInformedGrammar> knownStates = new HashMap<>();
/* 342 */     addNewState(knownStates, startState, isMixedContent);
/* 343 */     handleStateEntries(possibleElements, xscmVal, state, startState, knownStates, isMixedContent, elementsMaxOccursUnbounded);
/*     */ 
/*     */     
/* 346 */     return knownStates.get(startState);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract StartElementNS createStartElementNS(String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract StartElement translatElementDeclarationToFSA(XSElementDeclaration paramXSElementDeclaration) throws EXIException;
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleStateEntries(List<XSObject> possibleElements, XSCMValidator xscmVal, int[] originalState, CMState startState, Map<CMState, SchemaInformedGrammar> knownStates, boolean isMixedContent, List<XSElementDeclaration> elementsMaxOccursUnbounded) throws EXIException {
/* 361 */     assert knownStates.containsKey(startState);
/*     */     
/* 363 */     for (int ind = 0; ind < possibleElements.size(); ind++) {
/* 364 */       XSObject xs = possibleElements.get(ind);
/*     */       
/* 366 */       int[] cstate = new int[originalState.length];
/* 367 */       System.arraycopy(originalState, 0, cstate, 0, originalState.length);
/*     */       
/* 369 */       if (xs.getType() == 2) {
/*     */         
/* 371 */         XSElementDeclaration nextEl = (XSElementDeclaration)xs;
/*     */         
/* 373 */         QName qname = new QName(null, nextEl.getName(), null, nextEl.getNamespace());
/*     */         
/* 375 */         Object nextRet = xscmVal.oneTransition(qname, cstate, this.subGroupHandler);
/*     */ 
/*     */ 
/*     */         
/* 379 */         assert xs == nextRet;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 384 */         List<XSObject> nextPossibleElements = xscmVal.whatCanGoHere(cstate);
/* 385 */         boolean isEnd = xscmVal.endContentModel(cstate);
/* 386 */         int[] occurenceInfo = xscmVal.occurenceInfo(cstate);
/*     */ 
/*     */         
/* 389 */         CMState nextState = new CMState(nextPossibleElements, isEnd, cstate, elementsMaxOccursUnbounded, occurenceInfo);
/*     */ 
/*     */         
/* 392 */         printTransition(startState, xs, nextState);
/*     */ 
/*     */ 
/*     */         
/* 396 */         List<XSElementDeclaration> elements = getPossibleElementDeclarations(nextEl);
/* 397 */         assert elements.size() > 0;
/* 398 */         boolean isNewState = false;
/*     */         
/* 400 */         for (int i = 0; i < elements.size(); i++) {
/* 401 */           XSElementDeclaration nextEN = elements.get(i);
/*     */           
/* 403 */           StartElement startElement = translatElementDeclarationToFSA(nextEN);
/* 404 */           if (i == 0) {
/*     */             
/* 406 */             isNewState = handleStateEntry(startState, knownStates, (Event)startElement, nextState, isMixedContent);
/*     */           } else {
/*     */             
/* 409 */             handleStateEntry(startState, knownStates, (Event)startElement, nextState, isMixedContent);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 414 */         if (isNewState) {
/* 415 */           handleStateEntries(nextPossibleElements, xscmVal, cstate, nextState, knownStates, isMixedContent, elementsMaxOccursUnbounded);
/*     */         
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 421 */         assert xs.getType() == 9;
/* 422 */         XSWildcard nextWC = (XSWildcard)xs;
/* 423 */         short constraintType = nextWC.getConstraintType();
/* 424 */         if (constraintType == 1 || constraintType == 2) {
/*     */ 
/*     */           
/* 427 */           QName qname = new QName(null, "##wc", null, "");
/* 428 */           Object nextRet = xscmVal.oneTransition(qname, cstate, this.subGroupHandler);
/*     */ 
/*     */           
/* 431 */           assert xs == nextRet;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 436 */           List<XSObject> nextPossibleElements = xscmVal.whatCanGoHere(cstate);
/* 437 */           boolean isEnd = xscmVal.endContentModel(cstate);
/* 438 */           int[] occurenceInfo = xscmVal.occurenceInfo(cstate);
/* 439 */           CMState nextState = new CMState(nextPossibleElements, isEnd, cstate, elementsMaxOccursUnbounded, occurenceInfo);
/*     */ 
/*     */ 
/*     */           
/* 443 */           printTransition(startState, xs, nextState);
/*     */           
/* 445 */           Event xsEvent = START_ELEMENT_GENERIC;
/*     */           
/* 447 */           boolean isNewState = handleStateEntry(startState, knownStates, xsEvent, nextState, isMixedContent);
/*     */           
/* 449 */           if (isNewState) {
/* 450 */             handleStateEntries(nextPossibleElements, xscmVal, cstate, nextState, knownStates, isMixedContent, elementsMaxOccursUnbounded);
/*     */           
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 456 */           assert constraintType == 3;
/*     */           
/* 458 */           StringList sl = nextWC.getNsConstraintList();
/* 459 */           QName qname = new QName(null, "##wc", null, sl.item(0));
/* 460 */           Object nextRet = xscmVal.oneTransition(qname, cstate, this.subGroupHandler);
/*     */           
/* 462 */           assert xs == nextRet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 468 */           List<XSObject> nextPossibleElements = xscmVal.whatCanGoHere(cstate);
/* 469 */           boolean isEnd = xscmVal.endContentModel(cstate);
/* 470 */           int[] occurenceInfo = xscmVal.occurenceInfo(cstate);
/* 471 */           CMState nextState = new CMState(nextPossibleElements, isEnd, cstate, elementsMaxOccursUnbounded, occurenceInfo);
/*     */ 
/*     */ 
/*     */           
/* 475 */           printTransition(startState, xs, nextState);
/*     */           
/* 477 */           for (int i = 0; i < sl.getLength(); i++) {
/* 478 */             String namespaceURI = sl.item(i);
/* 479 */             addNamespaceStringEntry(namespaceURI);
/*     */             
/* 481 */             StartElementNS startElementNS = createStartElementNS(namespaceURI);
/* 482 */             boolean isNewState = handleStateEntry(startState, knownStates, (Event)startElementNS, nextState, isMixedContent);
/*     */             
/* 484 */             if (isNewState) {
/* 485 */               handleStateEntries(nextPossibleElements, xscmVal, cstate, nextState, knownStates, isMixedContent, elementsMaxOccursUnbounded);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void addLocalNameStringEntry(String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract List<String> addNamespaceStringEntry(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean handleStateEntry(CMState startState, Map<CMState, SchemaInformedGrammar> knownStates, Event xsEvent, CMState nextState, boolean isMixedContent) {
/* 516 */     SchemaInformedGrammar startRule = knownStates.get(startState);
/*     */ 
/*     */     
/* 519 */     if (knownStates.containsKey(nextState)) {
/* 520 */       startRule.addProduction(xsEvent, (Grammar)knownStates.get(nextState));
/* 521 */       return false;
/*     */     } 
/* 523 */     addNewState(knownStates, nextState, isMixedContent);
/* 524 */     startRule.addProduction(xsEvent, (Grammar)knownStates.get(nextState));
/* 525 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<XSElementDeclaration> getPossibleElementDeclarations(XSElementDeclaration el) {
/* 544 */     List<XSElementDeclaration> listElements = new ArrayList<>();
/*     */ 
/*     */     
/* 547 */     listElements.add(el);
/*     */ 
/*     */ 
/*     */     
/* 551 */     XSNamedMap globalElements = this.xsModel.getComponents((short)2);
/*     */     
/* 553 */     if (globalElements != null && globalElements.size() > 0) {
/* 554 */       XSObjectList listSG = this.xsModel.getSubstitutionGroup(el);
/* 555 */       if (listSG != null && listSG.getLength() > 0) {
/* 556 */         for (int i = 0; i < listSG.getLength(); i++) {
/*     */           
/* 558 */           XSElementDeclaration ed = (XSElementDeclaration)listSG.item(i);
/* 559 */           listElements.add(ed);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 565 */     Collections.sort(listElements, elementDeclSort);
/*     */     
/* 567 */     return listElements;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void printTransition(CMState startState, XSObject xs, CMState nextState) {
/* 572 */     LOGGER.debug("\t{} --> {} --> {}", new Object[] { startState, xs, nextState });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String domain, String key, XMLParseException exception) throws XNIException {
/* 580 */     this.schemaParsingErrors.add("[xs-error] " + exception.getMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatalError(String domain, String key, XMLParseException exception) throws XNIException {
/* 585 */     this.schemaParsingErrors.add("[xs-fatalError] " + exception.getMessage());
/*     */   }
/*     */ 
/*     */   
/*     */   public void warning(String domain, String key, XMLParseException exception) throws XNIException {
/* 590 */     this.schemaParsingErrors.add("[xs-warning] " + exception.getMessage());
/*     */   }
/*     */   
/*     */   static class XSElementDeclarationSort
/*     */     implements Comparator<XSElementDeclaration> {
/*     */     public int compare(XSElementDeclaration e1, XSElementDeclaration e2) {
/* 596 */       return QNameSort.compare(e1.getNamespace(), e1.getName(), e2
/* 597 */           .getNamespace(), e2.getName());
/*     */     }
/*     */   }
/*     */   
/*     */   static class XSAttributeDeclarationSort
/*     */     implements Comparator<XSAttributeDeclaration> {
/*     */     public int compare(XSAttributeDeclaration a1, XSAttributeDeclaration a2) {
/* 604 */       return QNameSort.compare(a1.getNamespace(), a1.getName(), a2
/* 605 */           .getNamespace(), a2.getName());
/*     */     }
/*     */   }
/*     */   
/*     */   static class XSAttributeUseSort implements Comparator<XSAttributeUse> {
/*     */     public int compare(XSAttributeUse a1, XSAttributeUse a2) {
/* 611 */       return EXIContentModelBuilder.attributeDeclSort.compare(a1.getAttrDeclaration(), a2
/* 612 */           .getAttrDeclaration());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class CMState
/*     */   {
/*     */     protected final List<XSObject> states;
/*     */     
/*     */     protected final boolean end;
/*     */     
/*     */     protected final int[] state;
/*     */     
/*     */     protected final List<XSElementDeclaration> elementsMaxOccursUnbounded;
/*     */     protected final int[] occurenceInfo;
/*     */     
/*     */     public CMState(List<XSObject> states, boolean end, int[] state, List<XSElementDeclaration> elementsMaxOccursUnbounded, int[] occurenceInfo) {
/* 629 */       this.states = states;
/* 630 */       this.end = end;
/* 631 */       this.elementsMaxOccursUnbounded = elementsMaxOccursUnbounded;
/* 632 */       this.occurenceInfo = occurenceInfo;
/*     */       
/* 634 */       this.state = new int[state.length];
/* 635 */       System.arraycopy(state, 0, this.state, 0, state.length);
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/* 639 */       if (o instanceof CMState) {
/* 640 */         CMState other = (CMState)o;
/* 641 */         if (this.end == other.end && this.states.equals(other.states)) {
/*     */           
/* 643 */           assert this.state.length > 1 && other.state.length > 1;
/*     */ 
/*     */           
/* 646 */           if (this.state[0] == other.state[0] && this.state[1] == other.state[1]) {
/*     */             
/* 648 */             if (this.states.size() == 0 && other.states.size() == 0)
/* 649 */               return true; 
/* 650 */             if (this.state[2] != other.state[2]) {
/*     */               
/* 652 */               for (int i = 0; i < this.states.size(); i++) {
/* 653 */                 XSObject s = this.states.get(i);
/* 654 */                 if (this.elementsMaxOccursUnbounded.contains(s)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 662 */                   if (this.occurenceInfo == null) {
/* 663 */                     return true;
/*     */                   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 672 */                   assert this.occurenceInfo[0] == other.occurenceInfo[0];
/* 673 */                   return (this.occurenceInfo[2] >= this.occurenceInfo[0] && other.occurenceInfo[2] >= this.occurenceInfo[0]);
/*     */                 } 
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 679 */               return false;
/*     */             } 
/* 681 */             return true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 687 */       return false;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 691 */       return (this.end ? "F" : "N") + stateToString() + this.states.toString();
/*     */     }
/*     */     
/*     */     protected String stateToString() {
/* 695 */       StringBuilder s = new StringBuilder();
/* 696 */       s.append('(');
/* 697 */       for (int i = 0; i < this.state.length; i++) {
/* 698 */         s.append(this.state[i]);
/* 699 */         if (i < this.state.length - 1) {
/* 700 */           s.append(',');
/*     */         }
/*     */       } 
/* 703 */       s.append(')');
/*     */       
/* 705 */       return s.toString();
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 709 */       return this.end ? this.states.hashCode() : -this.states.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\EXIContentModelBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */