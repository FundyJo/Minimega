/*     */ package com.siemens.ct.exi.grammars.regex;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIRegularExpression
/*     */   extends RegularExpression
/*     */ {
/*     */   public static final int MAX_NUMBER_OF_CHARACTERS = 255;
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected Set<Integer> set;
/*     */   protected boolean isRestrictedSet;
/*  82 */   static String Letters = "L[ultmo]?";
/*     */   
/*  84 */   static String Marks = "M[nce]?";
/*     */   
/*  86 */   static String Numbers = "N[dlo]?";
/*     */   
/*  88 */   static String Punctuation = "P[cdseifo]?";
/*     */   
/*  90 */   static String Separators = "Z[slp]?";
/*     */   
/*  92 */   static String Symbols = "S[mcko]?";
/*     */   
/*  94 */   static String Others = "C[cfon]?";
/*     */ 
/*     */   
/*  97 */   static String IsCategory = "(" + Letters + ")|(" + Marks + ")|(" + Numbers + ")|(" + Punctuation + ")|(" + Separators + ")|(" + Symbols + ")|(" + Others + ")";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   static String IsBlock = "Is[a-zA-Z0-9-]+";
/*     */   
/* 104 */   static String charProp = "(" + IsCategory + ")|(" + IsBlock + ")";
/*     */   
/* 106 */   static String catEsc = "\\\\p\\{(" + charProp + ")\\}";
/*     */   
/* 108 */   static String complEsc = "\\\\P\\{(" + charProp + ")\\}";
/*     */ 
/*     */   
/* 111 */   static String MultiCharEsc2 = "\\\\[SiIcCdDwW]";
/*     */   
/*     */   public EXIRegularExpression(String regex) {
/* 114 */     super(regex, "X");
/*     */     
/* 116 */     this.set = new HashSet<>();
/* 117 */     this.isRestrictedSet = true;
/*     */ 
/*     */     
/* 120 */     String sanitizedString = regex.replaceAll("[^\000-￿]", "");
/* 121 */     if (sanitizedString.length() != regex.length()) {
/* 122 */       this.isRestrictedSet = false;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 128 */     Pattern pCatEsc = Pattern.compile(catEsc);
/* 129 */     Matcher mCatEsc = pCatEsc.matcher(regex);
/* 130 */     if (mCatEsc.find()) {
/* 131 */       this.isRestrictedSet = false;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 137 */     Pattern pComplexEsc = Pattern.compile(complEsc);
/* 138 */     Matcher mComplexEsc = pComplexEsc.matcher(regex);
/* 139 */     if (mComplexEsc.find()) {
/* 140 */       this.isRestrictedSet = false;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 146 */     Pattern pMultiCharEsc2 = Pattern.compile(MultiCharEsc2);
/* 147 */     Matcher mMultiCharEsc2 = pMultiCharEsc2.matcher(regex);
/* 148 */     while (mMultiCharEsc2.find()) {
/* 149 */       int start = mMultiCharEsc2.start();
/* 150 */       if (start > 0 && regex.charAt(start) == '\\' && regex
/* 151 */         .charAt(start - 1) == '\\') {
/*     */         continue;
/*     */       }
/* 154 */       this.isRestrictedSet = false;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 160 */     handleToken(this.tokentree);
/*     */   }
/*     */   
/*     */   protected void addChar(int cp) {
/* 164 */     this.set.add(Integer.valueOf(cp));
/*     */   }
/*     */   
/*     */   public boolean isEntireSetOfXMLCharacters() {
/* 168 */     return (this.set.isEmpty() || !this.isRestrictedSet || this.set
/* 169 */       .size() > 255);
/*     */   }
/*     */   
/*     */   public Set<Integer> getCodePoints() {
/* 173 */     return this.set; } protected void handleToken(Token t) { Token.CharToken cht; Token.StringToken st; String str; int L; int i; RangeToken rt;
/*     */     int[] ranges;
/*     */     int k;
/*     */     Token.ClosureToken clt;
/*     */     Token.ParenToken pt;
/* 178 */     if (!this.isRestrictedSet || this.set.size() > 255) {
/*     */       return;
/*     */     }
/* 181 */     switch (t.type) {
/*     */       case 11:
/* 183 */         this.isRestrictedSet = false;
/*     */       
/*     */       case 0:
/*     */       case 29:
/*     */       case 30:
/*     */       case 31:
/*     */       case 32:
/*     */       case 33:
/*     */       case 34:
/*     */       case 35:
/*     */       case 36:
/*     */       case 37:
/* 195 */         cht = (Token.CharToken)t;
/* 196 */         addChar(cht.getChar());
/*     */       
/*     */       case 10:
/* 199 */         st = (Token.StringToken)t;
/* 200 */         str = st.getString();
/*     */         
/* 202 */         L = str.codePointCount(0, str.length());
/*     */         
/* 204 */         for (i = 0; i < L; i++) {
/* 205 */           addChar(str.codePointAt(i));
/*     */         }
/*     */       
/*     */       case 4:
/* 209 */         rt = (RangeToken)t;
/* 210 */         ranges = rt.ranges;
/* 211 */         for (k = 0; k < ranges.length; k += 2) {
/*     */           
/* 213 */           if (ranges[k + 1] - ranges[k] > 255) {
/* 214 */             this.isRestrictedSet = false;
/*     */             return;
/*     */           } 
/* 217 */           for (int codePoint = ranges[k]; codePoint <= ranges[k + 1]; codePoint++) {
/* 218 */             addChar(codePoint);
/*     */           }
/*     */         } 
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 224 */         if (t instanceof Token.UnionToken) {
/* 225 */           Token.UnionToken ut = (Token.UnionToken)t;
/*     */           
/* 227 */           Vector<Token> children = ut.children;
/* 228 */           for (int j = 0; j < children.size(); j++) {
/* 229 */             Token subToken = children.get(j);
/* 230 */             handleToken(subToken);
/*     */           } 
/*     */         } else {
/* 233 */           assert t instanceof Token.ConcatToken;
/* 234 */           Token.ConcatToken cot = (Token.ConcatToken)t;
/* 235 */           handleToken(cot.child);
/*     */         } 
/*     */       
/*     */       case 3:
/* 239 */         clt = (Token.ClosureToken)t;
/* 240 */         handleToken(clt.child);
/*     */       
/*     */       case 6:
/* 243 */         pt = (Token.ParenToken)t;
/* 244 */         handleToken(pt.child);
/*     */       
/*     */       case 7:
/*     */         return;
/*     */     } 
/* 249 */     throw new RuntimeException("[EXI] RegExprToken " + t + " not handled!"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 256 */     if (super.equals(obj)) {
/* 257 */       if (!(obj instanceof EXIRegularExpression))
/* 258 */         return false; 
/* 259 */       EXIRegularExpression r = (EXIRegularExpression)obj;
/* 260 */       return this.set.equals(r.set);
/*     */     } 
/* 262 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 274 */     return super.hashCode() ^ this.set.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\EXIRegularExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */