/*      */ package com.siemens.ct.exi.grammars.regex;
/*      */ 
/*      */ import java.util.Locale;
/*      */ import java.util.MissingResourceException;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class RegexParser
/*      */ {
/*      */   static final int T_CHAR = 0;
/*      */   static final int T_EOF = 1;
/*      */   static final int T_OR = 2;
/*      */   static final int T_STAR = 3;
/*      */   static final int T_PLUS = 4;
/*      */   static final int T_QUESTION = 5;
/*      */   static final int T_LPAREN = 6;
/*      */   static final int T_RPAREN = 7;
/*      */   static final int T_DOT = 8;
/*      */   static final int T_LBRACKET = 9;
/*      */   static final int T_BACKSOLIDUS = 10;
/*      */   static final int T_CARET = 11;
/*      */   static final int T_DOLLAR = 12;
/*      */   static final int T_LPAREN2 = 13;
/*      */   static final int T_LOOKAHEAD = 14;
/*      */   static final int T_NEGATIVELOOKAHEAD = 15;
/*      */   static final int T_LOOKBEHIND = 16;
/*      */   static final int T_NEGATIVELOOKBEHIND = 17;
/*      */   static final int T_INDEPENDENT = 18;
/*      */   static final int T_SET_OPERATIONS = 19;
/*      */   static final int T_POSIX_CHARCLASS_START = 20;
/*      */   static final int T_COMMENT = 21;
/*      */   static final int T_MODIFIERS = 22;
/*      */   static final int T_CONDITION = 23;
/*      */   static final int T_XMLSCHEMA_CC_SUBTRACTION = 24;
/*      */   int offset;
/*      */   String regex;
/*      */   int regexlen;
/*      */   int options;
/*      */   ResourceBundle resources;
/*      */   int chardata;
/*      */   int nexttoken;
/*      */   protected static final int S_NORMAL = 0;
/*      */   protected static final int S_INBRACKETS = 1;
/*      */   protected static final int S_INXBRACKETS = 2;
/*      */   
/*      */   static class ReferencePosition
/*      */   {
/*      */     int refNumber;
/*      */     int position;
/*      */     
/*      */     ReferencePosition(int n, int pos) {
/*   74 */       this.refNumber = n;
/*   75 */       this.position = pos;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   89 */   int context = 0;
/*   90 */   int parenOpened = 1;
/*   91 */   int parennumber = 1;
/*      */   boolean hasBackReferences;
/*   93 */   Vector references = null;
/*   94 */   int parenCount = 0;
/*      */   
/*      */   public RegexParser() {
/*   97 */     setLocale(Locale.getDefault());
/*      */   }
/*      */   
/*      */   public RegexParser(Locale locale) {
/*  101 */     setLocale(locale);
/*      */   }
/*      */   
/*      */   public void setLocale(Locale locale) {
/*      */     try {
/*  106 */       if (locale != null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  114 */     catch (MissingResourceException mre) {
/*  115 */       throw new RuntimeException("Installation Problem???  Couldn't load messages: " + mre
/*      */           
/*  117 */           .getMessage());
/*      */     } 
/*      */   }
/*      */   
/*      */   final ParseException ex(String key, int loc) {
/*  122 */     return new ParseException(this.resources.getString(key), loc);
/*      */   }
/*      */   
/*      */   protected final boolean isSet(int flag) {
/*  126 */     return ((this.options & flag) == flag);
/*      */   }
/*      */   
/*      */   synchronized Token parse(String regex, int options) throws ParseException {
/*  130 */     this.options = options;
/*  131 */     this.offset = 0;
/*  132 */     setContext(0);
/*  133 */     this.parennumber = 1;
/*  134 */     this.parenOpened = 1;
/*  135 */     this.hasBackReferences = false;
/*  136 */     this.regex = regex;
/*  137 */     if (isSet(16))
/*  138 */       this.regex = REUtil.stripExtendedComment(this.regex); 
/*  139 */     this.regexlen = this.regex.length();
/*      */     
/*  141 */     next();
/*  142 */     Token ret = parseRegex();
/*  143 */     if (this.offset != this.regexlen)
/*  144 */       throw ex("parser.parse.1", this.offset); 
/*  145 */     if (this.parenCount < 0)
/*  146 */       throw ex("parser.factor.0", this.offset); 
/*  147 */     if (this.references != null) {
/*  148 */       for (int i = 0; i < this.references.size(); i++) {
/*      */         
/*  150 */         ReferencePosition position = this.references.elementAt(i);
/*  151 */         if (this.parennumber <= position.refNumber)
/*  152 */           throw ex("parser.parse.2", position.position); 
/*      */       } 
/*  154 */       this.references.removeAllElements();
/*      */     } 
/*  156 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setContext(int con) {
/*  167 */     this.context = con;
/*      */   }
/*      */   
/*      */   final int read() {
/*  171 */     return this.nexttoken;
/*      */   }
/*      */   final void next() {
/*      */     int ret;
/*  175 */     if (this.offset >= this.regexlen) {
/*  176 */       this.chardata = -1;
/*  177 */       this.nexttoken = 1;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  182 */     int ch = this.regex.charAt(this.offset++);
/*  183 */     this.chardata = ch;
/*      */     
/*  185 */     if (this.context == 1) {
/*      */       int i;
/*      */ 
/*      */       
/*  189 */       switch (ch) {
/*      */         case 92:
/*  191 */           i = 10;
/*  192 */           if (this.offset >= this.regexlen)
/*  193 */             throw ex("parser.next.1", this.offset - 1); 
/*  194 */           this.chardata = this.regex.charAt(this.offset++);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 45:
/*  201 */           if (this.offset < this.regexlen && this.regex
/*  202 */             .charAt(this.offset) == '[') {
/*  203 */             this.offset++;
/*  204 */             i = 24; break;
/*      */           } 
/*  206 */           i = 0;
/*      */           break;
/*      */         
/*      */         case 91:
/*  210 */           if (!isSet(512) && this.offset < this.regexlen && this.regex
/*      */             
/*  212 */             .charAt(this.offset) == ':') {
/*  213 */             this.offset++;
/*  214 */             i = 20;
/*      */             break;
/*      */           } 
/*      */         default:
/*  218 */           if (REUtil.isHighSurrogate(ch) && this.offset < this.regexlen) {
/*  219 */             int low = this.regex.charAt(this.offset);
/*  220 */             if (REUtil.isLowSurrogate(low)) {
/*  221 */               this.chardata = REUtil.composeFromSurrogates(ch, low);
/*  222 */               this.offset++;
/*      */             } 
/*      */           } 
/*  225 */           i = 0; break;
/*      */       } 
/*  227 */       this.nexttoken = i;
/*      */       
/*      */       return;
/*      */     } 
/*  231 */     switch (ch) {
/*      */       case 124:
/*  233 */         ret = 2;
/*      */         break;
/*      */       case 42:
/*  236 */         ret = 3;
/*      */         break;
/*      */       case 43:
/*  239 */         ret = 4;
/*      */         break;
/*      */       case 63:
/*  242 */         ret = 5;
/*      */         break;
/*      */       case 41:
/*  245 */         ret = 7;
/*      */         break;
/*      */       case 46:
/*  248 */         ret = 8;
/*      */         break;
/*      */       case 91:
/*  251 */         ret = 9;
/*      */         break;
/*      */       case 94:
/*  254 */         if (isSet(512)) {
/*  255 */           ret = 0; break;
/*      */         } 
/*  257 */         ret = 11;
/*      */         break;
/*      */       
/*      */       case 36:
/*  261 */         if (isSet(512)) {
/*  262 */           ret = 0; break;
/*      */         } 
/*  264 */         ret = 12;
/*      */         break;
/*      */       
/*      */       case 40:
/*  268 */         ret = 6;
/*  269 */         this.parenCount++;
/*  270 */         if (this.offset >= this.regexlen)
/*      */           break; 
/*  272 */         if (this.regex.charAt(this.offset) != '?')
/*      */           break; 
/*  274 */         if (++this.offset >= this.regexlen)
/*  275 */           throw ex("parser.next.2", this.offset - 1); 
/*  276 */         ch = this.regex.charAt(this.offset++);
/*  277 */         switch (ch) {
/*      */           case 58:
/*  279 */             ret = 13;
/*      */             break;
/*      */           case 61:
/*  282 */             ret = 14;
/*      */             break;
/*      */           case 33:
/*  285 */             ret = 15;
/*      */             break;
/*      */           case 91:
/*  288 */             ret = 19;
/*      */             break;
/*      */           case 62:
/*  291 */             ret = 18;
/*      */             break;
/*      */           case 60:
/*  294 */             if (this.offset >= this.regexlen)
/*  295 */               throw ex("parser.next.2", this.offset - 3); 
/*  296 */             ch = this.regex.charAt(this.offset++);
/*  297 */             if (ch == 61) {
/*  298 */               ret = 16; break;
/*  299 */             }  if (ch == 33) {
/*  300 */               ret = 17; break;
/*      */             } 
/*  302 */             throw ex("parser.next.3", this.offset - 3);
/*      */           
/*      */           case 35:
/*  305 */             while (this.offset < this.regexlen) {
/*  306 */               ch = this.regex.charAt(this.offset++);
/*  307 */               if (ch == 41)
/*      */                 break; 
/*      */             } 
/*  310 */             if (ch != 41)
/*  311 */               throw ex("parser.next.4", this.offset - 1); 
/*  312 */             ret = 21;
/*      */             break;
/*      */         } 
/*  315 */         if (ch == 45 || (97 <= ch && ch <= 122) || (65 <= ch && ch <= 90)) {
/*      */           
/*  317 */           this.offset--;
/*  318 */           ret = 22; break;
/*      */         } 
/*  320 */         if (ch == 40) {
/*  321 */           ret = 23;
/*      */           break;
/*      */         } 
/*  324 */         throw ex("parser.next.2", this.offset - 2);
/*      */ 
/*      */ 
/*      */       
/*      */       case 92:
/*  329 */         ret = 10;
/*  330 */         if (this.offset >= this.regexlen)
/*  331 */           throw ex("parser.next.1", this.offset - 1); 
/*  332 */         this.chardata = this.regex.charAt(this.offset++);
/*      */         break;
/*      */       
/*      */       default:
/*  336 */         ret = 0; break;
/*      */     } 
/*  338 */     this.nexttoken = ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Token parseRegex() throws ParseException {
/*  351 */     Token tok = parseTerm();
/*  352 */     Token parent = null;
/*  353 */     while (read() == 2) {
/*  354 */       next();
/*  355 */       if (parent == null) {
/*  356 */         parent = Token.createUnion();
/*  357 */         parent.addChild(tok);
/*  358 */         tok = parent;
/*      */       } 
/*  360 */       tok.addChild(parseTerm());
/*      */     } 
/*  362 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Token parseTerm() throws ParseException {
/*  369 */     int ch = read();
/*  370 */     Token tok = null;
/*  371 */     if (ch == 2 || ch == 7 || ch == 1) {
/*  372 */       tok = Token.createEmpty();
/*      */     } else {
/*  374 */       tok = parseFactor();
/*  375 */       Token concat = null;
/*  376 */       while ((ch = read()) != 2 && ch != 7 && ch != 1) {
/*  377 */         if (concat == null) {
/*  378 */           concat = Token.createConcat();
/*  379 */           concat.addChild(tok);
/*  380 */           tok = concat;
/*      */         } 
/*  382 */         concat.addChild(parseFactor());
/*      */       } 
/*      */     } 
/*      */     
/*  386 */     if (ch == 7) {
/*  387 */       this.parenCount--;
/*      */     }
/*  389 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Token processCaret() throws ParseException {
/*  395 */     next();
/*  396 */     return Token.token_linebeginning;
/*      */   }
/*      */   
/*      */   Token processDollar() throws ParseException {
/*  400 */     next();
/*  401 */     return Token.token_lineend;
/*      */   }
/*      */   
/*      */   Token processLookahead() throws ParseException {
/*  405 */     next();
/*  406 */     Token tok = Token.createLook(20, parseRegex());
/*  407 */     if (read() != 7)
/*  408 */       throw ex("parser.factor.1", this.offset - 1); 
/*  409 */     next();
/*  410 */     return tok;
/*      */   }
/*      */   
/*      */   Token processNegativelookahead() throws ParseException {
/*  414 */     next();
/*      */     
/*  416 */     Token tok = Token.createLook(21, parseRegex());
/*  417 */     if (read() != 7)
/*  418 */       throw ex("parser.factor.1", this.offset - 1); 
/*  419 */     next();
/*  420 */     return tok;
/*      */   }
/*      */   
/*      */   Token processLookbehind() throws ParseException {
/*  424 */     next();
/*  425 */     Token tok = Token.createLook(22, parseRegex());
/*  426 */     if (read() != 7)
/*  427 */       throw ex("parser.factor.1", this.offset - 1); 
/*  428 */     next();
/*  429 */     return tok;
/*      */   }
/*      */   
/*      */   Token processNegativelookbehind() throws ParseException {
/*  433 */     next();
/*  434 */     Token tok = Token.createLook(23, 
/*  435 */         parseRegex());
/*  436 */     if (read() != 7)
/*  437 */       throw ex("parser.factor.1", this.offset - 1); 
/*  438 */     next();
/*  439 */     return tok;
/*      */   }
/*      */   
/*      */   Token processBacksolidus_A() throws ParseException {
/*  443 */     next();
/*  444 */     return Token.token_stringbeginning;
/*      */   }
/*      */   
/*      */   Token processBacksolidus_Z() throws ParseException {
/*  448 */     next();
/*  449 */     return Token.token_stringend2;
/*      */   }
/*      */   
/*      */   Token processBacksolidus_z() throws ParseException {
/*  453 */     next();
/*  454 */     return Token.token_stringend;
/*      */   }
/*      */   
/*      */   Token processBacksolidus_b() throws ParseException {
/*  458 */     next();
/*  459 */     return Token.token_wordedge;
/*      */   }
/*      */   
/*      */   Token processBacksolidus_B() throws ParseException {
/*  463 */     next();
/*  464 */     return Token.token_not_wordedge;
/*      */   }
/*      */   
/*      */   Token processBacksolidus_lt() throws ParseException {
/*  468 */     next();
/*  469 */     return Token.token_wordbeginning;
/*      */   }
/*      */   
/*      */   Token processBacksolidus_gt() throws ParseException {
/*  473 */     next();
/*  474 */     return Token.token_wordend;
/*      */   }
/*      */   
/*      */   Token processStar(Token tok) throws ParseException {
/*  478 */     next();
/*  479 */     if (read() == 5) {
/*  480 */       next();
/*  481 */       return Token.createNGClosure(tok);
/*      */     } 
/*  483 */     return Token.createClosure(tok);
/*      */   }
/*      */ 
/*      */   
/*      */   Token processPlus(Token tok) throws ParseException {
/*  488 */     next();
/*  489 */     if (read() == 5) {
/*  490 */       next();
/*  491 */       return Token.createConcat(tok, Token.createNGClosure(tok));
/*      */     } 
/*  493 */     return Token.createConcat(tok, Token.createClosure(tok));
/*      */   }
/*      */ 
/*      */   
/*      */   Token processQuestion(Token tok) throws ParseException {
/*  498 */     next();
/*  499 */     Token par = Token.createUnion();
/*  500 */     if (read() == 5) {
/*  501 */       next();
/*  502 */       par.addChild(Token.createEmpty());
/*  503 */       par.addChild(tok);
/*      */     } else {
/*  505 */       par.addChild(tok);
/*  506 */       par.addChild(Token.createEmpty());
/*      */     } 
/*  508 */     return par;
/*      */   }
/*      */   
/*      */   boolean checkQuestion(int off) {
/*  512 */     return (off < this.regexlen && this.regex.charAt(off) == '?');
/*      */   }
/*      */   
/*      */   Token processParen() throws ParseException {
/*  516 */     next();
/*  517 */     int p = this.parenOpened++;
/*  518 */     Token tok = Token.createParen(parseRegex(), p);
/*  519 */     if (read() != 7)
/*  520 */       throw ex("parser.factor.1", this.offset - 1); 
/*  521 */     this.parennumber++;
/*  522 */     next();
/*  523 */     return tok;
/*      */   }
/*      */   
/*      */   Token processParen2() throws ParseException {
/*  527 */     next();
/*  528 */     Token tok = Token.createParen(parseRegex(), 0);
/*  529 */     if (read() != 7)
/*  530 */       throw ex("parser.factor.1", this.offset - 1); 
/*  531 */     next();
/*  532 */     return tok;
/*      */   }
/*      */ 
/*      */   
/*      */   Token processCondition() throws ParseException {
/*  537 */     if (this.offset + 1 >= this.regexlen) {
/*  538 */       throw ex("parser.factor.4", this.offset);
/*      */     }
/*  540 */     int refno = -1;
/*  541 */     Token condition = null;
/*  542 */     int ch = this.regex.charAt(this.offset);
/*  543 */     if (49 <= ch && ch <= 57) {
/*  544 */       refno = ch - 48;
/*  545 */       int finalRefno = refno;
/*      */       
/*  547 */       if (this.parennumber <= refno) {
/*  548 */         throw ex("parser.parse.2", this.offset);
/*      */       }
/*  550 */       while (this.offset + 1 < this.regexlen) {
/*  551 */         ch = this.regex.charAt(this.offset + 1);
/*  552 */         if (49 <= ch && ch <= 57) {
/*  553 */           refno = refno * 10 + ch - 48;
/*  554 */           if (refno < this.parennumber) {
/*  555 */             finalRefno = refno;
/*  556 */             this.offset++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  565 */       this.hasBackReferences = true;
/*  566 */       if (this.references == null)
/*  567 */         this.references = new Vector(); 
/*  568 */       this.references.addElement(new ReferencePosition(finalRefno, this.offset));
/*      */       
/*  570 */       this.offset++;
/*  571 */       if (this.regex.charAt(this.offset) != ')')
/*  572 */         throw ex("parser.factor.1", this.offset); 
/*  573 */       this.offset++;
/*      */     } else {
/*  575 */       if (ch == 63)
/*  576 */         this.offset--; 
/*  577 */       next();
/*  578 */       condition = parseFactor();
/*  579 */       switch (condition.type) {
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */           break;
/*      */         case 8:
/*  586 */           if (read() != 7)
/*  587 */             throw ex("parser.factor.1", this.offset - 1); 
/*      */           break;
/*      */         default:
/*  590 */           throw ex("parser.factor.5", this.offset);
/*      */       } 
/*      */     
/*      */     } 
/*  594 */     next();
/*  595 */     Token yesPattern = parseRegex();
/*  596 */     Token noPattern = null;
/*  597 */     if (yesPattern.type == 2) {
/*  598 */       if (yesPattern.size() != 2)
/*  599 */         throw ex("parser.factor.6", this.offset); 
/*  600 */       noPattern = yesPattern.getChild(1);
/*  601 */       yesPattern = yesPattern.getChild(0);
/*      */     } 
/*  603 */     if (read() != 7)
/*  604 */       throw ex("parser.factor.1", this.offset - 1); 
/*  605 */     next();
/*  606 */     return Token.createCondition(refno, condition, yesPattern, noPattern);
/*      */   }
/*      */ 
/*      */   
/*      */   Token processModifiers() throws ParseException {
/*      */     Token tok;
/*  612 */     int add = 0, mask = 0, ch = -1;
/*  613 */     while (this.offset < this.regexlen) {
/*  614 */       ch = this.regex.charAt(this.offset);
/*  615 */       int v = REUtil.getOptionValue(ch);
/*  616 */       if (v == 0)
/*      */         break; 
/*  618 */       add |= v;
/*  619 */       this.offset++;
/*      */     } 
/*  621 */     if (this.offset >= this.regexlen)
/*  622 */       throw ex("parser.factor.2", this.offset - 1); 
/*  623 */     if (ch == 45) {
/*  624 */       this.offset++;
/*  625 */       while (this.offset < this.regexlen) {
/*  626 */         ch = this.regex.charAt(this.offset);
/*  627 */         int v = REUtil.getOptionValue(ch);
/*  628 */         if (v == 0)
/*      */           break; 
/*  630 */         mask |= v;
/*  631 */         this.offset++;
/*      */       } 
/*  633 */       if (this.offset >= this.regexlen) {
/*  634 */         throw ex("parser.factor.2", this.offset - 1);
/*      */       }
/*      */     } 
/*  637 */     if (ch == 58) {
/*  638 */       this.offset++;
/*  639 */       next();
/*  640 */       tok = Token.createModifierGroup(parseRegex(), add, mask);
/*  641 */       if (read() != 7)
/*  642 */         throw ex("parser.factor.1", this.offset - 1); 
/*  643 */       next();
/*  644 */     } else if (ch == 41) {
/*  645 */       this.offset++;
/*  646 */       next();
/*  647 */       tok = Token.createModifierGroup(parseRegex(), add, mask);
/*      */     } else {
/*  649 */       throw ex("parser.factor.3", this.offset);
/*      */     } 
/*  651 */     return tok;
/*      */   }
/*      */   
/*      */   Token processIndependent() throws ParseException {
/*  655 */     next();
/*  656 */     Token tok = Token.createLook(24, parseRegex());
/*  657 */     if (read() != 7)
/*  658 */       throw ex("parser.factor.1", this.offset - 1); 
/*  659 */     next();
/*  660 */     return tok;
/*      */   }
/*      */   
/*      */   Token processBacksolidus_c() throws ParseException {
/*      */     int ch2;
/*  665 */     if (this.offset >= this.regexlen || ((
/*  666 */       ch2 = this.regex.charAt(this.offset++)) & 0xFFE0) != 64)
/*  667 */       throw ex("parser.atom.1", this.offset - 1); 
/*  668 */     next();
/*  669 */     return Token.createChar(ch2 - 64);
/*      */   }
/*      */   
/*      */   Token processBacksolidus_C() throws ParseException {
/*  673 */     throw ex("parser.process.1", this.offset);
/*      */   }
/*      */   
/*      */   Token processBacksolidus_i() throws ParseException {
/*  677 */     Token tok = Token.createChar(105);
/*  678 */     next();
/*  679 */     return tok;
/*      */   }
/*      */   
/*      */   Token processBacksolidus_I() throws ParseException {
/*  683 */     throw ex("parser.process.1", this.offset);
/*      */   }
/*      */   
/*      */   Token processBacksolidus_g() throws ParseException {
/*  687 */     next();
/*  688 */     return Token.getGraphemePattern();
/*      */   }
/*      */   
/*      */   Token processBacksolidus_X() throws ParseException {
/*  692 */     next();
/*  693 */     return Token.getCombiningCharacterSequence();
/*      */   }
/*      */   
/*      */   Token processBackreference() throws ParseException {
/*  697 */     int refnum = this.chardata - 48;
/*  698 */     int finalRefnum = refnum;
/*      */     
/*  700 */     if (this.parennumber <= refnum) {
/*  701 */       throw ex("parser.parse.2", this.offset - 2);
/*      */     }
/*  703 */     while (this.offset < this.regexlen) {
/*  704 */       int ch = this.regex.charAt(this.offset);
/*  705 */       if (49 <= ch && ch <= 57) {
/*  706 */         refnum = refnum * 10 + ch - 48;
/*  707 */         if (refnum < this.parennumber) {
/*  708 */           this.offset++;
/*  709 */           finalRefnum = refnum;
/*  710 */           this.chardata = ch;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  719 */     Token tok = Token.createBackReference(finalRefnum);
/*  720 */     this.hasBackReferences = true;
/*  721 */     if (this.references == null)
/*  722 */       this.references = new Vector(); 
/*  723 */     this.references.addElement(new ReferencePosition(finalRefnum, this.offset - 2));
/*      */     
/*  725 */     next();
/*  726 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Token parseFactor() throws ParseException {
/*  741 */     int ch = read();
/*      */     
/*  743 */     switch (ch) {
/*      */       case 11:
/*  745 */         return processCaret();
/*      */       case 12:
/*  747 */         return processDollar();
/*      */       case 14:
/*  749 */         return processLookahead();
/*      */       case 15:
/*  751 */         return processNegativelookahead();
/*      */       case 16:
/*  753 */         return processLookbehind();
/*      */       case 17:
/*  755 */         return processNegativelookbehind();
/*      */       
/*      */       case 21:
/*  758 */         next();
/*  759 */         return Token.createEmpty();
/*      */       
/*      */       case 10:
/*  762 */         switch (this.chardata) {
/*      */           case 65:
/*  764 */             return processBacksolidus_A();
/*      */           case 90:
/*  766 */             return processBacksolidus_Z();
/*      */           case 122:
/*  768 */             return processBacksolidus_z();
/*      */           case 98:
/*  770 */             return processBacksolidus_b();
/*      */           case 66:
/*  772 */             return processBacksolidus_B();
/*      */           case 60:
/*  774 */             return processBacksolidus_lt();
/*      */           case 62:
/*  776 */             return processBacksolidus_gt();
/*      */         } 
/*      */         break;
/*      */     } 
/*  780 */     Token tok = parseAtom();
/*  781 */     ch = read();
/*  782 */     switch (ch) {
/*      */       case 3:
/*  784 */         return processStar(tok);
/*      */       case 4:
/*  786 */         return processPlus(tok);
/*      */       case 5:
/*  788 */         return processQuestion(tok);
/*      */       case 0:
/*  790 */         if (this.chardata == 123 && this.offset < this.regexlen) {
/*      */           
/*  792 */           int off = this.offset;
/*  793 */           int min = 0, max = -1;
/*      */           
/*  795 */           if ((ch = this.regex.charAt(off++)) >= 48 && ch <= 57) {
/*      */             
/*  797 */             min = ch - 48;
/*  798 */             while (off < this.regexlen && (
/*  799 */               ch = this.regex.charAt(off++)) >= 48 && ch <= 57) {
/*      */               
/*  801 */               min = min * 10 + ch - 48;
/*  802 */               if (min < 0)
/*  803 */                 throw ex("parser.quantifier.5", this.offset); 
/*      */             } 
/*      */           } else {
/*  806 */             throw ex("parser.quantifier.1", this.offset);
/*      */           } 
/*      */           
/*  809 */           max = min;
/*  810 */           if (ch == 44) {
/*      */             
/*  812 */             if (off >= this.regexlen)
/*  813 */               throw ex("parser.quantifier.3", this.offset); 
/*  814 */             if ((ch = this.regex.charAt(off++)) >= 48 && ch <= 57) {
/*      */ 
/*      */               
/*  817 */               max = ch - 48;
/*  818 */               while (off < this.regexlen && (
/*  819 */                 ch = this.regex.charAt(off++)) >= 48 && ch <= 57) {
/*      */                 
/*  821 */                 max = max * 10 + ch - 48;
/*  822 */                 if (max < 0) {
/*  823 */                   throw ex("parser.quantifier.5", this.offset);
/*      */                 }
/*      */               } 
/*  826 */               if (min > max)
/*  827 */                 throw ex("parser.quantifier.4", this.offset); 
/*      */             } else {
/*  829 */               max = -1;
/*      */             } 
/*      */           } 
/*      */           
/*  833 */           if (ch != 125) {
/*  834 */             throw ex("parser.quantifier.2", this.offset);
/*      */           }
/*  836 */           if (checkQuestion(off)) {
/*  837 */             tok = Token.createNGClosure(tok);
/*  838 */             this.offset = off + 1;
/*      */           } else {
/*  840 */             tok = Token.createClosure(tok);
/*  841 */             this.offset = off;
/*      */           } 
/*      */           
/*  844 */           tok.setMin(min);
/*  845 */           tok.setMax(max);
/*      */           
/*  847 */           next();
/*      */         }  break;
/*      */     } 
/*  850 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Token parseAtom() throws ParseException {
/*  859 */     int ch2, pstart, high, ch = read();
/*  860 */     Token tok = null;
/*  861 */     switch (ch) {
/*      */       case 6:
/*  863 */         return processParen();
/*      */       case 13:
/*  865 */         return processParen2();
/*      */       case 23:
/*  867 */         return processCondition();
/*      */       case 22:
/*  869 */         return processModifiers();
/*      */       case 18:
/*  871 */         return processIndependent();
/*      */       case 8:
/*  873 */         next();
/*  874 */         tok = Token.token_dot;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  975 */         return tok;case 9: return parseCharacterClass(true);case 19: return parseSetOperations();case 10: switch (this.chardata) { case 68: case 83: case 87: case 100: case 115: case 119: tok = getTokenForShorthand(this.chardata); next(); return tok;case 101: case 102: case 110: case 114: case 116: case 117: case 118: case 120: ch2 = decodeEscaped(); if (ch2 < 65536) { tok = Token.createChar(ch2); break; }  tok = Token.createString(REUtil.decomposeToSurrogates(ch2)); break;case 99: return processBacksolidus_c();case 67: return processBacksolidus_C();case 105: return processBacksolidus_i();case 73: return processBacksolidus_I();case 103: return processBacksolidus_g();case 88: return processBacksolidus_X();case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: return processBackreference();case 80: case 112: pstart = this.offset; tok = processBacksolidus_pP(this.chardata); if (tok == null) throw ex("parser.atom.5", pstart);  break;default: tok = Token.createChar(this.chardata); break; }  next(); return tok;case 0: if (this.chardata == 93 || this.chardata == 123 || this.chardata == 125) throw ex("parser.atom.4", this.offset - 1);  tok = Token.createChar(this.chardata); high = this.chardata; next(); if (REUtil.isHighSurrogate(high) && read() == 0 && REUtil.isLowSurrogate(this.chardata)) { char[] sur = new char[2]; sur[0] = (char)high; sur[1] = (char)this.chardata; tok = Token.createParen(Token.createString(new String(sur)), 0); next(); }  return tok;
/*      */     } 
/*      */     throw ex("parser.atom.4", this.offset - 1);
/*      */   }
/*      */   protected RangeToken processBacksolidus_pP(int c) throws ParseException {
/*  980 */     next();
/*  981 */     if (read() != 0 || this.chardata != 123) {
/*  982 */       throw ex("parser.atom.2", this.offset - 1);
/*      */     }
/*      */     
/*  985 */     boolean positive = (c == 112);
/*  986 */     int namestart = this.offset;
/*  987 */     int nameend = this.regex.indexOf('}', namestart);
/*      */     
/*  989 */     if (nameend < 0) {
/*  990 */       throw ex("parser.atom.3", this.offset);
/*      */     }
/*  992 */     String pname = this.regex.substring(namestart, nameend);
/*  993 */     this.offset = nameend + 1;
/*      */     
/*  995 */     return Token.getRange(pname, positive, 
/*  996 */         isSet(512));
/*      */   }
/*      */   
/*      */   int processCIinCharacterClass(RangeToken tok, int c) {
/* 1000 */     return decodeEscaped();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RangeToken parseCharacterClass(boolean useNrange) throws ParseException {
/*      */     RangeToken tok;
/* 1011 */     setContext(1);
/* 1012 */     next();
/* 1013 */     boolean nrange = false;
/* 1014 */     RangeToken base = null;
/*      */     
/* 1016 */     if (read() == 0 && this.chardata == 94) {
/* 1017 */       nrange = true;
/* 1018 */       next();
/* 1019 */       if (useNrange) {
/* 1020 */         tok = Token.createNRange();
/*      */       } else {
/* 1022 */         base = Token.createRange();
/* 1023 */         base.addRange(0, 1114111);
/* 1024 */         tok = Token.createRange();
/*      */       } 
/*      */     } else {
/* 1027 */       tok = Token.createRange();
/*      */     } 
/*      */     
/* 1030 */     boolean firstloop = true; int type;
/* 1031 */     while ((type = read()) != 1 && (
/* 1032 */       type != 0 || this.chardata != 93 || firstloop)) {
/*      */       
/* 1034 */       int c = this.chardata;
/* 1035 */       boolean end = false;
/* 1036 */       if (type == 10) {
/* 1037 */         int pstart; RangeToken tok2; switch (c) {
/*      */           case 68:
/*      */           case 83:
/*      */           case 87:
/*      */           case 100:
/*      */           case 115:
/*      */           case 119:
/* 1044 */             tok.mergeRanges(getTokenForShorthand(c));
/* 1045 */             end = true;
/*      */             break;
/*      */           
/*      */           case 67:
/*      */           case 73:
/*      */           case 99:
/*      */           case 105:
/* 1052 */             c = processCIinCharacterClass(tok, c);
/* 1053 */             if (c < 0) {
/* 1054 */               end = true;
/*      */             }
/*      */             break;
/*      */           case 80:
/*      */           case 112:
/* 1059 */             pstart = this.offset;
/* 1060 */             tok2 = processBacksolidus_pP(c);
/* 1061 */             if (tok2 == null)
/* 1062 */               throw ex("parser.atom.5", pstart); 
/* 1063 */             tok.mergeRanges(tok2);
/* 1064 */             end = true;
/*      */             break;
/*      */           
/*      */           default:
/* 1068 */             c = decodeEscaped();
/*      */             break;
/*      */         } 
/*      */       
/* 1072 */       } else if (type == 20) {
/* 1073 */         int nameend = this.regex.indexOf(':', this.offset);
/* 1074 */         if (nameend < 0)
/* 1075 */           throw ex("parser.cc.1", this.offset); 
/* 1076 */         boolean positive = true;
/* 1077 */         if (this.regex.charAt(this.offset) == '^') {
/* 1078 */           this.offset++;
/* 1079 */           positive = false;
/*      */         } 
/* 1081 */         String name = this.regex.substring(this.offset, nameend);
/* 1082 */         RangeToken range = Token.getRange(name, positive, 
/* 1083 */             isSet(512));
/* 1084 */         if (range == null)
/* 1085 */           throw ex("parser.cc.3", this.offset); 
/* 1086 */         tok.mergeRanges(range);
/* 1087 */         end = true;
/* 1088 */         if (nameend + 1 >= this.regexlen || this.regex
/* 1089 */           .charAt(nameend + 1) != ']')
/* 1090 */           throw ex("parser.cc.1", nameend); 
/* 1091 */         this.offset = nameend + 2;
/* 1092 */       } else if (type == 24 && !firstloop) {
/* 1093 */         if (nrange) {
/* 1094 */           nrange = false;
/* 1095 */           if (useNrange) {
/* 1096 */             tok = (RangeToken)Token.complementRanges(tok);
/*      */           } else {
/* 1098 */             base.subtractRanges(tok);
/* 1099 */             tok = base;
/*      */           } 
/*      */         } 
/* 1102 */         RangeToken range2 = parseCharacterClass(false);
/* 1103 */         tok.subtractRanges(range2);
/* 1104 */         if (read() != 0 || this.chardata != 93) {
/* 1105 */           throw ex("parser.cc.5", this.offset);
/*      */         }
/*      */         break;
/*      */       } 
/* 1109 */       next();
/* 1110 */       if (!end) {
/* 1111 */         if (read() != 0 || this.chardata != 45)
/*      */         
/*      */         { 
/* 1114 */           if (!isSet(2) || c > 65535) {
/*      */             
/* 1116 */             tok.addRange(c, c);
/*      */           } else {
/* 1118 */             addCaseInsensitiveChar(tok, c);
/*      */           }  }
/* 1120 */         else { if (type == 24) {
/* 1121 */             throw ex("parser.cc.8", this.offset - 1);
/*      */           }
/* 1123 */           next();
/* 1124 */           if ((type = read()) == 1)
/* 1125 */             throw ex("parser.cc.2", this.offset); 
/* 1126 */           if (type == 0 && this.chardata == 93) {
/* 1127 */             if (!isSet(2) || c > 65535) {
/*      */               
/* 1129 */               tok.addRange(c, c);
/*      */             } else {
/* 1131 */               addCaseInsensitiveChar(tok, c);
/*      */             } 
/* 1133 */             tok.addRange(45, 45);
/*      */           } else {
/* 1135 */             int rangeend = this.chardata;
/* 1136 */             if (type == 10) {
/* 1137 */               rangeend = decodeEscaped();
/*      */             }
/* 1139 */             next();
/* 1140 */             if (c > rangeend) {
/* 1141 */               throw ex("parser.ope.3", this.offset - 1);
/*      */             }
/* 1143 */             if (!isSet(2) || (c > 65535 && rangeend > 65535)) {
/*      */               
/* 1145 */               tok.addRange(c, rangeend);
/*      */             } else {
/* 1147 */               addCaseInsensitiveCharRange(tok, c, rangeend);
/*      */             } 
/*      */           }  }
/*      */       
/*      */       }
/* 1152 */       if (isSet(1024) && 
/* 1153 */         read() == 0 && this.chardata == 44) {
/* 1154 */         next();
/*      */       }
/* 1156 */       firstloop = false;
/*      */     } 
/* 1158 */     if (read() == 1) {
/* 1159 */       throw ex("parser.cc.2", this.offset);
/*      */     }
/*      */     
/* 1162 */     if (!useNrange && nrange) {
/* 1163 */       base.subtractRanges(tok);
/* 1164 */       tok = base;
/*      */     } 
/* 1166 */     tok.sortRanges();
/* 1167 */     tok.compactRanges();
/* 1168 */     setContext(0);
/* 1169 */     next();
/*      */     
/* 1171 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RangeToken parseSetOperations() throws ParseException {
/* 1178 */     RangeToken tok = parseCharacterClass(false);
/*      */     int type;
/* 1180 */     while ((type = read()) != 7) {
/* 1181 */       int ch = this.chardata;
/* 1182 */       if ((type == 0 && (ch == 45 || ch == 38)) || type == 4) {
/* 1183 */         next();
/* 1184 */         if (read() != 9)
/* 1185 */           throw ex("parser.ope.1", this.offset - 1); 
/* 1186 */         RangeToken t2 = parseCharacterClass(false);
/* 1187 */         if (type == 4) {
/* 1188 */           tok.mergeRanges(t2); continue;
/* 1189 */         }  if (ch == 45) {
/* 1190 */           tok.subtractRanges(t2); continue;
/* 1191 */         }  if (ch == 38) {
/* 1192 */           tok.intersectRanges(t2); continue;
/*      */         } 
/* 1194 */         throw new RuntimeException("ASSERT");
/*      */       } 
/* 1196 */       throw ex("parser.ope.2", this.offset - 1);
/*      */     } 
/*      */     
/* 1199 */     next();
/* 1200 */     return tok;
/*      */   }
/*      */   
/*      */   Token getTokenForShorthand(int ch) {
/*      */     Token tok;
/* 1205 */     switch (ch) {
/*      */       
/*      */       case 100:
/* 1208 */         tok = isSet(32) ? Token.getRange("Nd", true) : Token.token_0to9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1235 */         return tok;case 68: tok = isSet(32) ? Token.getRange("Nd", false) : Token.token_not_0to9; return tok;case 119: tok = isSet(32) ? Token.getRange("IsWord", true) : Token.token_wordchars; return tok;case 87: tok = isSet(32) ? Token.getRange("IsWord", false) : Token.token_not_wordchars; return tok;case 115: tok = isSet(32) ? Token.getRange("IsSpace", true) : Token.token_spaces; return tok;case 83: tok = isSet(32) ? Token.getRange("IsSpace", false) : Token.token_not_spaces; return tok;
/*      */     } 
/*      */     throw new RuntimeException("Internal Error: shorthands: \\u" + Integer.toString(ch, 16));
/*      */   }
/*      */   int decodeEscaped() throws ParseException {
/*      */     int v1, uv;
/* 1241 */     if (read() != 10)
/* 1242 */       throw ex("parser.next.1", this.offset - 1); 
/* 1243 */     int c = this.chardata;
/* 1244 */     switch (c) {
/*      */       case 101:
/* 1246 */         c = 27;
/*      */         break;
/*      */       case 102:
/* 1249 */         c = 12;
/*      */         break;
/*      */       case 110:
/* 1252 */         c = 10;
/*      */         break;
/*      */       case 114:
/* 1255 */         c = 13;
/*      */         break;
/*      */       case 116:
/* 1258 */         c = 9;
/*      */         break;
/*      */       
/*      */       case 120:
/* 1262 */         next();
/* 1263 */         if (read() != 0)
/* 1264 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1265 */         if (this.chardata == 123) {
/* 1266 */           int i = 0;
/* 1267 */           int j = 0;
/*      */           while (true) {
/* 1269 */             next();
/* 1270 */             if (read() != 0)
/* 1271 */               throw ex("parser.descape.1", this.offset - 1); 
/* 1272 */             if ((i = hexChar(this.chardata)) < 0)
/*      */               break; 
/* 1274 */             if (j > j * 16)
/* 1275 */               throw ex("parser.descape.2", this.offset - 1); 
/* 1276 */             j = j * 16 + i;
/*      */           } 
/* 1278 */           if (this.chardata != 125)
/* 1279 */             throw ex("parser.descape.3", this.offset - 1); 
/* 1280 */           if (j > 1114111)
/* 1281 */             throw ex("parser.descape.4", this.offset - 1); 
/* 1282 */           c = j; break;
/*      */         } 
/* 1284 */         v1 = 0;
/* 1285 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1286 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1287 */         uv = v1;
/* 1288 */         next();
/* 1289 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1290 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1291 */         uv = uv * 16 + v1;
/* 1292 */         c = uv;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 117:
/* 1297 */         v1 = 0;
/* 1298 */         next();
/* 1299 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1300 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1301 */         uv = v1;
/* 1302 */         next();
/* 1303 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1304 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1305 */         uv = uv * 16 + v1;
/* 1306 */         next();
/* 1307 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1308 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1309 */         uv = uv * 16 + v1;
/* 1310 */         next();
/* 1311 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1312 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1313 */         uv = uv * 16 + v1;
/* 1314 */         c = uv;
/*      */         break;
/*      */       
/*      */       case 118:
/* 1318 */         next();
/* 1319 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1320 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1321 */         uv = v1;
/* 1322 */         next();
/* 1323 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1324 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1325 */         uv = uv * 16 + v1;
/* 1326 */         next();
/* 1327 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1328 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1329 */         uv = uv * 16 + v1;
/* 1330 */         next();
/* 1331 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1332 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1333 */         uv = uv * 16 + v1;
/* 1334 */         next();
/* 1335 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1336 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1337 */         uv = uv * 16 + v1;
/* 1338 */         next();
/* 1339 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1340 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1341 */         uv = uv * 16 + v1;
/* 1342 */         if (uv > 1114111)
/* 1343 */           throw ex("parser.descappe.4", this.offset - 1); 
/* 1344 */         c = uv;
/*      */         break;
/*      */       case 65:
/*      */       case 90:
/*      */       case 122:
/* 1349 */         throw ex("parser.descape.5", this.offset - 2);
/*      */     } 
/*      */     
/* 1352 */     return c;
/*      */   }
/*      */   
/*      */   private static final int hexChar(int ch) {
/* 1356 */     if (ch < 48)
/* 1357 */       return -1; 
/* 1358 */     if (ch > 102)
/* 1359 */       return -1; 
/* 1360 */     if (ch <= 57)
/* 1361 */       return ch - 48; 
/* 1362 */     if (ch < 65)
/* 1363 */       return -1; 
/* 1364 */     if (ch <= 70)
/* 1365 */       return ch - 65 + 10; 
/* 1366 */     if (ch < 97)
/* 1367 */       return -1; 
/* 1368 */     return ch - 97 + 10;
/*      */   }
/*      */   
/*      */   protected static final void addCaseInsensitiveChar(RangeToken tok, int c) {
/* 1372 */     int[] caseMap = CaseInsensitiveMap.get(c);
/* 1373 */     tok.addRange(c, c);
/*      */     
/* 1375 */     if (caseMap != null) {
/* 1376 */       for (int i = 0; i < caseMap.length; i += 2) {
/* 1377 */         tok.addRange(caseMap[i], caseMap[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final void addCaseInsensitiveCharRange(RangeToken tok, int start, int end) {
/*      */     int r1, r2;
/* 1387 */     if (start <= end) {
/* 1388 */       r1 = start;
/* 1389 */       r2 = end;
/*      */     } else {
/* 1391 */       r1 = end;
/* 1392 */       r2 = start;
/*      */     } 
/*      */     
/* 1395 */     tok.addRange(r1, r2);
/* 1396 */     for (int ch = r1; ch <= r2; ch++) {
/* 1397 */       int[] caseMap = CaseInsensitiveMap.get(ch);
/* 1398 */       if (caseMap != null)
/* 1399 */         for (int i = 0; i < caseMap.length; i += 2)
/* 1400 */           tok.addRange(caseMap[i], caseMap[i]);  
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\RegexParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */