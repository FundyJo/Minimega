/*      */ package com.siemens.ct.exi.grammars.regex;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.text.CharacterIterator;
/*      */ import java.util.Locale;
/*      */ import java.util.Stack;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RegularExpression
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 6242499334195006401L;
/*  589 */   private static final Logger LOGGER = LoggerFactory.getLogger(RegularExpression.class);
/*      */   String regex;
/*      */   int options;
/*      */   int nofparen;
/*      */   Token tokentree;
/*      */   
/*  595 */   private synchronized void compile(Token tok) { if (this.operations != null)
/*      */       return; 
/*  597 */     this.numberOfClosures = 0;
/*  598 */     this.operations = compile(tok, null, false); } private Op compile(Token tok, Op next, boolean reverse) { Op ret; Op.UnionOp uni; int i; Token child;
/*      */     int min;
/*      */     int max;
/*      */     Token.ConditionToken ctok;
/*      */     int ref;
/*      */     Op condition;
/*      */     Op yes;
/*      */     Op no;
/*  606 */     switch (tok.type) {
/*      */       case 11:
/*  608 */         ret = Op.createDot();
/*  609 */         ret.next = next;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  761 */         return ret;case 0: ret = Op.createChar(tok.getChar()); ret.next = next; return ret;case 8: ret = Op.createAnchor(tok.getChar()); ret.next = next; return ret;case 4: case 5: ret = Op.createRange(tok); ret.next = next; return ret;case 1: ret = next; if (!reverse) { for (int j = tok.size() - 1; j >= 0; j--) ret = compile(tok.getChild(j), ret, false);  } else { for (int j = 0; j < tok.size(); j++) ret = compile(tok.getChild(j), ret, true);  }  return ret;case 2: uni = Op.createUnion(tok.size()); for (i = 0; i < tok.size(); i++) uni.addElement(compile(tok.getChild(i), next, reverse));  ret = uni; return ret;case 3: case 9: child = tok.getChild(0); min = tok.getMin(); max = tok.getMax(); if (min >= 0 && min == max) { ret = next; for (int j = 0; j < min; j++) ret = compile(child, ret, reverse);  } else { if (min > 0 && max > 0) max -= min;  if (max > 0) { ret = next; for (int j = 0; j < max; j++) { Op.ChildOp q = Op.createQuestion((tok.type == 9)); q.next = next; q.setChild(compile(child, ret, reverse)); ret = q; }  } else { Op.ChildOp op; if (tok.type == 9) { op = Op.createNonGreedyClosure(); } else { op = Op.createClosure(this.numberOfClosures++); }  op.next = next; op.setChild(compile(child, op, reverse)); ret = op; }  if (min > 0) for (int j = 0; j < min; j++) ret = compile(child, ret, reverse);   }  return ret;case 7: ret = next; return ret;case 10: ret = Op.createString(tok.getString()); ret.next = next; return ret;case 12: ret = Op.createBackReference(tok.getReferenceNumber()); ret.next = next; return ret;case 6: if (tok.getParenNumber() == 0) { ret = compile(tok.getChild(0), next, reverse); } else if (reverse) { next = Op.createCapture(tok.getParenNumber(), next); next = compile(tok.getChild(0), next, reverse); ret = Op.createCapture(-tok.getParenNumber(), next); } else { next = Op.createCapture(-tok.getParenNumber(), next); next = compile(tok.getChild(0), next, reverse); ret = Op.createCapture(tok.getParenNumber(), next); }  return ret;case 20: ret = Op.createLook(20, next, compile(tok.getChild(0), null, false)); return ret;case 21: ret = Op.createLook(21, next, compile(tok.getChild(0), null, false)); return ret;case 22: ret = Op.createLook(22, next, compile(tok.getChild(0), null, true)); return ret;case 23: ret = Op.createLook(23, next, compile(tok.getChild(0), null, true)); return ret;case 24: ret = Op.createIndependent(next, compile(tok.getChild(0), null, reverse)); return ret;case 25: ret = Op.createModifier(next, compile(tok.getChild(0), null, reverse), ((Token.ModifierToken)tok).getOptions(), ((Token.ModifierToken)tok).getOptionsMask()); return ret;case 26: ctok = (Token.ConditionToken)tok; ref = ctok.refNumber; condition = (ctok.condition == null) ? null : compile(ctok.condition, null, reverse); yes = compile(ctok.yes, next, reverse); no = (ctok.no == null) ? null : compile(ctok.no, next, reverse); ret = Op.createCondition(next, ref, condition, yes, no); return ret;
/*      */     } 
/*      */     throw new RuntimeException("Unknown token type: " + tok.type); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(char[] target) {
/*  773 */     return matches(target, 0, target.length, (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(char[] target, int start, int end) {
/*  787 */     return matches(target, start, end, (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(char[] target, Match match) {
/*  800 */     return matches(target, 0, target.length, match);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(char[] target, int start, int end, Match match) {
/*      */     int matchStart;
/*  818 */     synchronized (this) {
/*  819 */       if (this.operations == null)
/*  820 */         prepare(); 
/*  821 */       if (this.context == null)
/*  822 */         this.context = new Context(); 
/*      */     } 
/*  824 */     Context con = null;
/*  825 */     synchronized (this.context) {
/*  826 */       con = this.context.inuse ? new Context() : this.context;
/*  827 */       con.reset(target, start, end, this.numberOfClosures);
/*      */     } 
/*  829 */     if (match != null) {
/*  830 */       match.setNumberOfGroups(this.nofparen);
/*  831 */       match.setSource(target);
/*  832 */     } else if (this.hasBackReferences) {
/*  833 */       match = new Match();
/*  834 */       match.setNumberOfGroups(this.nofparen);
/*      */     } 
/*      */ 
/*      */     
/*  838 */     con.match = match;
/*      */     
/*  840 */     if (isSet(this.options, 512)) {
/*  841 */       int i = match(con, this.operations, con.start, 1, this.options);
/*      */ 
/*      */       
/*  844 */       if (i == con.limit) {
/*  845 */         if (con.match != null) {
/*  846 */           con.match.setBeginning(0, con.start);
/*  847 */           con.match.setEnd(0, i);
/*      */         } 
/*  849 */         con.setInUse(false);
/*  850 */         return true;
/*      */       } 
/*  852 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  858 */     if (this.fixedStringOnly) {
/*      */       
/*  860 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/*  861 */       if (o >= 0) {
/*  862 */         if (con.match != null) {
/*  863 */           con.match.setBeginning(0, o);
/*  864 */           con.match.setEnd(0, o + this.fixedString.length());
/*      */         } 
/*  866 */         con.setInUse(false);
/*  867 */         return true;
/*      */       } 
/*  869 */       con.setInUse(false);
/*  870 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  878 */     if (this.fixedString != null) {
/*  879 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/*  880 */       if (o < 0) {
/*      */         
/*  882 */         con.setInUse(false);
/*  883 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/*  887 */     int limit = con.limit - this.minlength;
/*      */     
/*  889 */     int matchEnd = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  894 */     if (this.operations != null && this.operations.type == 7 && 
/*  895 */       (this.operations.getChild()).type == 0) {
/*  896 */       if (isSet(this.options, 4)) {
/*  897 */         matchStart = con.start;
/*  898 */         matchEnd = match(con, this.operations, con.start, 1, this.options);
/*      */       } else {
/*      */         
/*  901 */         boolean previousIsEOL = true;
/*  902 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/*  903 */           int ch = target[matchStart];
/*  904 */           if (isEOLChar(ch)) {
/*  905 */             previousIsEOL = true;
/*      */           } else {
/*  907 */             if (previousIsEOL && 
/*  908 */               0 <= (matchEnd = match(con, this.operations, matchStart, 1, this.options))) {
/*      */               break;
/*      */             }
/*      */ 
/*      */             
/*  913 */             previousIsEOL = false;
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  922 */     else if (this.firstChar != null) {
/*      */       
/*  924 */       RangeToken range = this.firstChar;
/*  925 */       for (matchStart = con.start; matchStart <= limit; matchStart++) {
/*  926 */         int ch = target[matchStart];
/*  927 */         if (REUtil.isHighSurrogate(ch) && matchStart + 1 < con.limit) {
/*  928 */           ch = REUtil.composeFromSurrogates(ch, target[matchStart + 1]);
/*      */         }
/*      */         
/*  931 */         if (range.match(ch))
/*      */         {
/*      */           
/*  934 */           if (0 <= (matchEnd = match(con, this.operations, matchStart, 1, this.options)))
/*      */           {
/*      */             break;
/*      */           
/*      */           }
/*      */         }
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  945 */       for (matchStart = con.start; matchStart <= limit && 
/*  946 */         0 > (matchEnd = match(con, this.operations, matchStart, 1, this.options)); matchStart++);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  952 */     if (matchEnd >= 0) {
/*  953 */       if (con.match != null) {
/*  954 */         con.match.setBeginning(0, matchStart);
/*  955 */         con.match.setEnd(0, matchEnd);
/*      */       } 
/*  957 */       con.setInUse(false);
/*  958 */       return true;
/*      */     } 
/*  960 */     con.setInUse(false);
/*  961 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(String target) {
/*  972 */     return matches(target, 0, target.length(), (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(String target, int start, int end) {
/*  986 */     return matches(target, start, end, (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(String target, Match match) {
/*  999 */     return matches(target, 0, target.length(), match);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(String target, int start, int end, Match match) {
/*      */     int matchStart;
/* 1017 */     synchronized (this) {
/* 1018 */       if (this.operations == null)
/* 1019 */         prepare(); 
/* 1020 */       if (this.context == null)
/* 1021 */         this.context = new Context(); 
/*      */     } 
/* 1023 */     Context con = null;
/* 1024 */     synchronized (this.context) {
/* 1025 */       con = this.context.inuse ? new Context() : this.context;
/* 1026 */       con.reset(target, start, end, this.numberOfClosures);
/*      */     } 
/* 1028 */     if (match != null) {
/* 1029 */       match.setNumberOfGroups(this.nofparen);
/* 1030 */       match.setSource(target);
/* 1031 */     } else if (this.hasBackReferences) {
/* 1032 */       match = new Match();
/* 1033 */       match.setNumberOfGroups(this.nofparen);
/*      */     } 
/*      */ 
/*      */     
/* 1037 */     con.match = match;
/*      */     
/* 1039 */     if (isSet(this.options, 512)) {
/* 1040 */       LOGGER.debug("target string={}", target);
/* 1041 */       int i = match(con, this.operations, con.start, 1, this.options);
/*      */       
/* 1043 */       LOGGER.debug("matchEnd={}, con.limit={}", Integer.valueOf(i), Integer.valueOf(con.limit));
/* 1044 */       if (i == con.limit) {
/* 1045 */         if (con.match != null) {
/* 1046 */           con.match.setBeginning(0, con.start);
/* 1047 */           con.match.setEnd(0, i);
/*      */         } 
/* 1049 */         con.setInUse(false);
/* 1050 */         return true;
/*      */       } 
/* 1052 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1058 */     if (this.fixedStringOnly) {
/*      */       
/* 1060 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/* 1061 */       if (o >= 0) {
/* 1062 */         if (con.match != null) {
/* 1063 */           con.match.setBeginning(0, o);
/* 1064 */           con.match.setEnd(0, o + this.fixedString.length());
/*      */         } 
/* 1066 */         con.setInUse(false);
/* 1067 */         return true;
/*      */       } 
/* 1069 */       con.setInUse(false);
/* 1070 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1078 */     if (this.fixedString != null) {
/* 1079 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/* 1080 */       if (o < 0) {
/*      */         
/* 1082 */         con.setInUse(false);
/* 1083 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/* 1087 */     int limit = con.limit - this.minlength;
/*      */     
/* 1089 */     int matchEnd = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1094 */     if (this.operations != null && this.operations.type == 7 && 
/* 1095 */       (this.operations.getChild()).type == 0) {
/* 1096 */       if (isSet(this.options, 4)) {
/* 1097 */         matchStart = con.start;
/* 1098 */         matchEnd = match(con, this.operations, con.start, 1, this.options);
/*      */       } else {
/*      */         
/* 1101 */         boolean previousIsEOL = true;
/* 1102 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 1103 */           int ch = target.charAt(matchStart);
/* 1104 */           if (isEOLChar(ch)) {
/* 1105 */             previousIsEOL = true;
/*      */           } else {
/* 1107 */             if (previousIsEOL && 
/* 1108 */               0 <= (matchEnd = match(con, this.operations, matchStart, 1, this.options))) {
/*      */               break;
/*      */             }
/*      */ 
/*      */             
/* 1113 */             previousIsEOL = false;
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1122 */     else if (this.firstChar != null) {
/*      */       
/* 1124 */       RangeToken range = this.firstChar;
/* 1125 */       for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 1126 */         int ch = target.charAt(matchStart);
/* 1127 */         if (REUtil.isHighSurrogate(ch) && matchStart + 1 < con.limit) {
/* 1128 */           ch = REUtil.composeFromSurrogates(ch, target
/* 1129 */               .charAt(matchStart + 1));
/*      */         }
/* 1131 */         if (range.match(ch))
/*      */         {
/*      */           
/* 1134 */           if (0 <= (matchEnd = match(con, this.operations, matchStart, 1, this.options)))
/*      */           {
/*      */             break;
/*      */           
/*      */           }
/*      */         }
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1145 */       for (matchStart = con.start; matchStart <= limit && 
/* 1146 */         0 > (matchEnd = match(con, this.operations, matchStart, 1, this.options)); matchStart++);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1152 */     if (matchEnd >= 0) {
/* 1153 */       if (con.match != null) {
/* 1154 */         con.match.setBeginning(0, matchStart);
/* 1155 */         con.match.setEnd(0, matchEnd);
/*      */       } 
/* 1157 */       con.setInUse(false);
/* 1158 */       return true;
/*      */     } 
/* 1160 */     con.setInUse(false);
/* 1161 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int match(Context con, Op op, int offset, int dx, int opts) {
/* 1170 */     ExpressionTarget target = con.target;
/* 1171 */     Stack<Op> opStack = new Stack();
/* 1172 */     IntStack dataStack = new IntStack();
/* 1173 */     boolean isSetIgnoreCase = isSet(opts, 2);
/* 1174 */     int retValue = -1;
/* 1175 */     boolean returned = false;
/*      */     
/*      */     while (true) {
/* 1178 */       if (op == null || offset > con.limit || offset < con.start) {
/* 1179 */         if (op == null) {
/*      */           
/* 1181 */           retValue = (isSet(opts, 512) && offset != con.limit) ? -1 : offset;
/*      */         } else {
/* 1183 */           retValue = -1;
/*      */         } 
/* 1185 */         returned = true;
/*      */       } else {
/* 1187 */         int o1, i; String literal; int id, refno, localopts; Op.ConditionOp cop; int ch, o2, literallen; RangeToken tok; int j; retValue = -1;
/*      */         
/* 1189 */         switch (op.type) {
/*      */           case 1:
/* 1191 */             o1 = (dx > 0) ? offset : (offset - 1);
/* 1192 */             if (o1 >= con.limit || o1 < 0 || 
/*      */               
/* 1194 */               !matchChar(op.getData(), target.charAt(o1), isSetIgnoreCase)) {
/*      */               
/* 1196 */               returned = true;
/*      */               break;
/*      */             } 
/* 1199 */             offset += dx;
/* 1200 */             op = op.next;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 0:
/* 1205 */             o1 = (dx > 0) ? offset : (offset - 1);
/* 1206 */             if (o1 >= con.limit || o1 < 0) {
/* 1207 */               returned = true;
/*      */               break;
/*      */             } 
/* 1210 */             if (isSet(opts, 4)) {
/* 1211 */               if (REUtil.isHighSurrogate(target.charAt(o1)) && o1 + dx >= 0 && o1 + dx < con.limit)
/*      */               {
/* 1213 */                 o1 += dx;
/*      */               }
/*      */             } else {
/* 1216 */               int k = target.charAt(o1);
/* 1217 */               if (REUtil.isHighSurrogate(k) && o1 + dx >= 0 && o1 + dx < con.limit) {
/*      */                 
/* 1219 */                 o1 += dx;
/* 1220 */                 k = REUtil.composeFromSurrogates(k, target
/* 1221 */                     .charAt(o1));
/*      */               } 
/* 1223 */               if (isEOLChar(k)) {
/* 1224 */                 returned = true;
/*      */                 break;
/*      */               } 
/*      */             } 
/* 1228 */             offset = (dx > 0) ? (o1 + 1) : o1;
/* 1229 */             op = op.next;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 3:
/*      */           case 4:
/* 1235 */             o1 = (dx > 0) ? offset : (offset - 1);
/* 1236 */             if (o1 >= con.limit || o1 < 0) {
/* 1237 */               returned = true;
/*      */               break;
/*      */             } 
/* 1240 */             ch = target.charAt(offset);
/* 1241 */             if (REUtil.isHighSurrogate(ch) && o1 + dx < con.limit && o1 + dx >= 0) {
/*      */               
/* 1243 */               o1 += dx;
/*      */               
/* 1245 */               ch = REUtil.composeFromSurrogates(ch, target.charAt(o1));
/*      */             } 
/* 1247 */             tok = op.getToken();
/* 1248 */             if (!tok.match(ch)) {
/* 1249 */               returned = true;
/*      */               break;
/*      */             } 
/* 1252 */             offset = (dx > 0) ? (o1 + 1) : o1;
/* 1253 */             op = op.next;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 5:
/* 1258 */             if (!matchAnchor(target, op, con, offset, opts)) {
/* 1259 */               returned = true;
/*      */               break;
/*      */             } 
/* 1262 */             op = op.next;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 16:
/* 1267 */             i = op.getData();
/* 1268 */             if (i <= 0 || i >= this.nofparen) {
/* 1269 */               throw new RuntimeException("Internal Error: Reference number must be more than zero: " + i);
/*      */             }
/*      */ 
/*      */             
/* 1273 */             if (con.match.getBeginning(i) < 0 || con.match
/* 1274 */               .getEnd(i) < 0) {
/* 1275 */               returned = true;
/*      */               break;
/*      */             } 
/* 1278 */             o2 = con.match.getBeginning(i);
/* 1279 */             j = con.match.getEnd(i) - o2;
/* 1280 */             if (dx > 0) {
/* 1281 */               if (!target.regionMatches(isSetIgnoreCase, offset, con.limit, o2, j)) {
/*      */                 
/* 1283 */                 returned = true;
/*      */                 break;
/*      */               } 
/* 1286 */               offset += j;
/*      */             } else {
/* 1288 */               if (!target.regionMatches(isSetIgnoreCase, offset - j, con.limit, o2, j)) {
/*      */                 
/* 1290 */                 returned = true;
/*      */                 break;
/*      */               } 
/* 1293 */               offset -= j;
/*      */             } 
/* 1295 */             op = op.next;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 6:
/* 1300 */             literal = op.getString();
/* 1301 */             literallen = literal.length();
/* 1302 */             if (dx > 0) {
/* 1303 */               if (!target.regionMatches(isSetIgnoreCase, offset, con.limit, literal, literallen)) {
/*      */                 
/* 1305 */                 returned = true;
/*      */                 break;
/*      */               } 
/* 1308 */               offset += literallen;
/*      */             } else {
/* 1310 */               if (!target.regionMatches(isSetIgnoreCase, offset - literallen, con.limit, literal, literallen)) {
/*      */                 
/* 1312 */                 returned = true;
/*      */                 break;
/*      */               } 
/* 1315 */               offset -= literallen;
/*      */             } 
/* 1317 */             op = op.next;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 7:
/* 1323 */             id = op.getData();
/* 1324 */             if (con.closureContexts[id].contains(offset)) {
/* 1325 */               returned = true;
/*      */               
/*      */               break;
/*      */             } 
/* 1329 */             con.closureContexts[id].addOffset(offset);
/*      */ 
/*      */ 
/*      */           
/*      */           case 9:
/* 1334 */             opStack.push(op);
/* 1335 */             dataStack.push(offset);
/* 1336 */             op = op.getChild();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */           case 10:
/* 1342 */             opStack.push(op);
/* 1343 */             dataStack.push(offset);
/* 1344 */             op = op.next;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 11:
/* 1349 */             if (op.size() == 0) {
/* 1350 */               returned = true; break;
/*      */             } 
/* 1352 */             opStack.push(op);
/* 1353 */             dataStack.push(0);
/* 1354 */             dataStack.push(offset);
/* 1355 */             op = op.elementAt(0);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 15:
/* 1360 */             refno = op.getData();
/* 1361 */             if (con.match != null) {
/* 1362 */               if (refno > 0) {
/* 1363 */                 dataStack.push(con.match.getBeginning(refno));
/* 1364 */                 con.match.setBeginning(refno, offset);
/*      */               } else {
/* 1366 */                 int index = -refno;
/* 1367 */                 dataStack.push(con.match.getEnd(index));
/* 1368 */                 con.match.setEnd(index, offset);
/*      */               } 
/* 1370 */               opStack.push(op);
/* 1371 */               dataStack.push(offset);
/*      */             } 
/* 1373 */             op = op.next;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/* 1381 */             opStack.push(op);
/* 1382 */             dataStack.push(dx);
/* 1383 */             dataStack.push(offset);
/*      */             
/* 1385 */             dx = (op.type == 20 || op.type == 21) ? 1 : -1;
/* 1386 */             op = op.getChild();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 24:
/* 1391 */             opStack.push(op);
/* 1392 */             dataStack.push(offset);
/* 1393 */             op = op.getChild();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 25:
/* 1398 */             localopts = opts;
/* 1399 */             localopts |= op.getData();
/* 1400 */             localopts &= op.getData2() ^ 0xFFFFFFFF;
/* 1401 */             opStack.push(op);
/* 1402 */             dataStack.push(opts);
/* 1403 */             dataStack.push(offset);
/* 1404 */             opts = localopts;
/* 1405 */             op = op.getChild();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 26:
/* 1410 */             cop = (Op.ConditionOp)op;
/* 1411 */             if (cop.refNumber > 0) {
/* 1412 */               if (cop.refNumber >= this.nofparen) {
/* 1413 */                 throw new RuntimeException("Internal Error: Reference number must be more than zero: " + cop.refNumber);
/*      */               }
/*      */ 
/*      */               
/* 1417 */               if (con.match.getBeginning(cop.refNumber) >= 0 && con.match
/* 1418 */                 .getEnd(cop.refNumber) >= 0) {
/* 1419 */                 op = cop.yes; break;
/* 1420 */               }  if (cop.no != null) {
/* 1421 */                 op = cop.no; break;
/*      */               } 
/* 1423 */               op = cop.next;
/*      */               break;
/*      */             } 
/* 1426 */             opStack.push(op);
/* 1427 */             dataStack.push(offset);
/* 1428 */             op = cop.condition;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 1434 */             throw new RuntimeException("Unknown operation type: " + op.type);
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/* 1440 */       while (returned) {
/*      */         int unionIndex, refno, saved; Op.ConditionOp cop;
/* 1442 */         if (opStack.isEmpty()) {
/* 1443 */           return retValue;
/*      */         }
/*      */         
/* 1446 */         op = opStack.pop();
/* 1447 */         offset = dataStack.pop();
/*      */         
/* 1449 */         switch (op.type) {
/*      */           case 7:
/*      */           case 9:
/* 1452 */             if (retValue < 0) {
/* 1453 */               op = op.next;
/* 1454 */               returned = false;
/*      */             } 
/*      */ 
/*      */           
/*      */           case 8:
/*      */           case 10:
/* 1460 */             if (retValue < 0) {
/* 1461 */               op = op.getChild();
/* 1462 */               returned = false;
/*      */             } 
/*      */ 
/*      */           
/*      */           case 11:
/* 1467 */             unionIndex = dataStack.pop();
/* 1468 */             LOGGER.debug("UNION={}, ret={}", Integer.valueOf(unionIndex), Integer.valueOf(retValue));
/*      */             
/* 1470 */             if (retValue < 0) {
/* 1471 */               if (++unionIndex < op.size()) {
/* 1472 */                 opStack.push(op);
/* 1473 */                 dataStack.push(unionIndex);
/* 1474 */                 dataStack.push(offset);
/* 1475 */                 op = op.elementAt(unionIndex);
/* 1476 */                 returned = false; continue;
/*      */               } 
/* 1478 */               retValue = -1;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 15:
/* 1485 */             refno = op.getData();
/* 1486 */             saved = dataStack.pop();
/* 1487 */             if (retValue < 0) {
/* 1488 */               if (refno > 0) {
/* 1489 */                 con.match.setBeginning(refno, saved); continue;
/*      */               } 
/* 1491 */               con.match.setEnd(-refno, saved);
/*      */             } 
/*      */ 
/*      */ 
/*      */           
/*      */           case 20:
/*      */           case 22:
/* 1498 */             dx = dataStack.pop();
/* 1499 */             if (0 <= retValue) {
/* 1500 */               op = op.next;
/* 1501 */               returned = false;
/*      */             } 
/* 1503 */             retValue = -1;
/*      */ 
/*      */ 
/*      */           
/*      */           case 21:
/*      */           case 23:
/* 1509 */             dx = dataStack.pop();
/* 1510 */             if (0 > retValue) {
/* 1511 */               op = op.next;
/* 1512 */               returned = false;
/*      */             } 
/* 1514 */             retValue = -1;
/*      */ 
/*      */ 
/*      */           
/*      */           case 25:
/* 1519 */             opts = dataStack.pop();
/*      */ 
/*      */           
/*      */           case 24:
/* 1523 */             if (retValue >= 0) {
/* 1524 */               offset = retValue;
/* 1525 */               op = op.next;
/* 1526 */               returned = false;
/*      */             } 
/*      */ 
/*      */           
/*      */           case 26:
/* 1531 */             cop = (Op.ConditionOp)op;
/* 1532 */             if (0 <= retValue) {
/* 1533 */               op = cop.yes;
/* 1534 */             } else if (cop.no != null) {
/* 1535 */               op = cop.no;
/*      */             } else {
/* 1537 */               op = cop.next;
/*      */             } 
/*      */             
/* 1540 */             returned = false;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean matchChar(int ch, int other, boolean ignoreCase) {
/* 1551 */     return ignoreCase ? matchIgnoreCase(ch, other) : ((ch == other));
/*      */   }
/*      */   
/*      */   boolean matchAnchor(ExpressionTarget target, Op op, Context con, int offset, int opts) {
/*      */     int after, before;
/* 1556 */     boolean go = false;
/* 1557 */     switch (op.getData()) {
/*      */       case 94:
/* 1559 */         if (isSet(opts, 8)) {
/* 1560 */           if (offset != con.start && (offset <= con.start || offset >= con.limit || 
/*      */             
/* 1562 */             !isEOLChar(target.charAt(offset - 1))))
/* 1563 */             return false;  break;
/*      */         } 
/* 1565 */         if (offset != con.start) {
/* 1566 */           return false;
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 64:
/* 1572 */         if (offset != con.start && (offset <= con.start || 
/* 1573 */           !isEOLChar(target.charAt(offset - 1)))) {
/* 1574 */           return false;
/*      */         }
/*      */         break;
/*      */       case 36:
/* 1578 */         if (isSet(opts, 8)) {
/* 1579 */           if (offset != con.limit && (offset >= con.limit || 
/* 1580 */             !isEOLChar(target.charAt(offset))))
/* 1581 */             return false;  break;
/*      */         } 
/* 1583 */         if (offset != con.limit && (offset + 1 != con.limit || 
/* 1584 */           !isEOLChar(target.charAt(offset))) && (offset + 2 != con.limit || target
/* 1585 */           .charAt(offset) != '\r' || target
/* 1586 */           .charAt(offset + 1) != '\n')) {
/* 1587 */           return false;
/*      */         }
/*      */         break;
/*      */       
/*      */       case 65:
/* 1592 */         if (offset != con.start) {
/* 1593 */           return false;
/*      */         }
/*      */         break;
/*      */       case 90:
/* 1597 */         if (offset != con.limit && (offset + 1 != con.limit || 
/* 1598 */           !isEOLChar(target.charAt(offset))) && (offset + 2 != con.limit || target
/* 1599 */           .charAt(offset) != '\r' || target
/* 1600 */           .charAt(offset + 1) != '\n')) {
/* 1601 */           return false;
/*      */         }
/*      */         break;
/*      */       case 122:
/* 1605 */         if (offset != con.limit) {
/* 1606 */           return false;
/*      */         }
/*      */         break;
/*      */       case 98:
/* 1610 */         if (con.length == 0) {
/* 1611 */           return false;
/*      */         }
/* 1613 */         after = getWordType(target, con.start, con.limit, offset, opts);
/*      */         
/* 1615 */         if (after == 0)
/* 1616 */           return false; 
/* 1617 */         before = getPreviousWordType(target, con.start, con.limit, offset, opts);
/*      */         
/* 1619 */         if (after == before) {
/* 1620 */           return false;
/*      */         }
/*      */         break;
/*      */       
/*      */       case 66:
/* 1625 */         if (con.length == 0) {
/* 1626 */           go = true;
/*      */         } else {
/* 1628 */           after = getWordType(target, con.start, con.limit, offset, opts);
/*      */ 
/*      */           
/* 1631 */           go = (after == 0 || after == getPreviousWordType(target, con.start, con.limit, offset, opts));
/*      */         } 
/*      */         
/* 1634 */         if (!go) {
/* 1635 */           return false;
/*      */         }
/*      */         break;
/*      */       case 60:
/* 1639 */         if (con.length == 0 || offset == con.limit)
/* 1640 */           return false; 
/* 1641 */         if (getWordType(target, con.start, con.limit, offset, opts) != 1 || 
/* 1642 */           getPreviousWordType(target, con.start, con.limit, offset, opts) != 2)
/*      */         {
/* 1644 */           return false;
/*      */         }
/*      */         break;
/*      */       case 62:
/* 1648 */         if (con.length == 0 || offset == con.start)
/* 1649 */           return false; 
/* 1650 */         if (getWordType(target, con.start, con.limit, offset, opts) != 2 || 
/* 1651 */           getPreviousWordType(target, con.start, con.limit, offset, opts) != 1)
/*      */         {
/* 1653 */           return false;
/*      */         }
/*      */         break;
/*      */     } 
/* 1657 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int getPreviousWordType(ExpressionTarget target, int begin, int end, int offset, int opts) {
/* 1662 */     int ret = getWordType(target, begin, end, --offset, opts);
/* 1663 */     while (ret == 0)
/* 1664 */       ret = getWordType(target, begin, end, --offset, opts); 
/* 1665 */     return ret;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int getWordType(ExpressionTarget target, int begin, int end, int offset, int opts) {
/* 1670 */     if (offset < begin || offset >= end)
/* 1671 */       return 2; 
/* 1672 */     return getWordType0(target.charAt(offset), opts);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(CharacterIterator target) {
/* 1682 */     return matches(target, (Match)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(CharacterIterator target, Match match) {
/* 1695 */     int matchStart, start = target.getBeginIndex();
/* 1696 */     int end = target.getEndIndex();
/*      */     
/* 1698 */     synchronized (this) {
/* 1699 */       if (this.operations == null)
/* 1700 */         prepare(); 
/* 1701 */       if (this.context == null)
/* 1702 */         this.context = new Context(); 
/*      */     } 
/* 1704 */     Context con = null;
/* 1705 */     synchronized (this.context) {
/* 1706 */       con = this.context.inuse ? new Context() : this.context;
/* 1707 */       con.reset(target, start, end, this.numberOfClosures);
/*      */     } 
/* 1709 */     if (match != null) {
/* 1710 */       match.setNumberOfGroups(this.nofparen);
/* 1711 */       match.setSource(target);
/* 1712 */     } else if (this.hasBackReferences) {
/* 1713 */       match = new Match();
/* 1714 */       match.setNumberOfGroups(this.nofparen);
/*      */     } 
/*      */ 
/*      */     
/* 1718 */     con.match = match;
/*      */     
/* 1720 */     if (isSet(this.options, 512)) {
/* 1721 */       int i = match(con, this.operations, con.start, 1, this.options);
/*      */ 
/*      */       
/* 1724 */       if (i == con.limit) {
/* 1725 */         if (con.match != null) {
/* 1726 */           con.match.setBeginning(0, con.start);
/* 1727 */           con.match.setEnd(0, i);
/*      */         } 
/* 1729 */         con.setInUse(false);
/* 1730 */         return true;
/*      */       } 
/* 1732 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1738 */     if (this.fixedStringOnly) {
/*      */       
/* 1740 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/* 1741 */       if (o >= 0) {
/* 1742 */         if (con.match != null) {
/* 1743 */           con.match.setBeginning(0, o);
/* 1744 */           con.match.setEnd(0, o + this.fixedString.length());
/*      */         } 
/* 1746 */         con.setInUse(false);
/* 1747 */         return true;
/*      */       } 
/* 1749 */       con.setInUse(false);
/* 1750 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1758 */     if (this.fixedString != null) {
/* 1759 */       int o = this.fixedStringTable.matches(target, con.start, con.limit);
/* 1760 */       if (o < 0) {
/*      */         
/* 1762 */         con.setInUse(false);
/* 1763 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/* 1767 */     int limit = con.limit - this.minlength;
/*      */     
/* 1769 */     int matchEnd = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1774 */     if (this.operations != null && this.operations.type == 7 && 
/* 1775 */       (this.operations.getChild()).type == 0) {
/* 1776 */       if (isSet(this.options, 4)) {
/* 1777 */         matchStart = con.start;
/* 1778 */         matchEnd = match(con, this.operations, con.start, 1, this.options);
/*      */       } else {
/*      */         
/* 1781 */         boolean previousIsEOL = true;
/* 1782 */         for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 1783 */           int ch = target.setIndex(matchStart);
/* 1784 */           if (isEOLChar(ch)) {
/* 1785 */             previousIsEOL = true;
/*      */           } else {
/* 1787 */             if (previousIsEOL && 
/* 1788 */               0 <= (matchEnd = match(con, this.operations, matchStart, 1, this.options))) {
/*      */               break;
/*      */             }
/*      */ 
/*      */             
/* 1793 */             previousIsEOL = false;
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1802 */     else if (this.firstChar != null) {
/*      */       
/* 1804 */       RangeToken range = this.firstChar;
/* 1805 */       for (matchStart = con.start; matchStart <= limit; matchStart++) {
/* 1806 */         int ch = target.setIndex(matchStart);
/* 1807 */         if (REUtil.isHighSurrogate(ch) && matchStart + 1 < con.limit) {
/* 1808 */           ch = REUtil.composeFromSurrogates(ch, target
/* 1809 */               .setIndex(matchStart + 1));
/*      */         }
/* 1811 */         if (range.match(ch))
/*      */         {
/*      */           
/* 1814 */           if (0 <= (matchEnd = match(con, this.operations, matchStart, 1, this.options)))
/*      */           {
/*      */             break;
/*      */           
/*      */           }
/*      */         }
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1825 */       for (matchStart = con.start; matchStart <= limit && 
/* 1826 */         0 > (matchEnd = match(con, this.operations, matchStart, 1, this.options)); matchStart++);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1832 */     if (matchEnd >= 0) {
/* 1833 */       if (con.match != null) {
/* 1834 */         con.match.setBeginning(0, matchStart);
/* 1835 */         con.match.setEnd(0, matchEnd);
/*      */       } 
/* 1837 */       con.setInUse(false);
/* 1838 */       return true;
/*      */     } 
/* 1840 */     con.setInUse(false);
/* 1841 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean hasBackReferences = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   transient int minlength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1874 */   transient Op operations = null;
/*      */   transient int numberOfClosures;
/* 1876 */   transient Context context = null;
/* 1877 */   transient RangeToken firstChar = null;
/*      */   
/* 1879 */   transient String fixedString = null;
/*      */   transient int fixedStringOptions;
/* 1881 */   transient BMPattern fixedStringTable = null; transient boolean fixedStringOnly = false; static final int IGNORE_CASE = 2; static final int SINGLE_LINE = 4; static final int MULTIPLE_LINES = 8; static final int EXTENDED_COMMENT = 16; static final int USE_UNICODE_CATEGORY = 32; static final int UNICODE_WORD_BOUNDARY = 64; static final int PROHIBIT_HEAD_CHARACTER_OPTIMIZATION = 128; static final int PROHIBIT_FIXED_STRING_OPTIMIZATION = 256; static final int XMLSCHEMA_MODE = 512; static final int SPECIAL_COMMA = 1024; private static final int WT_IGNORE = 0;
/*      */   private static final int WT_LETTER = 1;
/*      */   private static final int WT_OTHER = 2;
/*      */   static final int LINE_FEED = 10;
/*      */   static final int CARRIAGE_RETURN = 13;
/*      */   static final int LINE_SEPARATOR = 8232;
/*      */   static final int PARAGRAPH_SEPARATOR = 8233;
/*      */   
/*      */   static abstract class ExpressionTarget {
/*      */     abstract char charAt(int param1Int);
/*      */     
/*      */     abstract boolean regionMatches(boolean param1Boolean, int param1Int1, int param1Int2, String param1String, int param1Int3);
/*      */     
/*      */     abstract boolean regionMatches(boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, int param1Int4); }
/*      */   
/*      */   static final class StringTarget extends ExpressionTarget { private String target;
/*      */     
/*      */     StringTarget(String target) {
/* 1899 */       this.target = target;
/*      */     }
/*      */     
/*      */     final void resetTarget(String target) {
/* 1903 */       this.target = target;
/*      */     }
/*      */     
/*      */     final char charAt(int index) {
/* 1907 */       return this.target.charAt(index);
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean regionMatches(boolean ignoreCase, int offset, int limit, String part, int partlen) {
/* 1912 */       if (limit - offset < partlen) {
/* 1913 */         return false;
/*      */       }
/* 1915 */       return ignoreCase ? this.target.regionMatches(true, offset, part, 0, partlen) : 
/* 1916 */         this.target.regionMatches(offset, part, 0, partlen);
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean regionMatches(boolean ignoreCase, int offset, int limit, int offset2, int partlen) {
/* 1921 */       if (limit - offset < partlen) {
/* 1922 */         return false;
/*      */       }
/* 1924 */       return ignoreCase ? this.target.regionMatches(true, offset, this.target, offset2, partlen) : 
/* 1925 */         this.target.regionMatches(offset, this.target, offset2, partlen);
/*      */     } }
/*      */ 
/*      */   
/*      */   static final class CharArrayTarget
/*      */     extends ExpressionTarget
/*      */   {
/*      */     char[] target;
/*      */     
/*      */     CharArrayTarget(char[] target) {
/* 1935 */       this.target = target;
/*      */     }
/*      */     
/*      */     final void resetTarget(char[] target) {
/* 1939 */       this.target = target;
/*      */     }
/*      */     
/*      */     char charAt(int index) {
/* 1943 */       return this.target[index];
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean regionMatches(boolean ignoreCase, int offset, int limit, String part, int partlen) {
/* 1948 */       if (offset < 0 || limit - offset < partlen) {
/* 1949 */         return false;
/*      */       }
/* 1951 */       return ignoreCase ? regionMatchesIgnoreCase(offset, limit, part, partlen) : 
/* 1952 */         regionMatches(offset, limit, part, partlen);
/*      */     }
/*      */ 
/*      */     
/*      */     private final boolean regionMatches(int offset, int limit, String part, int partlen) {
/* 1957 */       int i = 0;
/* 1958 */       while (partlen-- > 0) {
/* 1959 */         if (this.target[offset++] != part.charAt(i++)) {
/* 1960 */           return false;
/*      */         }
/*      */       } 
/* 1963 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private final boolean regionMatchesIgnoreCase(int offset, int limit, String part, int partlen) {
/* 1968 */       int i = 0;
/* 1969 */       while (partlen-- > 0) {
/* 1970 */         char ch1 = this.target[offset++];
/* 1971 */         char ch2 = part.charAt(i++);
/* 1972 */         if (ch1 == ch2) {
/*      */           continue;
/*      */         }
/* 1975 */         char uch1 = Character.toUpperCase(ch1);
/* 1976 */         char uch2 = Character.toUpperCase(ch2);
/* 1977 */         if (uch1 == uch2) {
/*      */           continue;
/*      */         }
/* 1980 */         if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2)) {
/* 1981 */           return false;
/*      */         }
/*      */       } 
/* 1984 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean regionMatches(boolean ignoreCase, int offset, int limit, int offset2, int partlen) {
/* 1989 */       if (offset < 0 || limit - offset < partlen) {
/* 1990 */         return false;
/*      */       }
/* 1992 */       return ignoreCase ? regionMatchesIgnoreCase(offset, limit, offset2, partlen) : 
/* 1993 */         regionMatches(offset, limit, offset2, partlen);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean regionMatches(int offset, int limit, int offset2, int partlen) {
/* 1999 */       int i = offset2;
/* 2000 */       while (partlen-- > 0) {
/* 2001 */         if (this.target[offset++] != this.target[i++])
/* 2002 */           return false; 
/*      */       } 
/* 2004 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private final boolean regionMatchesIgnoreCase(int offset, int limit, int offset2, int partlen) {
/* 2009 */       int i = offset2;
/* 2010 */       while (partlen-- > 0) {
/* 2011 */         char ch1 = this.target[offset++];
/* 2012 */         char ch2 = this.target[i++];
/* 2013 */         if (ch1 == ch2) {
/*      */           continue;
/*      */         }
/* 2016 */         char uch1 = Character.toUpperCase(ch1);
/* 2017 */         char uch2 = Character.toUpperCase(ch2);
/* 2018 */         if (uch1 == uch2) {
/*      */           continue;
/*      */         }
/* 2021 */         if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2)) {
/* 2022 */           return false;
/*      */         }
/*      */       } 
/* 2025 */       return true;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class CharacterIteratorTarget extends ExpressionTarget {
/*      */     CharacterIterator target;
/*      */     
/*      */     CharacterIteratorTarget(CharacterIterator target) {
/* 2033 */       this.target = target;
/*      */     }
/*      */     
/*      */     final void resetTarget(CharacterIterator target) {
/* 2037 */       this.target = target;
/*      */     }
/*      */     
/*      */     final char charAt(int index) {
/* 2041 */       return this.target.setIndex(index);
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean regionMatches(boolean ignoreCase, int offset, int limit, String part, int partlen) {
/* 2046 */       if (offset < 0 || limit - offset < partlen) {
/* 2047 */         return false;
/*      */       }
/* 2049 */       return ignoreCase ? regionMatchesIgnoreCase(offset, limit, part, partlen) : 
/* 2050 */         regionMatches(offset, limit, part, partlen);
/*      */     }
/*      */ 
/*      */     
/*      */     private final boolean regionMatches(int offset, int limit, String part, int partlen) {
/* 2055 */       int i = 0;
/* 2056 */       while (partlen-- > 0) {
/* 2057 */         if (this.target.setIndex(offset++) != part.charAt(i++)) {
/* 2058 */           return false;
/*      */         }
/*      */       } 
/* 2061 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private final boolean regionMatchesIgnoreCase(int offset, int limit, String part, int partlen) {
/* 2066 */       int i = 0;
/* 2067 */       while (partlen-- > 0) {
/* 2068 */         char ch1 = this.target.setIndex(offset++);
/* 2069 */         char ch2 = part.charAt(i++);
/* 2070 */         if (ch1 == ch2) {
/*      */           continue;
/*      */         }
/* 2073 */         char uch1 = Character.toUpperCase(ch1);
/* 2074 */         char uch2 = Character.toUpperCase(ch2);
/* 2075 */         if (uch1 == uch2) {
/*      */           continue;
/*      */         }
/* 2078 */         if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2)) {
/* 2079 */           return false;
/*      */         }
/*      */       } 
/* 2082 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean regionMatches(boolean ignoreCase, int offset, int limit, int offset2, int partlen) {
/* 2087 */       if (offset < 0 || limit - offset < partlen) {
/* 2088 */         return false;
/*      */       }
/* 2090 */       return ignoreCase ? regionMatchesIgnoreCase(offset, limit, offset2, partlen) : 
/* 2091 */         regionMatches(offset, limit, offset2, partlen);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean regionMatches(int offset, int limit, int offset2, int partlen) {
/* 2097 */       int i = offset2;
/* 2098 */       while (partlen-- > 0) {
/* 2099 */         if (this.target.setIndex(offset++) != this.target.setIndex(i++)) {
/* 2100 */           return false;
/*      */         }
/*      */       } 
/* 2103 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private final boolean regionMatchesIgnoreCase(int offset, int limit, int offset2, int partlen) {
/* 2108 */       int i = offset2;
/* 2109 */       while (partlen-- > 0) {
/* 2110 */         char ch1 = this.target.setIndex(offset++);
/* 2111 */         char ch2 = this.target.setIndex(i++);
/* 2112 */         if (ch1 == ch2) {
/*      */           continue;
/*      */         }
/* 2115 */         char uch1 = Character.toUpperCase(ch1);
/* 2116 */         char uch2 = Character.toUpperCase(ch2);
/* 2117 */         if (uch1 == uch2) {
/*      */           continue;
/*      */         }
/* 2120 */         if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2)) {
/* 2121 */           return false;
/*      */         }
/*      */       } 
/* 2124 */       return true;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class ClosureContext
/*      */   {
/* 2130 */     int[] offsets = new int[4];
/* 2131 */     int currentIndex = 0;
/*      */     
/*      */     boolean contains(int offset) {
/* 2134 */       for (int i = 0; i < this.currentIndex; i++) {
/* 2135 */         if (this.offsets[i] == offset) {
/* 2136 */           return true;
/*      */         }
/*      */       } 
/* 2139 */       return false;
/*      */     }
/*      */     
/*      */     void reset() {
/* 2143 */       this.currentIndex = 0;
/*      */     }
/*      */ 
/*      */     
/*      */     void addOffset(int offset) {
/* 2148 */       if (this.currentIndex == this.offsets.length) {
/* 2149 */         this.offsets = expandOffsets();
/*      */       }
/* 2151 */       this.offsets[this.currentIndex++] = offset;
/*      */     }
/*      */     
/*      */     private int[] expandOffsets() {
/* 2155 */       int len = this.offsets.length;
/* 2156 */       int newLen = len << 1;
/* 2157 */       int[] newOffsets = new int[newLen];
/*      */       
/* 2159 */       System.arraycopy(this.offsets, 0, newOffsets, 0, this.currentIndex);
/* 2160 */       return newOffsets;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class Context
/*      */   {
/*      */     int start;
/*      */     
/*      */     int limit;
/*      */     
/*      */     int length;
/*      */     
/*      */     Match match;
/*      */     boolean inuse = false;
/*      */     RegularExpression.ClosureContext[] closureContexts;
/*      */     private RegularExpression.StringTarget stringTarget;
/*      */     private RegularExpression.CharArrayTarget charArrayTarget;
/*      */     private RegularExpression.CharacterIteratorTarget characterIteratorTarget;
/*      */     RegularExpression.ExpressionTarget target;
/*      */     
/*      */     private void resetCommon(int nofclosures) {
/* 2182 */       this.length = this.limit - this.start;
/* 2183 */       setInUse(true);
/* 2184 */       this.match = null;
/* 2185 */       if (this.closureContexts == null || this.closureContexts.length != nofclosures)
/*      */       {
/* 2187 */         this.closureContexts = new RegularExpression.ClosureContext[nofclosures];
/*      */       }
/* 2189 */       for (int i = 0; i < nofclosures; i++) {
/* 2190 */         if (this.closureContexts[i] == null) {
/* 2191 */           this.closureContexts[i] = new RegularExpression.ClosureContext();
/*      */         } else {
/* 2193 */           this.closureContexts[i].reset();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void reset(CharacterIterator target, int start, int limit, int nofclosures) {
/* 2200 */       if (this.characterIteratorTarget == null) {
/* 2201 */         this.characterIteratorTarget = new RegularExpression.CharacterIteratorTarget(target);
/*      */       } else {
/* 2203 */         this.characterIteratorTarget.resetTarget(target);
/*      */       } 
/* 2205 */       this.target = this.characterIteratorTarget;
/* 2206 */       this.start = start;
/* 2207 */       this.limit = limit;
/* 2208 */       resetCommon(nofclosures);
/*      */     }
/*      */     
/*      */     void reset(String target, int start, int limit, int nofclosures) {
/* 2212 */       if (this.stringTarget == null) {
/* 2213 */         this.stringTarget = new RegularExpression.StringTarget(target);
/*      */       } else {
/* 2215 */         this.stringTarget.resetTarget(target);
/*      */       } 
/* 2217 */       this.target = this.stringTarget;
/* 2218 */       this.start = start;
/* 2219 */       this.limit = limit;
/* 2220 */       resetCommon(nofclosures);
/*      */     }
/*      */     
/*      */     void reset(char[] target, int start, int limit, int nofclosures) {
/* 2224 */       if (this.charArrayTarget == null) {
/* 2225 */         this.charArrayTarget = new RegularExpression.CharArrayTarget(target);
/*      */       } else {
/* 2227 */         this.charArrayTarget.resetTarget(target);
/*      */       } 
/* 2229 */       this.target = this.charArrayTarget;
/* 2230 */       this.start = start;
/* 2231 */       this.limit = limit;
/* 2232 */       resetCommon(nofclosures);
/*      */     }
/*      */     
/*      */     synchronized void setInUse(boolean inUse) {
/* 2236 */       this.inuse = inUse;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepare() {
/* 2247 */     compile(this.tokentree);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2257 */     this.minlength = this.tokentree.getMinLength();
/*      */     
/* 2259 */     this.firstChar = null;
/* 2260 */     if (!isSet(this.options, 128) && 
/* 2261 */       !isSet(this.options, 512)) {
/* 2262 */       RangeToken firstChar = Token.createRange();
/* 2263 */       int fresult = this.tokentree.analyzeFirstCharacter(firstChar, this.options);
/*      */       
/* 2265 */       if (fresult == 1) {
/* 2266 */         firstChar.compactRanges();
/* 2267 */         this.firstChar = firstChar;
/* 2268 */         LOGGER.debug("DEBUG: Use the first character optimization: {}", firstChar);
/*      */       } 
/*      */     } 
/*      */     
/* 2272 */     if (this.operations != null && (this.operations.type == 6 || this.operations.type == 1) && this.operations.next == null) {
/*      */ 
/*      */       
/* 2275 */       LOGGER.debug(" *** Only fixed string! *** ");
/* 2276 */       this.fixedStringOnly = true;
/* 2277 */       if (this.operations.type == 6) {
/* 2278 */         this.fixedString = this.operations.getString();
/* 2279 */       } else if (this.operations.getData() >= 65536) {
/* 2280 */         this.fixedString = REUtil.decomposeToSurrogates(this.operations
/* 2281 */             .getData());
/*      */       } else {
/* 2283 */         char[] ac = new char[1];
/* 2284 */         ac[0] = (char)this.operations.getData();
/* 2285 */         this.fixedString = new String(ac);
/*      */       } 
/* 2287 */       this.fixedStringOptions = this.options;
/* 2288 */       this.fixedStringTable = new BMPattern(this.fixedString, 256, isSet(this.fixedStringOptions, 2));
/*      */     }
/* 2290 */     else if (!isSet(this.options, 256) && 
/* 2291 */       !isSet(this.options, 512)) {
/* 2292 */       Token.FixedStringContainer container = new Token.FixedStringContainer();
/* 2293 */       this.tokentree.findFixedString(container, this.options);
/* 2294 */       this
/* 2295 */         .fixedString = (container.token == null) ? null : container.token.getString();
/* 2296 */       this.fixedStringOptions = container.options;
/* 2297 */       if (this.fixedString != null && this.fixedString.length() < 2) {
/* 2298 */         this.fixedString = null;
/*      */       }
/* 2300 */       if (this.fixedString != null) {
/* 2301 */         this
/* 2302 */           .fixedStringTable = new BMPattern(this.fixedString, 256, isSet(this.fixedStringOptions, 2));
/* 2303 */         LOGGER.debug("DEBUG: The longest fixed string: {}/{}", Integer.valueOf(this.fixedString.length()), REUtil.createOptionString(this.fixedStringOptions));
/* 2304 */         LOGGER.debug("String: ");
/* 2305 */         REUtil.dumpString(this.fixedString);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean isSet(int options, int flag) {
/* 2386 */     return ((options & flag) == flag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RegularExpression(String regex) throws ParseException {
/* 2398 */     this(regex, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RegularExpression(String regex, String options) throws ParseException {
/* 2413 */     setPattern(regex, options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RegularExpression(String regex, String options, Locale locale) throws ParseException {
/* 2428 */     setPattern(regex, options, locale);
/*      */   }
/*      */ 
/*      */   
/*      */   RegularExpression(String regex, Token tok, int parens, boolean hasBackReferences, int options) {
/* 2433 */     this.regex = regex;
/* 2434 */     this.tokentree = tok;
/* 2435 */     this.nofparen = parens;
/* 2436 */     this.options = options;
/* 2437 */     this.hasBackReferences = hasBackReferences;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPattern(String newPattern) throws ParseException {
/* 2444 */     setPattern(newPattern, Locale.getDefault());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPattern(String newPattern, Locale locale) throws ParseException {
/* 2449 */     setPattern(newPattern, this.options, locale);
/*      */   }
/*      */ 
/*      */   
/*      */   private void setPattern(String newPattern, int options, Locale locale) throws ParseException {
/* 2454 */     this.regex = newPattern;
/* 2455 */     this.options = options;
/*      */ 
/*      */     
/* 2458 */     RegexParser rp = isSet(this.options, 512) ? new ParserForXMLSchema(locale) : new RegexParser(locale);
/* 2459 */     this.tokentree = rp.parse(this.regex, this.options);
/* 2460 */     this.nofparen = rp.parennumber;
/* 2461 */     this.hasBackReferences = rp.hasBackReferences;
/*      */     
/* 2463 */     this.operations = null;
/* 2464 */     this.context = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPattern(String newPattern, String options) throws ParseException {
/* 2472 */     setPattern(newPattern, options, Locale.getDefault());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPattern(String newPattern, String options, Locale locale) throws ParseException {
/* 2477 */     setPattern(newPattern, REUtil.parseOptions(options), locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPattern() {
/* 2484 */     return this.regex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2491 */     return this.tokentree.toString(this.options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getOptions() {
/* 2502 */     return REUtil.createOptionString(this.options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 2509 */     if (obj == null)
/* 2510 */       return false; 
/* 2511 */     if (!(obj instanceof RegularExpression))
/* 2512 */       return false; 
/* 2513 */     RegularExpression r = (RegularExpression)obj;
/* 2514 */     return (this.regex.equals(r.regex) && this.options == r.options);
/*      */   }
/*      */   
/*      */   boolean equals(String pattern, int options) {
/* 2518 */     return (this.regex.equals(pattern) && this.options == options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 2525 */     return (this.regex + "/" + getOptions()).hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfGroups() {
/* 2534 */     return this.nofparen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int getWordType0(char ch, int opts) {
/* 2544 */     if (!isSet(opts, 64)) {
/* 2545 */       if (isSet(opts, 32)) {
/* 2546 */         return Token.getRange("IsWord", true).match(ch) ? 1 : 
/* 2547 */           2;
/*      */       }
/* 2549 */       return isWordChar(ch) ? 1 : 2;
/*      */     } 
/*      */     
/* 2552 */     switch (Character.getType(ch)) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/* 2562 */         return 1;
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 16:
/* 2567 */         return 0;
/*      */       
/*      */       case 15:
/* 2570 */         switch (ch) {
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\013':
/*      */           case '\f':
/*      */           case '\r':
/* 2576 */             return 2;
/*      */         } 
/* 2578 */         return 0;
/*      */     } 
/*      */ 
/*      */     
/* 2582 */     return 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean isEOLChar(int ch) {
/* 2594 */     return (ch == 10 || ch == 13 || ch == 8232 || ch == 8233);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean isWordChar(int ch) {
/* 2599 */     if (ch == 95)
/* 2600 */       return true; 
/* 2601 */     if (ch < 48)
/* 2602 */       return false; 
/* 2603 */     if (ch > 122)
/* 2604 */       return false; 
/* 2605 */     if (ch <= 57)
/* 2606 */       return true; 
/* 2607 */     if (ch < 65)
/* 2608 */       return false; 
/* 2609 */     if (ch <= 90)
/* 2610 */       return true; 
/* 2611 */     if (ch < 97)
/* 2612 */       return false; 
/* 2613 */     return true;
/*      */   }
/*      */   
/*      */   private static final boolean matchIgnoreCase(int chardata, int ch) {
/* 2617 */     if (chardata == ch)
/* 2618 */       return true; 
/* 2619 */     if (chardata > 65535 || ch > 65535)
/* 2620 */       return false; 
/* 2621 */     char uch1 = Character.toUpperCase((char)chardata);
/* 2622 */     char uch2 = Character.toUpperCase((char)ch);
/* 2623 */     if (uch1 == uch2)
/* 2624 */       return true; 
/* 2625 */     return (Character.toLowerCase(uch1) == Character.toLowerCase(uch2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class IntStack
/*      */   {
/*      */     private int fDepth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int[] fData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/* 2655 */       return this.fDepth;
/*      */     }
/*      */ 
/*      */     
/*      */     public void push(int value) {
/* 2660 */       ensureCapacity(this.fDepth + 1);
/* 2661 */       this.fData[this.fDepth++] = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public int peek() {
/* 2666 */       return this.fData[this.fDepth - 1];
/*      */     }
/*      */ 
/*      */     
/*      */     public int elementAt(int depth) {
/* 2671 */       return this.fData[depth];
/*      */     }
/*      */ 
/*      */     
/*      */     public int pop() {
/* 2676 */       return this.fData[--this.fDepth];
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 2681 */       this.fDepth = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void ensureCapacity(int size) {
/* 2690 */       if (this.fData == null) {
/* 2691 */         this.fData = new int[32];
/* 2692 */       } else if (this.fData.length <= size) {
/* 2693 */         int[] newdata = new int[this.fData.length * 2];
/* 2694 */         System.arraycopy(this.fData, 0, newdata, 0, this.fData.length);
/* 2695 */         this.fData = newdata;
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\RegularExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */