/*     */ package com.siemens.ct.exi.grammars.regex;
/*     */ 
/*     */ import java.text.CharacterIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Match
/*     */   implements Cloneable
/*     */ {
/*  38 */   int[] beginpos = null;
/*  39 */   int[] endpos = null;
/*  40 */   int nofgroups = 0;
/*     */   
/*  42 */   CharacterIterator ciSource = null;
/*  43 */   String strSource = null;
/*  44 */   char[] charSource = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object clone() {
/*  56 */     Match ma = new Match();
/*  57 */     if (this.nofgroups > 0) {
/*  58 */       ma.setNumberOfGroups(this.nofgroups);
/*  59 */       if (this.ciSource != null)
/*  60 */         ma.setSource(this.ciSource); 
/*  61 */       if (this.strSource != null)
/*  62 */         ma.setSource(this.strSource); 
/*  63 */       for (int i = 0; i < this.nofgroups; i++) {
/*  64 */         ma.setBeginning(i, getBeginning(i));
/*  65 */         ma.setEnd(i, getEnd(i));
/*     */       } 
/*     */     } 
/*  68 */     return ma;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setNumberOfGroups(int n) {
/*  75 */     int oldn = this.nofgroups;
/*  76 */     this.nofgroups = n;
/*  77 */     if (oldn <= 0 || oldn < n || n * 2 < oldn) {
/*  78 */       this.beginpos = new int[n];
/*  79 */       this.endpos = new int[n];
/*     */     } 
/*  81 */     for (int i = 0; i < n; i++) {
/*  82 */       this.beginpos[i] = -1;
/*  83 */       this.endpos[i] = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSource(CharacterIterator ci) {
/*  91 */     this.ciSource = ci;
/*  92 */     this.strSource = null;
/*  93 */     this.charSource = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSource(String str) {
/* 100 */     this.ciSource = null;
/* 101 */     this.strSource = str;
/* 102 */     this.charSource = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSource(char[] chars) {
/* 109 */     this.ciSource = null;
/* 110 */     this.strSource = null;
/* 111 */     this.charSource = chars;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setBeginning(int index, int v) {
/* 118 */     this.beginpos[index] = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setEnd(int index, int v) {
/* 125 */     this.endpos[index] = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfGroups() {
/* 133 */     if (this.nofgroups <= 0)
/* 134 */       throw new IllegalStateException("A result is not set."); 
/* 135 */     return this.nofgroups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBeginning(int index) {
/* 146 */     if (this.beginpos == null)
/* 147 */       throw new IllegalStateException("A result is not set."); 
/* 148 */     if (index < 0 || this.nofgroups <= index) {
/* 149 */       throw new IllegalArgumentException("The parameter must be less than " + this.nofgroups + ": " + index);
/*     */     }
/*     */     
/* 152 */     return this.beginpos[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEnd(int index) {
/* 163 */     if (this.endpos == null)
/* 164 */       throw new IllegalStateException("A result is not set."); 
/* 165 */     if (index < 0 || this.nofgroups <= index) {
/* 166 */       throw new IllegalArgumentException("The parameter must be less than " + this.nofgroups + ": " + index);
/*     */     }
/*     */     
/* 169 */     return this.endpos[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCapturedText(int index) {
/*     */     String ret;
/* 180 */     if (this.beginpos == null)
/* 181 */       throw new IllegalStateException("match() has never been called."); 
/* 182 */     if (index < 0 || this.nofgroups <= index) {
/* 183 */       throw new IllegalArgumentException("The parameter must be less than " + this.nofgroups + ": " + index);
/*     */     }
/*     */ 
/*     */     
/* 187 */     int begin = this.beginpos[index], end = this.endpos[index];
/* 188 */     if (begin < 0 || end < 0)
/* 189 */       return null; 
/* 190 */     if (this.ciSource != null) {
/* 191 */       ret = REUtil.substring(this.ciSource, begin, end);
/* 192 */     } else if (this.strSource != null) {
/* 193 */       ret = this.strSource.substring(begin, end);
/*     */     } else {
/* 195 */       ret = new String(this.charSource, begin, end - begin);
/*     */     } 
/* 197 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\Match.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */