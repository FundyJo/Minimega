/*     */ package com.siemens.ct.exi.grammars.regex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CaseInsensitiveMap
/*     */ {
/*  32 */   private static int CHUNK_SHIFT = 10;
/*  33 */   private static int CHUNK_SIZE = 1 << CHUNK_SHIFT;
/*  34 */   private static int CHUNK_MASK = CHUNK_SIZE - 1;
/*  35 */   private static int INITIAL_CHUNK_COUNT = 64;
/*     */   
/*     */   private static int[][][] caseInsensitiveMap;
/*  38 */   private static Boolean mapBuilt = Boolean.FALSE;
/*     */   
/*  40 */   private static int LOWER_CASE_MATCH = 1;
/*  41 */   private static int UPPER_CASE_MATCH = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] get(int codePoint) {
/*  48 */     if (mapBuilt == Boolean.FALSE) {
/*  49 */       synchronized (mapBuilt) {
/*  50 */         if (mapBuilt == Boolean.FALSE) {
/*  51 */           buildCaseInsensitiveMap();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*  56 */     return (codePoint < 65536) ? getMapping(codePoint) : null;
/*     */   }
/*     */   
/*     */   private static int[] getMapping(int codePoint) {
/*  60 */     int chunk = codePoint >>> CHUNK_SHIFT;
/*  61 */     int offset = codePoint & CHUNK_MASK;
/*     */     
/*  63 */     return caseInsensitiveMap[chunk][offset];
/*     */   }
/*     */   
/*     */   private static void buildCaseInsensitiveMap() {
/*  67 */     caseInsensitiveMap = new int[INITIAL_CHUNK_COUNT][][];
/*  68 */     for (int i = 0; i < INITIAL_CHUNK_COUNT; i++) {
/*  69 */       caseInsensitiveMap[i] = new int[CHUNK_SIZE][];
/*     */     }
/*     */ 
/*     */     
/*  73 */     for (int j = 0; j < 65536; j++) {
/*  74 */       int lc = Character.toLowerCase(j);
/*  75 */       int uc = Character.toUpperCase(j);
/*     */ 
/*     */       
/*  78 */       if (lc != uc || lc != j) {
/*  79 */         int[] map = new int[2];
/*  80 */         int index = 0;
/*     */         
/*  82 */         if (lc != j) {
/*  83 */           map[index++] = lc;
/*  84 */           map[index++] = LOWER_CASE_MATCH;
/*  85 */           int[] lcMap = getMapping(lc);
/*  86 */           if (lcMap != null) {
/*  87 */             map = updateMap(j, map, lc, lcMap, LOWER_CASE_MATCH);
/*     */           }
/*     */         } 
/*     */         
/*  91 */         if (uc != j) {
/*  92 */           if (index == map.length) {
/*  93 */             map = expandMap(map, 2);
/*     */           }
/*  95 */           map[index++] = uc;
/*  96 */           map[index++] = UPPER_CASE_MATCH;
/*  97 */           int[] ucMap = getMapping(uc);
/*  98 */           if (ucMap != null) {
/*  99 */             map = updateMap(j, map, uc, ucMap, UPPER_CASE_MATCH);
/*     */           }
/*     */         } 
/*     */         
/* 103 */         set(j, map);
/*     */       } 
/*     */     } 
/*     */     
/* 107 */     mapBuilt = Boolean.TRUE;
/*     */   }
/*     */   
/*     */   private static int[] expandMap(int[] srcMap, int expandBy) {
/* 111 */     int oldLen = srcMap.length;
/* 112 */     int[] newMap = new int[oldLen + expandBy];
/*     */     
/* 114 */     System.arraycopy(srcMap, 0, newMap, 0, oldLen);
/* 115 */     return newMap;
/*     */   }
/*     */   
/*     */   private static void set(int codePoint, int[] map) {
/* 119 */     int chunk = codePoint >>> CHUNK_SHIFT;
/* 120 */     int offset = codePoint & CHUNK_MASK;
/*     */     
/* 122 */     caseInsensitiveMap[chunk][offset] = map;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int[] updateMap(int codePoint, int[] codePointMap, int ciCodePoint, int[] ciCodePointMap, int matchType) {
/* 127 */     for (int i = 0; i < ciCodePointMap.length; i += 2) {
/* 128 */       int c = ciCodePointMap[i];
/* 129 */       int[] cMap = getMapping(c);
/* 130 */       if (cMap != null && 
/* 131 */         contains(cMap, ciCodePoint, matchType)) {
/* 132 */         if (!contains(cMap, codePoint)) {
/* 133 */           cMap = expandAndAdd(cMap, codePoint, matchType);
/* 134 */           set(c, cMap);
/*     */         } 
/* 136 */         if (!contains(codePointMap, c)) {
/* 137 */           codePointMap = expandAndAdd(codePointMap, c, matchType);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 143 */     if (!contains(ciCodePointMap, codePoint)) {
/* 144 */       ciCodePointMap = expandAndAdd(ciCodePointMap, codePoint, matchType);
/* 145 */       set(ciCodePoint, ciCodePointMap);
/*     */     } 
/*     */     
/* 148 */     return codePointMap;
/*     */   }
/*     */   
/*     */   private static boolean contains(int[] map, int codePoint) {
/* 152 */     for (int i = 0; i < map.length; i += 2) {
/* 153 */       if (map[i] == codePoint) {
/* 154 */         return true;
/*     */       }
/*     */     } 
/* 157 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean contains(int[] map, int codePoint, int matchType) {
/* 161 */     for (int i = 0; i < map.length; i += 2) {
/* 162 */       if (map[i] == codePoint && map[i + 1] == matchType) {
/* 163 */         return true;
/*     */       }
/*     */     } 
/* 166 */     return false;
/*     */   }
/*     */   
/*     */   private static int[] expandAndAdd(int[] srcMap, int codePoint, int matchType) {
/* 170 */     int oldLen = srcMap.length;
/* 171 */     int[] newMap = new int[oldLen + 2];
/*     */     
/* 173 */     System.arraycopy(srcMap, 0, newMap, 0, oldLen);
/* 174 */     newMap[oldLen] = codePoint;
/* 175 */     newMap[oldLen + 1] = matchType;
/* 176 */     return newMap;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\CaseInsensitiveMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */