/*     */ package com.siemens.ct.exi.grammars.persistency;
/*     */ 
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.DatetimeDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.EnumerationDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.ListDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.NBitUnsignedIntegerDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.RestrictedCharacterSetDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.charset.RestrictedCharacterSet;
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.AttributeNS;
/*     */ import com.siemens.ct.exi.core.grammars.event.Characters;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElementNS;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import com.siemens.ct.exi.core.types.BuiltInType;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrammarIdDispenser
/*     */ {
/*     */   static final int DEFAULT_RECURSIVE_HANDLED_DEPTH_STOP = 100;
/*     */   final int RECURSIVE_HANDLED_DEPTH_STOP;
/*     */   final boolean doOptimizeGrammars;
/*     */   private List<Grammar> grammars;
/*     */   
/*     */   public GrammarIdDispenser() {
/*  72 */     this(true);
/*     */   }
/*     */   
/*     */   public GrammarIdDispenser(boolean optimizeGrammars) {
/*  76 */     this(optimizeGrammars, 100);
/*     */   }
/*     */   
/*     */   public GrammarIdDispenser(boolean optimizeGrammars, int depth) {
/*  80 */     this.doOptimizeGrammars = optimizeGrammars;
/*  81 */     this.RECURSIVE_HANDLED_DEPTH_STOP = depth;
/*  82 */     this.grammars = new ArrayList<>();
/*     */   }
/*     */   
/*     */   public void clear() {
/*  86 */     this.grammars.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Grammar getEqualGrammar(Grammar gr) {
/*  93 */     for (Grammar gx : this.grammars) {
/*  94 */       if (gr == gx)
/*     */       {
/*  96 */         return gx;
/*     */       }
/*     */       
/*  99 */       if (isSameGrammarType(gr, gx))
/*     */       {
/*     */         
/* 102 */         if (gr.getNumberOfEvents() == gx.getNumberOfEvents()) {
/* 103 */           List<Grammar> handled = new ArrayList<>();
/* 104 */           if (isEqualGrammar(gr, gx, handled))
/*     */           {
/*     */ 
/*     */             
/* 108 */             return gx;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 115 */     return null;
/*     */   }
/*     */   
/*     */   private static int getGrammarTypeID(Grammar gr) {
/* 119 */     if (gr instanceof com.siemens.ct.exi.core.grammars.grammar.Document)
/* 120 */       return 0; 
/* 121 */     if (gr instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedDocContent)
/* 122 */       return 1; 
/* 123 */     if (gr instanceof com.siemens.ct.exi.core.grammars.grammar.DocEnd)
/* 124 */       return 2; 
/* 125 */     if (gr instanceof com.siemens.ct.exi.core.grammars.grammar.Fragment)
/* 126 */       return 3; 
/* 127 */     if (gr instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFragmentContent)
/* 128 */       return 4; 
/* 129 */     if (gr instanceof SchemaInformedFirstStartTagGrammar)
/* 130 */       return 5; 
/* 131 */     if (gr instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedStartTagGrammar)
/* 132 */       return 6; 
/* 133 */     if (gr instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedElement) {
/* 134 */       return 7;
/*     */     }
/* 136 */     if (gr instanceof com.siemens.ct.exi.core.grammars.grammar.BuiltInDocContent)
/* 137 */       return 8; 
/* 138 */     if (gr instanceof com.siemens.ct.exi.core.grammars.grammar.BuiltInFragmentContent) {
/* 139 */       return 9;
/*     */     }
/* 141 */     throw new RuntimeException("Unexpected Grammar Type for: " + gr);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isSameGrammarType(Grammar gr, Grammar gx) {
/* 146 */     int grTID = getGrammarTypeID(gr);
/* 147 */     int gxTID = getGrammarTypeID(gx);
/*     */     
/* 149 */     if (grTID != gxTID) {
/* 150 */       return false;
/*     */     }
/*     */     
/* 153 */     if (gr instanceof SchemaInformedFirstStartTagGrammar) {
/* 154 */       SchemaInformedFirstStartTagGrammar fr = (SchemaInformedFirstStartTagGrammar)gr;
/* 155 */       SchemaInformedFirstStartTagGrammar fx = (SchemaInformedFirstStartTagGrammar)gx;
/* 156 */       if (fr.isTypeCastable() != fx.isTypeCastable()) {
/* 157 */         return false;
/*     */       }
/* 159 */       if (fr.isNillable() != fx.isNillable()) {
/* 160 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 164 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isEqualGrammar(Grammar gr, Grammar gx, List<Grammar> handled) {
/* 168 */     if (gr == gx) {
/* 169 */       return true;
/*     */     }
/* 171 */     if (gr == null && gx != null && gx.getNumberOfEvents() == 0) {
/* 172 */       return true;
/*     */     }
/* 174 */     if (gx == null && gr != null && gr.getNumberOfEvents() == 0) {
/* 175 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 179 */     for (Grammar g : handled) {
/* 180 */       if (g == gx)
/*     */       {
/* 182 */         for (Grammar gg : handled) {
/* 183 */           if (gg == gr) {
/* 184 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 189 */     handled.add(gx);
/* 190 */     handled.add(gr);
/*     */     
/* 192 */     if (handled.size() > this.RECURSIVE_HANDLED_DEPTH_STOP)
/*     */     {
/* 194 */       return false;
/*     */     }
/*     */     
/* 197 */     if (!isSameGrammarType(gr, gx)) {
/* 198 */       return false;
/*     */     }
/*     */     
/* 201 */     if (gr.getNumberOfEvents() != gx.getNumberOfEvents()) {
/* 202 */       return false;
/*     */     }
/*     */     
/* 205 */     for (int i = 0; i < gr.getNumberOfEvents(); i++) {
/* 206 */       Attribute ar, ax; AttributeNS ansr, ansx; StartElement ser, sex; StartElementNS sensr, sensx; Characters chr, chx; Production pr = gr.getProduction(i);
/* 207 */       Production px = gx.getProduction(i);
/*     */ 
/*     */       
/* 210 */       Event er = pr.getEvent();
/* 211 */       Event ex = px.getEvent();
/*     */       
/* 213 */       if (er.getEventType() != ex.getEventType()) {
/* 214 */         return false;
/*     */       }
/*     */       
/* 217 */       switch (er.getEventType()) {
/*     */         case BINARY_BASE64:
/*     */         case BINARY_HEX:
/*     */         case BOOLEAN:
/*     */         case BOOLEAN_FACET:
/*     */         case DECIMAL:
/*     */         case FLOAT:
/*     */           break;
/*     */         case UNSIGNED_INTEGER:
/* 226 */           ar = (Attribute)er;
/* 227 */           ax = (Attribute)ex;
/* 228 */           if (!ar.getQName().equals(ax.getQName())) {
/* 229 */             return false;
/*     */           }
/* 231 */           if (!isEqualDatatype(ar.getDatatype(), ax.getDatatype())) {
/* 232 */             return false;
/*     */           }
/*     */           break;
/*     */         case INTEGER:
/* 236 */           ansr = (AttributeNS)er;
/* 237 */           ansx = (AttributeNS)ex;
/* 238 */           if (!ansr.getNamespaceURI().equals(ansx.getNamespaceURI())) {
/* 239 */             return false;
/*     */           }
/*     */           break;
/*     */         case STRING:
/* 243 */           ser = (StartElement)er;
/* 244 */           sex = (StartElement)ex;
/*     */           
/* 246 */           if (!ser.getQName().equals(sex.getQName())) {
/* 247 */             return false;
/*     */           }
/*     */           
/* 250 */           if (!isEqualGrammar(ser.getGrammar(), sex.getGrammar(), handled))
/*     */           {
/*     */             
/* 253 */             return false;
/*     */           }
/*     */           break;
/*     */         
/*     */         case NBIT_UNSIGNED_INTEGER:
/* 258 */           sensr = (StartElementNS)er;
/* 259 */           sensx = (StartElementNS)ex;
/* 260 */           if (!sensr.getNamespaceURI().equals(sensx.getNamespaceURI())) {
/* 261 */             return false;
/*     */           }
/*     */           break;
/*     */         case DATETIME:
/* 265 */           chr = (Characters)er;
/* 266 */           chx = (Characters)ex;
/* 267 */           if (!isEqualDatatype(chr.getDatatype(), chx.getDatatype())) {
/* 268 */             return false;
/*     */           }
/*     */           break;
/*     */         default:
/* 272 */           throw new RuntimeException("Unexpected Grammar Event Type for: " + er);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 277 */       Grammar nr = pr.getNextGrammar();
/* 278 */       Grammar nx = px.getNextGrammar();
/*     */       
/* 280 */       if (!isEqualGrammar(nr, nx, handled))
/*     */       {
/* 282 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 286 */     return true; } private static boolean isEqualDatatype(Datatype dt1, Datatype dt2) { NBitUnsignedIntegerDatatype nbit1, nbit2; DatetimeDatatype d1, d2; RestrictedCharacterSetDatatype r1, r2; RestrictedCharacterSet rcs1, rcs2; int i;
/*     */     EnumerationDatatype e1, e2;
/*     */     int j;
/*     */     ListDatatype l1, l2;
/* 290 */     BuiltInType bit1 = dt1.getBuiltInType();
/* 291 */     BuiltInType bit2 = dt2.getBuiltInType();
/*     */     
/* 293 */     if (bit1 != bit2) {
/* 294 */       return false;
/*     */     }
/*     */     
/* 297 */     switch (bit1)
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case BINARY_BASE64:
/*     */       case BINARY_HEX:
/*     */       case BOOLEAN:
/*     */       case BOOLEAN_FACET:
/*     */       case DECIMAL:
/*     */       case FLOAT:
/*     */       case UNSIGNED_INTEGER:
/*     */       case INTEGER:
/*     */       case STRING:
/* 373 */         return true;case NBIT_UNSIGNED_INTEGER: nbit1 = (NBitUnsignedIntegerDatatype)dt1; nbit2 = (NBitUnsignedIntegerDatatype)dt2; if (nbit1.getNumberOfBits() != nbit2.getNumberOfBits()) return false;  if (!nbit1.getLowerBound().equals(nbit2.getLowerBound())) return false;  if (!nbit1.getUpperBound().equals(nbit2.getUpperBound())) return false; case DATETIME: d1 = (DatetimeDatatype)dt1; d2 = (DatetimeDatatype)dt2; if (d1.getDatetimeType() != d2.getDatetimeType()) return false; case RCS_STRING: r1 = (RestrictedCharacterSetDatatype)dt1; r2 = (RestrictedCharacterSetDatatype)dt2; rcs1 = r1.getRestrictedCharacterSet(); rcs2 = r2.getRestrictedCharacterSet(); if (rcs1.size() != rcs2.size()) return false;  for (i = 0; i < rcs1.size(); i++) { if (rcs1.getCodePoint(i) != rcs2.getCodePoint(i)) return false;  } case ENUMERATION: e1 = (EnumerationDatatype)dt1; e2 = (EnumerationDatatype)dt2; if (e1.getEnumerationSize() != e2.getEnumerationSize())
/*     */           return false;  if (e1.getEnumValueDatatype().getBuiltInType() != e2.getEnumValueDatatype().getBuiltInType())
/*     */           return false;  for (j = 0; j < e1.getEnumerationSize(); j++) { Value v1 = e1.getEnumValue(j); Value v2 = e2.getEnumValue(j); if (!v1.equals(v2))
/*     */             return false;  } case LIST: l1 = (ListDatatype)dt1; l2 = (ListDatatype)dt2; if (!isEqualDatatype(l1.getListDatatype(), l2.getListDatatype()))
/* 377 */           return false;  }  return false; } public boolean isGrammarHandled(Grammar gr) { boolean handled = false;
/* 378 */     if (this.doOptimizeGrammars) {
/*     */       
/* 380 */       Grammar gx = getEqualGrammar(gr);
/* 381 */       if (gx == null) {
/* 382 */         handled = false;
/*     */       } else {
/* 384 */         handled = true;
/*     */       } 
/*     */     } else {
/*     */       
/* 388 */       Iterator<Grammar> giter = getGrammarIterator();
/* 389 */       while (!handled && giter.hasNext()) {
/* 390 */         Grammar g = giter.next();
/* 391 */         if (g == gr)
/*     */         {
/* 393 */           handled = true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 398 */     return handled; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHandledGrammar(Grammar gr) {
/* 406 */     this.grammars.add(gr);
/*     */   }
/*     */   
/*     */   public Iterator<Grammar> getGrammarIterator() {
/* 410 */     return this.grammars.iterator();
/*     */   }
/*     */   
/*     */   private int getKnownGrammarID(Grammar r) {
/* 414 */     for (int i = 0; i < this.grammars.size(); i++) {
/* 415 */       if (this.grammars.get(i) == r) {
/* 416 */         return i;
/*     */       }
/*     */     } 
/* 419 */     return -1;
/*     */   }
/*     */   
/*     */   public Grammar getGrammar(int gid) {
/* 423 */     if (this.grammars != null && this.grammars.size() > gid && gid >= 0) {
/* 424 */       return this.grammars.get(gid);
/*     */     }
/* 426 */     throw new RuntimeException("Unexpected grammarID");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGrammarIDProof(Grammar g) {
/* 431 */     if (!isGrammarHandled(g)) {
/* 432 */       addHandledGrammar(g);
/*     */     }
/*     */     
/* 435 */     return getGrammarID(g);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGrammarID(Grammar r) {
/*     */     int id;
/* 443 */     if (this.doOptimizeGrammars) {
/* 444 */       id = getKnownGrammarID(r);
/* 445 */       if (id != -1) {
/* 446 */         return id;
/*     */       }
/*     */       
/* 449 */       Grammar gx = getEqualGrammar(r);
/* 450 */       if (gx == null) {
/* 451 */         throw new RuntimeException("no valid grammar ID found for :" + r + ". MUST be handled before!!");
/*     */       }
/*     */       
/* 454 */       id = getGrammarID(gx);
/*     */     } else {
/*     */       
/* 457 */       if (!isGrammarHandled(r)) {
/* 458 */         addHandledGrammar(r);
/*     */       }
/*     */       
/* 461 */       id = getKnownGrammarID(r);
/*     */     } 
/*     */     
/* 464 */     return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\persistency\GrammarIdDispenser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */