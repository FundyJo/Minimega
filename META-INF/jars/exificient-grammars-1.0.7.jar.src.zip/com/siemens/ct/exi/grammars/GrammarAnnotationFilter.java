/*     */ package com.siemens.ct.exi.grammars;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.DTDHandler;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrammarAnnotationFilter
/*     */   implements ContentHandler
/*     */ {
/*  33 */   private static final TransformerFactory tf = TransformerFactory.newInstance();
/*     */   
/*     */   private ContentHandler ch;
/*     */   
/*     */   private boolean rootElement;
/*     */   
/*     */   private final AttributesImpl typeNameAtts;
/*     */ 
/*     */   
/*     */   public GrammarAnnotationFilter(OutputStream os, String typeName) throws SAXException {
/*  43 */     this.typeNameAtts = new AttributesImpl();
/*  44 */     this.typeNameAtts.addAttribute("", "name", "name", "CDATA", typeName);
/*     */     
/*     */     try {
/*  47 */       Transformer t = tf.newTransformer();
/*     */       
/*  49 */       t.transform(new SAXSource(new XMLReader() {
/*     */               public ContentHandler getContentHandler() {
/*  51 */                 return GrammarAnnotationFilter.this.ch;
/*     */               }
/*     */               
/*     */               public DTDHandler getDTDHandler() {
/*  55 */                 return null;
/*     */               }
/*     */               
/*     */               public EntityResolver getEntityResolver() {
/*  59 */                 return null;
/*     */               }
/*     */               
/*     */               public ErrorHandler getErrorHandler() {
/*  63 */                 return null;
/*     */               }
/*     */               
/*     */               public boolean getFeature(String name) {
/*  67 */                 return false;
/*     */               }
/*     */               
/*     */               public Object getProperty(String name) {
/*  71 */                 return null;
/*     */               }
/*     */ 
/*     */               
/*     */               public void parse(InputSource input) {}
/*     */ 
/*     */               
/*     */               public void parse(String systemId) {}
/*     */               
/*     */               public void setContentHandler(ContentHandler handler) {
/*  81 */                 GrammarAnnotationFilter.this.ch = handler;
/*     */               }
/*     */ 
/*     */               
/*     */               public void setDTDHandler(DTDHandler handler) {}
/*     */ 
/*     */               
/*     */               public void setEntityResolver(EntityResolver resolver) {}
/*     */ 
/*     */               
/*     */               public void setErrorHandler(ErrorHandler handler) {}
/*     */ 
/*     */               
/*     */               public void setFeature(String name, boolean value) {}
/*     */ 
/*     */               
/*     */               public void setProperty(String name, Object value) {}
/*     */             },  new InputSource()), new StreamResult(os));
/*  99 */     } catch (TransformerException e) {
/* 100 */       throw new SAXException(e);
/*     */     } 
/*     */     
/* 103 */     if (this.ch == null)
/* 104 */       throw new SAXException("Transformer didn't set ContentHandler"); 
/*     */   }
/*     */   
/*     */   public void setDocumentLocator(Locator locator) {
/* 108 */     this.ch.setDocumentLocator(locator);
/*     */   }
/*     */   
/*     */   public void startDocument() throws SAXException {
/* 112 */     this.ch.startDocument();
/* 113 */     this.rootElement = true;
/*     */   }
/*     */   
/*     */   public void endDocument() throws SAXException {
/* 117 */     this.ch.endDocument();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/* 122 */     this.ch.startPrefixMapping(prefix, uri);
/*     */   }
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {
/* 126 */     this.ch.endPrefixMapping(prefix);
/*     */   }
/*     */   
/*     */   private String fixQName(String qname, String ename) {
/* 130 */     int index = qname.indexOf(':');
/* 131 */     if (index == -1)
/*     */     {
/* 133 */       return ename;
/*     */     }
/* 135 */     return qname.substring(0, index + 1) + ename;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
/* 142 */     if (this.rootElement && "http://www.w3.org/2001/XMLSchema".equals(uri) && "annotation"
/* 143 */       .equals(localName))
/*     */     
/* 145 */     { this.ch.startElement(uri, "schema", fixQName(qName, "schema"), null); }
/* 146 */     else { if (this.rootElement) {
/* 147 */         throw new SAXException("No annotation element as root element");
/*     */       }
/* 149 */       if ("http://www.w3.org/2001/XMLSchema".equals(uri) && "appinfo"
/* 150 */         .equals(localName)) {
/*     */         int indexAt;
/*     */         
/* 153 */         if (atts != null && (
/*     */           
/* 155 */           indexAt = atts.getIndex("http://www.w3.org/2009/exi", "prepopulateValues")) != -1 && "true"
/*     */ 
/*     */           
/* 158 */           .equals(atts.getValue(indexAt))) {
/*     */           
/* 160 */           this.ch.startElement(uri, "simpleType", 
/* 161 */               fixQName(qName, "simpleType"), this.typeNameAtts);
/*     */         } else {
/* 163 */           throw new SAXException("No prepopulateValues attribute in annotation element");
/*     */         } 
/*     */       } else {
/*     */         
/* 167 */         this.ch.startElement(uri, localName, qName, atts);
/*     */       }  }
/*     */ 
/*     */     
/* 171 */     this.rootElement = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) throws SAXException {
/* 177 */     if ("http://www.w3.org/2001/XMLSchema".equals(uri) && "annotation"
/* 178 */       .equals(localName)) {
/* 179 */       this.ch.endElement(uri, "schema", fixQName(qName, "schema"));
/* 180 */     } else if ("http://www.w3.org/2001/XMLSchema".equals(uri) && "appinfo"
/* 181 */       .equals(localName)) {
/* 182 */       this.ch.endElement(uri, "simpleType", fixQName(qName, "simpleType"));
/*     */     } else {
/* 184 */       this.ch.endElement(uri, localName, qName);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 190 */     this.ch.characters(ch, start, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
/* 195 */     this.ch.ignorableWhitespace(ch, start, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) throws SAXException {
/* 200 */     this.ch.processingInstruction(target, data);
/*     */   }
/*     */   
/*     */   public void skippedEntity(String name) throws SAXException {
/* 204 */     this.ch.skippedEntity(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\GrammarAnnotationFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */