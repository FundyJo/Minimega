/*     */ package com.siemens.ct.exi.grammars.persistency;
/*     */ 
/*     */ import com.siemens.ct.exi.core.context.GrammarContext;
/*     */ import com.siemens.ct.exi.core.context.GrammarUriContext;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.datatype.Datatype;
/*     */ import com.siemens.ct.exi.core.datatype.DatetimeDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.EnumerationDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.ListDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.NBitUnsignedIntegerDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.RestrictedCharacterSetDatatype;
/*     */ import com.siemens.ct.exi.core.datatype.charset.RestrictedCharacterSet;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.Grammars;
/*     */ import com.siemens.ct.exi.core.grammars.SchemaInformedGrammars;
/*     */ import com.siemens.ct.exi.core.grammars.event.Attribute;
/*     */ import com.siemens.ct.exi.core.grammars.event.AttributeNS;
/*     */ import com.siemens.ct.exi.core.grammars.event.Characters;
/*     */ import com.siemens.ct.exi.core.grammars.event.DatatypeEvent;
/*     */ import com.siemens.ct.exi.core.grammars.event.Event;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElement;
/*     */ import com.siemens.ct.exi.core.grammars.event.StartElementNS;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.Grammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFirstStartTagGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.grammar.SchemaInformedGrammar;
/*     */ import com.siemens.ct.exi.core.grammars.production.Production;
/*     */ import com.siemens.ct.exi.core.types.BuiltIn;
/*     */ import com.siemens.ct.exi.core.types.BuiltInType;
/*     */ import com.siemens.ct.exi.core.values.IntegerValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import com.siemens.ct.exi.grammars.XSDGrammarsBuilder;
/*     */ import com.siemens.ct.exi.grammars.util.PrintfUtils;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Grammars2JSON
/*     */ {
/*  79 */   private static final Logger LOGGER = LoggerFactory.getLogger(Grammars2JSON.class);
/*     */   
/*  81 */   public static final PrintStream ps = System.out;
/*     */   
/*     */   public static final boolean STATS_ON = true;
/*     */   
/*  85 */   protected int statsCountTransitions = 0;
/*  86 */   protected int statsCountStates = 0;
/*     */   
/*  88 */   GrammarsPreperation gpreps = new GrammarsPreperation();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clear() {
/*  95 */     this.gpreps.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toGrammarsJSON(SchemaInformedGrammars grammars, OutputStream os) throws IOException, EXIException {
/* 102 */     clear();
/*     */ 
/*     */     
/* 105 */     this.gpreps.prepareGrammars((Grammars)grammars);
/*     */     
/* 107 */     GrammarContext grammarContext = grammars.getGrammarContext();
/*     */     
/* 109 */     Writer w = new OutputStreamWriter(os);
/*     */     
/* 111 */     List<Datatype> listOfDatatypes = new ArrayList<>();
/*     */     
/* 113 */     for (int i = 0; i < this.gpreps.getNumberOfGrammars(); i++) {
/* 114 */       Grammar r = this.gpreps.getGrammar(i);
/* 115 */       for (int k = 0; k < r.getNumberOfEvents(); k++) {
/* 116 */         Production p = r.getProduction(k);
/* 117 */         Event e = p.getEvent();
/* 118 */         if (e instanceof DatatypeEvent) {
/* 119 */           DatatypeEvent de = (DatatypeEvent)e;
/*     */           
/* 121 */           if (!listOfDatatypes.contains(de.getDatatype()) && de
/* 122 */             .getDatatype() != BuiltIn.getDefaultDatatype()) {
/* 123 */             listOfDatatypes.add(de.getDatatype());
/*     */           }
/*     */           
/* 126 */           Datatype base = de.getDatatype().getBaseDatatype();
/* 127 */           if (base != null && !listOfDatatypes.contains(base)) {
/* 128 */             listOfDatatypes.add(base);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 134 */     int ind = 0;
/* 135 */     PrintfUtils.printfIndLn(w, ind, "{", new Object[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     ind++;
/* 143 */     PrintfUtils.printfIndLn(w, ind, "\"%s\" : { ", new Object[] { "qnames" });
/*     */ 
/*     */     
/* 146 */     ind++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     PrintfUtils.printfIndLn(w, ind, "\"%s\" : [", new Object[] { "namespaceContext", 
/*     */           
/* 156 */           Integer.valueOf(grammarContext.getNumberOfGrammarQNameContexts()) });
/* 157 */     ind++;
/*     */     int j;
/* 159 */     for (j = 0; j < grammarContext.getNumberOfGrammarUriContexts(); j++) {
/*     */       
/* 161 */       PrintfUtils.printfIndLn(w, ind, "{", new Object[0]);
/*     */       
/* 163 */       ind++;
/*     */       
/* 165 */       GrammarUriContext guc = grammarContext.getGrammarUriContext(j);
/*     */ 
/*     */       
/* 168 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "uriID", 
/* 169 */             Integer.valueOf(guc.getNamespaceUriID()) });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 174 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\", ", new Object[] { "uri", guc
/* 175 */             .getNamespaceUri() });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 181 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : [", new Object[] { "qnameContext" });
/*     */       
/* 183 */       ind++;
/*     */ 
/*     */       
/* 186 */       for (int k = 0; k < guc.getNumberOfQNames(); k++) {
/* 187 */         QNameContext qnc = guc.getQNameContext(k);
/*     */ 
/*     */         
/* 190 */         PrintfUtils.printfIndLn(w, ind, "{", new Object[0]);
/* 191 */         ind++;
/*     */         
/* 193 */         PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "uriID", 
/*     */               
/* 195 */               Integer.valueOf(qnc.getNamespaceUriID()) });
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 200 */         PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "localNameID", 
/*     */               
/* 202 */               Integer.valueOf(qnc.getLocalNameID()) });
/*     */ 
/*     */ 
/*     */         
/* 206 */         PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\"", new Object[] { "localName", qnc
/*     */               
/* 208 */               .getLocalName() });
/*     */ 
/*     */         
/* 211 */         if (qnc.getTypeGrammar() != null) {
/* 212 */           PrintfUtils.printfIndLn(w, ind, ",", new Object[0]);
/* 213 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %s ", new Object[] { "globalTypeGrammarID", 
/*     */                 
/* 215 */                 Integer.valueOf(this.gpreps.getGrammarID((Grammar)qnc.getTypeGrammar())) });
/*     */         } 
/*     */ 
/*     */         
/* 219 */         if (qnc.getGlobalStartElement() != null) {
/* 220 */           StartElement se = qnc.getGlobalStartElement();
/* 221 */           PrintfUtils.printfIndLn(w, ind, ",", new Object[0]);
/*     */           
/* 223 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %s ", new Object[] {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 228 */                 "globalElementGrammarID", Integer.valueOf(this.gpreps.getGrammarID(se.getGrammar()))
/*     */               });
/*     */         } 
/*     */         
/* 232 */         if (qnc.getGlobalAttribute() != null) {
/* 233 */           Attribute at = qnc.getGlobalAttribute();
/*     */ 
/*     */           
/* 236 */           PrintfUtils.printfIndLn(w, ind, ",", new Object[0]);
/*     */           
/* 238 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %s ", new Object[] {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 243 */                 "globalAttributeDatatypeID", Integer.valueOf(listOfDatatypes.indexOf(at
/* 244 */                     .getDatatype()))
/*     */               });
/*     */         } 
/* 247 */         ind--;
/* 248 */         PrintfUtils.printfIndLn(w, ind, "}", new Object[0]);
/* 249 */         if (k < guc.getNumberOfQNames() - 1) {
/* 250 */           PrintfUtils.printfIndLn(w, ind, ", ", new Object[0]);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 257 */       ind--;
/* 258 */       PrintfUtils.printfIndLn(w, ind, "]", new Object[0]);
/*     */       
/* 260 */       ind--;
/* 261 */       PrintfUtils.printfIndLn(w, ind, "}", new Object[0]);
/*     */ 
/*     */       
/* 264 */       if (j < grammarContext.getNumberOfGrammarUriContexts() - 1) {
/* 265 */         PrintfUtils.printfIndLn(w, ind, ", ", new Object[0]);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 270 */     ind--;
/* 271 */     PrintfUtils.printfIndLn(w, ind, "]", new Object[0]);
/*     */     
/* 273 */     ind--;
/* 274 */     PrintfUtils.printfIndLn(w, ind, "}", new Object[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 279 */     PrintfUtils.printfIndLn(w, ind, ",", new Object[0]);
/* 280 */     PrintfUtils.printfIndLn(w, ind, "\"%s\" : [ ", new Object[] { "simpleDatatypes" });
/*     */     
/* 282 */     ind++;
/*     */     
/* 284 */     for (j = 0; j < listOfDatatypes.size(); j++) {
/* 285 */       Datatype dt = listOfDatatypes.get(j);
/*     */       
/* 287 */       PrintfUtils.printfIndLn(w, ind, "{", new Object[0]);
/*     */ 
/*     */ 
/*     */       
/* 291 */       ind++;
/* 292 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d,", new Object[] { "simpleDatatypeID", 
/* 293 */             Integer.valueOf(j) });
/* 294 */       printBuiltInDatatype(w, ind, dt);
/*     */ 
/*     */       
/* 297 */       dt.getSchemaType();
/*     */       
/* 299 */       ind--;
/*     */       
/* 301 */       PrintfUtils.printfIndLn(w, ind, "}", new Object[0]);
/*     */       
/* 303 */       if (j < listOfDatatypes.size() - 1) {
/* 304 */         PrintfUtils.printfIndLn(w, ind, ", ", new Object[0]);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 309 */     ind--;
/* 310 */     PrintfUtils.printfIndLn(w, ind, "]", new Object[0]);
/*     */     
/* 312 */     PrintfUtils.printfIndLn(w, ind, ", ", new Object[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 317 */     PrintfUtils.printfIndLn(w, ind, "\"grs\" : {", new Object[0]);
/* 318 */     ind++;
/*     */     
/* 320 */     PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "documentGrammarID", 
/*     */           
/* 322 */           Integer.valueOf(this.gpreps.getGrammarID(grammars.getDocumentGrammar())) });
/* 323 */     PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "fragmentGrammarID", 
/*     */           
/* 325 */           Integer.valueOf(this.gpreps.getGrammarID(grammars.getFragmentGrammar())) });
/*     */     
/* 327 */     PrintfUtils.printfIndLn(w, ind, "\"%s\" : [", new Object[] { "grammar", 
/*     */           
/* 329 */           Integer.valueOf(this.gpreps.getGrammarID(grammars.getDocumentGrammar())) });
/* 330 */     ind++;
/*     */     
/* 332 */     for (j = 0; j < this.gpreps.getNumberOfGrammars(); j++) {
/* 333 */       Grammar r = this.gpreps.getGrammar(j);
/* 334 */       printGrammar(w, ind, (SchemaInformedGrammar)r, listOfDatatypes);
/*     */ 
/*     */       
/* 337 */       if (j < this.gpreps.getNumberOfGrammars() - 1) {
/* 338 */         PrintfUtils.printfIndLn(w, ind, ", ", new Object[0]);
/*     */       }
/*     */     } 
/*     */     
/* 342 */     ind--;
/* 343 */     PrintfUtils.printfIndLn(w, ind, "]", new Object[0]);
/*     */     
/* 345 */     ind--;
/* 346 */     PrintfUtils.printfIndLn(w, ind, "}", new Object[0]);
/*     */ 
/*     */ 
/*     */     
/* 350 */     PrintfUtils.printfIndLn(w, 0, "}", new Object[0]);
/*     */     
/* 352 */     w.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void printGrammar(Writer w, int ind, SchemaInformedGrammar sir, List<Datatype> listOfDatatypes) throws IOException {
/* 358 */     PrintfUtils.printfIndLn(w, ind, "{", new Object[0]);
/* 359 */     ind++;
/*     */     
/* 361 */     PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%d\" ,", new Object[] { "grammarID", 
/* 362 */           Integer.valueOf(this.gpreps.getGrammarID((Grammar)sir)) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 368 */     if (sir instanceof SchemaInformedFirstStartTagGrammar) {
/* 369 */       SchemaInformedFirstStartTagGrammar fst = (SchemaInformedFirstStartTagGrammar)sir;
/*     */       
/* 371 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "type", "firstStartTagContent" });
/*     */ 
/*     */ 
/*     */       
/* 375 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : %s ,", new Object[] { "isTypeCastable", 
/* 376 */             Boolean.valueOf(fst.isTypeCastable()) });
/* 377 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : %s ,", new Object[] { "isNillable", 
/* 378 */             Boolean.valueOf(fst.isNillable()) });
/*     */     }
/* 380 */     else if (sir instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedStartTagGrammar) {
/*     */       
/* 382 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "type", "startTagContent" });
/*     */     
/*     */     }
/* 385 */     else if (sir instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedElement) {
/* 386 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "type", "elementContent" });
/*     */     }
/* 388 */     else if (sir instanceof com.siemens.ct.exi.core.grammars.grammar.Document) {
/* 389 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "type", "document" });
/*     */     }
/* 391 */     else if (sir instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedDocContent) {
/* 392 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "type", "docContent" });
/*     */     }
/* 394 */     else if (sir instanceof com.siemens.ct.exi.core.grammars.grammar.DocEnd) {
/* 395 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "type", "docEnd" });
/*     */     }
/* 397 */     else if (sir instanceof com.siemens.ct.exi.core.grammars.grammar.Fragment) {
/* 398 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "type", "fragment" });
/*     */     }
/* 400 */     else if (sir instanceof com.siemens.ct.exi.core.grammars.grammar.SchemaInformedFragmentContent) {
/* 401 */       PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "type", "fragmentContent" });
/*     */     }
/*     */     else {
/*     */       
/* 405 */       throw new RuntimeException("Unkown Rule type: " + sir);
/*     */     } 
/*     */     
/* 408 */     this.statsCountStates++;
/*     */ 
/*     */     
/* 411 */     PrintfUtils.printfIndLn(w, ind, "\"%s\" : [ ", new Object[] { "production" });
/*     */     
/* 413 */     ind++;
/* 414 */     printGrammarProduction(w, ind, sir, listOfDatatypes);
/* 415 */     ind--;
/* 416 */     PrintfUtils.printfIndLn(w, ind, "]", new Object[0]);
/*     */     
/* 418 */     ind--;
/* 419 */     PrintfUtils.printfIndLn(w, ind, "}", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void printGrammarProduction(Writer w, int ind, SchemaInformedGrammar sir, List<Datatype> listOfDatatypes) throws IOException {
/* 426 */     for (int i = 0; i < sir.getNumberOfEvents(); i++) {
/*     */       StartElement se; StartElementNS seNS; Attribute at; AttributeNS atNS; Characters ch; QNameContext eqname; Datatype dt; Grammar seRule; Datatype datatype1;
/* 428 */       this.statsCountTransitions++;
/*     */ 
/*     */       
/* 431 */       PrintfUtils.printfIndLn(w, ind, "{", new Object[0]);
/* 432 */       ind++;
/*     */       
/* 434 */       Production ei = sir.getProduction(i);
/* 435 */       Event event = ei.getEvent();
/* 436 */       EventType eventType = event.getEventType();
/* 437 */       switch (eventType) {
/*     */         case NBIT_UNSIGNED_INTEGER:
/* 439 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "startDocument" });
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case LIST:
/* 445 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "endDocument" });
/*     */           break;
/*     */ 
/*     */         
/*     */         case ENUMERATION:
/* 450 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "startElement" });
/*     */ 
/*     */ 
/*     */           
/* 454 */           se = (StartElement)event;
/* 455 */           eqname = se.getQNameContext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 461 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "startElementNamespaceID", 
/*     */                 
/* 463 */                 Integer.valueOf(eqname.getNamespaceUriID()) });
/* 464 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "startElementLocalNameID", 
/*     */                 
/* 466 */                 Integer.valueOf(eqname.getLocalNameID()) });
/*     */ 
/*     */           
/* 469 */           seRule = se.getGrammar();
/* 470 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "startElementGrammarID", 
/*     */                 
/* 472 */                 Integer.valueOf(this.gpreps.getGrammarID(seRule)) });
/*     */           break;
/*     */         
/*     */         case DATETIME:
/* 476 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "startElementNS" });
/*     */ 
/*     */ 
/*     */           
/* 480 */           seNS = (StartElementNS)event;
/* 481 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "startElementNamespaceID", 
/*     */                 
/* 483 */                 Integer.valueOf(seNS.getNamespaceUriID()) });
/*     */           break;
/*     */         
/*     */         case RCS_STRING:
/* 487 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "endElement" });
/*     */           break;
/*     */         
/*     */         case BOOLEAN_FACET:
/* 491 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "attribute" });
/*     */ 
/*     */           
/* 494 */           at = (Attribute)event;
/* 495 */           eqname = at.getQNameContext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 501 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "attributeNamespaceID", 
/*     */                 
/* 503 */                 Integer.valueOf(eqname.getNamespaceUriID()) });
/* 504 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "attributeLocalNameID", 
/*     */                 
/* 506 */                 Integer.valueOf(eqname.getLocalNameID()) });
/*     */ 
/*     */           
/* 509 */           datatype1 = at.getDatatype();
/* 510 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "attributeDatatypeID", 
/*     */                 
/* 512 */                 Integer.valueOf(listOfDatatypes.indexOf(datatype1)) });
/*     */           break;
/*     */ 
/*     */         
/*     */         case null:
/* 517 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "attributeNS" });
/*     */ 
/*     */ 
/*     */           
/* 521 */           atNS = (AttributeNS)event;
/* 522 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "attributeNamespaceID", 
/*     */                 
/* 524 */                 Integer.valueOf(atNS.getNamespaceUriID()) });
/*     */           break;
/*     */         
/*     */         case null:
/* 528 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "characters" });
/*     */ 
/*     */           
/* 531 */           ch = (Characters)event;
/* 532 */           dt = ch.getDatatype();
/*     */           
/* 534 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d ,", new Object[] { "charactersDatatypeID", 
/*     */                 
/* 536 */                 Integer.valueOf(listOfDatatypes.indexOf(dt)) });
/*     */           break;
/*     */         
/*     */         case null:
/* 540 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "startElementGeneric" });
/*     */           break;
/*     */ 
/*     */         
/*     */         case null:
/* 545 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "attributeGeneric" });
/*     */           break;
/*     */ 
/*     */         
/*     */         case null:
/* 550 */           PrintfUtils.printfIndLn(w, ind, "\"%s\" : \"%s\" ,", new Object[] { "event", "charactersGeneric" });
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 555 */           LOGGER.error("Unknown Event {}", ei.getEvent());
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 560 */       Grammar nextRule = ei.getNextGrammar();
/* 561 */       if (nextRule.getNumberOfEvents() > 0) {
/* 562 */         PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d", new Object[] { "nextGrammarID", 
/*     */               
/* 564 */               Integer.valueOf(this.gpreps.getGrammarID(nextRule)) });
/*     */       } else {
/*     */         
/* 567 */         PrintfUtils.printfIndLn(w, ind, "\"%s\" : %d", new Object[] { "nextGrammarID", 
/* 568 */               Integer.valueOf(-1) });
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 573 */       ind--;
/* 574 */       PrintfUtils.printfIndLn(w, ind, "}", new Object[0]);
/*     */       
/* 576 */       if (i < sir.getNumberOfEvents() - 1) {
/* 577 */         PrintfUtils.printfIndLn(w, ind, ", ", new Object[0]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void printBuiltInDatatype(Writer w, int ind, Datatype dt) throws IOException {
/* 585 */     printBuiltInDatatype(w, ind, dt, "type"); } protected void printBuiltInDatatype(Writer w, int ind, Datatype dt, String typeID) throws IOException { NBitUnsignedIntegerDatatype nbdt; IntegerValue ivLower, ivUpper; ListDatatype ldt; EnumerationDatatype edt;
/*     */     int i;
/*     */     DatetimeDatatype ddt;
/*     */     RestrictedCharacterSetDatatype rcsdt;
/*     */     RestrictedCharacterSet rcs;
/*     */     int j;
/* 591 */     BuiltInType bit = dt.getBuiltInType();
/*     */     
/* 593 */     PrintfUtils.printfInd(w, ind, "\"%s\": \"%s\"", new Object[] { typeID, bit });
/*     */     
/* 595 */     switch (bit) {
/*     */       case NBIT_UNSIGNED_INTEGER:
/* 597 */         PrintfUtils.printfLn(w, ",", new Object[] { bit });
/* 598 */         nbdt = (NBitUnsignedIntegerDatatype)dt;
/* 599 */         ivLower = nbdt.getLowerBound();
/* 600 */         PrintfUtils.printfIndLn(w, ind, "\"%s\": %s,", new Object[] { "lowerBound", ivLower
/* 601 */               .toString() });
/* 602 */         ivUpper = nbdt.getUpperBound();
/* 603 */         PrintfUtils.printfIndLn(w, ind, "\"%s\": %s", new Object[] { "upperBound", ivUpper
/* 604 */               .toString() });
/*     */         return;
/*     */       case LIST:
/* 607 */         PrintfUtils.printfLn(w, ",", new Object[] { bit });
/* 608 */         ldt = (ListDatatype)dt;
/*     */         
/* 610 */         printBuiltInDatatype(w, ind, ldt.getListDatatype(), "listType");
/*     */         return;
/*     */       
/*     */       case ENUMERATION:
/* 614 */         PrintfUtils.printfLn(w, ",", new Object[] { bit });
/* 615 */         edt = (EnumerationDatatype)dt;
/*     */         
/* 617 */         PrintfUtils.printfInd(w, ind, "\"%s\": [", new Object[] { "enumValues" });
/*     */         
/* 619 */         for (i = 0; i < edt.getEnumerationSize(); i++) {
/*     */           
/* 621 */           Value enumVal = edt.getEnumValue(i);
/*     */           
/* 623 */           PrintfUtils.printf(w, "\"%s\"", new Object[] { enumVal.toString() });
/* 624 */           if (i + 1 < edt.getEnumerationSize()) {
/* 625 */             PrintfUtils.printf(w, ", ", new Object[0]);
/*     */           }
/*     */         } 
/* 628 */         PrintfUtils.printfLn(w, "]", new Object[0]);
/*     */         return;
/*     */       
/*     */       case DATETIME:
/* 632 */         PrintfUtils.printfLn(w, ",", new Object[] { bit });
/* 633 */         ddt = (DatetimeDatatype)dt;
/* 634 */         PrintfUtils.printfIndLn(w, ind, "\"%s\": \"%s\"", new Object[] { "datetimeType", ddt
/* 635 */               .getDatetimeType().toString() });
/*     */         return;
/*     */       case RCS_STRING:
/* 638 */         PrintfUtils.printfLn(w, ",", new Object[] { bit });
/* 639 */         rcsdt = (RestrictedCharacterSetDatatype)dt;
/*     */         
/* 641 */         rcs = rcsdt.getRestrictedCharacterSet();
/* 642 */         PrintfUtils.printfInd(w, ind, "\"%s\": [", new Object[] { "codePoints" });
/* 643 */         for (j = 0; j < rcs.size(); j++) {
/* 644 */           PrintfUtils.printf(w, "%d", new Object[] { Integer.valueOf(rcs.getCodePoint(j)) });
/* 645 */           if (j + 1 < rcs.size()) {
/* 646 */             PrintfUtils.printf(w, ", ", new Object[0]);
/*     */           }
/*     */         } 
/* 649 */         PrintfUtils.printfLn(w, "]", new Object[0]);
/*     */         return;
/*     */       
/*     */       case BOOLEAN_FACET:
/* 653 */         PrintfUtils.printfLn(w, ",", new Object[] { bit });
/* 654 */         PrintfUtils.printfIndLn(w, ind, "\"%s\": \"%s\"", new Object[] { "facet", "true" });
/*     */         return;
/*     */     } 
/*     */     
/* 658 */     PrintfUtils.printfLn(w, "", new Object[] { bit }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 665 */     if (args == null || args.length == 0) {
/*     */       
/* 667 */       ps.println("#########################################################################");
/* 668 */       ps.println("###   EXIficient - Grammars2JSON                                     ###");
/* 669 */       ps.println("###   Command-Shell Options                                          ###");
/* 670 */       ps.println("#########################################################################");
/* 671 */       ps.println(" <xsd-input-file>");
/*     */     } else {
/* 673 */       String xsd = args[0];
/* 674 */       String grsOut = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 689 */       grsOut = xsd + ".grs";
/*     */       
/* 691 */       XSDGrammarsBuilder grammarBuilder = XSDGrammarsBuilder.newInstance();
/*     */       
/* 693 */       grammarBuilder.loadGrammars(xsd);
/*     */       
/* 695 */       SchemaInformedGrammars grammarIn = grammarBuilder.toGrammars();
/*     */       
/* 697 */       Grammars2JSON g2j = new Grammars2JSON();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 702 */       FileOutputStream fos = new FileOutputStream(grsOut);
/* 703 */       g2j.toGrammarsJSON(grammarIn, fos);
/* 704 */       fos.close();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 710 */       System.out.println("Transitions: " + g2j.statsCountTransitions);
/* 711 */       System.out.println("States: " + g2j.statsCountStates);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\persistency\Grammars2JSON.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */