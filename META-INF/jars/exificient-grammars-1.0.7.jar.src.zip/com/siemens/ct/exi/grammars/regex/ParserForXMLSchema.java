/*     */ package com.siemens.ct.exi.grammars.regex;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ParserForXMLSchema
/*     */   extends RegexParser
/*     */ {
/*     */   public ParserForXMLSchema() {}
/*     */   
/*     */   public ParserForXMLSchema(Locale locale) {
/*  46 */     super(locale);
/*     */   }
/*     */   
/*     */   Token processCaret() throws ParseException {
/*  50 */     next();
/*  51 */     return Token.createChar(94);
/*     */   }
/*     */   
/*     */   Token processDollar() throws ParseException {
/*  55 */     next();
/*  56 */     return Token.createChar(36);
/*     */   }
/*     */   
/*     */   Token processLookahead() throws ParseException {
/*  60 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processNegativelookahead() throws ParseException {
/*  64 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processLookbehind() throws ParseException {
/*  68 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processNegativelookbehind() throws ParseException {
/*  72 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_A() throws ParseException {
/*  76 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_Z() throws ParseException {
/*  80 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_z() throws ParseException {
/*  84 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_b() throws ParseException {
/*  88 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_B() throws ParseException {
/*  92 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_lt() throws ParseException {
/*  96 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_gt() throws ParseException {
/* 100 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processStar(Token tok) throws ParseException {
/* 104 */     next();
/* 105 */     return Token.createClosure(tok);
/*     */   }
/*     */ 
/*     */   
/*     */   Token processPlus(Token tok) throws ParseException {
/* 110 */     next();
/* 111 */     return Token.createConcat(tok, Token.createClosure(tok));
/*     */   }
/*     */ 
/*     */   
/*     */   Token processQuestion(Token tok) throws ParseException {
/* 116 */     next();
/* 117 */     Token par = Token.createUnion();
/* 118 */     par.addChild(tok);
/* 119 */     par.addChild(Token.createEmpty());
/* 120 */     return par;
/*     */   }
/*     */   
/*     */   boolean checkQuestion(int off) {
/* 124 */     return false;
/*     */   }
/*     */   
/*     */   Token processParen() throws ParseException {
/* 128 */     next();
/* 129 */     Token tok = Token.createParen(parseRegex(), 0);
/* 130 */     if (read() != 7)
/* 131 */       throw ex("parser.factor.1", this.offset - 1); 
/* 132 */     next();
/* 133 */     return tok;
/*     */   }
/*     */   
/*     */   Token processParen2() throws ParseException {
/* 137 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processCondition() throws ParseException {
/* 141 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processModifiers() throws ParseException {
/* 145 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processIndependent() throws ParseException {
/* 149 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_c() throws ParseException {
/* 153 */     next();
/* 154 */     return getTokenForShorthand(99);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_C() throws ParseException {
/* 158 */     next();
/* 159 */     return getTokenForShorthand(67);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_i() throws ParseException {
/* 163 */     next();
/* 164 */     return getTokenForShorthand(105);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_I() throws ParseException {
/* 168 */     next();
/* 169 */     return getTokenForShorthand(73);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_g() throws ParseException {
/* 173 */     throw ex("parser.process.1", this.offset - 2);
/*     */   }
/*     */   
/*     */   Token processBacksolidus_X() throws ParseException {
/* 177 */     throw ex("parser.process.1", this.offset - 2);
/*     */   }
/*     */   
/*     */   Token processBackreference() throws ParseException {
/* 181 */     throw ex("parser.process.1", this.offset - 4);
/*     */   }
/*     */   
/*     */   int processCIinCharacterClass(RangeToken tok, int c) {
/* 185 */     tok.mergeRanges(getTokenForShorthand(c));
/* 186 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RangeToken parseCharacterClass(boolean useNrange) throws ParseException {
/*     */     RangeToken tok;
/* 207 */     setContext(1);
/* 208 */     next();
/* 209 */     boolean nrange = false;
/* 210 */     boolean wasDecoded = false;
/* 211 */     RangeToken base = null;
/*     */     
/* 213 */     if (read() == 0 && this.chardata == 94) {
/* 214 */       nrange = true;
/* 215 */       next();
/* 216 */       base = Token.createRange();
/* 217 */       base.addRange(0, 1114111);
/* 218 */       tok = Token.createRange();
/*     */     } else {
/* 220 */       tok = Token.createRange();
/*     */     } 
/*     */     
/* 223 */     boolean firstloop = true; int type;
/* 224 */     while ((type = read()) != 1) {
/*     */ 
/*     */       
/* 227 */       wasDecoded = false;
/*     */       
/* 229 */       if (type == 0 && this.chardata == 93 && !firstloop) {
/* 230 */         if (nrange) {
/* 231 */           base.subtractRanges(tok);
/* 232 */           tok = base;
/*     */         } 
/*     */         break;
/*     */       } 
/* 236 */       int c = this.chardata;
/* 237 */       boolean end = false;
/* 238 */       if (type == 10) {
/* 239 */         int pstart; RangeToken tok2; switch (c) {
/*     */           case 68:
/*     */           case 83:
/*     */           case 87:
/*     */           case 100:
/*     */           case 115:
/*     */           case 119:
/* 246 */             tok.mergeRanges(getTokenForShorthand(c));
/* 247 */             end = true;
/*     */             break;
/*     */           
/*     */           case 67:
/*     */           case 73:
/*     */           case 99:
/*     */           case 105:
/* 254 */             c = processCIinCharacterClass(tok, c);
/* 255 */             if (c < 0) {
/* 256 */               end = true;
/*     */             }
/*     */             break;
/*     */           case 80:
/*     */           case 112:
/* 261 */             pstart = this.offset;
/* 262 */             tok2 = processBacksolidus_pP(c);
/* 263 */             if (tok2 == null)
/* 264 */               throw ex("parser.atom.5", pstart); 
/* 265 */             tok.mergeRanges(tok2);
/* 266 */             end = true;
/*     */             break;
/*     */           
/*     */           case 45:
/* 270 */             c = decodeEscaped();
/* 271 */             wasDecoded = true;
/*     */             break;
/*     */           
/*     */           default:
/* 275 */             c = decodeEscaped();
/*     */             break;
/*     */         } 
/* 278 */       } else if (type == 24 && !firstloop) {
/*     */         
/* 280 */         if (nrange) {
/* 281 */           base.subtractRanges(tok);
/* 282 */           tok = base;
/*     */         } 
/* 284 */         RangeToken range2 = parseCharacterClass(false);
/* 285 */         tok.subtractRanges(range2);
/* 286 */         if (read() != 0 || this.chardata != 93)
/* 287 */           throw ex("parser.cc.5", this.offset); 
/*     */         break;
/*     */       } 
/* 290 */       next();
/* 291 */       if (!end) {
/* 292 */         if (type == 0) {
/* 293 */           if (c == 91)
/* 294 */             throw ex("parser.cc.6", this.offset - 2); 
/* 295 */           if (c == 93)
/* 296 */             throw ex("parser.cc.7", this.offset - 2); 
/* 297 */           if (c == 45 && this.chardata != 93 && !firstloop) {
/* 298 */             throw ex("parser.cc.8", this.offset - 2);
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 305 */         if (read() != 0 || this.chardata != 45 || (c == 45 && firstloop)) {
/*     */           
/* 307 */           if (!isSet(2) || c > 65535) {
/*     */             
/* 309 */             tok.addRange(c, c);
/*     */           } else {
/* 311 */             addCaseInsensitiveChar(tok, c);
/*     */           } 
/*     */         } else {
/*     */           
/* 315 */           next();
/* 316 */           if ((type = read()) == 1) {
/* 317 */             throw ex("parser.cc.2", this.offset);
/*     */           }
/* 319 */           if (type == 0 && this.chardata == 93)
/*     */           
/*     */           { 
/*     */ 
/*     */             
/* 324 */             if (!isSet(2) || c > 65535) {
/*     */               
/* 326 */               tok.addRange(c, c);
/*     */             } else {
/* 328 */               addCaseInsensitiveChar(tok, c);
/*     */             } 
/* 330 */             tok.addRange(45, 45); }
/* 331 */           else { if (type == 24) {
/* 332 */               throw ex("parser.cc.8", this.offset - 1);
/*     */             }
/*     */             
/* 335 */             int rangeend = this.chardata;
/* 336 */             if (type == 0) {
/* 337 */               if (rangeend == 91)
/* 338 */                 throw ex("parser.cc.6", this.offset - 1); 
/* 339 */               if (rangeend == 93)
/* 340 */                 throw ex("parser.cc.7", this.offset - 1); 
/* 341 */               if (rangeend == 45)
/* 342 */                 throw ex("parser.cc.8", this.offset - 2); 
/* 343 */             } else if (type == 10) {
/* 344 */               rangeend = decodeEscaped();
/* 345 */             }  next();
/*     */             
/* 347 */             if (c > rangeend)
/* 348 */               throw ex("parser.ope.3", this.offset - 1); 
/* 349 */             if (!isSet(2) || (c > 65535 && rangeend > 65535)) {
/*     */               
/* 351 */               tok.addRange(c, rangeend);
/*     */             } else {
/* 353 */               addCaseInsensitiveCharRange(tok, c, rangeend);
/*     */             }  }
/*     */         
/*     */         } 
/*     */       } 
/* 358 */       firstloop = false;
/*     */     } 
/* 360 */     if (read() == 1)
/* 361 */       throw ex("parser.cc.2", this.offset); 
/* 362 */     tok.sortRanges();
/* 363 */     tok.compactRanges();
/*     */     
/* 365 */     setContext(0);
/* 366 */     next();
/*     */     
/* 368 */     return tok;
/*     */   }
/*     */   
/*     */   protected RangeToken parseSetOperations() throws ParseException {
/* 372 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token getTokenForShorthand(int ch) {
/* 376 */     switch (ch) {
/*     */       case 100:
/* 378 */         return getRange("xml:isDigit", true);
/*     */       case 68:
/* 380 */         return getRange("xml:isDigit", false);
/*     */       case 119:
/* 382 */         return getRange("xml:isWord", true);
/*     */       case 87:
/* 384 */         return getRange("xml:isWord", false);
/*     */       case 115:
/* 386 */         return getRange("xml:isSpace", true);
/*     */       case 83:
/* 388 */         return getRange("xml:isSpace", false);
/*     */       case 99:
/* 390 */         return getRange("xml:isNameChar", true);
/*     */       case 67:
/* 392 */         return getRange("xml:isNameChar", false);
/*     */       case 105:
/* 394 */         return getRange("xml:isInitialNameChar", true);
/*     */       case 73:
/* 396 */         return getRange("xml:isInitialNameChar", false);
/*     */     } 
/* 398 */     throw new RuntimeException("Internal Error: shorthands: \\u" + 
/* 399 */         Integer.toString(ch, 16));
/*     */   }
/*     */ 
/*     */   
/*     */   int decodeEscaped() throws ParseException {
/* 404 */     if (read() != 10)
/* 405 */       throw ex("parser.next.1", this.offset - 1); 
/* 406 */     int c = this.chardata;
/* 407 */     switch (c) {
/*     */       case 110:
/* 409 */         c = 10;
/*     */       
/*     */       case 114:
/* 412 */         c = 13;
/*     */       
/*     */       case 116:
/* 415 */         c = 9;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 40:
/*     */       case 41:
/*     */       case 42:
/*     */       case 43:
/*     */       case 45:
/*     */       case 46:
/*     */       case 63:
/*     */       case 91:
/*     */       case 92:
/*     */       case 93:
/*     */       case 94:
/*     */       case 123:
/*     */       case 124:
/*     */       case 125:
/* 435 */         return c;
/*     */     } 
/*     */     throw ex("parser.process.1", this.offset - 2);
/* 438 */   } private static Map<String, Token> ranges = null;
/* 439 */   private static Map<String, Token> ranges2 = null; private static final String SPACES = "\t\n\r\r  "; private static final String NAMECHARS = "-.0:AZ__az··ÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁːˑ̀͠͡ͅΆΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁ҃҆ҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆֹֻֽֿֿׁׂ֑֣֡ׄׄאתװײءغـْ٠٩ٰڷںھۀێېۓە۪ۭۨ۰۹ँःअह़्॑॔क़ॣ०९ঁঃঅঌএঐওনপরললশহ়়াৄেৈো্ৗৗড়ঢ়য়ৣ০ৱਂਂਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹ਼਼ਾੂੇੈੋ੍ਖ਼ੜਫ਼ਫ਼੦ੴઁઃઅઋઍઍએઑઓનપરલળવહ઼ૅેૉો્ૠૠ૦૯ଁଃଅଌଏଐଓନପରଲଳଶହ଼ୃେୈୋ୍ୖୗଡ଼ଢ଼ୟୡ୦୯ஂஃஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹாூெைொ்ௗௗ௧௯ఁఃఅఌఎఐఒనపళవహాౄెైొ్ౕౖౠౡ౦౯ಂಃಅಌಎಐಒನಪಳವಹಾೄೆೈೊ್ೕೖೞೞೠೡ೦೯ംഃഅഌഎഐഒനപഹാൃെൈൊ്ൗൗൠൡ൦൯กฮะฺเ๎๐๙ກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະູົຽເໄໆໆ່ໍ໐໙༘༙༠༩༹༹༵༵༷༷༾ཇཉཀྵ྄ཱ྆ྋྐྕྗྗྙྭྱྷྐྵྐྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼ⃐⃜⃡⃡ΩΩKÅ℮℮ↀↂ々々〇〇〡〯〱〵ぁゔ゙゚ゝゞァヺーヾㄅㄬ一龥가힣";
/*     */   private static final String LETTERS = "AZazÀÖØöøıĴľŁňŊžƀǰǴǵǺȗɐʨʻˁʰˑΆΆΈΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆאתװײءغفيٱڷںھۀێېۓەەۥۦअहऽऽक़ॡঅঌএঐওনপরললশহড়ঢ়য়ৡৰৱਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹਖ਼ੜਫ਼ਫ਼ੲੴઅઋઍઍએઑઓનપરલળવહઽઽૠૠଅଌଏଐଓନପରଲଳଶହଽଽଡ଼ଢ଼ୟୡஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹఅఌఎఐఒనపళవహౠౡಅಌಎಐಒನಪಳವಹೞೞೠೡഅഌഎഐഒനപഹൠൡกฮะะาำเๅກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະະາຳຽຽເໄཀཇཉཀྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼΩΩKÅ℮℮ↀↂ〇〇〡〩ぁゔァヺㄅㄬ一龥가힣ｦﾟ";
/*     */   
/*     */   protected static synchronized RangeToken getRange(String name, boolean positive) {
/* 443 */     if (ranges == null) {
/* 444 */       ranges = new HashMap<>();
/* 445 */       ranges2 = new HashMap<>();
/*     */       
/* 447 */       Token token = Token.createRange();
/* 448 */       setupRange(token, "\t\n\r\r  ");
/* 449 */       ranges.put("xml:isSpace", token);
/* 450 */       ranges2.put("xml:isSpace", Token.complementRanges(token));
/*     */       
/* 452 */       token = Token.createRange();
/* 453 */       setupRange(token, "09٠٩۰۹०९০৯੦੯૦૯୦୯௧௯౦౯೦೯൦൯๐๙໐໙༠༩၀၉፩፱០៩᠐᠙０９");
/* 454 */       setupRange(token, DIGITS_INT);
/* 455 */       ranges.put("xml:isDigit", token);
/* 456 */       ranges2.put("xml:isDigit", Token.complementRanges(token));
/*     */       
/* 458 */       token = Token.createRange();
/* 459 */       setupRange(token, "AZazÀÖØöøıĴľŁňŊžƀǰǴǵǺȗɐʨʻˁʰˑΆΆΈΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆאתװײءغفيٱڷںھۀێېۓەەۥۦअहऽऽक़ॡঅঌএঐওনপরললশহড়ঢ়য়ৡৰৱਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹਖ਼ੜਫ਼ਫ਼ੲੴઅઋઍઍએઑઓનપરલળવહઽઽૠૠଅଌଏଐଓନପରଲଳଶହଽଽଡ଼ଢ଼ୟୡஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹఅఌఎఐఒనపళవహౠౡಅಌಎಐಒನಪಳವಹೞೞೠೡഅഌഎഐഒനപഹൠൡกฮะะาำเๅກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະະາຳຽຽເໄཀཇཉཀྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼΩΩKÅ℮℮ↀↂ〇〇〡〩ぁゔァヺㄅㄬ一龥가힣ｦﾟ");
/* 460 */       setupRange(token, LETTERS_INT);
/* 461 */       token.mergeRanges(ranges.get("xml:isDigit"));
/* 462 */       ranges.put("xml:isWord", token);
/* 463 */       ranges2.put("xml:isWord", Token.complementRanges(token));
/*     */       
/* 465 */       token = Token.createRange();
/* 466 */       setupRange(token, "-.0:AZ__az··ÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁːˑ̀͠͡ͅΆΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁ҃҆ҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆֹֻֽֿֿׁׂ֑֣֡ׄׄאתװײءغـْ٠٩ٰڷںھۀێېۓە۪ۭۨ۰۹ँःअह़्॑॔क़ॣ०९ঁঃঅঌএঐওনপরললশহ়়াৄেৈো্ৗৗড়ঢ়য়ৣ০ৱਂਂਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹ਼਼ਾੂੇੈੋ੍ਖ਼ੜਫ਼ਫ਼੦ੴઁઃઅઋઍઍએઑઓનપરલળવહ઼ૅેૉો્ૠૠ૦૯ଁଃଅଌଏଐଓନପରଲଳଶହ଼ୃେୈୋ୍ୖୗଡ଼ଢ଼ୟୡ୦୯ஂஃஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹாூெைொ்ௗௗ௧௯ఁఃఅఌఎఐఒనపళవహాౄెైొ్ౕౖౠౡ౦౯ಂಃಅಌಎಐಒನಪಳವಹಾೄೆೈೊ್ೕೖೞೞೠೡ೦೯ംഃഅഌഎഐഒനപഹാൃെൈൊ്ൗൗൠൡ൦൯กฮะฺเ๎๐๙ກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະູົຽເໄໆໆ່ໍ໐໙༘༙༠༩༹༹༵༵༷༷༾ཇཉཀྵ྄ཱ྆ྋྐྕྗྗྙྭྱྷྐྵྐྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼ⃐⃜⃡⃡ΩΩKÅ℮℮ↀↂ々々〇〇〡〯〱〵ぁゔ゙゚ゝゞァヺーヾㄅㄬ一龥가힣");
/* 467 */       ranges.put("xml:isNameChar", token);
/* 468 */       ranges2.put("xml:isNameChar", Token.complementRanges(token));
/*     */       
/* 470 */       token = Token.createRange();
/* 471 */       setupRange(token, "AZazÀÖØöøıĴľŁňŊžƀǰǴǵǺȗɐʨʻˁʰˑΆΆΈΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆאתװײءغفيٱڷںھۀێېۓەەۥۦअहऽऽक़ॡঅঌএঐওনপরললশহড়ঢ়য়ৡৰৱਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹਖ਼ੜਫ਼ਫ਼ੲੴઅઋઍઍએઑઓનપરલળવહઽઽૠૠଅଌଏଐଓନପରଲଳଶହଽଽଡ଼ଢ଼ୟୡஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹఅఌఎఐఒనపళవహౠౡಅಌಎಐಒನಪಳವಹೞೞೠೡഅഌഎഐഒനപഹൠൡกฮะะาำเๅກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະະາຳຽຽເໄཀཇཉཀྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼΩΩKÅ℮℮ↀↂ〇〇〡〩ぁゔァヺㄅㄬ一龥가힣ｦﾟ");
/* 472 */       token.addRange(95, 95);
/* 473 */       token.addRange(58, 58);
/* 474 */       ranges.put("xml:isInitialNameChar", token);
/* 475 */       ranges2.put("xml:isInitialNameChar", Token.complementRanges(token));
/*     */     } 
/*     */     
/* 478 */     RangeToken tok = positive ? (RangeToken)ranges.get(name) : (RangeToken)ranges2.get(name);
/* 479 */     return tok;
/*     */   }
/*     */   
/*     */   static void setupRange(Token range, String src) {
/* 483 */     int len = src.length();
/* 484 */     for (int i = 0; i < len; i += 2)
/* 485 */       range.addRange(src.charAt(i), src.charAt(i + 1)); 
/*     */   }
/*     */   
/*     */   static void setupRange(Token range, int[] src) {
/* 489 */     int len = src.length;
/* 490 */     for (int i = 0; i < len; i += 2) {
/* 491 */       range.addRange(src[i], src[i + 1]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 569 */   private static final int[] LETTERS_INT = new int[] { 120720, 120744, 120746, 120777, 195099, 195101 };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DIGITS = "09٠٩۰۹०९০৯੦੯૦૯୦୯௧௯౦౯೦೯൦൯๐๙໐໙༠༩၀၉፩፱០៩᠐᠙０９";
/*     */ 
/*     */   
/* 576 */   private static final int[] DIGITS_INT = new int[] { 120782, 120831 };
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\regex\ParserForXMLSchema.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */