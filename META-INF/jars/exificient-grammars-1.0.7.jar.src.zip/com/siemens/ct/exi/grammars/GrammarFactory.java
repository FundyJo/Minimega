/*     */ package com.siemens.ct.exi.grammars;
/*     */ 
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.Grammars;
/*     */ import com.siemens.ct.exi.core.grammars.SchemaInformedGrammars;
/*     */ import com.siemens.ct.exi.core.grammars.SchemaLessGrammars;
/*     */ import java.io.InputStream;
/*     */ import org.apache.xerces.xni.parser.XMLEntityResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrammarFactory
/*     */ {
/*  48 */   protected XSDGrammarsBuilder grammarBuilder = XSDGrammarsBuilder.newInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GrammarFactory newInstance() {
/*  57 */     return new GrammarFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Grammars createGrammars(String xsdLocation) throws EXIException {
/*  70 */     return createGrammars(xsdLocation, (XMLEntityResolver)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Grammars createGrammars(String xsdLocation, XMLEntityResolver entityResolver) throws EXIException {
/*  86 */     if (xsdLocation == null || xsdLocation.equals("")) {
/*  87 */       throw new EXIException("SchemaLocation not specified correctly!");
/*     */     }
/*     */     
/*  90 */     this.grammarBuilder.loadGrammars(xsdLocation, entityResolver);
/*  91 */     SchemaInformedGrammars g = this.grammarBuilder.toGrammars();
/*  92 */     g.setSchemaId(xsdLocation);
/*  93 */     return (Grammars)g;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Grammars createGrammars(InputStream is) throws EXIException {
/* 107 */     return createGrammars(is, (XMLEntityResolver)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Grammars createGrammars(InputStream is, XMLEntityResolver entityResolver) throws EXIException {
/* 123 */     this.grammarBuilder.loadGrammars(is, entityResolver);
/* 124 */     SchemaInformedGrammars g = this.grammarBuilder.toGrammars();
/* 125 */     g.setSchemaId("No-Schema-ID-Set");
/* 126 */     return (Grammars)g;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Grammars createXSDTypesOnlyGrammars() throws EXIException {
/* 139 */     this.grammarBuilder.loadXSDTypesOnlyGrammars();
/* 140 */     SchemaInformedGrammars g = this.grammarBuilder.toGrammars();
/* 141 */     g.setBuiltInXMLSchemaTypesOnly(true);
/* 142 */     return (Grammars)g;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Grammars createSchemaLessGrammars() {
/* 152 */     return (Grammars)new SchemaLessGrammars();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-grammars-1.0.7.jar!\com\siemens\ct\exi\grammars\GrammarFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */