/*     */ package com.siemens.ct.exi.main.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SkipRootElementXMLEventReader
/*     */   implements XMLEventReader
/*     */ {
/*     */   List<XMLEvent> events;
/*  44 */   int index = -1;
/*     */ 
/*     */   
/*     */   public SkipRootElementXMLEventReader(XMLEventReader parent) throws XMLStreamException {
/*  48 */     this.events = new ArrayList<>();
/*  49 */     int openElement = 0;
/*     */     
/*  51 */     while (parent.hasNext()) {
/*  52 */       XMLEvent next = parent.nextEvent();
/*     */       
/*  54 */       if (next.isStartDocument()) {
/*  55 */         this.events.add(next); continue;
/*  56 */       }  if (next.isEndDocument()) {
/*  57 */         this.events.add(next); continue;
/*  58 */       }  if (next.isStartElement()) {
/*  59 */         if (openElement > 0) {
/*  60 */           this.events.add(next);
/*     */         }
/*  62 */         openElement++; continue;
/*  63 */       }  if (next.isEndElement()) {
/*  64 */         openElement--;
/*  65 */         if (openElement > 0)
/*  66 */           this.events.add(next); 
/*     */         continue;
/*     */       } 
/*  69 */       if (openElement > 0) {
/*  70 */         this.events.add(next);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object next() {
/*  79 */     return this.events.get(this.index);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove() {}
/*     */ 
/*     */   
/*     */   public void close() throws XMLStreamException {}
/*     */ 
/*     */   
/*     */   public String getElementText() throws XMLStreamException {
/*  90 */     return null;
/*     */   }
/*     */   
/*     */   public Object getProperty(String arg0) throws IllegalArgumentException {
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasNext() {
/*  98 */     return (++this.index < this.events.size());
/*     */   }
/*     */   
/*     */   public XMLEvent nextEvent() throws XMLStreamException {
/* 102 */     return this.events.get(this.index);
/*     */   }
/*     */   
/*     */   public XMLEvent nextTag() throws XMLStreamException {
/* 106 */     return this.events.get(this.index);
/*     */   }
/*     */   
/*     */   public XMLEvent peek() throws XMLStreamException {
/* 110 */     return this.events.get(this.index);
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\mai\\util\SkipRootElementXMLEventReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */