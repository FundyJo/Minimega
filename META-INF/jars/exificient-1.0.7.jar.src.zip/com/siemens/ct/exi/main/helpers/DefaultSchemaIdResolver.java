/*    */ package com.siemens.ct.exi.main.helpers;
/*    */ 
/*    */ import com.siemens.ct.exi.core.SchemaIdResolver;
/*    */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*    */ import com.siemens.ct.exi.core.grammars.Grammars;
/*    */ import com.siemens.ct.exi.grammars.GrammarFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultSchemaIdResolver
/*    */   implements SchemaIdResolver
/*    */ {
/*    */   protected GrammarFactory getGrammarFactory() {
/* 56 */     return GrammarFactory.newInstance();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Grammars resolveSchemaId(String schemaId) throws EXIException {
/* 64 */     if (schemaId == null)
/* 65 */       return getGrammarFactory().createSchemaLessGrammars(); 
/* 66 */     if ("".equals(schemaId)) {
/* 67 */       return getGrammarFactory().createXSDTypesOnlyGrammars();
/*    */     }
/*    */     
/*    */     try {
/* 71 */       return getGrammarFactory().createGrammars(schemaId);
/* 72 */     } catch (Exception e) {
/* 73 */       throw new EXIException(getClass().getName() + " failed to retrieve schemaId == " + schemaId, e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\helpers\DefaultSchemaIdResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */