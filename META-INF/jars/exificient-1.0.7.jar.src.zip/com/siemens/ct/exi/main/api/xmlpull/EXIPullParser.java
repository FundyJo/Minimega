/*     */ package com.siemens.ct.exi.main.api.xmlpull;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIBodyDecoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EXIStreamDecoder;
/*     */ import com.siemens.ct.exi.core.container.DocType;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.container.ProcessingInstruction;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.xmlpull.v1.XmlPullParser;
/*     */ import org.xmlpull.v1.XmlPullParserException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIPullParser
/*     */   implements XmlPullParser
/*     */ {
/*     */   protected final EXIFactory factory;
/*     */   protected final EXIStreamDecoder exiStream;
/*     */   protected EXIBodyDecoder decoder;
/*     */   protected EventType eventType;
/*     */   protected EventType preReadEventType;
/*     */   protected QNameContext element;
/*     */   protected List<AttributeContainer> attributes;
/*     */   protected Value characters;
/*     */   protected DocType docType;
/*     */   protected char[] entityReference;
/*     */   protected char[] comment;
/*     */   protected ProcessingInstruction processingInstruction;
/*     */   String endElementPrefix;
/*     */   
/*     */   static class AttributeContainer
/*     */   {
/*     */     final QNameContext qname;
/*     */     final Value value;
/*     */     final String prefix;
/*     */     
/*     */     public AttributeContainer(QNameContext qname, Value value, String prefix) {
/*  81 */       this.qname = qname;
/*  82 */       this.value = value;
/*  83 */       this.prefix = prefix;
/*     */     }
/*     */   }
/*     */   
/*     */   public EXIPullParser(EXIFactory factory) throws EXIException {
/*  88 */     this.factory = factory;
/*     */     
/*  90 */     this.exiStream = factory.createEXIStreamDecoder();
/*  91 */     this.attributes = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFeature(String name, boolean state) throws XmlPullParserException {
/*  98 */     throw new XmlPullParserException("EXI does not support setting feature " + name + " to " + state);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getFeature(String name) {
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) throws XmlPullParserException {
/* 109 */     throw new XmlPullParserException("EXI does not support setting property " + name + " to " + value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) {
/* 115 */     return null;
/*     */   }
/*     */   
/*     */   public void setInput(Reader in) throws XmlPullParserException {
/* 119 */     throw new XmlPullParserException("EXI requires byte-based stream. Consider using InputStream.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInput(InputStream inputStream, String inputEncoding) throws XmlPullParserException {
/*     */     try {
/* 126 */       parseHeader(inputStream);
/* 127 */     } catch (EXIException e) {
/* 128 */       throw new XmlPullParserException("[EXI] " + e.getMessage());
/* 129 */     } catch (IOException e) {
/* 130 */       throw new XmlPullParserException("[EXI] " + e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void parseHeader(InputStream is) throws EXIException, IOException {
/* 135 */     assert is != null;
/* 136 */     assert this.exiStream != null;
/*     */ 
/*     */     
/* 139 */     this.decoder = this.exiStream.decodeHeader(is);
/*     */ 
/*     */     
/* 142 */     initForEachRun();
/*     */ 
/*     */     
/* 145 */     this.eventType = this.decoder.next();
/* 146 */     assert this.eventType == EventType.START_DOCUMENT;
/* 147 */     this.decoder.decodeStartDocument();
/*     */   }
/*     */   
/*     */   protected void initForEachRun() {
/* 151 */     this.eventType = null;
/*     */     
/* 153 */     this.preReadEventType = null;
/* 154 */     this.attributes.clear();
/*     */   }
/*     */   
/*     */   public String getInputEncoding() {
/* 158 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void defineEntityReplacementText(String entityName, String replacementText) throws XmlPullParserException {}
/*     */ 
/*     */   
/*     */   public int getNamespaceCount(int depth) throws XmlPullParserException {
/* 167 */     List<NamespaceDeclaration> ns = this.decoder.getDeclaredPrefixDeclarations();
/* 168 */     if (ns == null) {
/* 169 */       return 0;
/*     */     }
/* 171 */     return ns.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespacePrefix(int pos) throws XmlPullParserException {
/* 176 */     List<NamespaceDeclaration> ns = this.decoder.getDeclaredPrefixDeclarations();
/* 177 */     if (ns == null || pos >= ns.size()) {
/* 178 */       return null;
/*     */     }
/* 180 */     return ((NamespaceDeclaration)ns.get(pos)).prefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespaceUri(int pos) throws XmlPullParserException {
/* 185 */     List<NamespaceDeclaration> ns = this.decoder.getDeclaredPrefixDeclarations();
/* 186 */     if (ns == null || pos >= ns.size()) {
/* 187 */       return null;
/*     */     }
/* 189 */     return ((NamespaceDeclaration)ns.get(pos)).namespaceURI;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespace(String prefix) {
/* 194 */     if (prefix == null) {
/* 195 */       return null;
/*     */     }
/*     */     
/* 198 */     List<NamespaceDeclaration> ns = this.decoder.getDeclaredPrefixDeclarations();
/* 199 */     if (ns != null) {
/* 200 */       for (int i = ns.size() - 1; i >= 0; i--) {
/* 201 */         if (prefix.equals(((NamespaceDeclaration)ns.get(i)).prefix)) {
/* 202 */           return ((NamespaceDeclaration)ns.get(i)).namespaceURI;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDepth() {
/* 212 */     return 0;
/*     */   }
/*     */   
/*     */   public String getPositionDescription() {
/* 216 */     return null;
/*     */   }
/*     */   
/*     */   public int getLineNumber() {
/* 220 */     return 0;
/*     */   }
/*     */   
/*     */   public int getColumnNumber() {
/* 224 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean isWhitespace() throws XmlPullParserException {
/* 228 */     switch (getEventType()) {
/*     */       case 4:
/* 230 */         return (this.characters.toString().trim().length() == 0);
/*     */       case 5:
/* 232 */         return false;
/*     */       case 9:
/* 234 */         return false;
/*     */     } 
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/*     */     try {
/* 242 */       switch (getEventType()) {
/*     */         case 4:
/* 244 */           return this.characters.toString();
/*     */         case 9:
/* 246 */           return new String(this.comment);
/*     */         case 6:
/* 248 */           return new String(this.entityReference);
/*     */         case 10:
/* 250 */           return getDocTypeString();
/*     */       } 
/* 252 */       throw new RuntimeException("Unexpected event, id=" + 
/* 253 */           getEventType());
/*     */     }
/* 255 */     catch (XmlPullParserException e) {
/* 256 */       throw new RuntimeException("Unexpected text, error=" + e
/* 257 */           .getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getDocTypeString() {
/* 262 */     StringBuilder sb = new StringBuilder();
/* 263 */     sb.append("<!DOCTYPE ");
/* 264 */     sb.append(this.docType.name);
/*     */     
/* 266 */     if (this.docType.publicID.length > 0) {
/* 267 */       sb.append(" PUBLIC ");
/* 268 */       sb.append('"');
/* 269 */       sb.append(this.docType.publicID);
/* 270 */       sb.append('"');
/*     */     } 
/* 272 */     if (this.docType.systemID.length > 0) {
/* 273 */       if (this.docType.publicID.length == 0) {
/* 274 */         sb.append(" SYSTEM ");
/*     */       } else {
/* 276 */         sb.append(' ');
/*     */       } 
/* 278 */       sb.append('"');
/* 279 */       sb.append(this.docType.systemID);
/* 280 */       sb.append('"');
/*     */     } 
/* 282 */     if (this.docType.text.length > 0) {
/* 283 */       sb.append(' ');
/* 284 */       sb.append('[');
/* 285 */       sb.append(this.docType.text);
/* 286 */       sb.append(']');
/*     */     } 
/* 288 */     sb.append('>');
/*     */     
/* 290 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public char[] getTextCharacters(int[] holderForStartAndLength) {
/* 294 */     char[] ch = getText().toCharArray();
/* 295 */     holderForStartAndLength[0] = 0;
/* 296 */     holderForStartAndLength[1] = ch.length;
/* 297 */     return ch;
/*     */   }
/*     */   
/*     */   public String getNamespace() {
/* 301 */     int et = getEventType(this.eventType);
/* 302 */     if (et == 2 || et == 3) {
/* 303 */       return this.element.getNamespaceUri();
/*     */     }
/* 305 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 310 */     int et = getEventType(this.eventType);
/* 311 */     if (et == 2 || et == 3)
/* 312 */       return this.element.getLocalName(); 
/* 313 */     if (et == 6) {
/* 314 */       return new String(this.entityReference);
/*     */     }
/* 316 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/* 321 */     int et = getEventType(this.eventType);
/* 322 */     if (et == 2 || et == 3) {
/* 323 */       if (this.endElementPrefix != null) {
/* 324 */         return this.endElementPrefix;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 330 */       return this.decoder.getElementPrefix();
/*     */     } 
/* 332 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmptyElementTag() throws XmlPullParserException {
/* 337 */     return false;
/*     */   }
/*     */   
/*     */   public int getAttributeCount() {
/* 341 */     return this.attributes.size();
/*     */   }
/*     */   
/*     */   public String getAttributeNamespace(int index) {
/* 345 */     if (index >= 0 && index < this.attributes.size()) {
/* 346 */       return ((AttributeContainer)this.attributes.get(index)).qname.getNamespaceUri();
/*     */     }
/* 348 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttributeName(int index) {
/* 353 */     if (index >= 0 && index < this.attributes.size()) {
/* 354 */       return ((AttributeContainer)this.attributes.get(index)).qname.getLocalName();
/*     */     }
/* 356 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttributePrefix(int index) {
/* 361 */     if (index >= 0 && index < this.attributes.size()) {
/* 362 */       return ((AttributeContainer)this.attributes.get(index)).prefix;
/*     */     }
/* 364 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttributeType(int index) {
/* 369 */     return "CDATA";
/*     */   }
/*     */   
/*     */   public boolean isAttributeDefault(int index) {
/* 373 */     return false;
/*     */   }
/*     */   
/*     */   public String getAttributeValue(int index) {
/* 377 */     if (index >= 0 && index < this.attributes.size()) {
/* 378 */       return ((AttributeContainer)this.attributes.get(index)).value.toString();
/*     */     }
/* 380 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttributeValue(String namespace, String name) {
/* 385 */     if (name == null) {
/* 386 */       return null;
/*     */     }
/* 388 */     if (namespace == null) {
/* 389 */       namespace = "";
/*     */     }
/*     */     
/* 392 */     for (int i = 0; i < this.attributes.size(); i++) {
/* 393 */       if (((AttributeContainer)this.attributes.get(i)).qname.getNamespaceUri().equals(namespace) && ((AttributeContainer)this.attributes
/* 394 */         .get(i)).qname.getLocalName().equals(name)) {
/* 395 */         return ((AttributeContainer)this.attributes.get(i)).value.toString();
/*     */       }
/*     */     } 
/*     */     
/* 399 */     return null;
/*     */   }
/*     */   
/*     */   public int getEventType() throws XmlPullParserException {
/* 403 */     return getEventType(this.eventType);
/*     */   }
/*     */   
/*     */   protected static int getEventType(EventType eventType) {
/* 407 */     assert eventType != null;
/* 408 */     switch (eventType) {
/*     */       case START_DOCUMENT:
/* 410 */         return 0;
/*     */       case ATTRIBUTE_XSI_TYPE:
/*     */       case ATTRIBUTE_XSI_NIL:
/*     */       case ATTRIBUTE:
/*     */       case ATTRIBUTE_NS:
/*     */       case ATTRIBUTE_GENERIC:
/*     */       case ATTRIBUTE_INVALID_VALUE:
/*     */       case ATTRIBUTE_ANY_INVALID_VALUE:
/*     */       case ATTRIBUTE_GENERIC_UNDECLARED:
/* 419 */         return -2;
/*     */       case START_ELEMENT:
/*     */       case START_ELEMENT_NS:
/*     */       case START_ELEMENT_GENERIC:
/*     */       case START_ELEMENT_GENERIC_UNDECLARED:
/* 424 */         return 2;
/*     */       case END_ELEMENT:
/*     */       case END_ELEMENT_UNDECLARED:
/* 427 */         return 3;
/*     */       case CHARACTERS:
/*     */       case CHARACTERS_GENERIC:
/*     */       case CHARACTERS_GENERIC_UNDECLARED:
/* 431 */         return 4;
/*     */       case END_DOCUMENT:
/* 433 */         return 1;
/*     */       case DOC_TYPE:
/* 435 */         return 10;
/*     */       case NAMESPACE_DECLARATION:
/* 437 */         return -3;
/*     */       
/*     */       case SELF_CONTAINED:
/* 440 */         return -1;
/*     */       case ENTITY_REFERENCE:
/* 442 */         return 6;
/*     */       case COMMENT:
/* 444 */         return 9;
/*     */       case PROCESSING_INSTRUCTION:
/* 446 */         return 8;
/*     */     } 
/* 448 */     throw new RuntimeException("Unexpected EXI Event '" + eventType + "' ");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int next() throws XmlPullParserException, IOException {
/* 454 */     return nextToken();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EventType decodeEvent(EventType nextEventType) throws EXIException, IOException {
/* 463 */     this.endElementPrefix = null;
/*     */     
/* 465 */     switch (nextEventType) {
/*     */       
/*     */       case START_DOCUMENT:
/* 468 */         this.decoder.decodeStartDocument();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 546 */         return nextEventType;case END_DOCUMENT: this.decoder.decodeEndDocument(); return nextEventType;case ATTRIBUTE_XSI_NIL: this.attributes.add(new AttributeContainer(this.decoder.decodeAttributeXsiNil(), this.decoder.getAttributeValue(), this.decoder.getAttributePrefix())); return nextEventType;case ATTRIBUTE_XSI_TYPE: this.attributes.add(new AttributeContainer(this.decoder.decodeAttributeXsiType(), this.decoder.getAttributeValue(), this.decoder.getAttributePrefix())); return nextEventType;case ATTRIBUTE: case ATTRIBUTE_NS: case ATTRIBUTE_GENERIC: case ATTRIBUTE_INVALID_VALUE: case ATTRIBUTE_ANY_INVALID_VALUE: case ATTRIBUTE_GENERIC_UNDECLARED: this.attributes.add(new AttributeContainer(this.decoder.decodeAttribute(), this.decoder.getAttributeValue(), this.decoder.getAttributePrefix())); return nextEventType;case NAMESPACE_DECLARATION: this.decoder.decodeNamespaceDeclaration(); return nextEventType;case SELF_CONTAINED: this.decoder.decodeStartSelfContainedFragment(); return nextEventType;case START_ELEMENT: case START_ELEMENT_NS: case START_ELEMENT_GENERIC: case START_ELEMENT_GENERIC_UNDECLARED: this.element = this.decoder.decodeStartElement(); return nextEventType;case END_ELEMENT: case END_ELEMENT_UNDECLARED: this.endElementPrefix = this.decoder.getElementPrefix(); this.element = this.decoder.decodeEndElement(); return nextEventType;case CHARACTERS: case CHARACTERS_GENERIC: case CHARACTERS_GENERIC_UNDECLARED: this.characters = this.decoder.decodeCharacters(); return nextEventType;case DOC_TYPE: this.docType = this.decoder.decodeDocType(); return nextEventType;case ENTITY_REFERENCE: this.entityReference = this.decoder.decodeEntityReference(); return nextEventType;case COMMENT: this.comment = this.decoder.decodeComment(); return nextEventType;case PROCESSING_INSTRUCTION: this.processingInstruction = this.decoder.decodeProcessingInstruction(); return nextEventType;
/*     */     } 
/*     */     throw new RuntimeException("Unexpected EXI Event '" + this.eventType + "' ");
/*     */   } protected void handleAttributes() throws EXIException, IOException, XmlPullParserException {
/*     */     EventType et;
/* 551 */     assert getEventType() == 2;
/* 552 */     this.attributes.clear();
/*     */     
/*     */     do {
/* 555 */       et = this.decoder.next();
/* 556 */       if (!isAttributeEvent(et))
/* 557 */         continue;  decodeEvent(et);
/*     */     }
/* 559 */     while (isAttributeEvent(et));
/*     */     
/* 561 */     this.preReadEventType = et;
/*     */   }
/*     */   
/*     */   private boolean isAttributeEvent(EventType et) {
/* 565 */     boolean isAttributeEvent = false;
/* 566 */     switch (et) {
/*     */       case ATTRIBUTE:
/*     */       case ATTRIBUTE_NS:
/*     */       case ATTRIBUTE_GENERIC:
/*     */       case ATTRIBUTE_INVALID_VALUE:
/*     */       case ATTRIBUTE_ANY_INVALID_VALUE:
/*     */       case ATTRIBUTE_GENERIC_UNDECLARED:
/* 573 */         isAttributeEvent = true;
/*     */         break;
/*     */       
/*     */       case NAMESPACE_DECLARATION:
/* 577 */         isAttributeEvent = true;
/*     */         break;
/*     */       case SELF_CONTAINED:
/* 580 */         isAttributeEvent = true;
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 585 */     return isAttributeEvent;
/*     */   }
/*     */ 
/*     */   
/*     */   public int nextToken() throws XmlPullParserException, IOException {
/*     */     try {
/* 591 */       if (this.preReadEventType == null) {
/* 592 */         this.eventType = decodeEvent(this.decoder.next());
/*     */       } else {
/* 594 */         this.eventType = this.preReadEventType;
/* 595 */         this.preReadEventType = null;
/* 596 */         decodeEvent(this.eventType);
/*     */       } 
/*     */       
/* 599 */       int ev = getEventType();
/* 600 */       if (ev == 2) {
/* 601 */         handleAttributes();
/*     */       }
/*     */       
/* 604 */       return ev;
/* 605 */     } catch (Exception e) {
/* 606 */       throw new IOException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void require(int type, String namespace, String name) throws XmlPullParserException, IOException {}
/*     */ 
/*     */   
/*     */   public String nextText() throws XmlPullParserException, IOException {
/* 615 */     if (getEventType() != 2) {
/* 616 */       throw new XmlPullParserException("parser must be on START_TAG to read next text", this, null);
/*     */     }
/*     */     
/* 619 */     int eventType = next();
/* 620 */     if (eventType == 4) {
/* 621 */       String result = getText();
/* 622 */       eventType = next();
/* 623 */       if (eventType != 3) {
/* 624 */         throw new XmlPullParserException("event TEXT it must be immediately followed by END_TAG", this, null);
/*     */       }
/*     */ 
/*     */       
/* 628 */       return result;
/* 629 */     }  if (eventType == 3) {
/* 630 */       return "";
/*     */     }
/* 632 */     throw new XmlPullParserException("parser must be on START_TAG or TEXT to read text", this, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nextTag() throws XmlPullParserException, IOException {
/* 639 */     int eventType = next();
/* 640 */     if (eventType == 4 && isWhitespace()) {
/* 641 */       eventType = next();
/*     */     }
/* 643 */     if (eventType != 2 && eventType != 3) {
/* 644 */       throw new XmlPullParserException("expected start or end tag", this, null);
/*     */     }
/*     */     
/* 647 */     return eventType;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\xmlpull\EXIPullParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */