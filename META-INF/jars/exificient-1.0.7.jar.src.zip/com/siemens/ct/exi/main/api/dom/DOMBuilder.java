/*     */ package com.siemens.ct.exi.main.api.dom;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.main.api.sax.SAXFactory;
/*     */ import java.io.InputStream;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentFragment;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMBuilder
/*     */ {
/*     */   protected EXIFactory factory;
/*     */   protected DOMImplementation domImplementation;
/*     */   
/*     */   public DOMBuilder(EXIFactory factory) throws ParserConfigurationException {
/*  57 */     this.factory = factory;
/*     */ 
/*     */     
/*  60 */     DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
/*  61 */     dbFactory.setNamespaceAware(true);
/*  62 */     DocumentBuilder builder = dbFactory.newDocumentBuilder();
/*  63 */     this.domImplementation = builder.getDOMImplementation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentFragment parseFragment(InputStream is) throws EXIException {
/*     */     try {
/*  74 */       SaxToDomHandler s2dHandler = new SaxToDomHandler(this.domImplementation, true);
/*     */ 
/*     */       
/*  77 */       XMLReader reader = (new SAXFactory(this.factory)).createEXIReader();
/*  78 */       reader.setFeature("http://xml.org/sax/features/namespace-prefixes", true);
/*     */       
/*  80 */       reader.setContentHandler(s2dHandler);
/*     */       
/*  82 */       reader.parse(new InputSource(is));
/*     */       
/*  84 */       return s2dHandler.getDocumentFragment();
/*  85 */     } catch (Exception e) {
/*  86 */       throw new EXIException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Document parse(InputStream is) throws EXIException {
/*  91 */     return parse(is, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Document parse(InputStream is, boolean exiBodyOnly) throws EXIException {
/*     */     try {
/*  98 */       SaxToDomHandler s2dHandler = new SaxToDomHandler(this.domImplementation, false);
/*     */ 
/*     */       
/* 101 */       XMLReader reader = (new SAXFactory(this.factory)).createEXIReader();
/*     */       
/* 103 */       reader.setFeature("http://www.w3.org/exi/features/exi-body-only", exiBodyOnly);
/*     */       
/* 105 */       reader.setFeature("http://xml.org/sax/features/namespace-prefixes", true);
/*     */       
/* 107 */       reader.setProperty("http://xml.org/sax/properties/lexical-handler", s2dHandler);
/*     */       
/* 109 */       reader.setProperty("http://xml.org/sax/properties/declaration-handler", s2dHandler);
/*     */ 
/*     */       
/* 112 */       reader.setContentHandler(s2dHandler);
/* 113 */       reader.setDTDHandler(s2dHandler);
/*     */       
/* 115 */       reader.parse(new InputSource(is));
/*     */ 
/*     */       
/* 118 */       return s2dHandler.getDocument();
/* 119 */     } catch (Exception e) {
/* 120 */       throw new EXIException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\dom\DOMBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */