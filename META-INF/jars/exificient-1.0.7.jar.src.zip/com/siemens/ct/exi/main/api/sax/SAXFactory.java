/*    */ package com.siemens.ct.exi.main.api.sax;
/*    */ 
/*    */ import com.siemens.ct.exi.core.EXIFactory;
/*    */ import com.siemens.ct.exi.core.FidelityOptions;
/*    */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*    */ import org.xml.sax.XMLReader;
/*    */ 
/*    */ 
/*    */ public class SAXFactory
/*    */ {
/*    */   protected final EXIFactory exiFactory;
/*    */   
/*    */   public SAXFactory(EXIFactory exiFactory) {
/* 14 */     this.exiFactory = exiFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public XMLReader createEXIReader() throws EXIException {
/* 26 */     return new SAXDecoder(this.exiFactory);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SAXEncoder createEXIWriter() throws EXIException {
/* 43 */     FidelityOptions fidelityOptions = this.exiFactory.getFidelityOptions();
/* 44 */     if (fidelityOptions.isFidelityEnabled("PRESERVE_PREFIXES") || fidelityOptions
/*    */       
/* 46 */       .isFidelityEnabled("PRESERVE_COMMENTS") || fidelityOptions
/*    */       
/* 48 */       .isFidelityEnabled("PRESERVE_PIS") || fidelityOptions
/*    */       
/* 50 */       .isFidelityEnabled("PRESERVE_DTDS")) {
/* 51 */       return new SAXEncoderExtendedHandler(this.exiFactory);
/*    */     }
/* 53 */     return new SAXEncoder(this.exiFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\sax\SAXFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */