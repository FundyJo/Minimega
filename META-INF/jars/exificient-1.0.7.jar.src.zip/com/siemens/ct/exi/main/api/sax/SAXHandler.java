/*    */ package com.siemens.ct.exi.main.api.sax;
/*    */ 
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.ContentHandler;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.ext.DefaultHandler2;
/*    */ import org.xml.sax.ext.LexicalHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SAXHandler
/*    */   extends DefaultHandler2
/*    */ {
/*    */   ContentHandler contentHandler;
/*    */   
/*    */   public SAXHandler(ContentHandler ch) {
/* 44 */     this.contentHandler = ch;
/*    */   }
/*    */ 
/*    */   
/*    */   public void startDocument() throws SAXException {
/* 49 */     this.contentHandler.startDocument();
/*    */   }
/*    */ 
/*    */   
/*    */   public void endDocument() throws SAXException {
/* 54 */     this.contentHandler.endDocument();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/* 60 */     this.contentHandler.startPrefixMapping(prefix, uri);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endPrefixMapping(String prefix) throws SAXException {
/* 65 */     this.contentHandler.endPrefixMapping(prefix);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
/* 71 */     this.contentHandler.startElement(uri, localName, qName, attributes);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void endElement(String uri, String localName, String qName) throws SAXException {
/* 77 */     this.contentHandler.endElement(uri, localName, qName);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 83 */     this.contentHandler.characters(ch, start, length);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void processingInstruction(String target, String data) throws SAXException {
/* 89 */     this.contentHandler.processingInstruction(target, data);
/*    */   }
/*    */ 
/*    */   
/*    */   public void comment(char[] ch, int start, int length) throws SAXException {
/* 94 */     if (this.contentHandler instanceof LexicalHandler)
/* 95 */       ((LexicalHandler)this.contentHandler).comment(ch, start, length); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\sax\SAXHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */