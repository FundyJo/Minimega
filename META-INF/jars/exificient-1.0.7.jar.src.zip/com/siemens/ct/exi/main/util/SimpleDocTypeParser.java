/*     */ package com.siemens.ct.exi.main.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.ext.DeclHandler;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleDocTypeParser
/*     */   implements LexicalHandler, ContentHandler, DeclHandler
/*     */ {
/*     */   XMLReader xmlReader;
/*     */   public String name;
/*     */   public String publicID;
/*     */   public String systemID;
/*     */   public String text;
/*     */   
/*     */   public SimpleDocTypeParser() throws SAXException {
/*  52 */     this.xmlReader = XMLReaderFactory.createXMLReader();
/*     */     
/*  54 */     this.xmlReader.setContentHandler(this);
/*     */ 
/*     */     
/*  57 */     this.xmlReader.setProperty("http://xml.org/sax/properties/lexical-handler", this);
/*     */ 
/*     */ 
/*     */     
/*  61 */     this.xmlReader.setProperty("http://xml.org/sax/properties/declaration-handler", this);
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.xmlReader.setFeature("http://xml.org/sax/features/resolve-dtd-uris", false);
/*     */ 
/*     */     
/*  68 */     this.xmlReader.setEntityResolver(new NoEntityResolver());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(String docTypeDecl) throws IOException, SAXException {
/*  77 */     StringBuilder dt = new StringBuilder();
/*  78 */     dt.append(docTypeDecl);
/*  79 */     dt.append("<foo />");
/*  80 */     Reader r = new StringReader(dt.toString());
/*  81 */     this.xmlReader.parse(new InputSource(r));
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {
/*  86 */     this.name = name;
/*  87 */     this.publicID = (publicId == null) ? "" : publicId;
/*  88 */     this.systemID = (systemId == null) ? "" : systemId;
/*  89 */     this.text = "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endDTD() throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void startEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void endEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void startCDATA() throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void endCDATA() throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentLocator(Locator locator) {}
/*     */ 
/*     */   
/*     */   public void startDocument() throws SAXException {}
/*     */ 
/*     */   
/*     */   public void endDocument() throws SAXException {}
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String prefix) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 140 */     this.text += new String(ch, start, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void skippedEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void elementDecl(String name, String model) throws SAXException {
/* 160 */     this.text += "<!ELEMENT " + name + " " + model + "> ";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void attributeDecl(String eName, String aName, String type, String mode, String value) throws SAXException {
/* 166 */     this.text += "<!ATTLIST " + eName + " " + aName + " " + type + " " + mode + "> ";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void internalEntityDecl(String name, String value) throws SAXException {
/* 173 */     this.text += "<!ENTITY " + name + " \"" + value + "\"> ";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void externalEntityDecl(String name, String publicId, String systemId) throws SAXException {
/* 179 */     if (publicId == null) {
/* 180 */       this.text += "<!ENTITY " + name + " SYSTEM \"" + systemId + "\"> ";
/*     */     } else {
/* 182 */       this.text += "<!ENTITY " + name + " PUBLIC \"" + systemId + "\"> ";
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\mai\\util\SimpleDocTypeParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */