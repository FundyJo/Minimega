/*     */ package com.siemens.ct.exi.main.api.xmlpull;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIBodyEncoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EXIStreamEncoder;
/*     */ import com.siemens.ct.exi.core.attributes.AttributeFactory;
/*     */ import com.siemens.ct.exi.core.attributes.AttributeList;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.xmlpull.v1.XmlSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXISerializer
/*     */   implements XmlSerializer
/*     */ {
/*     */   protected final EXIFactory factory;
/*     */   protected final EXIStreamEncoder exiStream;
/*     */   protected EXIBodyEncoder exiBody;
/*     */   protected OutputStream outputStream;
/*     */   protected List<NamespaceDeclaration> nsDecls;
/*     */   String currentNamespace;
/*     */   String currentName;
/*     */   protected boolean pendingATs;
/*     */   protected AttributeList exiAttributes;
/*     */   
/*     */   public EXISerializer(EXIFactory factory) throws EXIException {
/*  72 */     this.factory = factory;
/*     */     
/*  74 */     this.exiStream = factory.createEXIStreamEncoder();
/*     */     
/*  76 */     AttributeFactory attFactory = AttributeFactory.newInstance();
/*  77 */     this.exiAttributes = attFactory.createAttributeListInstance(factory);
/*     */     
/*  79 */     this.nsDecls = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFeature(String name, boolean state) throws IllegalArgumentException, IllegalStateException {
/*  85 */     throw new IllegalStateException("EXI does not support setting feature " + name + " to " + state);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFeature(String name) {
/*  91 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) throws IllegalArgumentException, IllegalStateException {
/*  97 */     throw new IllegalStateException("EXI does not support setting property " + name + " to " + value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) {
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOutput(OutputStream os, String encoding) throws IOException, IllegalArgumentException, IllegalStateException {
/*     */     try {
/* 109 */       this.outputStream = os;
/* 110 */       this.exiBody = this.exiStream.encodeHeader(os);
/* 111 */     } catch (EXIException e) {
/* 112 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOutput(Writer writer) throws IOException, IllegalArgumentException, IllegalStateException {
/* 118 */     throw new IllegalArgumentException("EXI requires byte-based stream. Consider using OutputStream");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void init() {
/* 123 */     this.pendingATs = false;
/* 124 */     this.exiAttributes.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument(String encoding, Boolean standalone) throws IOException, IllegalArgumentException, IllegalStateException {
/*     */     try {
/* 130 */       init();
/* 131 */       this.exiBody.encodeStartDocument();
/* 132 */     } catch (EXIException e) {
/* 133 */       throw new IOException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument() throws IOException, IllegalArgumentException, IllegalStateException {
/*     */     try {
/* 140 */       checkPendingATEvents();
/* 141 */       this.exiBody.encodeEndDocument();
/* 142 */       this.exiBody.flush();
/* 143 */     } catch (EXIException e) {
/* 144 */       throw new IOException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefix(String prefix, String namespace) throws IOException, IllegalArgumentException, IllegalStateException {
/* 151 */     this.nsDecls.add(new NamespaceDeclaration(namespace, prefix));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPrefix(String namespace, boolean generatePrefix) throws IllegalArgumentException {
/* 156 */     return null;
/*     */   }
/*     */   
/*     */   public int getDepth() {
/* 160 */     return 0;
/*     */   }
/*     */   
/*     */   public String getNamespace() {
/* 164 */     return this.currentNamespace;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 168 */     return this.currentName;
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlSerializer startTag(String namespace, String name) throws IOException, IllegalArgumentException, IllegalStateException {
/*     */     try {
/* 174 */       checkPendingATEvents();
/*     */       
/* 176 */       this.currentNamespace = namespace;
/* 177 */       this.currentName = name;
/* 178 */       this.exiBody.encodeStartElement(namespace, name, null);
/* 179 */       for (int i = 0; i < this.nsDecls.size(); i++) {
/* 180 */         NamespaceDeclaration ns = this.nsDecls.get(i);
/* 181 */         this.exiBody.encodeNamespaceDeclaration(ns.namespaceURI, ns.prefix);
/*     */       } 
/* 183 */       this.nsDecls.clear();
/* 184 */       return this;
/* 185 */     } catch (EXIException e) {
/* 186 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkPendingATEvents() throws IOException {
/*     */     try {
/* 193 */       if (this.pendingATs) {
/*     */ 
/*     */         
/* 196 */         this.exiBody.encodeAttributeList(this.exiAttributes);
/*     */         
/* 198 */         this.exiAttributes.clear();
/*     */         
/* 200 */         this.pendingATs = false;
/*     */       } 
/* 202 */     } catch (EXIException e) {
/* 203 */       throw new IOException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlSerializer attribute(String namespace, String name, String value) throws IOException, IllegalArgumentException, IllegalStateException {
/* 209 */     this.exiAttributes.addAttribute(namespace, name, null, value);
/* 210 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlSerializer endTag(String namespace, String name) throws IOException, IllegalArgumentException, IllegalStateException {
/*     */     try {
/* 216 */       checkPendingATEvents();
/* 217 */       this.exiBody.encodeEndElement();
/* 218 */       return this;
/* 219 */     } catch (EXIException e) {
/* 220 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlSerializer text(String text) throws IOException, IllegalArgumentException, IllegalStateException {
/*     */     try {
/* 227 */       checkPendingATEvents();
/* 228 */       this.exiBody.encodeCharacters((Value)new StringValue(text));
/* 229 */       return this;
/* 230 */     } catch (EXIException e) {
/* 231 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlSerializer text(char[] buf, int start, int len) throws IOException, IllegalArgumentException, IllegalStateException {
/* 237 */     return text(new String(buf, start, len));
/*     */   }
/*     */ 
/*     */   
/*     */   public void cdsect(String text) throws IOException, IllegalArgumentException, IllegalStateException {
/* 242 */     checkPendingATEvents();
/* 243 */     text("<![CDATA[" + text + "]]>");
/*     */   }
/*     */ 
/*     */   
/*     */   public void entityRef(String text) throws IOException, IllegalArgumentException, IllegalStateException {
/*     */     try {
/* 249 */       checkPendingATEvents();
/* 250 */       this.exiBody.encodeEntityReference(text);
/* 251 */     } catch (EXIException e) {
/* 252 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void processingInstruction(String text) throws IOException, IllegalArgumentException, IllegalStateException {
/* 258 */     checkPendingATEvents();
/* 259 */     text("<?" + text + "?>");
/*     */   }
/*     */ 
/*     */   
/*     */   public void comment(String text) throws IOException, IllegalArgumentException, IllegalStateException {
/*     */     try {
/* 265 */       checkPendingATEvents();
/* 266 */       char[] ch = text.toCharArray();
/* 267 */       this.exiBody.encodeComment(ch, 0, ch.length);
/* 268 */     } catch (EXIException e) {
/* 269 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void docdecl(String text) throws IOException, IllegalArgumentException, IllegalStateException {
/* 275 */     checkPendingATEvents();
/* 276 */     text("<!DOCTYPE " + text + ">");
/*     */   }
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(String text) throws IOException, IllegalArgumentException, IllegalStateException {
/* 281 */     text(text);
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 285 */     this.exiBody.flush();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\xmlpull\EXISerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */