/*    */ package com.siemens.ct.exi.main.util;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FragmentUtilities
/*    */ {
/*    */   public static InputStream getSurroundingRootInputStream(InputStream is) throws IOException {
/* 34 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*    */     
/* 36 */     baos.write("<root>".getBytes());
/*    */     
/*    */     int b;
/* 39 */     while ((b = is.read()) != -1) {
/* 40 */       baos.write(b);
/*    */     }
/*    */     
/* 43 */     baos.write("</root>".getBytes());
/* 44 */     baos.flush();
/*    */     
/* 46 */     return new ByteArrayInputStream(baos.toByteArray());
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\mai\\util\FragmentUtilities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */