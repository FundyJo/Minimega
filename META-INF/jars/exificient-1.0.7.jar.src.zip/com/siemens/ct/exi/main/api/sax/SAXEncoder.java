/*     */ package com.siemens.ct.exi.main.api.sax;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIBodyEncoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EXIStreamEncoder;
/*     */ import com.siemens.ct.exi.core.attributes.AttributeFactory;
/*     */ import com.siemens.ct.exi.core.attributes.AttributeList;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.DefaultHandler2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAXEncoder
/*     */   extends DefaultHandler2
/*     */ {
/*     */   protected EXIFactory factory;
/*     */   protected EXIStreamEncoder exiStream;
/*     */   protected EXIBodyEncoder encoder;
/*     */   protected AttributeList exiAttributes;
/*     */   
/*     */   public SAXEncoder(EXIFactory factory) throws EXIException {
/*  63 */     this.factory = factory;
/*     */ 
/*     */     
/*  66 */     this.exiStream = factory.createEXIStreamEncoder();
/*     */ 
/*     */     
/*  69 */     AttributeFactory attFactory = AttributeFactory.newInstance();
/*  70 */     this.exiAttributes = attFactory.createAttributeListInstance(factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputStream(OutputStream os) throws EXIException, IOException {
/*  77 */     if (!(os instanceof BufferedOutputStream) && !(os instanceof java.io.ByteArrayOutputStream) && !(os instanceof java.io.DataOutputStream))
/*     */     {
/*  79 */       os = new BufferedOutputStream(os);
/*     */     }
/*     */ 
/*     */     
/*  83 */     this.encoder = this.exiStream.encodeHeader(os);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/*  95 */     this.exiAttributes.addNamespaceDeclaration(uri, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String local, String raw, Attributes attributes) throws SAXException {
/*     */     try {
/* 107 */       startElementPfx(uri, local, null, attributes);
/* 108 */     } catch (Exception e) {
/* 109 */       throw new SAXException("startElement: " + raw, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startElementPfx(String uri, String local, String prefix, Attributes attributes) throws EXIException, IOException {
/* 116 */     this.encoder.encodeStartElement(uri, local, prefix);
/*     */ 
/*     */     
/* 119 */     if (attributes != null) {
/* 120 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 121 */         this.exiAttributes.addAttribute(attributes.getURI(i), attributes
/* 122 */             .getLocalName(i), getPrefixOf(attributes, i), attributes
/* 123 */             .getValue(i));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 128 */     this.encoder.encodeAttributeList(this.exiAttributes);
/* 129 */     this.exiAttributes.clear();
/*     */   }
/*     */   
/*     */   private String getPrefixOf(Attributes atts, int index) {
/* 133 */     String qname = atts.getQName(index);
/* 134 */     String localName = atts.getLocalName(index);
/*     */     
/* 136 */     int lengthDifference = qname.length() - localName.length();
/* 137 */     return (lengthDifference == 0) ? "" : 
/* 138 */       qname.substring(0, lengthDifference - 1);
/*     */   }
/*     */   
/*     */   public void startDocument() throws SAXException {
/*     */     try {
/* 143 */       this.encoder.encodeStartDocument();
/* 144 */     } catch (Exception e) {
/* 145 */       throw new SAXException("startDocument", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void endDocument() throws SAXException {
/*     */     try {
/* 151 */       this.encoder.encodeEndDocument();
/* 152 */       this.encoder.flush();
/* 153 */     } catch (Exception e) {
/* 154 */       throw new SAXException("endDocument", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String local, String raw) throws SAXException {
/*     */     try {
/* 161 */       this.encoder.encodeEndElement();
/* 162 */     } catch (Exception e) {
/* 163 */       throw new SAXException("endElement=" + raw, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/*     */     try {
/* 171 */       this.encoder.encodeCharacters((Value)new StringValue(new String(ch, start, length)));
/*     */     }
/* 173 */     catch (Exception e) {
/* 174 */       throw new SAXException("characters=" + new String(ch, start, length), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\sax\SAXEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */