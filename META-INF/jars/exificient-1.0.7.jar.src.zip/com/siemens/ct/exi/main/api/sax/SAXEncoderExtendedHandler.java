/*     */ package com.siemens.ct.exi.main.api.sax;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.FidelityOptions;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.util.xml.QNameUtilities;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAXEncoderExtendedHandler
/*     */   extends SAXEncoder
/*     */ {
/*     */   protected final boolean preserveDTD;
/*     */   protected final boolean preserveComment;
/*     */   protected final boolean preservePrefix;
/*     */   protected String docTypeName;
/*     */   protected String docTypePublicID;
/*     */   protected String docTypeSystemID;
/*     */   protected String docTypeText;
/*     */   protected boolean entityReferenceRange;
/*     */   protected boolean dtdRange;
/*     */   protected boolean retainEntityReference;
/*     */   
/*     */   public SAXEncoderExtendedHandler(EXIFactory factory) throws EXIException {
/*  65 */     super(factory);
/*     */     
/*  67 */     FidelityOptions fo = factory.getFidelityOptions();
/*  68 */     this.preserveDTD = fo.isFidelityEnabled("PRESERVE_DTDS");
/*  69 */     this.preserveComment = fo.isFidelityEnabled("PRESERVE_COMMENTS");
/*  70 */     this.preservePrefix = fo.isFidelityEnabled("PRESERVE_PREFIXES");
/*     */     
/*  72 */     this.retainEntityReference = factory.getEncodingOptions().isOptionEnabled("KEEP_ENTITY_REFERENCES_UNRESOLVED");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument() throws SAXException {
/*  79 */     this.entityReferenceRange = false;
/*  80 */     this.dtdRange = false;
/*     */     
/*  82 */     super.startDocument();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String local, String raw, Attributes attributes) throws SAXException {
/*     */     try {
/*  89 */       String prefix = null;
/*     */       
/*  91 */       if (this.preservePrefix) {
/*  92 */         prefix = QNameUtilities.getPrefixPart(raw);
/*     */       }
/*  94 */       startElementPfx(uri, local, prefix, attributes);
/*  95 */     } catch (Exception e) {
/*  96 */       throw new SAXException("startElement: " + raw, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 103 */     if (this.preserveDTD && this.entityReferenceRange) {
/* 104 */       if (!this.retainEntityReference)
/*     */       {
/*     */ 
/*     */         
/* 108 */         super.characters(ch, start, length);
/*     */       }
/*     */     } else {
/* 111 */       super.characters(ch, start, length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) throws SAXException {
/* 121 */     if (this.dtdRange) {
/*     */       
/* 123 */       if (this.preserveDTD) {
/* 124 */         this.docTypeText += "<!--" + new String(ch, start, length) + "-->";
/*     */       
/*     */       }
/*     */     }
/* 128 */     else if (this.preserveComment) {
/*     */       try {
/* 130 */         this.encoder.encodeComment(ch, start, length);
/* 131 */       } catch (Exception e) {
/* 132 */         throw new SAXException("comment", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) throws SAXException {
/*     */     try {
/* 141 */       if (this.dtdRange) {
/*     */         
/* 143 */         if (this.preserveDTD) {
/* 144 */           this.docTypeText += "<?" + target + " " + data + "?>";
/*     */         }
/*     */       } else {
/* 147 */         this.encoder.encodeProcessingInstruction(target, data);
/*     */       } 
/* 149 */     } catch (Exception e) {
/* 150 */       throw new SAXException("processingInstruction", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startCDATA() throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endCDATA() throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {
/*     */     try {
/* 169 */       if (this.preserveDTD) {
/* 170 */         this.docTypeName = name;
/* 171 */         this.docTypePublicID = (publicId == null) ? "" : publicId;
/* 172 */         this.docTypeSystemID = (systemId == null) ? "" : systemId;
/* 173 */         this.docTypeText = "";
/*     */       } 
/* 175 */       this.dtdRange = true;
/*     */     }
/* 177 */     catch (Exception e) {
/* 178 */       throw new SAXException("startDTD", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void endDTD() throws SAXException {
/*     */     try {
/* 184 */       if (this.preserveDTD) {
/* 185 */         this.encoder.encodeDocType(this.docTypeName, this.docTypePublicID, this.docTypeSystemID, this.docTypeText);
/*     */       }
/*     */ 
/*     */       
/* 189 */       this.dtdRange = false;
/* 190 */     } catch (Exception e) {
/* 191 */       throw new SAXException("endDTD", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void startEntity(String name) throws SAXException {
/* 196 */     if (!this.preserveDTD || 
/* 197 */       this.retainEntityReference);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 206 */     this.entityReferenceRange = true;
/*     */   }
/*     */   
/*     */   public void endEntity(String name) throws SAXException {
/*     */     try {
/* 211 */       if (this.preserveDTD && this.entityReferenceRange && 
/* 212 */         this.retainEntityReference)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 219 */         if (!name.startsWith("%") && !name.equals("[dtd]"))
/*     */         {
/*     */           
/* 222 */           this.encoder.encodeEntityReference(name);
/*     */         }
/*     */       }
/*     */       
/* 226 */       this.entityReferenceRange = false;
/*     */     }
/* 228 */     catch (Exception e) {
/* 229 */       throw new SAXException("endEntity " + name, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void skippedEntity(String name) throws SAXException {
/*     */     try {
/* 235 */       if (this.preserveDTD) {
/* 236 */         this.encoder.encodeEntityReference(name);
/*     */       }
/* 238 */     } catch (Exception e) {
/* 239 */       throw new SAXException("skippedEntity " + name, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notationDecl(String name, String publicId, String systemId) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unparsedEntityDecl(String name, String publicId, String systemId, String notationName) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void elementDecl(String name, String model) throws SAXException {
/* 262 */     if (this.preserveDTD)
/*     */     {
/*     */       
/* 265 */       this.docTypeText += "<!ELEMENT " + name + " " + model + "> ";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void attributeDecl(String eName, String aName, String type, String mode, String value) throws SAXException {
/* 271 */     if (this.preserveDTD)
/*     */     {
/* 273 */       this.docTypeText += "<!ATTLIST " + eName + " " + aName + " " + type + " " + mode + "> ";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void internalEntityDecl(String name, String value) throws SAXException {
/* 280 */     if (this.preserveDTD)
/*     */     {
/* 282 */       this.docTypeText += "<!ENTITY " + name + " \"" + value + "\"> ";
/*     */     }
/*     */   }
/*     */   
/*     */   public void externalEntityDecl(String name, String publicId, String systemId) throws SAXException {}
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\sax\SAXEncoderExtendedHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */