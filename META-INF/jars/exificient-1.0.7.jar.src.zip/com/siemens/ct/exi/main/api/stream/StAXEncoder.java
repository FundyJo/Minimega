/*     */ package com.siemens.ct.exi.main.api.stream;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIBodyEncoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EXIStreamEncoder;
/*     */ import com.siemens.ct.exi.core.FidelityOptions;
/*     */ import com.siemens.ct.exi.core.attributes.AttributeFactory;
/*     */ import com.siemens.ct.exi.core.attributes.AttributeList;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import com.siemens.ct.exi.main.util.SimpleDocTypeParser;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.Comment;
/*     */ import javax.xml.stream.events.DTD;
/*     */ import javax.xml.stream.events.EntityReference;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.ProcessingInstruction;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXEncoder
/*     */   implements XMLStreamWriter
/*     */ {
/*  76 */   private static final Logger LOGGER = LoggerFactory.getLogger(StAXEncoder.class);
/*     */ 
/*     */   
/*     */   protected EXIBodyEncoder encoder;
/*     */   
/*     */   protected EXIStreamEncoder exiStream;
/*     */   
/*     */   protected SimpleDocTypeParser dtdParser;
/*     */   
/*     */   protected final boolean preserveDTD;
/*     */   
/*     */   protected final boolean preserveComment;
/*     */   
/*     */   protected final boolean preservePI;
/*     */   
/*     */   protected boolean pendingATs;
/*     */   
/*     */   protected AttributeList exiAttributes;
/*     */   
/*     */   protected EncoderNamespaceContext nsContext;
/*     */ 
/*     */   
/*     */   public StAXEncoder(EXIFactory factory) throws EXIException {
/*  99 */     AttributeFactory attFactory = AttributeFactory.newInstance();
/* 100 */     this.exiAttributes = attFactory.createAttributeListInstance(factory);
/* 101 */     this.nsContext = new EncoderNamespaceContext();
/*     */     
/* 103 */     this.exiStream = factory.createEXIStreamEncoder();
/*     */     
/* 105 */     FidelityOptions fo = factory.getFidelityOptions();
/* 106 */     this.preserveDTD = fo.isFidelityEnabled("PRESERVE_DTDS");
/* 107 */     this.preserveComment = fo.isFidelityEnabled("PRESERVE_COMMENTS");
/* 108 */     this.preservePI = fo.isFidelityEnabled("PRESERVE_PIS");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputStream(OutputStream os) throws EXIException, IOException {
/* 114 */     this.encoder = this.exiStream.encodeHeader(os);
/*     */   }
/*     */   
/*     */   protected void init() {
/* 118 */     this.pendingATs = false;
/* 119 */     this.exiAttributes.clear();
/* 120 */     this.nsContext.reset();
/*     */   }
/*     */   
/*     */   protected SimpleDocTypeParser getDtdParser() throws SAXException {
/* 124 */     if (this.dtdParser == null) {
/* 125 */       this.dtdParser = new SimpleDocTypeParser();
/*     */     }
/* 127 */     return this.dtdParser;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encode(XMLEventReader xmlEvent) throws XMLStreamException, EXIException, IOException {
/* 133 */     while (xmlEvent.hasNext()) {
/* 134 */       StartElement se; QName qn; String pfx; Iterator<Namespace> namespaces; Iterator<Attribute> attributes; Namespace ns; Characters chars; ProcessingInstruction pi; Comment cm; DTD dtd; EntityReference er; XMLEvent event = xmlEvent.nextEvent();
/* 135 */       switch (event.getEventType()) {
/*     */         case 7:
/* 137 */           writeStartDocument();
/*     */           continue;
/*     */         case 8:
/* 140 */           writeEndDocument();
/*     */           continue;
/*     */         case 1:
/* 143 */           se = event.asStartElement();
/* 144 */           qn = se.getName();
/* 145 */           pfx = qn.getPrefix();
/* 146 */           writeStartElement(pfx, qn.getLocalPart(), qn.getNamespaceURI());
/*     */ 
/*     */ 
/*     */           
/* 150 */           namespaces = se.getNamespaces();
/* 151 */           while (namespaces.hasNext()) {
/* 152 */             Namespace namespace = namespaces.next();
/* 153 */             writeNamespace(namespace.getPrefix(), namespace.getNamespaceURI());
/*     */           } 
/*     */ 
/*     */           
/* 157 */           attributes = se.getAttributes();
/* 158 */           while (attributes.hasNext()) {
/* 159 */             Attribute at = attributes.next();
/* 160 */             QName qnAt = at.getName();
/* 161 */             writeAttribute(qnAt.getPrefix(), qnAt
/* 162 */                 .getNamespaceURI(), qnAt.getLocalPart(), at
/* 163 */                 .getValue());
/*     */           } 
/*     */           continue;
/*     */         case 2:
/* 167 */           writeEndElement();
/*     */           continue;
/*     */         case 13:
/* 170 */           ns = (Namespace)event;
/* 171 */           writeNamespace(ns.getPrefix(), ns.getNamespaceURI());
/*     */           continue;
/*     */         case 4:
/* 174 */           chars = event.asCharacters();
/* 175 */           writeCharacters(chars.getData());
/*     */           continue;
/*     */         
/*     */         case 6:
/*     */         case 10:
/*     */           continue;
/*     */         case 3:
/* 182 */           pi = (ProcessingInstruction)event;
/* 183 */           writeProcessingInstruction(pi.getTarget(), pi.getData());
/*     */           continue;
/*     */         case 5:
/* 186 */           cm = (Comment)event;
/* 187 */           writeComment(cm.getText());
/*     */           continue;
/*     */         case 11:
/* 190 */           dtd = (DTD)event;
/* 191 */           writeDTD(dtd.getDocumentTypeDeclaration());
/*     */           continue;
/*     */         case 15:
/*     */           continue;
/*     */         case 9:
/* 196 */           er = (EntityReference)event;
/* 197 */           writeEntityRef(er.getName());
/*     */           continue;
/*     */       } 
/* 200 */       LOGGER.warn("StAX Event '{}' not supported!", event);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encode(XMLStreamReader xmlStream) throws XMLStreamException, EXIException, IOException {
/* 211 */     assert xmlStream.getEventType() == 7;
/*     */     
/* 213 */     writeStartDocument();
/*     */     
/* 215 */     while (xmlStream.hasNext()) {
/* 216 */       QName qn; String pfx; int nsCnt, i, atCnt, j; String ignorableSpace; int event = xmlStream.next();
/* 217 */       switch (event) {
/*     */         
/*     */         case 7:
/* 220 */           throw new EXIException("Unexpected START_DOCUMENT event");
/*     */         case 8:
/* 222 */           writeEndDocument();
/*     */           continue;
/*     */         case 1:
/* 225 */           qn = xmlStream.getName();
/* 226 */           pfx = qn.getPrefix();
/* 227 */           writeStartElement(pfx, qn.getLocalPart(), qn.getNamespaceURI());
/*     */           
/* 229 */           nsCnt = xmlStream.getNamespaceCount();
/* 230 */           for (i = 0; i < nsCnt; i++) {
/* 231 */             String nsPfx = xmlStream.getNamespacePrefix(i);
/*     */             
/* 233 */             nsPfx = (nsPfx == null) ? "" : nsPfx;
/* 234 */             String nsUri = xmlStream.getNamespaceURI(i);
/* 235 */             writeNamespace(nsPfx, nsUri);
/*     */           } 
/*     */           
/* 238 */           atCnt = xmlStream.getAttributeCount();
/* 239 */           for (j = 0; j < atCnt; j++) {
/* 240 */             QName atQname = xmlStream.getAttributeName(j);
/* 241 */             writeAttribute(atQname.getPrefix(), atQname
/* 242 */                 .getNamespaceURI(), atQname.getLocalPart(), xmlStream
/* 243 */                 .getAttributeValue(j));
/*     */           } 
/*     */           continue;
/*     */         
/*     */         case 2:
/* 248 */           writeEndElement();
/*     */           continue;
/*     */         case 13:
/*     */           continue;
/*     */         case 4:
/* 253 */           writeCharacters(xmlStream.getTextCharacters(), xmlStream
/* 254 */               .getTextStart(), xmlStream.getTextLength());
/*     */           continue;
/*     */         
/*     */         case 6:
/* 258 */           ignorableSpace = xmlStream.getText();
/* 259 */           writeCharacters(ignorableSpace);
/*     */           continue;
/*     */         
/*     */         case 10:
/*     */           continue;
/*     */         
/*     */         case 3:
/* 266 */           writeProcessingInstruction(xmlStream.getPITarget(), xmlStream
/* 267 */               .getPIData());
/*     */           continue;
/*     */         case 5:
/* 270 */           writeComment(xmlStream.getText());
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 11:
/*     */         case 9:
/*     */           continue;
/*     */       } 
/*     */       
/* 279 */       LOGGER.warn("Event '{}' not supported!", Integer.valueOf(event));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkPendingATEvents() throws EXIException, IOException {
/* 288 */     if (this.pendingATs) {
/*     */       
/* 290 */       this.encoder.encodeAttributeList(this.exiAttributes);
/* 291 */       this.exiAttributes.clear();
/*     */       
/* 293 */       this.pendingATs = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeAttribute(String prefix, String namespaceURI, String localName, String value) throws XMLStreamException {
/*     */     try {
/* 308 */       this.exiAttributes.addAttribute(namespaceURI, localName, prefix, value);
/*     */     }
/* 310 */     catch (Exception e) {
/* 311 */       throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeCData(String data) throws XMLStreamException {
/*     */     try {
/* 324 */       checkPendingATEvents();
/*     */       
/* 326 */       writeCharacters(data);
/* 327 */     } catch (Exception e) {
/* 328 */       throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeCharacters(String text) throws XMLStreamException {
/*     */     try {
/* 341 */       checkPendingATEvents();
/* 342 */       this.encoder.encodeCharacters((Value)new StringValue(text));
/* 343 */     } catch (Exception e) {
/* 344 */       throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeCharacters(char[] text, int start, int len) throws XMLStreamException {
/* 357 */     writeCharacters(new String(text, start, len));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeComment(String data) throws XMLStreamException {
/* 368 */     if (this.preserveComment) {
/*     */       try {
/* 370 */         checkPendingATEvents();
/*     */         
/* 372 */         char[] chars = data.toCharArray();
/* 373 */         this.encoder.encodeComment(chars, 0, chars.length);
/* 374 */       } catch (Exception e) {
/* 375 */         throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDTD(String dtd) throws XMLStreamException {
/* 388 */     if (this.preserveDTD) {
/*     */       try {
/* 390 */         checkPendingATEvents();
/* 391 */         SimpleDocTypeParser dtdParser = getDtdParser();
/* 392 */         dtdParser.parse(dtd);
/*     */         
/* 394 */         this.encoder.encodeDocType(dtdParser.name, dtdParser.publicID, dtdParser.systemID, dtdParser.text);
/*     */       }
/* 396 */       catch (Exception e) {
/* 397 */         throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEndDocument() throws XMLStreamException {
/*     */     try {
/* 411 */       checkPendingATEvents();
/* 412 */       this.encoder.encodeEndDocument();
/* 413 */       this.encoder.flush();
/* 414 */     } catch (Exception e) {
/* 415 */       throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEndElement() throws XMLStreamException {
/*     */     try {
/* 429 */       checkPendingATEvents();
/* 430 */       this.encoder.encodeEndElement();
/* 431 */     } catch (Exception e) {
/* 432 */       throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEntityRef(String name) throws XMLStreamException {
/* 444 */     if (this.preserveDTD) {
/*     */       try {
/* 446 */         checkPendingATEvents();
/* 447 */         this.encoder.encodeEntityReference(name);
/* 448 */       } catch (Exception e) {
/* 449 */         throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeNamespace(String prefix, String namespaceURI) throws XMLStreamException {
/*     */     try {
/* 467 */       this.exiAttributes.addNamespaceDeclaration(namespaceURI, prefix);
/*     */     }
/* 469 */     catch (Exception e) {
/* 470 */       throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeProcessingInstruction(String target) throws XMLStreamException {
/* 485 */     writeProcessingInstruction(target, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeProcessingInstruction(String target, String data) throws XMLStreamException {
/* 499 */     if (this.preservePI) {
/*     */       try {
/* 501 */         checkPendingATEvents();
/* 502 */         this.encoder.encodeProcessingInstruction(target, data);
/* 503 */       } catch (Exception e) {
/* 504 */         throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartDocument() throws XMLStreamException {
/* 517 */     init();
/*     */     try {
/* 519 */       this.encoder.encodeStartDocument();
/* 520 */     } catch (Exception e) {
/* 521 */       throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartElement(String prefix, String localName, String namespaceURI) throws XMLStreamException {
/*     */     try {
/* 536 */       assert namespaceURI != null;
/* 537 */       assert localName != null;
/*     */       
/* 539 */       checkPendingATEvents();
/* 540 */       this.encoder.encodeStartElement(namespaceURI, localName, prefix);
/* 541 */       this.pendingATs = true;
/* 542 */     } catch (Exception e) {
/* 543 */       throw new XMLStreamException(e.getLocalizedMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws XMLStreamException {
/* 548 */     flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws XMLStreamException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceContext getNamespaceContext() {
/* 564 */     return this.nsContext;
/*     */   }
/*     */   
/*     */   public String getPrefix(String uri) throws XMLStreamException {
/* 568 */     return getNamespaceContext().getPrefix(uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws IllegalArgumentException {
/* 573 */     return null;
/*     */   }
/*     */   
/*     */   public void setDefaultNamespace(String uri) throws XMLStreamException {
/* 577 */     setPrefix("", uri);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespaceContext(NamespaceContext context) throws XMLStreamException {
/* 583 */     throw new IllegalArgumentException("NamespaceContext cannot be replaced");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefix(String prefix, String uri) throws XMLStreamException {
/* 589 */     writeNamespace(prefix, uri);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeAttribute(String localName, String value) throws XMLStreamException {
/* 594 */     writeAttribute("", localName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeAttribute(String namespaceURI, String localName, String value) throws XMLStreamException {
/* 599 */     writeAttribute(getNamespaceContext().getPrefix(namespaceURI), namespaceURI, localName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDefaultNamespace(String namespaceURI) throws XMLStreamException {
/* 605 */     setPrefix("", namespaceURI);
/*     */   }
/*     */   
/*     */   public void writeEmptyElement(String localName) throws XMLStreamException {
/* 609 */     writeEmptyElement("", localName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEmptyElement(String namespaceURI, String localName) throws XMLStreamException {
/* 614 */     writeEmptyElement("", localName, namespaceURI);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEmptyElement(String prefix, String localName, String namespaceURI) throws XMLStreamException {
/* 620 */     writeStartElement(prefix, localName, namespaceURI);
/* 621 */     writeEndElement();
/*     */   }
/*     */   
/*     */   public void writeStartDocument(String version) throws XMLStreamException {
/* 625 */     writeStartDocument();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartDocument(String encoding, String version) throws XMLStreamException {
/* 630 */     writeStartDocument();
/*     */   }
/*     */   
/*     */   public void writeStartElement(String localName) throws XMLStreamException {
/* 634 */     writeStartElement("", localName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartElement(String namespaceURI, String localName) throws XMLStreamException {
/* 639 */     writeStartElement(getNamespaceContext().getPrefix(namespaceURI), localName, namespaceURI);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class EncoderNamespaceContext
/*     */     implements NamespaceContext
/*     */   {
/* 648 */     List<List<NamespaceDeclaration>> nsContexts = new ArrayList<>();
/*     */ 
/*     */     
/*     */     public void reset() {
/* 652 */       this.nsContexts.clear();
/* 653 */       pushContext();
/* 654 */       bindPrefix("http://www.w3.org/XML/1998/namespace", "");
/* 655 */       bindPrefix("http://www.w3.org/XML/1998/namespace", "xml");
/*     */     }
/*     */     
/*     */     public void pushContext() {
/* 659 */       this.nsContexts.add(null);
/*     */     }
/*     */     
/*     */     public void bindPrefix(String namespaceURI, String prefix) {
/* 663 */       int level = this.nsContexts.size() - 1;
/* 664 */       List<NamespaceDeclaration> l = this.nsContexts.get(level);
/* 665 */       if (l == null) {
/* 666 */         l = new ArrayList<>();
/* 667 */         this.nsContexts.set(level, l);
/*     */       } 
/*     */       
/* 670 */       l.add(new NamespaceDeclaration(namespaceURI, prefix));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<NamespaceDeclaration> popContext() {
/* 676 */       assert this.nsContexts.size() > 1;
/* 677 */       return this.nsContexts.remove(this.nsContexts.size() - 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getNamespaceURI(String prefix) {
/* 682 */       int level = this.nsContexts.size() - 1;
/* 683 */       while (level >= 0) {
/* 684 */         List<NamespaceDeclaration> l = this.nsContexts.get(level);
/* 685 */         if (l != null) {
/* 686 */           for (NamespaceDeclaration nsDecl : l) {
/* 687 */             if (nsDecl.prefix.equals(prefix)) {
/* 688 */               return nsDecl.namespaceURI;
/*     */             }
/*     */           } 
/*     */         }
/* 692 */         level--;
/*     */       } 
/*     */       
/* 695 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPrefix(String namespaceURI) {
/* 700 */       int level = this.nsContexts.size() - 1;
/* 701 */       while (level >= 0) {
/* 702 */         List<NamespaceDeclaration> l = this.nsContexts.get(level);
/* 703 */         if (l != null) {
/* 704 */           for (NamespaceDeclaration nsDecl : l) {
/* 705 */             if (nsDecl.namespaceURI.equals(namespaceURI)) {
/* 706 */               return nsDecl.prefix;
/*     */             }
/*     */           } 
/*     */         }
/* 710 */         level--;
/*     */       } 
/*     */       
/* 713 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator getPrefixes(String namespaceURI) {
/* 718 */       List<String> prefixes = new ArrayList<>();
/*     */       
/* 720 */       int level = this.nsContexts.size() - 1;
/* 721 */       while (level >= 0) {
/* 722 */         List<NamespaceDeclaration> l = this.nsContexts.get(level);
/* 723 */         if (l != null) {
/* 724 */           for (NamespaceDeclaration nsDecl : l) {
/* 725 */             if (nsDecl.namespaceURI.equals(namespaceURI)) {
/* 726 */               prefixes.add(nsDecl.prefix);
/*     */             }
/*     */           } 
/*     */         }
/* 730 */         level--;
/*     */       } 
/*     */       
/* 733 */       return prefixes.iterator();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\stream\StAXEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */