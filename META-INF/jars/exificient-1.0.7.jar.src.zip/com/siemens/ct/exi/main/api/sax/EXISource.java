/*    */ package com.siemens.ct.exi.main.api.sax;
/*    */ 
/*    */ import com.siemens.ct.exi.core.EXIFactory;
/*    */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*    */ import com.siemens.ct.exi.core.helpers.DefaultEXIFactory;
/*    */ import javax.xml.transform.sax.SAXSource;
/*    */ import org.xml.sax.XMLReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EXISource
/*    */   extends SAXSource
/*    */ {
/*    */   SAXFactory saxFactory;
/*    */   
/*    */   public EXISource() throws EXIException {
/* 48 */     this(DefaultEXIFactory.newInstance());
/*    */   }
/*    */   
/*    */   public EXISource(EXIFactory exiFactory) throws EXIException {
/* 52 */     this.saxFactory = new SAXFactory(exiFactory);
/*    */     
/* 54 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void init() throws EXIException {
/* 59 */     XMLReader xmlReader = this.saxFactory.createEXIReader();
/*    */ 
/*    */     
/* 62 */     setXMLReader(xmlReader);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\sax\EXISource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */