/*     */ package com.siemens.ct.exi.main.api.dom;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIBodyEncoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EXIStreamEncoder;
/*     */ import com.siemens.ct.exi.core.attributes.AttributeFactory;
/*     */ import com.siemens.ct.exi.core.attributes.AttributeList;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.values.StringValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentFragment;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMWriter
/*     */ {
/*  60 */   private static final Logger LOGGER = LoggerFactory.getLogger(DOMWriter.class);
/*     */   
/*     */   protected EXIFactory factory;
/*     */   
/*     */   protected EXIStreamEncoder exiStream;
/*     */   
/*     */   protected EXIBodyEncoder exiBody;
/*     */   
/*     */   private AttributeList exiAttributes;
/*     */   protected boolean preserveWhitespaces;
/*     */   protected boolean preserveComments;
/*     */   protected boolean preservePIs;
/*     */   
/*     */   public DOMWriter(EXIFactory factory) throws EXIException {
/*  74 */     this.factory = factory;
/*     */     
/*  76 */     this.exiStream = factory.createEXIStreamEncoder();
/*     */ 
/*     */     
/*  79 */     AttributeFactory attFactory = AttributeFactory.newInstance();
/*  80 */     this.exiAttributes = attFactory.createAttributeListInstance(factory);
/*     */ 
/*     */     
/*  83 */     this.preserveComments = factory.getFidelityOptions().isFidelityEnabled("PRESERVE_COMMENTS");
/*     */     
/*  85 */     this.preservePIs = factory.getFidelityOptions().isFidelityEnabled("PRESERVE_PIS");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOutput(OutputStream os) throws EXIException, IOException {
/*  90 */     this.exiBody = this.exiStream.encodeHeader(os);
/*     */   }
/*     */   
/*     */   public void encode(Document doc) throws EXIException, IOException {
/*  94 */     if (this.exiBody == null) {
/*  95 */       throw new EXIException("Please specify output stream");
/*     */     }
/*     */     
/*  98 */     this.exiBody.encodeStartDocument();
/*     */ 
/*     */ 
/*     */     
/* 102 */     encodeChildNodes(doc.getChildNodes());
/*     */     
/* 104 */     this.exiBody.encodeEndDocument();
/* 105 */     this.exiBody.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeFragment(DocumentFragment docFragment) throws EXIException, IOException {
/* 110 */     if (this.exiBody == null) {
/* 111 */       throw new EXIException("Please specify output stream");
/*     */     }
/*     */     
/* 114 */     this.exiBody.encodeStartDocument();
/* 115 */     encodeChildNodes(docFragment.getChildNodes());
/* 116 */     this.exiBody.encodeEndDocument();
/* 117 */     this.exiBody.flush();
/*     */   }
/*     */   
/*     */   public void encode(Node n) throws EXIException, IOException {
/* 121 */     if (n.getNodeType() == 9) {
/* 122 */       encode((Document)n);
/* 123 */     } else if (n.getNodeType() == 11) {
/* 124 */       encodeFragment((DocumentFragment)n);
/*     */     } else {
/* 126 */       this.exiBody.encodeStartDocument();
/* 127 */       encodeNode(n);
/* 128 */       this.exiBody.encodeEndDocument();
/* 129 */       this.exiBody.flush();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void encodeNode(Node root) throws EXIException, IOException {
/* 134 */     assert root.getNodeType() == 1;
/*     */ 
/*     */ 
/*     */     
/* 138 */     String namespaceURI = (root.getNamespaceURI() == null) ? "" : root.getNamespaceURI();
/* 139 */     String localName = root.getLocalName();
/* 140 */     if (localName == null)
/*     */     {
/* 142 */       localName = root.getNodeName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     String prefix = root.getPrefix();
/* 149 */     if (prefix == null) {
/* 150 */       prefix = "";
/*     */     }
/* 152 */     this.exiBody.encodeStartElement(namespaceURI, localName, prefix);
/*     */ 
/*     */     
/* 155 */     NamedNodeMap attributes = root.getAttributes();
/*     */     
/* 157 */     for (int i = 0; i < attributes.getLength(); i++) {
/* 158 */       Node at = attributes.item(i);
/*     */ 
/*     */       
/* 161 */       if ("http://www.w3.org/2000/xmlns/".equals(at.getNamespaceURI())) {
/*     */         
/* 163 */         String pfx = (at.getPrefix() == null) ? "" : at.getLocalName();
/* 164 */         this.exiAttributes.addNamespaceDeclaration(at.getNodeValue(), pfx);
/*     */       } else {
/* 166 */         String atLocalName = at.getLocalName();
/* 167 */         if (atLocalName == null)
/*     */         {
/* 169 */           atLocalName = at.getNodeName();
/*     */         }
/* 171 */         this.exiAttributes.addAttribute(at.getNamespaceURI(), atLocalName, at
/* 172 */             .getPrefix(), at.getNodeValue());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 177 */     this.exiBody.encodeAttributeList(this.exiAttributes);
/* 178 */     this.exiAttributes.clear();
/*     */ 
/*     */     
/* 181 */     NodeList children = root.getChildNodes();
/* 182 */     encodeChildNodes(children);
/*     */ 
/*     */     
/* 185 */     this.exiBody.encodeEndElement();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void encodeChildNodes(NodeList children) throws EXIException, IOException {
/* 190 */     for (int i = 0; i < children.getLength(); i++) {
/* 191 */       DocumentType dt; String publicID, systemID, text; Node n = children.item(i);
/* 192 */       switch (n.getNodeType()) {
/*     */         case 1:
/* 194 */           encodeNode(n);
/*     */           break;
/*     */         case 2:
/*     */           break;
/*     */         case 3:
/* 199 */           this.exiBody.encodeCharacters((Value)new StringValue(n.getNodeValue()));
/*     */           break;
/*     */         case 8:
/* 202 */           if (this.preserveComments) {
/* 203 */             String c = n.getNodeValue();
/* 204 */             this.exiBody.encodeComment(c.toCharArray(), 0, c.length());
/*     */           } 
/*     */           break;
/*     */         case 10:
/* 208 */           dt = (DocumentType)n;
/*     */           
/* 210 */           publicID = (dt.getPublicId() == null) ? "" : dt.getPublicId();
/*     */           
/* 212 */           systemID = (dt.getSystemId() == null) ? "" : dt.getSystemId();
/*     */           
/* 214 */           text = (dt.getInternalSubset() == null) ? "" : dt.getInternalSubset();
/* 215 */           this.exiBody.encodeDocType(dt.getName(), publicID, systemID, text);
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 5:
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 4:
/* 226 */           this.exiBody.encodeCharacters((Value)new StringValue(n.getNodeValue()));
/*     */           break;
/*     */         case 7:
/* 229 */           if (this.preservePIs) {
/* 230 */             ProcessingInstruction pi = (ProcessingInstruction)n;
/* 231 */             this.exiBody.encodeProcessingInstruction(pi.getTarget(), pi
/* 232 */                 .getData());
/*     */           } 
/*     */           break;
/*     */         default:
/* 236 */           LOGGER.error("[WARNING] Unhandled DOM NodeType: " + n
/* 237 */               .getNodeType());
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\dom\DOMWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */