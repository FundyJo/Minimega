/*     */ package com.siemens.ct.exi.main.api.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentFragment;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.EntityReference;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.DTDHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.DeclHandler;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaxToDomHandler
/*     */   extends DefaultHandler
/*     */   implements LexicalHandler, DTDHandler, DeclHandler
/*     */ {
/*     */   protected Document document;
/*     */   protected DocumentFragment docFragment;
/*     */   protected DOMImplementation domImplementation;
/*     */   protected boolean fragment;
/*     */   protected Node currentNode;
/*     */   protected DocumentType dt;
/*     */   protected List<PrefixMapping> prefixes;
/*     */   
/*     */   public SaxToDomHandler(DOMImplementation domImplementation, boolean fragment) {
/*  73 */     this.domImplementation = domImplementation;
/*  74 */     this.fragment = fragment;
/*     */     
/*  76 */     this.prefixes = new ArrayList<>();
/*     */   }
/*     */   
/*     */   protected Document checkDocument() {
/*  80 */     if (this.document == null) {
/*     */       
/*  82 */       this.document = this.domImplementation.createDocument(null, null, this.dt);
/*     */       
/*  84 */       if (this.fragment) {
/*  85 */         this.docFragment = this.document.createDocumentFragment();
/*  86 */         this.currentNode = this.docFragment;
/*     */       } else {
/*  88 */         this.currentNode = this.document;
/*     */       } 
/*     */     } 
/*  91 */     return this.document;
/*     */   }
/*     */   
/*     */   public Document getDocument() {
/*  95 */     return this.document;
/*     */   }
/*     */   
/*     */   public DocumentFragment getDocumentFragment() {
/*  99 */     return this.docFragment;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String name, String qName, Attributes attrs) throws SAXException {
/* 105 */     Element element = checkDocument().createElementNS(uri, qName);
/*     */     
/*     */     int i;
/* 108 */     for (i = 0; i < this.prefixes.size(); i++) {
/* 109 */       PrefixMapping pm = this.prefixes.get(i);
/*     */       
/* 111 */       String qname = (pm.prefix.length() == 0) ? "xmlns" : ("xmlns:" + pm.prefix);
/* 112 */       Attr attr = checkDocument().createAttributeNS("http://www.w3.org/2000/xmlns/", qname);
/*     */       
/* 114 */       attr.setValue(pm.uri);
/* 115 */       element.setAttributeNodeNS(attr);
/*     */     } 
/* 117 */     this.prefixes.clear();
/*     */ 
/*     */     
/* 120 */     for (i = 0; i < attrs.getLength(); i++) {
/* 121 */       String value = attrs.getValue(i);
/* 122 */       String ns_uri = attrs.getURI(i);
/*     */       
/* 124 */       String qname = attrs.getQName(i);
/* 125 */       Attr attr = checkDocument().createAttributeNS(ns_uri, qname);
/*     */       
/* 127 */       attr.setValue(value);
/* 128 */       element.setAttributeNodeNS(attr);
/*     */     } 
/*     */ 
/*     */     
/* 132 */     this.currentNode.appendChild(element);
/* 133 */     this.currentNode = element;
/*     */   }
/*     */   
/*     */   static class PrefixMapping {
/*     */     public final String prefix;
/*     */     public final String uri;
/*     */     
/*     */     public PrefixMapping(String prefix, String uri) {
/* 141 */       this.prefix = prefix;
/* 142 */       this.uri = uri;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/* 149 */     this.prefixes.add(new PrefixMapping(prefix, uri));
/*     */   }
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String name, String qName) {
/* 154 */     this.currentNode = this.currentNode.getParentNode();
/*     */   }
/*     */   
/*     */   public void characters(char[] ch, int start, int length) {
/* 158 */     if (length > 0) {
/*     */       
/* 160 */       String ss = new String(ch, start, length);
/* 161 */       Text text = checkDocument().createTextNode(ss);
/* 162 */       this.currentNode.appendChild(text);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void processingInstruction(String target, String data) {
/* 168 */     ProcessingInstruction pi = checkDocument().createProcessingInstruction(target, data);
/*     */     
/* 170 */     this.currentNode.appendChild(pi);
/*     */   }
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) throws SAXException {
/* 175 */     Comment cm = checkDocument().createComment(new String(ch, start, length));
/*     */     
/* 177 */     this.currentNode.appendChild(cm);
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {
/* 182 */     this.dt = this.domImplementation.createDocumentType(name, publicId, systemId);
/*     */     
/* 184 */     checkDocument();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endDTD() throws SAXException {
/* 191 */     this.dt = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endCDATA() throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startCDATA() throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notationDecl(String name, String publicId, String systemId) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unparsedEntityDecl(String name, String publicId, String systemId, String notationName) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void attributeDecl(String eName, String aName, String type, String mode, String value) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void elementDecl(String name, String model) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void externalEntityDecl(String name, String publicId, String systemId) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void internalEntityDecl(String name, String value) throws SAXException {
/* 240 */     if (this.dt != null) {
/*     */       
/* 242 */       EntityReference er = checkDocument().createEntityReference(name);
/* 243 */       er.setNodeValue(value);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\dom\SaxToDomHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */