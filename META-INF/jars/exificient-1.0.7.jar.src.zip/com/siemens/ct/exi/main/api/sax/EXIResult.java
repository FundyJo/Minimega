/*    */ package com.siemens.ct.exi.main.api.sax;
/*    */ 
/*    */ import com.siemens.ct.exi.core.EXIFactory;
/*    */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*    */ import com.siemens.ct.exi.core.helpers.DefaultEXIFactory;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import javax.xml.transform.sax.SAXResult;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EXIResult
/*    */   extends SAXResult
/*    */ {
/*    */   protected SAXEncoder handler;
/*    */   
/*    */   public EXIResult() throws IOException, EXIException {
/* 49 */     this(DefaultEXIFactory.newInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   public EXIResult(EXIFactory exiFactory) throws EXIException {
/* 54 */     this.handler = (new SAXFactory(exiFactory)).createEXIWriter();
/*    */     
/* 56 */     setHandler(this.handler);
/* 57 */     setLexicalHandler(this.handler);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setOutputStream(OutputStream os) throws EXIException, IOException {
/* 62 */     this.handler.setOutputStream(os);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\sax\EXIResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */