/*     */ package com.siemens.ct.exi.main.cmd;
/*     */ 
/*     */ import com.siemens.ct.exi.core.CodingMode;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.FidelityOptions;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.helpers.DefaultEXIFactory;
/*     */ import com.siemens.ct.exi.grammars.GrammarFactory;
/*     */ import com.siemens.ct.exi.main.api.sax.EXIResult;
/*     */ import com.siemens.ct.exi.main.api.sax.SAXFactory;
/*     */ import com.siemens.ct.exi.main.util.FragmentUtilities;
/*     */ import com.siemens.ct.exi.main.util.NoEntityResolver;
/*     */ import com.siemens.ct.exi.main.util.SkipRootElementXMLReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.xml.sax.DTDHandler;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EXIficientCMD
/*     */ {
/*  91 */   public static final PrintStream ps = System.out;
/*     */   
/*     */   public static final String HELP = "-h";
/*     */   
/*  95 */   public static final String ENCODE = "-" + CmdOption.encode;
/*  96 */   public static final String DECODE = "-" + CmdOption.decode;
/*     */   
/*     */   public static final String INPUT = "-i";
/*     */   
/*     */   public static final String OUTPUT = "-o";
/* 101 */   public static final String NO_SCHEMA = "-" + SchemaOption.noSchema;
/* 102 */   public static final String XSD_SCHEMA = "-" + SchemaOption.xsdSchema;
/* 103 */   public static final String SCHEMA = "-" + SchemaOption.schema;
/*     */   
/*     */   public static final String OPTION_STRICT = "-strict";
/*     */   
/*     */   public static final String PRESERVE_COMMENTS = "-preserveComments";
/*     */   
/*     */   public static final String PRESERVE_LEXICAL_VALUES = "-preserveLexicalValues";
/*     */   
/*     */   public static final String PRESERVE_PREFIXES = "-preservePrefixes";
/*     */   
/*     */   public static final String PRESERVE_PIS = "-preservePIs";
/*     */   
/*     */   public static final String PRESERVE_DTDS = "-preserveDTDs";
/*     */   public static final String INCLUDE_OPTIONS = "-includeOptions";
/*     */   public static final String INCLUDE_COOKIE = "-includeCookie";
/*     */   public static final String INCLUDE_SCHEMA_ID = "-includeSchemaId";
/*     */   public static final String INCLUDE_SCHEMA_LOCATION = "-includeSchemaLocation";
/*     */   public static final String INCLUDE_INSIGNIFICANT_XSI_NIL = "-includeInsignificantXsiNil";
/*     */   public static final String INCLUDE_PROFILE_VALUES = "-includeProfileValues";
/*     */   public static final String RETAIN_ENTITY_REFERENCE = "-retainEntityReference";
/*     */   public static final String FRAGMENT = "-fragment";
/*     */   public static final String SELF_CONTAINED = "-selfContained";
/*     */   public static final String DATATYPE_REPRESENTATION_MAP = "-datatypeRepresentationMap";
/*     */   public static final String CODING_BYTEPACKED = "-bytePacked";
/*     */   public static final String CODING_PRE_COMPRESSION = "-preCompression";
/*     */   public static final String CODING_COMPRESSION = "-compression";
/*     */   public static final String BLOCK_SIZE = "-blockSize";
/*     */   public static final String VALUE_MAX_LENGTH = "-valueMaxLength";
/*     */   public static final String VALUE_PARTITION_CAPACITY = "-valuePartitionCapacity";
/*     */   public static final String NO_LOCAL_VALUE_PARTITIONS = "-noLocalValuePartitions";
/*     */   public static final String MAXIMUM_NUMBER_OF_BUILT_IN_PRODUCTIONS = "-maximumNumberOfBuiltInProductions";
/*     */   public static final String MAXIMUM_NUMBER_OF_BUILT_IN_ELEMENT_GRAMMARS = "-maximumNumberOfBuiltInElementGrammars";
/* 135 */   public static String DEFAULT_EXI_FILE_EXTENSION = ".exi";
/* 136 */   public static String DEFAULT_XML_FILE_EXTENSION = ".xml";
/*     */   
/*     */   protected boolean inputParametersOK;
/*     */   
/*     */   protected CmdOption cmdOption;
/*     */   
/*     */   protected EXIFactory exiFactory;
/*     */   
/*     */   protected String input;
/*     */   protected String output;
/*     */   
/*     */   private static void printHeader() {
/* 148 */     ps.println("#########################################################################");
/* 149 */     ps.println("###   EXIficient                                                     ###");
/* 150 */     ps.println("###   Command-Shell Options                                          ###");
/* 151 */     ps.println("#########################################################################");
/*     */   }
/*     */   
/*     */   private static void printHelp() {
/* 155 */     printHeader();
/*     */     
/* 157 */     ps.println();
/* 158 */     ps.println(" -h                               /* shows help */");
/*     */     
/* 160 */     ps.println();
/* 161 */     ps.println(" " + ENCODE);
/* 162 */     ps.println(" " + DECODE);
/* 163 */     ps.println();
/* 164 */     ps.println(" -i <input-file>");
/* 165 */     ps.println(" -o <output-file>");
/* 166 */     ps.println();
/* 167 */     ps.println(" " + SCHEMA + " <schema-input-file>");
/* 168 */     ps.println(" " + XSD_SCHEMA + "                       /* XML schema datatypes only */");
/*     */     
/* 170 */     ps.println(" " + NO_SCHEMA + "                        /* default */");
/* 171 */     ps.println();
/* 172 */     ps.println(" -strict");
/* 173 */     ps.println(" -preservePrefixes");
/* 174 */     ps.println(" -preserveComments");
/* 175 */     ps.println(" -preserveLexicalValues");
/* 176 */     ps.println(" -preservePIs                     /* processing instructions */");
/*     */     
/* 178 */     ps.println(" -preserveDTDs                    /* DTDs & entity references */");
/*     */     
/* 180 */     ps.println();
/* 181 */     ps.println(" -bytePacked");
/* 182 */     ps.println(" -preCompression");
/* 183 */     ps.println(" -compression");
/* 184 */     ps.println();
/* 185 */     ps.println(" -blockSize <value>");
/* 186 */     ps.println(" -valueMaxLength <value>");
/* 187 */     ps.println(" -valuePartitionCapacity <value>");
/* 188 */     ps.println();
/* 189 */     ps.println(" -noLocalValuePartitions          /* EXI Profile parameters */");
/*     */     
/* 191 */     ps.println(" -maximumNumberOfBuiltInProductions <value>");
/* 192 */     ps.println(" -maximumNumberOfBuiltInElementGrammars <value>");
/*     */     
/* 194 */     ps.println();
/* 195 */     ps.println(" -includeOptions");
/* 196 */     ps.println(" -includeCookie");
/* 197 */     ps.println(" -includeSchemaId");
/* 198 */     ps.println(" -includeSchemaLocation");
/* 199 */     ps.println(" -includeInsignificantXsiNil");
/* 200 */     ps.println(" -includeProfileValues");
/* 201 */     ps.println(" -retainEntityReference");
/* 202 */     ps.println(" -fragment");
/* 203 */     ps.println(" -selfContained <{urn:foo}elWithNS,elDefNS>");
/* 204 */     ps.println(" -datatypeRepresentationMap <qnameType,qnameRepresentation,{http://www.w3.org/2001/XMLSchema}decimal,{http://www.w3.org/2009/exi}string>");
/*     */ 
/*     */ 
/*     */     
/* 208 */     ps.println();
/* 209 */     ps.println("# Examples");
/* 210 */     ps.println(" " + ENCODE + " " + SCHEMA + " notebook.xsd " + "-i" + " notebook.xml");
/*     */     
/* 212 */     ps.println(" " + DECODE + " " + SCHEMA + " notebook.xsd " + "-i" + " notebook.xml.exi " + "-o" + " notebookDec.xml");
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void printError(String msg) {
/* 217 */     ps.println("[ERROR] " + msg);
/*     */   }
/*     */   
/*     */   protected static void printWarning(String msg) {
/* 221 */     ps.println("[Warning] " + msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parseArguments(String[] args) throws EXIException {
/* 226 */     this.cmdOption = null;
/* 227 */     SchemaOption schemaOption = SchemaOption.noSchema;
/* 228 */     String schemaLocation = null;
/*     */     
/* 230 */     this.input = null;
/* 231 */     this.output = null;
/*     */     
/* 233 */     this.exiFactory = DefaultEXIFactory.newInstance();
/*     */ 
/*     */     
/* 236 */     boolean wIncludeOptions = false;
/* 237 */     boolean wIncludeSchemaId = false;
/* 238 */     boolean wIncludeProfileValues = false;
/* 239 */     boolean wStrict = false;
/* 240 */     boolean wPreserveComments = false;
/* 241 */     boolean wPreservePIs = false;
/* 242 */     boolean wPreservePrefixes = false;
/* 243 */     boolean wPreserveDTD = false;
/*     */     
/* 245 */     int indexArgument = 0;
/* 246 */     while (indexArgument < args.length) {
/* 247 */       String argument = args[indexArgument];
/*     */ 
/*     */       
/* 250 */       if ("-h".equalsIgnoreCase(argument)) {
/* 251 */         printHelp();
/*     */         
/*     */         break;
/*     */       } 
/* 255 */       if (ENCODE.equalsIgnoreCase(argument)) {
/* 256 */         this.cmdOption = CmdOption.encode;
/* 257 */       } else if (DECODE.equalsIgnoreCase(argument)) {
/* 258 */         this.cmdOption = CmdOption.decode;
/*     */       
/*     */       }
/* 261 */       else if ("-i".equalsIgnoreCase(argument)) {
/* 262 */         assert indexArgument + 1 < args.length;
/* 263 */         indexArgument++;
/*     */         
/* 265 */         this.input = args[indexArgument];
/* 266 */       } else if ("-o".equalsIgnoreCase(argument)) {
/* 267 */         assert indexArgument + 1 < args.length;
/* 268 */         indexArgument++;
/*     */         
/* 270 */         this.output = args[indexArgument];
/*     */       
/*     */       }
/* 273 */       else if (NO_SCHEMA.equalsIgnoreCase(argument)) {
/*     */         
/* 275 */         schemaOption = SchemaOption.noSchema;
/* 276 */       } else if (XSD_SCHEMA.equalsIgnoreCase(argument)) {
/*     */         
/* 278 */         schemaOption = SchemaOption.xsdSchema;
/* 279 */       } else if (SCHEMA.equalsIgnoreCase(argument)) {
/*     */         
/* 281 */         schemaOption = SchemaOption.schema;
/*     */         
/* 283 */         assert indexArgument + 1 < args.length;
/* 284 */         indexArgument++;
/*     */         
/* 286 */         schemaLocation = args[indexArgument];
/*     */       
/*     */       }
/* 289 */       else if ("-strict".equalsIgnoreCase(argument)) {
/* 290 */         wStrict = true;
/* 291 */         FidelityOptions fo = FidelityOptions.createStrict();
/* 292 */         this.exiFactory.setFidelityOptions(fo);
/* 293 */       } else if ("-blockSize".equalsIgnoreCase(argument)) {
/* 294 */         assert indexArgument + 1 < args.length;
/* 295 */         indexArgument++;
/* 296 */         int blockSize = Integer.parseInt(args[indexArgument]);
/* 297 */         this.exiFactory.setBlockSize(blockSize);
/* 298 */       } else if ("-valueMaxLength".equalsIgnoreCase(argument)) {
/* 299 */         assert indexArgument + 1 < args.length;
/* 300 */         indexArgument++;
/* 301 */         int valueMaxLength = Integer.parseInt(args[indexArgument]);
/* 302 */         this.exiFactory.setValueMaxLength(valueMaxLength);
/* 303 */       } else if ("-valuePartitionCapacity".equalsIgnoreCase(argument)) {
/* 304 */         assert indexArgument + 1 < args.length;
/* 305 */         indexArgument++;
/*     */         
/* 307 */         int valuePartitionCapacity = Integer.parseInt(args[indexArgument]);
/* 308 */         this.exiFactory.setValuePartitionCapacity(valuePartitionCapacity);
/* 309 */       } else if ("-maximumNumberOfBuiltInElementGrammars"
/* 310 */         .equalsIgnoreCase(argument)) {
/* 311 */         assert indexArgument + 1 < args.length;
/* 312 */         indexArgument++;
/*     */ 
/*     */         
/* 315 */         int maximumNumberOfEvolvingBuiltInElementGrammars = Integer.parseInt(args[indexArgument]);
/* 316 */         this.exiFactory
/* 317 */           .setMaximumNumberOfBuiltInElementGrammars(maximumNumberOfEvolvingBuiltInElementGrammars);
/* 318 */       } else if ("-maximumNumberOfBuiltInProductions"
/* 319 */         .equalsIgnoreCase(argument)) {
/* 320 */         assert indexArgument + 1 < args.length;
/* 321 */         indexArgument++;
/*     */ 
/*     */         
/* 324 */         int maximumNumberOfBuiltInProductions = Integer.parseInt(args[indexArgument]);
/* 325 */         this.exiFactory
/* 326 */           .setMaximumNumberOfBuiltInProductions(maximumNumberOfBuiltInProductions);
/*     */       
/*     */       }
/* 329 */       else if ("-preserveComments".equalsIgnoreCase(argument)) {
/* 330 */         FidelityOptions fo = this.exiFactory.getFidelityOptions();
/* 331 */         fo.setFidelity("PRESERVE_COMMENTS", wPreserveComments = true);
/*     */ 
/*     */       
/*     */       }
/* 335 */       else if ("-preserveLexicalValues".equalsIgnoreCase(argument)) {
/* 336 */         FidelityOptions fo = this.exiFactory.getFidelityOptions();
/* 337 */         fo.setFidelity("PRESERVE_LEXICAL_VALUES", true);
/*     */       
/*     */       }
/* 340 */       else if ("-preservePrefixes".equalsIgnoreCase(argument)) {
/* 341 */         FidelityOptions fo = this.exiFactory.getFidelityOptions();
/* 342 */         fo.setFidelity("PRESERVE_PREFIXES", wPreservePrefixes = true);
/*     */ 
/*     */       
/*     */       }
/* 346 */       else if ("-preservePIs".equalsIgnoreCase(argument)) {
/* 347 */         FidelityOptions fo = this.exiFactory.getFidelityOptions();
/* 348 */         fo.setFidelity("PRESERVE_PIS", wPreservePIs = true);
/*     */       
/*     */       }
/* 351 */       else if ("-preserveDTDs".equalsIgnoreCase(argument)) {
/* 352 */         FidelityOptions fo = this.exiFactory.getFidelityOptions();
/* 353 */         fo.setFidelity("PRESERVE_DTDS", wPreserveDTD = true);
/*     */       
/*     */       }
/* 356 */       else if ("-bytePacked".equalsIgnoreCase(argument)) {
/* 357 */         this.exiFactory.setCodingMode(CodingMode.BYTE_PACKED);
/*     */       
/*     */       }
/* 360 */       else if ("-preCompression".equalsIgnoreCase(argument)) {
/* 361 */         this.exiFactory.setCodingMode(CodingMode.PRE_COMPRESSION);
/*     */       
/*     */       }
/* 364 */       else if ("-compression".equalsIgnoreCase(argument)) {
/* 365 */         this.exiFactory.setCodingMode(CodingMode.COMPRESSION);
/*     */       
/*     */       }
/* 368 */       else if ("-noLocalValuePartitions".equalsIgnoreCase(argument)) {
/* 369 */         this.exiFactory.setLocalValuePartitions(false);
/*     */       
/*     */       }
/* 372 */       else if ("-includeOptions".equalsIgnoreCase(argument)) {
/* 373 */         wIncludeOptions = true;
/* 374 */         this.exiFactory.getEncodingOptions().setOption("INCLUDE_OPTIONS");
/*     */ 
/*     */       
/*     */       }
/* 378 */       else if ("-includeCookie".equalsIgnoreCase(argument)) {
/* 379 */         this.exiFactory.getEncodingOptions().setOption("INCLUDE_COOKIE");
/*     */ 
/*     */       
/*     */       }
/* 383 */       else if ("-includeSchemaId".equalsIgnoreCase(argument)) {
/* 384 */         wIncludeSchemaId = true;
/* 385 */         this.exiFactory.getEncodingOptions().setOption("INCLUDE_SCHEMA_ID");
/*     */ 
/*     */       
/*     */       }
/* 389 */       else if ("-includeSchemaLocation".equalsIgnoreCase(argument)) {
/* 390 */         this.exiFactory.getEncodingOptions().setOption("INCLUDE_XSI_SCHEMALOCATION");
/*     */ 
/*     */       
/*     */       }
/* 394 */       else if ("-includeInsignificantXsiNil".equalsIgnoreCase(argument)) {
/* 395 */         this.exiFactory.getEncodingOptions().setOption("INCLUDE_INSIGNIFICANT_XSI_NIL");
/*     */ 
/*     */       
/*     */       }
/* 399 */       else if ("-includeProfileValues".equalsIgnoreCase(argument)) {
/* 400 */         wIncludeProfileValues = true;
/* 401 */         this.exiFactory.getEncodingOptions().setOption("INCLUDE_PROFILE_VALUES");
/*     */ 
/*     */       
/*     */       }
/* 405 */       else if ("-retainEntityReference".equalsIgnoreCase(argument)) {
/* 406 */         this.exiFactory.getEncodingOptions().setOption("KEEP_ENTITY_REFERENCES_UNRESOLVED");
/*     */ 
/*     */       
/*     */       }
/* 410 */       else if ("-fragment".equalsIgnoreCase(argument)) {
/* 411 */         this.exiFactory.setFragment(true);
/*     */       
/*     */       }
/* 414 */       else if ("-selfContained".equalsIgnoreCase(argument)) {
/* 415 */         assert indexArgument + 1 < args.length;
/* 416 */         indexArgument++;
/*     */         
/* 418 */         String qnames = args[indexArgument];
/* 419 */         StringTokenizer st = new StringTokenizer(qnames, ",");
/* 420 */         QName[] scElements = new QName[st.countTokens()];
/* 421 */         int i = 0;
/* 422 */         while (st.hasMoreTokens()) {
/* 423 */           scElements[i++] = QName.valueOf(st.nextToken());
/*     */         }
/* 425 */         this.exiFactory.setSelfContainedElements(scElements);
/* 426 */         this.exiFactory.getFidelityOptions().setFidelity("SELF_CONTAINED", true);
/*     */ 
/*     */       
/*     */       }
/* 430 */       else if ("-datatypeRepresentationMap".equalsIgnoreCase(argument)) {
/* 431 */         assert indexArgument + 1 < args.length;
/* 432 */         indexArgument++;
/*     */         
/* 434 */         String dtrs = args[indexArgument];
/* 435 */         StringTokenizer st = new StringTokenizer(dtrs, ",");
/*     */         
/* 437 */         assert st.countTokens() % 2 == 0;
/* 438 */         QName[] dtrMapTypes = new QName[st.countTokens() / 2];
/* 439 */         QName[] dtrMapRepresentations = new QName[st.countTokens() / 2];
/*     */         
/* 441 */         int i = 0;
/* 442 */         while (st.hasMoreTokens()) {
/* 443 */           dtrMapTypes[i] = QName.valueOf(st.nextToken());
/* 444 */           dtrMapRepresentations[i] = QName.valueOf(st.nextToken());
/* 445 */           i++;
/*     */         } 
/* 447 */         this.exiFactory.setDatatypeRepresentationMap(dtrMapTypes, dtrMapRepresentations);
/*     */       } else {
/*     */         
/* 450 */         System.out.println("Unknown option '" + argument + "'");
/*     */       } 
/*     */       
/* 453 */       indexArgument++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 459 */     if (wIncludeSchemaId && !wIncludeOptions) {
/* 460 */       printWarning("-includeSchemaId ignored because -includeOptions not set");
/*     */     }
/*     */     
/* 463 */     if (wIncludeProfileValues && !wIncludeOptions) {
/* 464 */       printWarning("-includeProfileValues ignored because -includeOptions not set");
/*     */     }
/*     */ 
/*     */     
/* 468 */     if (this.exiFactory.getFidelityOptions().isStrict()) {
/* 469 */       if (wPreserveComments) {
/* 470 */         printWarning("-preserveComments ignored because -strict is set");
/*     */       }
/*     */       
/* 473 */       if (wPreservePIs) {
/* 474 */         printWarning("-preservePIs ignored because -strict is set");
/*     */       }
/*     */       
/* 477 */       if (wPreserveDTD) {
/* 478 */         printWarning("-preserveDTDs ignored because -strict is set");
/*     */       }
/*     */       
/* 481 */       if (wPreservePrefixes) {
/* 482 */         printWarning("-preservePrefixes ignored because -strict is set");
/*     */       
/*     */       }
/*     */     }
/* 486 */     else if (wStrict) {
/* 487 */       printWarning("-strict ignored because a preserveOption is set");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 495 */     this.inputParametersOK = true;
/*     */     
/* 497 */     if (this.cmdOption == null) {
/* 498 */       this.inputParametersOK = false;
/* 499 */       printError("Missing coding option such as " + ENCODE + " and " + DECODE);
/*     */     } 
/*     */ 
/*     */     
/* 503 */     if (this.input == null) {
/* 504 */       this.inputParametersOK = false;
/* 505 */       printError("Missing option -i");
/* 506 */     } else if (!(new File(this.input)).exists()) {
/* 507 */       this.inputParametersOK = false;
/* 508 */       printError("Not existing input parameter -i, \"" + this.input + "\"");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 513 */     if (this.input != null && this.output == null)
/*     */     {
/* 515 */       if (CmdOption.encode == this.cmdOption) {
/* 516 */         this.output = this.input + DEFAULT_EXI_FILE_EXTENSION;
/*     */       } else {
/* 518 */         this.output = this.input + DEFAULT_XML_FILE_EXTENSION;
/*     */       } 
/*     */     }
/*     */     
/* 522 */     File fOutput = null;
/* 523 */     if (this.output == null) {
/* 524 */       this.inputParametersOK = false;
/* 525 */       printError("Missing output specification!");
/*     */     } else {
/* 527 */       fOutput = new File(this.output);
/*     */       
/* 529 */       if (fOutput.isDirectory()) {
/* 530 */         this.inputParametersOK = false;
/* 531 */         printError("Outputfile '" + this.output + "' is unexpectedly a directory");
/*     */       
/*     */       }
/* 534 */       else if (fOutput.exists()) {
/* 535 */         if (!fOutput.delete()) {
/* 536 */           this.inputParametersOK = false;
/* 537 */           printError("Existing outputfile '" + this.output + "' could not be deleted.");
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 542 */         assert !fOutput.exists();
/* 543 */         File parentDir = fOutput.getParentFile();
/* 544 */         if (parentDir != null && !parentDir.exists() && 
/* 545 */           !parentDir.mkdirs()) {
/* 546 */           this.inputParametersOK = false;
/* 547 */           printError("Output directories for file '" + this.output + "' could not be created.");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 555 */     if (this.inputParametersOK)
/*     */     {
/* 557 */       if (SchemaOption.noSchema != schemaOption)
/*     */       {
/*     */         
/* 560 */         if (SchemaOption.xsdSchema == schemaOption) {
/* 561 */           GrammarFactory gf = GrammarFactory.newInstance();
/* 562 */           this.exiFactory.setGrammars(gf.createXSDTypesOnlyGrammars());
/*     */         } else {
/* 564 */           GrammarFactory gf = GrammarFactory.newInstance();
/* 565 */           this.exiFactory.setGrammars(gf.createGrammars(schemaLocation));
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void process() throws EXIException, TransformerException, IOException, SAXException {
/* 572 */     if (this.inputParametersOK) {
/*     */       
/* 574 */       switch (this.cmdOption) {
/*     */         case decode:
/* 576 */           decode(this.input, this.exiFactory, this.output);
/*     */           return;
/*     */         case encode:
/* 579 */           encode(this.input, this.exiFactory, this.output);
/*     */           return;
/*     */       } 
/* 582 */       printError("Unexptected command option " + this.cmdOption);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 589 */       printError("Input parameters were incorrect");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 595 */     if (args == null || args.length == 0) {
/*     */       
/* 597 */       printHelp();
/*     */     } else {
/* 599 */       EXIficientCMD cmd = new EXIficientCMD();
/*     */       try {
/* 601 */         cmd.parseArguments(args);
/* 602 */         cmd.process();
/* 603 */       } catch (Exception e) {
/* 604 */         printError(e.getLocalizedMessage() + e.getClass());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decode(String input, EXIFactory exiFactory, String output) throws EXIException, TransformerException, IOException {
/* 611 */     OutputStream xmlOutput = new FileOutputStream(output);
/*     */     
/* 613 */     TransformerFactory tf = TransformerFactory.newInstance();
/* 614 */     Transformer transformer = tf.newTransformer();
/* 615 */     SAXSource exiSource = new SAXSource(new InputSource(new FileInputStream(input)));
/*     */     
/* 617 */     exiSource.setXMLReader((new SAXFactory(exiFactory)).createEXIReader());
/*     */     
/* 619 */     if (exiFactory.isFragment()) {
/* 620 */       transformer.setOutputProperty("omit-xml-declaration", "yes");
/*     */     }
/*     */ 
/*     */     
/* 624 */     transformer.transform(exiSource, new StreamResult(xmlOutput));
/*     */     
/* 626 */     xmlOutput.flush();
/* 627 */     xmlOutput.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLReader getXMLReader() throws SAXException {
/* 636 */     XMLReader xmlReader = XMLReaderFactory.createXMLReader();
/*     */ 
/*     */     
/* 639 */     xmlReader.setFeature("http://xml.org/sax/features/namespaces", true);
/*     */     
/* 641 */     xmlReader.setFeature("http://xml.org/sax/features/namespace-prefixes", false);
/*     */ 
/*     */     
/* 644 */     xmlReader.setFeature("http://xml.org/sax/features/validation", false);
/*     */     
/* 646 */     xmlReader.setFeature("http://xml.org/sax/features/resolve-dtd-uris", false);
/*     */ 
/*     */     
/* 649 */     xmlReader.setEntityResolver((EntityResolver)new NoEntityResolver());
/*     */     
/* 651 */     return xmlReader;
/*     */   }
/*     */   protected void encode(String input, EXIFactory exiFactory, String output) throws SAXException, EXIException, IOException {
/*     */     SkipRootElementXMLReader skipRootElementXMLReader;
/*     */     InputSource is;
/* 656 */     OutputStream os = new FileOutputStream(output);
/*     */     
/* 658 */     XMLReader xmlReader = getXMLReader();
/*     */     
/* 660 */     EXIResult exiResult = new EXIResult(exiFactory);
/* 661 */     exiResult.setOutputStream(os);
/*     */     
/* 663 */     xmlReader.setContentHandler(exiResult.getHandler());
/*     */ 
/*     */     
/* 666 */     xmlReader.setProperty("http://xml.org/sax/properties/lexical-handler", exiResult
/* 667 */         .getLexicalHandler());
/*     */     
/* 669 */     xmlReader.setProperty("http://xml.org/sax/properties/declaration-handler", exiResult
/*     */         
/* 671 */         .getLexicalHandler());
/*     */     
/* 673 */     xmlReader.setDTDHandler((DTDHandler)exiResult.getHandler());
/*     */ 
/*     */     
/* 676 */     if (exiFactory.isFragment()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 683 */       is = new InputSource(FragmentUtilities.getSurroundingRootInputStream(new FileInputStream(input)));
/*     */ 
/*     */       
/* 686 */       skipRootElementXMLReader = new SkipRootElementXMLReader(xmlReader);
/*     */     } else {
/* 688 */       is = new InputSource(input);
/*     */     } 
/*     */     
/* 691 */     skipRootElementXMLReader.parse(is);
/*     */     
/* 693 */     os.flush();
/* 694 */     os.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\cmd\EXIficientCMD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */