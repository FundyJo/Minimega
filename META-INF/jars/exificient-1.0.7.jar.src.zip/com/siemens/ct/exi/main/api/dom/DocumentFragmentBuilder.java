/*    */ package com.siemens.ct.exi.main.api.dom;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.DocumentFragment;
/*    */ import org.w3c.dom.Node;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocumentFragmentBuilder
/*    */ {
/*    */   protected DocumentBuilder docBuilder;
/*    */   
/*    */   public DocumentFragmentBuilder(DocumentBuilder docBuilder) {
/* 51 */     this.docBuilder = docBuilder;
/*    */   }
/*    */   
/*    */   public DocumentBuilder getDocumentBuilder() {
/* 55 */     return this.docBuilder;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DocumentFragment parse(InputStream is) throws SAXException, IOException {
/* 61 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 62 */     baos.write("<fragment>".getBytes());
/*    */     
/*    */     int b;
/* 65 */     while ((b = is.read()) != -1) {
/* 66 */       baos.write(b);
/*    */     }
/*    */     
/* 69 */     baos.write("</fragment>".getBytes());
/*    */ 
/*    */     
/* 72 */     Document doc = this.docBuilder.parse(new ByteArrayInputStream(baos
/* 73 */           .toByteArray()));
/*    */ 
/*    */ 
/*    */     
/* 77 */     Node node = doc.importNode(doc.getDocumentElement(), true);
/*    */ 
/*    */     
/* 80 */     DocumentFragment docfrag = doc.createDocumentFragment();
/*    */ 
/*    */     
/* 83 */     while (node.hasChildNodes()) {
/* 84 */       docfrag.appendChild(node.removeChild(node.getFirstChild()));
/*    */     }
/*    */ 
/*    */     
/* 88 */     return docfrag;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\dom\DocumentFragmentBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */