/*     */ package com.siemens.ct.exi.main.api.stream;
/*     */ 
/*     */ import com.siemens.ct.exi.core.EXIBodyDecoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EXIStreamDecoder;
/*     */ import com.siemens.ct.exi.core.SchemaIdResolver;
/*     */ import com.siemens.ct.exi.core.container.DocType;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.container.ProcessingInstruction;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import com.siemens.ct.exi.main.helpers.DefaultSchemaIdResolver;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StAXDecoder
/*     */   implements XMLStreamReader
/*     */ {
/*     */   protected EXIFactory noOptionsFactory;
/*     */   protected EXIStreamDecoder exiStream;
/*     */   protected EXIBodyDecoder decoder;
/*     */   protected boolean exiBodyOnly = false;
/*     */   protected QNameContext element;
/*     */   protected List<AttributeContainer> attributes;
/*     */   protected Value characters;
/*     */   protected DocType docType;
/*     */   protected char[] entityReference;
/*     */   protected char[] comment;
/*     */   protected ProcessingInstruction processingInstruction;
/*     */   protected boolean namespacePrefixes = false;
/*     */   protected EventType eventType;
/*     */   protected EventType preReadEventType;
/*     */   protected EXINamespaceContext nsContext;
/*     */   String endElementPrefix;
/*     */   List<NamespaceDeclaration> eePrefixes;
/*     */   
/*     */   static class AttributeContainer
/*     */   {
/*     */     final QNameContext qname;
/*     */     final Value value;
/*     */     final String prefix;
/*     */     
/*     */     public AttributeContainer(QNameContext qname, Value value, String prefix) {
/*  97 */       this.qname = qname;
/*  98 */       this.value = value;
/*  99 */       this.prefix = prefix;
/*     */     }
/*     */   }
/*     */   
/*     */   public StAXDecoder(EXIFactory noOptionsFactory) throws EXIException {
/* 104 */     this.noOptionsFactory = noOptionsFactory;
/* 105 */     if (noOptionsFactory.getSchemaIdResolver() == null)
/*     */     {
/* 107 */       noOptionsFactory.setSchemaIdResolver((SchemaIdResolver)new DefaultSchemaIdResolver());
/*     */     }
/* 109 */     this.exiStream = noOptionsFactory.createEXIStreamDecoder();
/* 110 */     this.attributes = new ArrayList<>();
/* 111 */     this.nsContext = new EXINamespaceContext();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInputStream(InputStream is) throws EXIException, IOException, XMLStreamException {
/* 117 */     parseHeader(is);
/*     */   }
/*     */   
/*     */   protected void initForEachRun() {
/* 121 */     this.eventType = null;
/* 122 */     this.preReadEventType = null;
/* 123 */     this.attributes.clear();
/*     */     
/* 125 */     if (this.noOptionsFactory.getFidelityOptions().isFidelityEnabled("PRESERVE_PREFIXES"))
/*     */     {
/* 127 */       this.namespacePrefixes = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parseHeader(InputStream is) throws EXIException, IOException, XMLStreamException {
/* 133 */     assert is != null;
/* 134 */     assert this.exiStream != null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     if (this.exiBodyOnly) {
/*     */       
/* 142 */       this.decoder = this.exiStream.getBodyOnlyDecoder(is);
/*     */     } else {
/*     */       
/* 145 */       this.decoder = this.exiStream.decodeHeader(is);
/*     */     } 
/*     */ 
/*     */     
/* 149 */     initForEachRun();
/*     */     
/* 151 */     this.eventType = this.decoder.next();
/* 152 */     assert this.eventType == EventType.START_DOCUMENT;
/* 153 */     this.decoder.decodeStartDocument();
/*     */   }
/*     */   
/*     */   public int getEventType() {
/* 157 */     return getEventType(this.eventType);
/*     */   }
/*     */   
/*     */   protected static int getEventType(EventType eventType) {
/* 161 */     assert eventType != null;
/* 162 */     switch (eventType) {
/*     */       case START_DOCUMENT:
/* 164 */         return 7;
/*     */       case ATTRIBUTE_XSI_TYPE:
/*     */       case ATTRIBUTE_XSI_NIL:
/*     */       case ATTRIBUTE:
/*     */       case ATTRIBUTE_NS:
/*     */       case ATTRIBUTE_GENERIC:
/*     */       case ATTRIBUTE_INVALID_VALUE:
/*     */       case ATTRIBUTE_ANY_INVALID_VALUE:
/*     */       case ATTRIBUTE_GENERIC_UNDECLARED:
/* 173 */         return 10;
/*     */       case START_ELEMENT:
/*     */       case START_ELEMENT_NS:
/*     */       case START_ELEMENT_GENERIC:
/*     */       case START_ELEMENT_GENERIC_UNDECLARED:
/* 178 */         return 1;
/*     */       case END_ELEMENT:
/*     */       case END_ELEMENT_UNDECLARED:
/* 181 */         return 2;
/*     */       case CHARACTERS:
/*     */       case CHARACTERS_GENERIC:
/*     */       case CHARACTERS_GENERIC_UNDECLARED:
/* 185 */         return 4;
/*     */       case END_DOCUMENT:
/* 187 */         return 8;
/*     */       case DOC_TYPE:
/* 189 */         return 11;
/*     */       case NAMESPACE_DECLARATION:
/* 191 */         return 13;
/*     */       
/*     */       case SELF_CONTAINED:
/* 194 */         return -1;
/*     */       case ENTITY_REFERENCE:
/* 196 */         return 9;
/*     */       case COMMENT:
/* 198 */         return 5;
/*     */       case PROCESSING_INSTRUCTION:
/* 200 */         return 3;
/*     */     } 
/* 202 */     throw new RuntimeException("Unexpected EXI Event '" + eventType + "' ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int next() throws XMLStreamException {
/*     */     try {
/* 210 */       if (this.eventType == EventType.END_ELEMENT || this.eventType == EventType.END_ELEMENT_UNDECLARED)
/*     */       {
/* 212 */         this.nsContext.popNamespaceDeclarations();
/*     */       }
/*     */ 
/*     */       
/* 216 */       if (this.preReadEventType == null) {
/* 217 */         this.eventType = decodeEvent(this.decoder.next());
/*     */       } else {
/* 219 */         this.eventType = this.preReadEventType;
/* 220 */         this.preReadEventType = null;
/* 221 */         decodeEvent(this.eventType);
/*     */       } 
/*     */       
/* 224 */       int ev = getEventType();
/* 225 */       if (ev == 1) {
/* 226 */         handleAttributes();
/*     */       }
/*     */       
/* 229 */       return ev;
/* 230 */     } catch (Exception e) {
/* 231 */       throw new XMLStreamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EventType decodeEvent(EventType nextEventType) throws EXIException, IOException {
/* 242 */     this.endElementPrefix = null;
/*     */     
/* 244 */     switch (nextEventType) {
/*     */       
/*     */       case START_DOCUMENT:
/* 247 */         this.decoder.decodeStartDocument();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 327 */         return nextEventType;case END_DOCUMENT: this.decoder.decodeEndDocument(); return nextEventType;case ATTRIBUTE_XSI_NIL: this.attributes.add(new AttributeContainer(this.decoder.decodeAttributeXsiNil(), this.decoder.getAttributeValue(), this.decoder.getAttributePrefix())); return nextEventType;case ATTRIBUTE_XSI_TYPE: this.attributes.add(new AttributeContainer(this.decoder.decodeAttributeXsiType(), this.decoder.getAttributeValue(), this.decoder.getAttributePrefix())); return nextEventType;case ATTRIBUTE: case ATTRIBUTE_NS: case ATTRIBUTE_GENERIC: case ATTRIBUTE_INVALID_VALUE: case ATTRIBUTE_ANY_INVALID_VALUE: case ATTRIBUTE_GENERIC_UNDECLARED: this.attributes.add(new AttributeContainer(this.decoder.decodeAttribute(), this.decoder.getAttributeValue(), this.decoder.getAttributePrefix())); return nextEventType;case NAMESPACE_DECLARATION: this.decoder.decodeNamespaceDeclaration(); return nextEventType;case SELF_CONTAINED: this.decoder.decodeStartSelfContainedFragment(); return nextEventType;case START_ELEMENT: case START_ELEMENT_NS: case START_ELEMENT_GENERIC: case START_ELEMENT_GENERIC_UNDECLARED: this.element = this.decoder.decodeStartElement(); return nextEventType;case END_ELEMENT: case END_ELEMENT_UNDECLARED: this.eePrefixes = this.decoder.getDeclaredPrefixDeclarations(); this.endElementPrefix = this.decoder.getElementPrefix(); this.element = this.decoder.decodeEndElement(); return nextEventType;case CHARACTERS: case CHARACTERS_GENERIC: case CHARACTERS_GENERIC_UNDECLARED: this.characters = this.decoder.decodeCharacters(); return nextEventType;case DOC_TYPE: this.docType = this.decoder.decodeDocType(); return nextEventType;case ENTITY_REFERENCE: this.entityReference = this.decoder.decodeEntityReference(); return nextEventType;case COMMENT: this.comment = this.decoder.decodeComment(); return nextEventType;case PROCESSING_INSTRUCTION: this.processingInstruction = this.decoder.decodeProcessingInstruction(); return nextEventType;
/*     */     } 
/*     */     throw new RuntimeException("Unexpected EXI Event '" + this.eventType + "' ");
/*     */   } public void close() throws XMLStreamException {}
/*     */   protected void handleAttributes() throws EXIException, IOException {
/*     */     int ev;
/*     */     EventType et;
/* 334 */     assert getEventType() == 1;
/* 335 */     this.attributes.clear();
/*     */ 
/*     */     
/*     */     do {
/* 339 */       et = this.decoder.next();
/* 340 */       ev = getEventType(et);
/* 341 */       if (et != EventType.SELF_CONTAINED && ev != 10 && ev != 13) {
/*     */         continue;
/*     */       }
/* 344 */       decodeEvent(et);
/*     */     }
/* 346 */     while (et == EventType.SELF_CONTAINED || ev == 10 || ev == 13);
/*     */ 
/*     */ 
/*     */     
/* 350 */     List<NamespaceDeclaration> nsDecls = getNamespaceDeclarations();
/* 351 */     this.nsContext.pushNamespaceDeclarations(nsDecls);
/*     */     
/* 353 */     this.preReadEventType = et;
/*     */   }
/*     */   
/*     */   public int getAttributeCount() {
/* 357 */     return this.attributes.size();
/*     */   }
/*     */   
/*     */   public String getAttributeLocalName(int index) {
/* 361 */     return ((AttributeContainer)this.attributes.get(index)).qname.getLocalName();
/*     */   }
/*     */   
/*     */   public QName getAttributeName(int index) {
/* 365 */     return ((AttributeContainer)this.attributes.get(index)).qname.getQName();
/*     */   }
/*     */   
/*     */   public String getAttributeNamespace(int index) {
/* 369 */     return ((AttributeContainer)this.attributes.get(index)).qname.getNamespaceUri();
/*     */   }
/*     */   
/*     */   public String getAttributePrefix(int index) {
/* 373 */     return ((AttributeContainer)this.attributes.get(index)).prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttributeType(int index) {
/* 379 */     return "CDATA";
/*     */   }
/*     */   
/*     */   public String getAttributeValue(int index) {
/* 383 */     return ((AttributeContainer)this.attributes.get(index)).value.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttributeValue(String namespaceURI, String localName) {
/* 390 */     for (AttributeContainer ac : this.attributes) {
/* 391 */       if (ac.qname.getLocalName().equals(localName)) {
/* 392 */         if (namespaceURI == null)
/* 393 */           return ac.value.toString(); 
/* 394 */         if (ac.qname.getNamespaceUri().equals(namespaceURI)) {
/* 395 */           return ac.value.toString();
/*     */         }
/*     */       } 
/*     */     } 
/* 399 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharacterEncodingScheme() {
/* 405 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementText() throws XMLStreamException {
/* 410 */     if (getEventType() != 1) {
/* 411 */       throw new XMLStreamException("parser must be on START_ELEMENT to read next text", 
/* 412 */           getLocation());
/*     */     }
/* 414 */     int eventType = next();
/* 415 */     StringBuffer buf = new StringBuffer();
/* 416 */     while (eventType != 2) {
/* 417 */       if (eventType == 4 || eventType == 12 || eventType == 6 || eventType == 9) {
/*     */ 
/*     */ 
/*     */         
/* 421 */         buf.append(getText());
/* 422 */       } else if (eventType != 3 && eventType != 5) {
/*     */ 
/*     */         
/* 425 */         if (eventType == 8)
/* 426 */           throw new XMLStreamException("unexpected end of document when reading element text content"); 
/* 427 */         if (eventType == 1) {
/* 428 */           throw new XMLStreamException("element text content may not contain START_ELEMENT", 
/* 429 */               getLocation());
/*     */         }
/* 431 */         throw new XMLStreamException("Unexpected event type " + eventType, 
/* 432 */             getLocation());
/*     */       } 
/* 434 */       eventType = next();
/*     */     } 
/* 436 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 442 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalName() {
/* 447 */     return this.element.getLocalName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/* 452 */     return EmptyLocation.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getName() {
/* 465 */     QName qn = new QName(this.element.getNamespaceUri(), this.element.getLocalName(), getPrefix());
/* 466 */     return qn;
/*     */   }
/*     */   
/*     */   List<NamespaceDeclaration> getNamespaceDeclarations() {
/*     */     List<NamespaceDeclaration> result;
/* 471 */     if (this.eventType == EventType.END_ELEMENT || this.eventType == EventType.END_ELEMENT_UNDECLARED) {
/*     */       
/* 473 */       result = this.eePrefixes;
/*     */     } else {
/* 475 */       result = this.decoder.getDeclaredPrefixDeclarations();
/*     */     } 
/* 477 */     return (result != null) ? result : 
/* 478 */       Collections.<NamespaceDeclaration>emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceContext getNamespaceContext() {
/* 490 */     return this.nsContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNamespaceCount() {
/* 503 */     List<NamespaceDeclaration> nsDecls = getNamespaceDeclarations();
/* 504 */     return (nsDecls == null) ? 0 : nsDecls.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespacePrefix(int index) {
/* 515 */     return ((NamespaceDeclaration)getNamespaceDeclarations().get(index)).prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespaceURI(int index) {
/* 526 */     return ((NamespaceDeclaration)getNamespaceDeclarations().get(index)).namespaceURI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespaceURI(String prefix) {
/* 537 */     List<NamespaceDeclaration> nsDecls = getNamespaceDeclarations();
/* 538 */     for (int i = 0; i < nsDecls.size(); i++) {
/* 539 */       NamespaceDeclaration nsDecl = nsDecls.get(i);
/* 540 */       if (nsDecl.prefix.equals(prefix)) {
/* 541 */         return nsDecl.namespaceURI;
/*     */       }
/*     */     } 
/* 544 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespaceURI() {
/* 558 */     return this.element.getNamespaceUri();
/*     */   }
/*     */   
/*     */   public String getPIData() {
/* 562 */     return this.processingInstruction.data;
/*     */   }
/*     */   
/*     */   public String getPITarget() {
/* 566 */     return this.processingInstruction.target;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/* 570 */     if (this.endElementPrefix != null) {
/* 571 */       return this.endElementPrefix;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 576 */     if (getEventType() == 1 || 
/* 577 */       getEventType() == 2) {
/* 578 */       return this.decoder.getElementPrefix();
/*     */     }
/* 580 */     assert getEventType() == 10;
/* 581 */     return this.decoder.getAttributePrefix();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String arg0) throws IllegalArgumentException {
/* 588 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 598 */     switch (getEventType()) {
/*     */       case 4:
/*     */       case 6:
/* 601 */         return this.characters.toString();
/*     */       case 5:
/* 603 */         return new String(this.comment);
/*     */       case 9:
/* 605 */         return new String(this.entityReference);
/*     */       case 11:
/* 607 */         return getDocTypeString();
/*     */     } 
/* 609 */     throw new RuntimeException("Unexpected event, id=" + getEventType());
/*     */   }
/*     */ 
/*     */   
/*     */   private String getDocTypeString() {
/* 614 */     StringBuilder sb = new StringBuilder();
/* 615 */     sb.append("<!DOCTYPE ");
/* 616 */     sb.append(this.docType.name);
/*     */     
/* 618 */     if (this.docType.publicID.length > 0) {
/* 619 */       sb.append(" PUBLIC ");
/* 620 */       sb.append('"');
/* 621 */       sb.append(this.docType.publicID);
/* 622 */       sb.append('"');
/*     */     } 
/* 624 */     if (this.docType.systemID.length > 0) {
/* 625 */       if (this.docType.publicID.length == 0) {
/* 626 */         sb.append(" SYSTEM ");
/*     */       } else {
/* 628 */         sb.append(' ');
/*     */       } 
/* 630 */       sb.append('"');
/* 631 */       sb.append(this.docType.systemID);
/* 632 */       sb.append('"');
/*     */     } 
/* 634 */     if (this.docType.text.length > 0) {
/* 635 */       sb.append(' ');
/* 636 */       sb.append('[');
/* 637 */       sb.append(this.docType.text);
/* 638 */       sb.append(']');
/*     */     } 
/* 640 */     sb.append('>');
/*     */     
/* 642 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getTextCharacters() {
/* 647 */     switch (getEventType()) {
/*     */       case 4:
/*     */       case 6:
/* 650 */         return this.characters.toString().toCharArray();
/*     */       case 5:
/* 652 */         return this.comment;
/*     */       case 9:
/* 654 */         return this.entityReference;
/*     */       case 11:
/* 656 */         return getDocTypeString().toCharArray();
/*     */     } 
/* 658 */     throw new RuntimeException("Unexpected event, id=" + getEventType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextCharacters(int sourceStart, char[] target, int targetStart, int length) throws XMLStreamException {
/*     */     char[] dt;
/* 686 */     if (getTextLength() > target.length - targetStart) {
/* 687 */       throw new RuntimeException("Buffer too small!");
/*     */     }
/*     */     
/* 690 */     switch (getEventType()) {
/*     */       case 4:
/*     */       case 6:
/* 693 */         this.characters.getCharacters(target, targetStart);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 701 */         return length;
/*     */       case 5:
/* 703 */         System.arraycopy(this.comment, sourceStart, target, targetStart, length);
/*     */         
/* 705 */         return length;
/*     */       case 9:
/* 707 */         System.arraycopy(this.entityReference, sourceStart, target, targetStart, length);
/*     */         
/* 709 */         return length;
/*     */       case 11:
/* 711 */         dt = getDocTypeString().toCharArray();
/* 712 */         System.arraycopy(dt, sourceStart, target, targetStart, length);
/* 713 */         return length;
/*     */     } 
/* 715 */     throw new RuntimeException("Unexpected event, id=" + getEventType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextLength() {
/* 723 */     switch (getEventType()) {
/*     */       case 4:
/*     */       case 6:
/* 726 */         return this.characters.getCharactersLength();
/*     */       case 5:
/* 728 */         return this.comment.length;
/*     */       case 9:
/* 730 */         return this.entityReference.length;
/*     */     } 
/* 732 */     throw new RuntimeException("Unexpected event, id=" + getEventType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextStart() {
/* 739 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVersion() {
/* 745 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasName() {
/* 749 */     switch (getEventType()) {
/*     */       case 1:
/*     */       case 10:
/* 752 */         return true;
/*     */     } 
/* 754 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() throws XMLStreamException {
/* 759 */     return (this.eventType != EventType.END_DOCUMENT);
/*     */   }
/*     */   
/*     */   public boolean hasText() {
/* 763 */     switch (getEventType()) {
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */       case 12:
/* 768 */         return true;
/*     */     } 
/* 770 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAttributeSpecified(int arg0) {
/* 783 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isCharacters() {
/* 787 */     return (getEventType() == 4);
/*     */   }
/*     */   
/*     */   public boolean isEndElement() {
/* 791 */     return (getEventType() == 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStandalone() {
/* 802 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isStartElement() {
/* 806 */     return (getEventType() == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWhiteSpace() {
/* 818 */     switch (getEventType()) {
/*     */       case 4:
/* 820 */         return (this.characters.toString().trim().length() == 0);
/*     */       case 12:
/* 822 */         return false;
/*     */       case 5:
/* 824 */         return false;
/*     */       case 6:
/* 826 */         return true;
/*     */     } 
/* 828 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nextTag() throws XMLStreamException {
/* 844 */     int eventType = next();
/* 845 */     while ((eventType == 4 && isWhiteSpace()) || (eventType == 12 && 
/*     */       
/* 847 */       isWhiteSpace()) || eventType == 6 || eventType == 3 || eventType == 5)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 852 */       eventType = next();
/*     */     }
/* 854 */     if (eventType != 1 && eventType != 2)
/*     */     {
/* 856 */       throw new XMLStreamException("expected start or end tag", 
/* 857 */           getLocation());
/*     */     }
/* 859 */     return eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void require(int type, String namespaceURI, String localName) throws XMLStreamException {
/* 876 */     int eventType = getEventType();
/*     */     
/* 878 */     if (eventType == type) {
/* 879 */       switch (eventType) {
/*     */         case 1:
/* 881 */           if (namespaceURI != null && 
/* 882 */             !this.element.getNamespaceUri().equals(namespaceURI)) {
/* 883 */             throw new XMLStreamException();
/*     */           }
/*     */           
/* 886 */           if (localName != null && 
/* 887 */             !this.element.getLocalName().equals(localName)) {
/* 888 */             throw new XMLStreamException();
/*     */           }
/*     */           break;
/*     */ 
/*     */         
/*     */         case 10:
/* 894 */           throw new XMLStreamException();
/*     */       } 
/*     */     } else {
/* 897 */       throw new XMLStreamException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean standaloneSet() {
/* 903 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class EXINamespaceContext
/*     */     implements NamespaceContext
/*     */   {
/* 914 */     List<List<NamespaceDeclaration>> _nsDecls = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void pushNamespaceDeclarations(List<NamespaceDeclaration> nsDecls) {
/* 934 */       this._nsDecls.add(nsDecls);
/*     */     }
/*     */     
/*     */     protected List<NamespaceDeclaration> popNamespaceDeclarations() {
/* 938 */       return this._nsDecls.remove(this._nsDecls.size() - 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getNamespaceURI(String prefix) {
/* 943 */       for (int k = this._nsDecls.size() - 1; k >= 0; k--) {
/* 944 */         List<NamespaceDeclaration> nsDecls = this._nsDecls.get(k);
/* 945 */         if (nsDecls != null) {
/* 946 */           for (int i = 0; i < nsDecls.size(); i++) {
/* 947 */             NamespaceDeclaration nsDecl = nsDecls.get(i);
/* 948 */             if (nsDecl.prefix.equals(prefix)) {
/* 949 */               return nsDecl.namespaceURI;
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 955 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPrefix(String namespaceURI) {
/* 960 */       for (int k = this._nsDecls.size() - 1; k >= 0; k--) {
/* 961 */         List<NamespaceDeclaration> nsDecls = this._nsDecls.get(k);
/* 962 */         if (nsDecls != null) {
/* 963 */           for (int i = 0; i < nsDecls.size(); i++) {
/* 964 */             NamespaceDeclaration nsDecl = nsDecls.get(i);
/* 965 */             if (nsDecl.namespaceURI.equals(namespaceURI)) {
/* 966 */               return nsDecl.prefix;
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 972 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator getPrefixes(String namespaceURI) {
/* 977 */       List<String> prefixes = new ArrayList<>();
/*     */       
/* 979 */       for (int k = this._nsDecls.size() - 1; k >= 0; k--) {
/* 980 */         List<NamespaceDeclaration> nsDecls = this._nsDecls.get(k);
/* 981 */         if (nsDecls != null) {
/* 982 */           for (int i = 0; i < nsDecls.size(); i++) {
/* 983 */             NamespaceDeclaration nsDecl = nsDecls.get(i);
/* 984 */             if (nsDecl.namespaceURI.equals(namespaceURI)) {
/* 985 */               prefixes.add(nsDecl.prefix);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 991 */       return prefixes.iterator();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\stream\StAXDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */