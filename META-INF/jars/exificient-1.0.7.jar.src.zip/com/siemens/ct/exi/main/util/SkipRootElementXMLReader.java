/*    */ package com.siemens.ct.exi.main.util;
/*    */ 
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.XMLReader;
/*    */ import org.xml.sax.helpers.XMLFilterImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SkipRootElementXMLReader
/*    */   extends XMLFilterImpl
/*    */ {
/* 39 */   private int openElement = 0;
/*    */   
/*    */   public SkipRootElementXMLReader(XMLReader parent) {
/* 42 */     super(parent);
/*    */     
/* 44 */     setContentHandler(parent.getContentHandler());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
/* 50 */     if (this.openElement > 0) {
/* 51 */       super.startElement(uri, localName, qName, atts);
/*    */     }
/*    */     
/* 54 */     this.openElement++;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void endElement(String uri, String localName, String qName) throws SAXException {
/* 60 */     this.openElement--;
/*    */     
/* 62 */     if (this.openElement > 0)
/* 63 */       super.endElement(uri, localName, qName); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\mai\\util\SkipRootElementXMLReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */