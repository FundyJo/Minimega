/*     */ package com.siemens.ct.exi.main.api.sax;
/*     */ 
/*     */ import com.siemens.ct.exi.core.Constants;
/*     */ import com.siemens.ct.exi.core.EXIBodyDecoder;
/*     */ import com.siemens.ct.exi.core.EXIFactory;
/*     */ import com.siemens.ct.exi.core.EXIStreamDecoder;
/*     */ import com.siemens.ct.exi.core.SchemaIdResolver;
/*     */ import com.siemens.ct.exi.core.container.DocType;
/*     */ import com.siemens.ct.exi.core.container.NamespaceDeclaration;
/*     */ import com.siemens.ct.exi.core.container.ProcessingInstruction;
/*     */ import com.siemens.ct.exi.core.context.QNameContext;
/*     */ import com.siemens.ct.exi.core.exceptions.EXIException;
/*     */ import com.siemens.ct.exi.core.grammars.event.EventType;
/*     */ import com.siemens.ct.exi.core.values.ListValue;
/*     */ import com.siemens.ct.exi.core.values.Value;
/*     */ import com.siemens.ct.exi.core.values.ValueType;
/*     */ import com.siemens.ct.exi.main.helpers.DefaultSchemaIdResolver;
/*     */ import com.siemens.ct.exi.main.util.NoEntityResolver;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.List;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.DTDHandler;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXNotSupportedException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.ext.DeclHandler;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAXDecoder
/*     */   implements XMLReader
/*     */ {
/*     */   protected EXIFactory noOptionsFactory;
/*     */   protected EXIStreamDecoder exiStream;
/*     */   protected ContentHandler contentHandler;
/*     */   protected DTDHandler dtdHandler;
/*     */   protected LexicalHandler lexicalHandler;
/*     */   protected DeclHandler declHandler;
/*     */   protected ErrorHandler errorHandler;
/*     */   protected static final String ATTRIBUTE_TYPE = "CDATA";
/*     */   protected static final int DEFAULT_CHAR_BUFFER_SIZE = 4096;
/*     */   protected char[] cbuffer;
/*     */   protected boolean namespaces = true;
/*     */   protected boolean namespacePrefixes = false;
/*     */   protected boolean exiBodyOnly = false;
/*     */   protected StringBuilder sbHelper;
/*     */   
/*     */   protected SAXDecoder(EXIFactory noOptionsFactory, char[] cbuffer) throws EXIException {
/*  96 */     this.noOptionsFactory = noOptionsFactory;
/*  97 */     if (noOptionsFactory.getSchemaIdResolver() == null)
/*     */     {
/*  99 */       noOptionsFactory.setSchemaIdResolver((SchemaIdResolver)new DefaultSchemaIdResolver());
/*     */     }
/* 101 */     this.exiStream = noOptionsFactory.createEXIStreamDecoder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     if (noOptionsFactory.getFidelityOptions().isFidelityEnabled("PRESERVE_PREFIXES"))
/*     */     {
/* 112 */       this.namespacePrefixes = true;
/*     */     }
/* 114 */     this.cbuffer = cbuffer;
/*     */   }
/*     */   
/*     */   public SAXDecoder(EXIFactory noOptionsFactory) throws EXIException {
/* 118 */     this(noOptionsFactory, new char[4096]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContentHandler(ContentHandler handler) {
/* 125 */     this.contentHandler = handler;
/*     */   }
/*     */   
/*     */   public ContentHandler getContentHandler() {
/* 129 */     return this.contentHandler;
/*     */   }
/*     */   
/*     */   public void setDTDHandler(DTDHandler handler) {
/* 133 */     this.dtdHandler = handler;
/*     */   }
/*     */   
/*     */   public DTDHandler getDTDHandler() {
/* 137 */     return this.dtdHandler;
/*     */   }
/*     */   
/*     */   public EntityResolver getEntityResolver() {
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEntityResolver(EntityResolver resolver) {}
/*     */ 
/*     */   
/*     */   public void setErrorHandler(ErrorHandler handler) {
/* 149 */     this.errorHandler = handler;
/*     */   }
/*     */   
/*     */   public ErrorHandler getErrorHandler() {
/* 153 */     return this.errorHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFeature(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
/* 163 */     if ("http://xml.org/sax/features/namespaces".equals(name))
/* 164 */       return this.namespaces; 
/* 165 */     if ("http://xml.org/sax/features/namespace-prefixes"
/* 166 */       .equals(name)) {
/* 167 */       return this.namespacePrefixes;
/*     */     }
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFeature(String name, boolean value) throws SAXNotRecognizedException, SAXNotSupportedException {
/* 175 */     if ("http://xml.org/sax/features/namespaces".equals(name)) {
/*     */       
/* 177 */       this.namespaces = value;
/* 178 */     } else if ("http://xml.org/sax/features/namespace-prefixes"
/* 179 */       .equals(name)) {
/* 180 */       this.namespacePrefixes = value;
/* 181 */     } else if ("http://www.w3.org/exi/features/exi-body-only".equals(name)) {
/* 182 */       this.exiBodyOnly = value;
/*     */     } else {
/* 184 */       throw new SAXNotRecognizedException(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) throws SAXNotRecognizedException, SAXNotSupportedException {
/* 190 */     if ("http://xml.org/sax/properties/lexical-handler".equals(name)) {
/* 191 */       this.lexicalHandler = (LexicalHandler)value;
/* 192 */     } else if ("http://xml.org/sax/properties/declaration-handler"
/* 193 */       .equals(name)) {
/* 194 */       this.declHandler = (DeclHandler)value;
/*     */     } else {
/* 196 */       throw new SAXNotRecognizedException(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws SAXNotRecognizedException, SAXNotSupportedException {
/* 202 */     if ("http://xml.org/sax/properties/lexical-handler".equals(name))
/* 203 */       return this.lexicalHandler; 
/* 204 */     if ("http://xml.org/sax/properties/declaration-handler"
/* 205 */       .equals(name)) {
/* 206 */       return this.declHandler;
/*     */     }
/* 208 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void parse(String systemId) throws IOException, SAXException {
/* 213 */     FileInputStream fis = new FileInputStream(systemId);
/* 214 */     InputSource is = new InputSource(fis);
/* 215 */     parse(is);
/*     */   }
/*     */   
/*     */   public void parse(InputSource inputSource) throws IOException, SAXException {
/* 219 */     assert inputSource != null;
/* 220 */     assert this.exiStream != null;
/*     */     
/* 222 */     if (this.contentHandler == null) {
/* 223 */       throw new SAXException("No content handler set!");
/*     */     }
/*     */     
/*     */     try {
/*     */       EXIBodyDecoder decoder;
/* 228 */       InputStream is = inputSource.getByteStream();
/*     */ 
/*     */       
/* 231 */       if (is == null && inputSource.getSystemId() != null) {
/* 232 */         is = new FileInputStream(inputSource.getSystemId());
/*     */       }
/* 234 */       if (is == null) {
/* 235 */         throw new EXIException("No valid input source " + is);
/*     */       }
/*     */ 
/*     */       
/* 239 */       if (this.exiBodyOnly) {
/*     */         
/* 241 */         decoder = this.exiStream.getBodyOnlyDecoder(is);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 246 */         decoder = this.exiStream.decodeHeader(is);
/*     */       } 
/*     */ 
/*     */       
/* 250 */       parseEXIEvents(decoder);
/*     */     }
/* 252 */     catch (EXIException e) {
/* 253 */       throw new SAXException("EXI " + e.getLocalizedMessage(), e);
/* 254 */     } catch (IllegalArgumentException i) {
/*     */ 
/*     */       
/* 257 */       throw new SAXException("Error decoding EXI file: " + i.getLocalizedMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseEXIEvents(EXIBodyDecoder decoder) throws IOException, EXIException, SAXException {
/* 266 */     QNameContext deferredStartElement = null;
/* 267 */     boolean isStartElementDeferred = false;
/* 268 */     AttributesImpl attributes = new AttributesImpl();
/*     */     EventType eventType;
/* 270 */     while ((eventType = decoder.next()) != null) {
/*     */       List<NamespaceDeclaration> eePrefixes; String eeQNameAsString; QNameContext eeQName; Value val; char[] chars; ListValue lv; ProcessingInstruction pi; Value[] values; int slen;
/* 272 */       switch (eventType) {
/*     */         
/*     */         case START_DOCUMENT:
/* 275 */           decoder.decodeStartDocument();
/* 276 */           this.contentHandler.startDocument();
/*     */           continue;
/*     */         case END_DOCUMENT:
/* 279 */           decoder.decodeEndDocument();
/* 280 */           this.contentHandler.endDocument();
/*     */           continue;
/*     */         
/*     */         case ATTRIBUTE_XSI_NIL:
/* 284 */           handleAttribute(decoder, decoder.decodeAttributeXsiNil(), attributes);
/*     */           continue;
/*     */         case ATTRIBUTE_XSI_TYPE:
/* 287 */           handleAttribute(decoder, decoder.decodeAttributeXsiType(), attributes);
/*     */           continue;
/*     */         case ATTRIBUTE:
/*     */         case ATTRIBUTE_NS:
/*     */         case ATTRIBUTE_GENERIC:
/*     */         case ATTRIBUTE_GENERIC_UNDECLARED:
/*     */         case ATTRIBUTE_INVALID_VALUE:
/*     */         case ATTRIBUTE_ANY_INVALID_VALUE:
/* 295 */           handleAttribute(decoder, decoder.decodeAttribute(), attributes);
/*     */           continue;
/*     */ 
/*     */         
/*     */         case NAMESPACE_DECLARATION:
/* 300 */           decoder.decodeNamespaceDeclaration();
/*     */           continue;
/*     */         
/*     */         case SELF_CONTAINED:
/* 304 */           decoder.decodeStartSelfContainedFragment();
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case START_ELEMENT:
/*     */         case START_ELEMENT_NS:
/*     */         case START_ELEMENT_GENERIC:
/*     */         case START_ELEMENT_GENERIC_UNDECLARED:
/* 313 */           if (isStartElementDeferred) {
/* 314 */             handleDeferredStartElement(decoder, deferredStartElement, attributes);
/*     */           }
/*     */           
/* 317 */           deferredStartElement = decoder.decodeStartElement();
/* 318 */           isStartElementDeferred = true;
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case END_ELEMENT:
/*     */         case END_ELEMENT_UNDECLARED:
/* 325 */           if (isStartElementDeferred) {
/* 326 */             handleDeferredStartElement(decoder, deferredStartElement, attributes);
/* 327 */             isStartElementDeferred = false;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 338 */           eePrefixes = null;
/* 339 */           if (this.namespaces) {
/* 340 */             eePrefixes = decoder.getDeclaredPrefixDeclarations();
/*     */           }
/* 342 */           eeQNameAsString = decoder.getElementQNameAsString();
/*     */           
/* 344 */           eeQName = decoder.decodeEndElement();
/*     */           
/* 346 */           this.contentHandler.endElement(eeQName.getNamespaceUri(), eeQName
/* 347 */               .getLocalName(), eeQNameAsString);
/*     */ 
/*     */           
/* 350 */           if (this.namespaces && eePrefixes != null) {
/* 351 */             for (int i = 0; i < eePrefixes.size(); i++) {
/* 352 */               NamespaceDeclaration ns = eePrefixes.get(i);
/* 353 */               this.contentHandler.endPrefixMapping(ns.prefix);
/*     */             } 
/*     */           }
/*     */           continue;
/*     */ 
/*     */         
/*     */         case CHARACTERS:
/*     */         case CHARACTERS_GENERIC:
/*     */         case CHARACTERS_GENERIC_UNDECLARED:
/* 362 */           if (isStartElementDeferred) {
/* 363 */             handleDeferredStartElement(decoder, deferredStartElement, attributes);
/* 364 */             isStartElementDeferred = false;
/*     */           } 
/*     */           
/* 367 */           val = decoder.decodeCharacters();
/*     */ 
/*     */           
/* 370 */           switch (val.getValueType()) {
/*     */             case START_DOCUMENT:
/*     */             case END_DOCUMENT:
/* 373 */               chars = val.getCharacters();
/* 374 */               this.contentHandler.characters(chars, 0, chars.length);
/*     */               continue;
/*     */             case ATTRIBUTE_XSI_NIL:
/* 377 */               lv = (ListValue)val;
/* 378 */               values = lv.toValues();
/*     */               
/* 380 */               if (values.length > 0) {
/* 381 */                 ValueType vt = values[0].getValueType();
/*     */ 
/*     */                 
/* 384 */                 for (int i = 0; i < values.length; i++) {
/* 385 */                   int len, offset; Value val2 = values[i];
/* 386 */                   switch (vt) {
/*     */                     case START_DOCUMENT:
/*     */                     case END_DOCUMENT:
/* 389 */                       chars = val2.getCharacters();
/* 390 */                       this.contentHandler.characters(chars, 0, chars.length);
/*     */                       
/* 392 */                       this.contentHandler
/* 393 */                         .characters(Constants.XSD_LIST_DELIM_CHAR_ARRAY, 0, Constants.XSD_LIST_DELIM_CHAR_ARRAY.length);
/*     */                       break;
/*     */ 
/*     */ 
/*     */                     
/*     */                     default:
/* 399 */                       offset = 0;
/* 400 */                       len = val2.getCharactersLength();
/*     */                       
/* 402 */                       if (this.cbuffer.length < offset + len + 1) {
/* 403 */                         this.contentHandler.characters(this.cbuffer, 0, offset);
/*     */                         
/* 405 */                         offset = 0;
/*     */                       } 
/* 407 */                       val2.getCharacters(this.cbuffer, offset);
/* 408 */                       offset += len;
/* 409 */                       this.cbuffer[offset++] = ' ';
/*     */                       
/* 411 */                       this.contentHandler.characters(this.cbuffer, 0, offset);
/*     */                       break;
/*     */                   } 
/*     */                 
/*     */                 } 
/*     */               } 
/*     */               continue;
/*     */           } 
/* 419 */           slen = val.getCharactersLength();
/* 420 */           ensureBufferCapacity(slen);
/*     */ 
/*     */           
/* 423 */           val.getCharacters(this.cbuffer, 0);
/* 424 */           this.contentHandler.characters(this.cbuffer, 0, slen);
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case DOC_TYPE:
/* 431 */           if (isStartElementDeferred) {
/* 432 */             handleDeferredStartElement(decoder, deferredStartElement, attributes);
/* 433 */             isStartElementDeferred = false;
/*     */           } 
/*     */           
/* 436 */           handleDocType(decoder.decodeDocType());
/*     */           continue;
/*     */         
/*     */         case ENTITY_REFERENCE:
/* 440 */           if (isStartElementDeferred) {
/* 441 */             handleDeferredStartElement(decoder, deferredStartElement, attributes);
/* 442 */             isStartElementDeferred = false;
/*     */           } 
/*     */           
/* 445 */           handleEntityReference(decoder.decodeEntityReference());
/*     */           continue;
/*     */         
/*     */         case COMMENT:
/* 449 */           if (isStartElementDeferred) {
/* 450 */             handleDeferredStartElement(decoder, deferredStartElement, attributes);
/* 451 */             isStartElementDeferred = false;
/*     */           } 
/*     */           
/* 454 */           handleComment(decoder.decodeComment());
/*     */           continue;
/*     */         
/*     */         case PROCESSING_INSTRUCTION:
/* 458 */           if (isStartElementDeferred) {
/* 459 */             handleDeferredStartElement(decoder, deferredStartElement, attributes);
/* 460 */             isStartElementDeferred = false;
/*     */           } 
/*     */ 
/*     */           
/* 464 */           pi = decoder.decodeProcessingInstruction();
/* 465 */           this.contentHandler.processingInstruction(pi.target, pi.data);
/*     */           continue;
/*     */       } 
/* 468 */       throw new RuntimeException("Unexpected EXI Event '" + eventType + "' ");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleDeferredStartElement(EXIBodyDecoder decoder, QNameContext deferredStartElement, AttributesImpl attributes) throws SAXException, IOException, EXIException {
/* 481 */     if (this.namespaces) {
/*     */       
/* 483 */       List<NamespaceDeclaration> prefixes = decoder.getDeclaredPrefixDeclarations();
/* 484 */       if (prefixes != null) {
/* 485 */         for (int i = 0; i < prefixes.size(); i++) {
/* 486 */           NamespaceDeclaration ns = prefixes.get(i);
/* 487 */           this.contentHandler.startPrefixMapping(ns.prefix, ns.namespaceURI);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 509 */     String seQNameAsString = decoder.getElementQNameAsString();
/*     */ 
/*     */     
/* 512 */     this.contentHandler.startElement(deferredStartElement.getNamespaceUri(), deferredStartElement
/* 513 */         .getLocalName(), seQNameAsString, attributes);
/*     */ 
/*     */ 
/*     */     
/* 517 */     attributes.clear();
/*     */   }
/*     */   
/*     */   protected void ensureBufferCapacity(int reqSize) {
/* 521 */     if (reqSize > this.cbuffer.length) {
/* 522 */       int newSize = this.cbuffer.length;
/*     */       
/*     */       do {
/* 525 */         newSize <<= 2;
/* 526 */       } while (newSize < reqSize);
/*     */       
/* 528 */       this.cbuffer = new char[newSize];
/*     */     } 
/*     */   }
/*     */   protected void handleAttribute(EXIBodyDecoder decoder, QNameContext atQName, AttributesImpl attributes) throws SAXException, IOException, EXIException {
/*     */     String sVal;
/*     */     ListValue lv;
/*     */     int slen;
/* 535 */     Value val = decoder.getAttributeValue();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 540 */     switch (val.getValueType()) {
/*     */       case START_DOCUMENT:
/*     */       case END_DOCUMENT:
/* 543 */         sVal = val.toString();
/*     */         break;
/*     */       case ATTRIBUTE_XSI_NIL:
/* 546 */         lv = (ListValue)val;
/*     */         
/* 548 */         if (lv.getNumberOfValues() > 0) {
/* 549 */           if (this.sbHelper == null) {
/* 550 */             this.sbHelper = new StringBuilder();
/*     */           } else {
/* 552 */             this.sbHelper.setLength(0);
/*     */           } 
/*     */           
/* 555 */           Value[] values = lv.toValues();
/* 556 */           ValueType vt = values[0].getValueType();
/* 557 */           for (int i = 0; i < values.length; i++) {
/* 558 */             int j; Value val2 = values[i];
/* 559 */             switch (vt) {
/*     */               case START_DOCUMENT:
/*     */               case END_DOCUMENT:
/* 562 */                 this.sbHelper.append(val2.getCharacters());
/* 563 */                 this.sbHelper.append(' ');
/*     */                 break;
/*     */               default:
/* 566 */                 j = val2.getCharactersLength();
/* 567 */                 ensureBufferCapacity(j);
/* 568 */                 val2.getCharacters(this.cbuffer, 0);
/* 569 */                 this.sbHelper.append(this.cbuffer, 0, j);
/* 570 */                 this.sbHelper.append(' ');
/*     */                 break;
/*     */             } 
/*     */           } 
/* 574 */           sVal = this.sbHelper.toString(); break;
/*     */         } 
/* 576 */         sVal = "";
/*     */         break;
/*     */       
/*     */       default:
/* 580 */         slen = val.getCharactersLength();
/* 581 */         ensureBufferCapacity(slen);
/* 582 */         sVal = val.toString(this.cbuffer, 0);
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 598 */     String atQNameAsString = decoder.getAttributeQNameAsString();
/*     */     
/* 600 */     attributes.addAttribute(atQName.getNamespaceUri(), atQName
/* 601 */         .getLocalName(), atQNameAsString, "CDATA", sVal);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleDocType(DocType docType) throws SAXException, IOException {
/* 606 */     if (this.lexicalHandler != null) {
/*     */       
/* 608 */       String name = new String(docType.name);
/* 609 */       String publicId = (docType.publicID.length == 0) ? null : new String(docType.publicID);
/*     */       
/* 611 */       String systemId = (docType.systemID.length == 0) ? null : new String(docType.systemID);
/*     */ 
/*     */ 
/*     */       
/* 615 */       this.contentHandler.characters(new char[0], 0, 0);
/*     */       
/* 617 */       this.lexicalHandler.startDTD(name, publicId, systemId);
/*     */       
/* 619 */       if (docType.text.length > 0) {
/*     */ 
/*     */ 
/*     */         
/* 623 */         DeclHandler dh = null;
/* 624 */         if (this.declHandler != null) {
/* 625 */           dh = this.declHandler;
/* 626 */         } else if (this.lexicalHandler instanceof DeclHandler) {
/*     */           
/* 628 */           dh = (DeclHandler)this.lexicalHandler;
/*     */         } 
/*     */         
/* 631 */         if (dh != null) {
/* 632 */           DocTypeTextLexicalHandler dttlh = new DocTypeTextLexicalHandler(dh);
/*     */           
/* 634 */           dttlh.parse(docType.text);
/*     */         } 
/*     */       } 
/*     */       
/* 638 */       this.lexicalHandler.endDTD();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleEntityReference(char[] erName) throws SAXException {
/* 644 */     String entityReferenceName = new String(erName);
/* 645 */     this.contentHandler.skippedEntity(entityReferenceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleComment(char[] comment) throws SAXException {
/* 660 */     if (this.lexicalHandler != null)
/*     */     {
/* 662 */       this.lexicalHandler.comment(comment, 0, comment.length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DocTypeTextLexicalHandler
/*     */   {
/*     */     XMLReader xmlReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DocTypeTextLexicalHandler(DeclHandler dh) throws SAXException {
/* 689 */       this.xmlReader = XMLReaderFactory.createXMLReader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 696 */       this.xmlReader.setFeature("http://xml.org/sax/features/resolve-dtd-uris", false);
/*     */ 
/*     */       
/* 699 */       this.xmlReader.setEntityResolver((EntityResolver)new NoEntityResolver());
/*     */       
/* 701 */       this.xmlReader.setProperty("http://xml.org/sax/properties/declaration-handler", dh);
/*     */     }
/*     */ 
/*     */     
/*     */     public void parse(char[] docTypeText) throws IOException, SAXException {
/* 706 */       StringBuilder dt = new StringBuilder();
/*     */       
/* 708 */       dt.append("<!DOCTYPE foo_name [ ");
/* 709 */       dt.append(docTypeText);
/* 710 */       dt.append("]>");
/* 711 */       dt.append("<foo />");
/*     */       
/* 713 */       Reader r = new StringReader(dt.toString());
/* 714 */       this.xmlReader.parse(new InputSource(r));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\exificient-1.0.7.jar!\com\siemens\ct\exi\main\api\sax\SAXDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */