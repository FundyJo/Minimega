/*     */ package dev.jab125.minimega.mod.compat.legacy4j.client;
/*     */ 
/*     */ import dev.jab125.minimega.call.Result;
/*     */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*     */ import dev.jab125.minimega.mod.p2p.matchmaking.obj.leaderboards.GlideMatchRecordObj;
/*     */ import dev.jab125.minimega.mod.p2p.matchmaking.obj.leaderboards.c2s.FetchGlideMatchesObj;
/*     */ import dev.jab125.minimega.mod.p2p.matchmaking.obj.leaderboards.s2c.ReceivedGlideMatchesObj;
/*     */ import dev.jab125.minimega.mod.util.controller.glide.GlideGameType;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import net.minecraft.resources.Identifier;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardPage;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardProvider;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardRequest;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardRow;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GlideLeaderboardProvider
/*     */   implements GlobalLeaderboardProvider
/*     */ {
/*     */   private final GlideGameType type;
/*     */   
/*     */   GlideLeaderboardProvider(GlideGameType type) {
/*  75 */     this.type = type;
/*     */   }
/*     */   
/*     */   public String id() {
/*  79 */     switch (Legacy4JCompatClient.null.$SwitchMap$dev$jab125$minimega$mod$util$controller$glide$GlideGameType[this.type.ordinal()]) { default: throw new MatchException(null, null);
/*     */       case 1: 
/*  81 */       case 2: break; }  return "minimega-" + "score" + "-attack";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletableFuture<GlobalLeaderboardPage> fetch(GlobalLeaderboardRequest globalLeaderboardRequest) {
/*  87 */     Identifier mapId = Identifier.parse(globalLeaderboardRequest.board().id());
/*  88 */     byte b = 20; Identifier identifier1 = mapId; GlideGameType glideGameType = this.type; FetchGlideMatchesObj fetchGlideMatchesObj1 = new FetchGlideMatchesObj(), fetchGlideMatchesObj2 = fetchGlideMatchesObj1; switch (false) {  }
/*  89 */      String cursor = globalLeaderboardRequest.cursor();
/*     */     try {
/*  91 */       int i = Integer.parseInt(cursor);
/*  92 */     } catch (NullPointerException|NumberFormatException nullPointerException) {
/*  93 */       cursor = globalLeaderboardRequest.previousCursor();
/*     */       try {
/*  95 */         int i = Integer.parseInt(cursor);
/*  96 */       } catch (NullPointerException|NumberFormatException nullPointerException1) {
/*  97 */         boolean bool = false;
/*     */       } 
/*     */     } 
/* 100 */     this(glideGameType, identifier1, b, bool, false);
/*     */     CompletableFuture<Result<Optional<ReceivedGlideMatchesObj>, IOException>> leaderboard = MinimegaClient.getLeaderboard(fetchGlideMatchesObj2);
/* 102 */     return leaderboard.thenApply(optionalIOExceptionResult -> (GlobalLeaderboardPage)optionalIOExceptionResult.map(()).opt().orElseGet(()));
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\Legacy4JCompatClient$GlideLeaderboardProvider.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */