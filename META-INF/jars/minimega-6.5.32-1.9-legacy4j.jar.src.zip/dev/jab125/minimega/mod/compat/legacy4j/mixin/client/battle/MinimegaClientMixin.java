/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.battle;
/*    */ 
/*    */ import com.llamalad7.mixinextras.expression.Definition;
/*    */ import com.llamalad7.mixinextras.expression.Expression;
/*    */ import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import java.util.Map;
/*    */ import net.minecraft.client.DeltaTracker;
/*    */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*    */ import net.minecraft.resources.Identifier;
/*    */ import net.minecraft.world.inventory.InventoryMenu;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import wily.legacy.util.LegacySprites;
/*    */ import wily.legacy.util.client.LegacyRenderUtil;
/*    */ 
/*    */ @Mixin({MinimegaClient.class})
/*    */ public class MinimegaClientMixin {
/*    */   @Inject(method = {"renderArmorInHud"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static void renderArmorInHud(GuiGraphicsExtractor context, DeltaTracker deltaTracker, CallbackInfo ci) {
/* 25 */     if (!LegacyRenderUtil.canDisplayHUD()) ci.cancel();
/*    */   
/*    */   }
/*    */   
/*    */   @Unique
/* 30 */   private static final Map<Identifier, Identifier> REPLACEMENTS = Map.of(InventoryMenu.EMPTY_ARMOR_SLOT_HELMET, LegacySprites.HEAD_SLOT, InventoryMenu.EMPTY_ARMOR_SLOT_CHESTPLATE, LegacySprites.CHEST_SLOT, InventoryMenu.EMPTY_ARMOR_SLOT_LEGGINGS, LegacySprites.LEGS_SLOT, InventoryMenu.EMPTY_ARMOR_SLOT_BOOTS, LegacySprites.FEET_SLOT);
/*    */ 
/*    */   
/*    */   @ModifyExpressionValue(method = {"renderArmorInHud"}, at = {@At("MIXINEXTRAS:EXPRESSION")})
/*    */   @Definition(id = "noItemIcon", local = {@Local(type = Identifier.class, name = {"noItemIcon"})})
/*    */   @Expression({"noItemIcon"})
/*    */   private static Identifier textureReplacements(Identifier original) {
/* 37 */     return REPLACEMENTS.getOrDefault(original, original);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\battle\MinimegaClientMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */