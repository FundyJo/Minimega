/*    */ package dev.jab125.minimega.mod.compat.legacy4j.client;
/*    */ 
/*    */ import dev.jab125.minimega.mod.client.extension.MinecraftExtension;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import wily.legacy.client.screen.ControlTooltip;
/*    */ 
/*    */ public class Legacy4JTooltips implements ControlTooltip.Event {
/*    */   public void addControlTooltips(ControlTooltip.Renderer renderer) {
/*    */     // Byte code:
/*    */     //   0: invokestatic getInstance : ()Lnet/minecraft/client/Minecraft;
/*    */     //   3: astore_2
/*    */     //   4: aload_2
/*    */     //   5: getfield level : Lnet/minecraft/client/multiplayer/ClientLevel;
/*    */     //   8: invokestatic getMinigameController : (Lnet/minecraft/world/level/Level;)Ldev/jab125/minimega/mod/util/controller/MinigamesController;
/*    */     //   11: astore_3
/*    */     //   12: aload_3
/*    */     //   13: invokevirtual getActiveMinigame : ()Ldev/jab125/minimega/mod/util/Minigame;
/*    */     //   16: astore #4
/*    */     //   18: aload #4
/*    */     //   20: getstatic dev/jab125/minimega/mod/util/Minigame.GLIDE : Ldev/jab125/minimega/mod/util/Minigame;
/*    */     //   23: if_acmpne -> 228
/*    */     //   26: aload_1
/*    */     //   27: invokestatic getInstance : ()Lnet/minecraft/client/Minecraft;
/*    */     //   30: getfield options : Lnet/minecraft/client/Options;
/*    */     //   33: getfield keyInventory : Lnet/minecraft/client/KeyMapping;
/*    */     //   36: <illegal opcode> get : ()Ljava/util/function/Supplier;
/*    */     //   41: invokevirtual add : (Lnet/minecraft/client/KeyMapping;Ljava/util/function/Supplier;)Lwily/legacy/client/screen/ControlTooltip$Renderer;
/*    */     //   44: pop
/*    */     //   45: aload_3
/*    */     //   46: getstatic dev/jab125/minimega/mod/util/Minigame.GLIDE : Ldev/jab125/minimega/mod/util/Minigame;
/*    */     //   49: invokevirtual getController : (Ldev/jab125/minimega/mod/util/Minigame;)Ldev/jab125/minimega/mod/util/controller/AbstractMinigameController;
/*    */     //   52: checkcast dev/jab125/minimega/mod/util/controller/glide/GlideMinigameController
/*    */     //   55: astore #5
/*    */     //   57: aload #5
/*    */     //   59: ifnonnull -> 63
/*    */     //   62: return
/*    */     //   63: aload #5
/*    */     //   65: invokevirtual getMinigameData : ()Ldev/jab125/minimega/mod/util/minigamedata/MinigameData;
/*    */     //   68: ifnonnull -> 72
/*    */     //   71: return
/*    */     //   72: aload #5
/*    */     //   74: invokevirtual getMinigameData : ()Ldev/jab125/minimega/mod/util/minigamedata/MinigameData;
/*    */     //   77: invokevirtual config : ()Ldev/jab125/minimega/mod/util/minigamedata/MinigameSpecificConfig;
/*    */     //   80: dup
/*    */     //   81: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   84: pop
/*    */     //   85: astore #8
/*    */     //   87: iconst_0
/*    */     //   88: istore #9
/*    */     //   90: aload #8
/*    */     //   92: iload #9
/*    */     //   94: <illegal opcode> typeSwitch : (Ldev/jab125/minimega/mod/util/minigamedata/MinigameSpecificConfig;I)I
/*    */     //   99: lookupswitch default -> 166, 0 -> 116
/*    */     //   116: aload #8
/*    */     //   118: checkcast dev/jab125/minimega/mod/util/minigamedata/GlideConfig
/*    */     //   121: astore #6
/*    */     //   123: aload #6
/*    */     //   125: invokevirtual type : ()Ldev/jab125/minimega/mod/util/controller/glide/GlideGameType;
/*    */     //   128: astore #10
/*    */     //   130: aload #6
/*    */     //   132: invokevirtual solo : ()Z
/*    */     //   135: istore #10
/*    */     //   137: iload #10
/*    */     //   139: istore #11
/*    */     //   141: iconst_1
/*    */     //   142: ifeq -> 152
/*    */     //   145: iload #10
/*    */     //   147: istore #7
/*    */     //   149: goto -> 158
/*    */     //   152: iconst_1
/*    */     //   153: istore #9
/*    */     //   155: goto -> 90
/*    */     //   158: iload #7
/*    */     //   160: ifeq -> 225
/*    */     //   163: goto -> 169
/*    */     //   166: goto -> 225
/*    */     //   169: aload #5
/*    */     //   171: invokevirtual getStage : ()I
/*    */     //   174: iconst_2
/*    */     //   175: if_icmpne -> 225
/*    */     //   178: aload_2
/*    */     //   179: getfield player : Lnet/minecraft/client/player/LocalPlayer;
/*    */     //   182: checkcast dev/jab125/minimega/mod/extension/EntityExtension
/*    */     //   185: invokeinterface mm$finishedMap : ()Z
/*    */     //   190: ifne -> 225
/*    */     //   193: aload_1
/*    */     //   194: getstatic wily/legacy/Legacy4JClient.keyCrafting : Lnet/minecraft/client/KeyMapping;
/*    */     //   197: <illegal opcode> get : ()Ljava/util/function/Supplier;
/*    */     //   202: invokevirtual add : (Lnet/minecraft/client/KeyMapping;Ljava/util/function/Supplier;)Lwily/legacy/client/screen/ControlTooltip$Renderer;
/*    */     //   205: pop
/*    */     //   206: aload_1
/*    */     //   207: invokestatic getInstance : ()Lnet/minecraft/client/Minecraft;
/*    */     //   210: getfield options : Lnet/minecraft/client/Options;
/*    */     //   213: getfield keyDrop : Lnet/minecraft/client/KeyMapping;
/*    */     //   216: <illegal opcode> get : ()Ljava/util/function/Supplier;
/*    */     //   221: invokevirtual add : (Lnet/minecraft/client/KeyMapping;Ljava/util/function/Supplier;)Lwily/legacy/client/screen/ControlTooltip$Renderer;
/*    */     //   224: pop
/*    */     //   225: goto -> 308
/*    */     //   228: aload #4
/*    */     //   230: getstatic dev/jab125/minimega/mod/util/Minigame.LOBBY : Ldev/jab125/minimega/mod/util/Minigame;
/*    */     //   233: if_acmpne -> 308
/*    */     //   236: aload_1
/*    */     //   237: getstatic wily/legacy/Legacy4JClient.keyCrafting : Lnet/minecraft/client/KeyMapping;
/*    */     //   240: <illegal opcode> get : ()Ljava/util/function/Supplier;
/*    */     //   245: invokevirtual add : (Lnet/minecraft/client/KeyMapping;Ljava/util/function/Supplier;)Lwily/legacy/client/screen/ControlTooltip$Renderer;
/*    */     //   248: pop
/*    */     //   249: aload_1
/*    */     //   250: invokestatic getInstance : ()Lnet/minecraft/client/Minecraft;
/*    */     //   253: getfield options : Lnet/minecraft/client/Options;
/*    */     //   256: getfield keyInventory : Lnet/minecraft/client/KeyMapping;
/*    */     //   259: aload_2
/*    */     //   260: <illegal opcode> get : (Lnet/minecraft/client/Minecraft;)Ljava/util/function/Supplier;
/*    */     //   265: invokevirtual add : (Lnet/minecraft/client/KeyMapping;Ljava/util/function/Supplier;)Lwily/legacy/client/screen/ControlTooltip$Renderer;
/*    */     //   268: pop
/*    */     //   269: aload_1
/*    */     //   270: invokestatic getInstance : ()Lnet/minecraft/client/Minecraft;
/*    */     //   273: getfield options : Lnet/minecraft/client/Options;
/*    */     //   276: getfield keyDrop : Lnet/minecraft/client/KeyMapping;
/*    */     //   279: <illegal opcode> get : ()Ljava/util/function/Supplier;
/*    */     //   284: invokevirtual add : (Lnet/minecraft/client/KeyMapping;Ljava/util/function/Supplier;)Lwily/legacy/client/screen/ControlTooltip$Renderer;
/*    */     //   287: pop
/*    */     //   288: goto -> 308
/*    */     //   291: astore #5
/*    */     //   293: new java/lang/MatchException
/*    */     //   296: dup
/*    */     //   297: aload #5
/*    */     //   299: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   302: aload #5
/*    */     //   304: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
/*    */     //   307: athrow
/*    */     //   308: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #17	-> 0
/*    */     //   #18	-> 4
/*    */     //   #19	-> 12
/*    */     //   #20	-> 18
/*    */     //   #21	-> 26
/*    */     //   #22	-> 45
/*    */     //   #23	-> 57
/*    */     //   #24	-> 63
/*    */     //   #25	-> 72
/*    */     //   #26	-> 193
/*    */     //   #27	-> 206
/*    */     //   #29	-> 225
/*    */     //   #30	-> 236
/*    */     //   #31	-> 249
/*    */     //   #32	-> 269
/*    */     //   #25	-> 291
/*    */     //   #34	-> 308
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   149	3	7	solo	Z
/*    */     //   158	8	7	solo	Z
/*    */     //   169	56	7	solo	Z
/*    */     //   57	168	5	controller	Ldev/jab125/minimega/mod/util/controller/glide/GlideMinigameController;
/*    */     //   4	287	2	instance	Lnet/minecraft/client/Minecraft;
/*    */     //   12	279	3	minigameController	Ldev/jab125/minimega/mod/util/controller/MinigamesController;
/*    */     //   18	273	4	activeMinigame	Ldev/jab125/minimega/mod/util/Minigame;
/*    */     //   0	309	0	this	Ldev/jab125/minimega/mod/compat/legacy4j/client/Legacy4JTooltips;
/*    */     //   0	309	1	renderer	Lwily/legacy/client/screen/ControlTooltip$Renderer;
/*    */     //   308	1	2	instance	Lnet/minecraft/client/Minecraft;
/*    */     //   308	1	3	minigameController	Ldev/jab125/minimega/mod/util/controller/MinigamesController;
/*    */     //   308	1	4	activeMinigame	Ldev/jab125/minimega/mod/util/Minigame;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   18	273	4	activeMinigame	Ldev/jab125/minimega/mod/util/Minigame<*>;
/*    */     //   308	1	4	activeMinigame	Ldev/jab125/minimega/mod/util/Minigame<*>;
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   125	128	291	java/lang/Throwable
/*    */     //   132	135	291	java/lang/Throwable
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\Legacy4JTooltips.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */