/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.util.Minigame;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import wily.legacy.client.screen.HostOptionsScreen;
/*    */ 
/*    */ @Mixin({HostOptionsScreen.class})
/*    */ public class HostOptionsScreenMixin {
/*    */   @WrapOperation(method = {"*"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;hasSingleplayerServer()Z")})
/*    */   boolean hasSingleplayerServer(Minecraft instance, Operation<Boolean> original) {
/* 16 */     return (((Boolean)original.call(new Object[] { instance })).booleanValue() && MinimegaClient.getMinigame() == Minigame.NONE);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\HostOptionsScreenMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */