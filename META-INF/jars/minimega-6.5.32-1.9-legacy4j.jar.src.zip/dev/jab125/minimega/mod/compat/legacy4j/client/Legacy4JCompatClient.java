/*     */ package dev.jab125.minimega.mod.compat.legacy4j.client;
/*     */ 
/*     */ import dev.jab125.minimega.call.Result;
/*     */ import dev.jab125.minimega.mod.Minimega;
/*     */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*     */ import dev.jab125.minimega.mod.client.gui.widget.IMapSelectionList;
/*     */ import dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen.LegacyDataScreen;
/*     */ import dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen.LegacyMapSelectionScreen;
/*     */ import dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen.LegacyMinigamesScreen;
/*     */ import dev.jab125.minimega.mod.data.MapInfo;
/*     */ import dev.jab125.minimega.mod.extension.MinecraftServerExtension;
/*     */ import dev.jab125.minimega.mod.p2p.matchmaking.obj.leaderboards.GlideMatchRecordObj;
/*     */ import dev.jab125.minimega.mod.p2p.matchmaking.obj.leaderboards.c2s.FetchGlideMatchesObj;
/*     */ import dev.jab125.minimega.mod.p2p.matchmaking.obj.leaderboards.s2c.ReceivedGlideMatchesObj;
/*     */ import dev.jab125.minimega.mod.party.MinigameParty;
/*     */ import dev.jab125.minimega.mod.util.controller.glide.GlideGameType;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.resources.Identifier;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.level.ServerPlayer;
/*     */ import wily.factoryapi.base.client.UIDefinitionManager;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardBoard;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardColumn;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardIcon;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardPage;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardProvider;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardRequest;
/*     */ import wily.legacy.api.client.leaderboards.GlobalLeaderboardRow;
/*     */ import wily.legacy.api.client.leaderboards.LegacyLeaderboards;
/*     */ import wily.legacy.client.screen.ControlTooltip;
/*     */ import wily.legacy.entity.LegacyPlayerInfo;
/*     */ 
/*     */ 
/*     */ public class Legacy4JCompatClient
/*     */ {
/*     */   public static Legacy4JTooltips tooltips;
/*     */   public static ControlTooltip.Event current;
/*     */   
/*     */   public Legacy4JCompatClient() {
/*  45 */     tooltips = new Legacy4JTooltips();
/*  46 */     UIDefinitionManager.registerNamedUITarget(Minimega.id("legacy_minigames_screen"), LegacyMinigamesScreen.class);
/*  47 */     UIDefinitionManager.registerNamedUITarget(Minimega.id("legacy_map_selection_screen"), LegacyMapSelectionScreen.class);
/*  48 */     UIDefinitionManager.registerNamedUITarget(Minimega.id("legacy_data_screen"), LegacyDataScreen.class);
/*     */     
/*  50 */     ServerPlayerEvents.JOIN.register(player -> {
/*     */           MinecraftServer server = player.level().getServer();
/*     */           
/*     */           if (Minimega.isMinigameServer(server)) {
/*     */             ((MinecraftServerExtension)server).getPartyFromPlayerUUID(player.getUUID()).flatMap(()).ifPresent(());
/*     */           }
/*     */         });
/*  57 */     for (MapInfo leaderboardGlideMap : IMapSelectionList.leaderboardGlideMaps()) {
/*  58 */       LegacyLeaderboards.registerBoard(new GlobalLeaderboardBoard("minimega-time-attack", leaderboardGlideMap.id().toString(), (Component)Component.translatable("minimega.leaderboards.glideTimeAttack").append((Component)Component.literal(" : ")).append(leaderboardGlideMap.displayName()), List.of(new GlobalLeaderboardColumn("time", 
/*  59 */                 (Component)Component.literal("Time"), GlobalLeaderboardIcon.sprite(Minimega.id("time_icon"))))));
/*     */       
/*  61 */       LegacyLeaderboards.registerBoard(new GlobalLeaderboardBoard("minimega-score-attack", leaderboardGlideMap.id().toString(), (Component)Component.translatable("minimega.leaderboards.glideScoreAttack").append((Component)Component.literal(" : ")).append(leaderboardGlideMap.displayName()), List.of(new GlobalLeaderboardColumn("score", 
/*  62 */                 (Component)Component.literal("Score"), GlobalLeaderboardIcon.sprite(Minimega.id("glide/score/1/0"))))));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  67 */     LegacyLeaderboards.registerProvider(new GlideLeaderboardProvider(GlideGameType.TIME_ATTACK));
/*  68 */     LegacyLeaderboards.registerProvider(new GlideLeaderboardProvider(GlideGameType.SCORE_ATTACK));
/*     */   }
/*     */   
/*     */   private static class GlideLeaderboardProvider implements GlobalLeaderboardProvider {
/*     */     private final GlideGameType type;
/*     */     
/*     */     GlideLeaderboardProvider(GlideGameType type) {
/*  75 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String id() {
/*     */       // Byte code:
/*     */       //   0: getstatic dev/jab125/minimega/mod/compat/legacy4j/client/Legacy4JCompatClient$1.$SwitchMap$dev$jab125$minimega$mod$util$controller$glide$GlideGameType : [I
/*     */       //   3: aload_0
/*     */       //   4: getfield type : Ldev/jab125/minimega/mod/util/controller/glide/GlideGameType;
/*     */       //   7: invokevirtual ordinal : ()I
/*     */       //   10: iaload
/*     */       //   11: lookupswitch default -> 36, 1 -> 46, 2 -> 51
/*     */       //   36: new java/lang/MatchException
/*     */       //   39: dup
/*     */       //   40: aconst_null
/*     */       //   41: aconst_null
/*     */       //   42: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */       //   45: athrow
/*     */       //   46: ldc 'time'
/*     */       //   48: goto -> 53
/*     */       //   51: ldc 'score'
/*     */       //   53: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */       //   58: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #79	-> 0
/*     */       //   #80	-> 46
/*     */       //   #81	-> 51
/*     */       //   #79	-> 53
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	59	0	this	Ldev/jab125/minimega/mod/compat/legacy4j/client/Legacy4JCompatClient$GlideLeaderboardProvider;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public CompletableFuture<GlobalLeaderboardPage> fetch(GlobalLeaderboardRequest globalLeaderboardRequest) {
/*  87 */       Identifier mapId = Identifier.parse(globalLeaderboardRequest.board().id());
/*  88 */       byte b = 20; Identifier identifier1 = mapId; GlideGameType glideGameType = this.type; FetchGlideMatchesObj fetchGlideMatchesObj1 = new FetchGlideMatchesObj(), fetchGlideMatchesObj2 = fetchGlideMatchesObj1; switch (false) {  }
/*  89 */        String cursor = globalLeaderboardRequest.cursor();
/*     */       try {
/*  91 */         int i = Integer.parseInt(cursor);
/*  92 */       } catch (NullPointerException|NumberFormatException nullPointerException) {
/*  93 */         cursor = globalLeaderboardRequest.previousCursor();
/*     */         try {
/*  95 */           int i = Integer.parseInt(cursor);
/*  96 */         } catch (NullPointerException|NumberFormatException nullPointerException1) {
/*  97 */           boolean bool = false;
/*     */         } 
/*     */       } 
/* 100 */       this(glideGameType, identifier1, b, bool, false);
/*     */       CompletableFuture<Result<Optional<ReceivedGlideMatchesObj>, IOException>> leaderboard = MinimegaClient.getLeaderboard(fetchGlideMatchesObj2);
/* 102 */       return leaderboard.thenApply(optionalIOExceptionResult -> (GlobalLeaderboardPage)optionalIOExceptionResult.map(()).opt().orElseGet(()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\Legacy4JCompatClient.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */