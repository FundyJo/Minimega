package dev.jab125.minimega.mod.compat.legacy4j;

public class Legacy4JCompat {}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\Legacy4JCompat.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */