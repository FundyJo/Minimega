/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import dev.jab125.minimega.mod.compat.legacy4j.client.Legacy4JCompatClient;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import wily.legacy.client.screen.ControlTooltip;
/*    */ 
/*    */ @Mixin({ControlTooltip.Event.class})
/*    */ public interface ControlTooltipEventMixin {
/*    */   @Inject(method = {"setupControlTooltips"}, at = {@At("HEAD")}, remap = false)
/*    */   private void mm$setupControlTooltips(CallbackInfo ci) {
/* 14 */     Legacy4JCompatClient.current = (ControlTooltip.Event)this;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\ControlTooltipEventMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */