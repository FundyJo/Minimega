/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.glide;
/*    */ 
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.compat.legacy4j.client.Legacy4JCompatClient;
/*    */ import dev.jab125.minimega.mod.util.Minigame;
/*    */ import net.minecraft.client.DeltaTracker;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin(value = {Gui.class}, priority = 899)
/*    */ public class GuiMixin {
/*    */   @Inject(method = {"extractHotbarAndDecorations"}, at = {@At("HEAD")})
/*    */   void ahskdahsjdashdjk(GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
/* 19 */     if (MinimegaClient.getMinigame() == Minigame.LOBBY)
/*    */     {
/* 21 */       if ((Minecraft.getInstance()).screen == null && (Minecraft.getInstance()).level != null)
/* 22 */         Legacy4JCompatClient.tooltips.setupControlTooltips(); 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\glide\GuiMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */