/*    */ package dev.jab125.minimega.mod.compat.legacy4j.client.gui.widget;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.client.gui.Font;
/*    */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*    */ import net.minecraft.client.gui.narration.NarrationElementOutput;
/*    */ import net.minecraft.client.input.InputWithModifiers;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.resources.Identifier;
/*    */ import wily.factoryapi.base.client.FactoryGuiGraphics;
/*    */ import wily.legacy.client.screen.ListButton;
/*    */ import wily.legacy.client.screen.RenderableVList;
/*    */ import wily.legacy.util.client.LegacyRenderUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends ListButton
/*    */ {
/*    */   null(RenderableVList arg0, int arg1, int arg2, int arg3, int arg4, Component arg5) {
/* 55 */     super(arg0, arg1, arg2, arg3, arg4, arg5);
/*    */   }
/*    */   protected void extractContents(GuiGraphicsExtractor guiGraphics, int i, int j, float f) {
/* 58 */     super.extractContents(guiGraphics, i, j, f);
/*    */     
/* 60 */     FactoryGuiGraphics.of(guiGraphics).blitSprite(iconSprite, getX() + 5, getY() + 5, 20, 20);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void renderScrollingString(GuiGraphicsExtractor guiGraphics, Font font, int i, int j) {
/* 65 */     int k = getX() + 35;
/* 66 */     int l = getX() + getWidth();
/* 67 */     LegacyRenderUtil.renderScrollingString(guiGraphics, font, getMessage(), k, getY(), l, getY() + getHeight(), j, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onPress(InputWithModifiers modifiers) {
/* 72 */     onPress.accept(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
/* 77 */     defaultButtonNarrationText(narrationElementOutput);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\gui\widget\MapList$1.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */