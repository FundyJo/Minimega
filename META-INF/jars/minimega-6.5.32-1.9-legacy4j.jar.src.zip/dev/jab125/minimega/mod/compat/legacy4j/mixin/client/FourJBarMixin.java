/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import com.llamalad7.mixinextras.expression.Definition;
/*    */ import com.llamalad7.mixinextras.expression.Definitions;
/*    */ import com.llamalad7.mixinextras.expression.Expression;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import com.mojang.blaze3d.pipeline.RenderPipeline;
/*    */ import dev.jab125.minimega.mod.client.gui.bar.FourJBar;
/*    */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*    */ import net.minecraft.resources.Identifier;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import wily.legacy.util.client.LegacyRenderUtil;
/*    */ 
/*    */ @Mixin({FourJBar.class})
/*    */ public class FourJBarMixin {
/*    */   @WrapOperation(method = {"extractBackground"}, at = {@At("MIXINEXTRAS:EXPRESSION")})
/*    */   @Definitions({@Definition(id = "blitSprite", method = {"Lnet/minecraft/client/gui/GuiGraphicsExtractor;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIIIF)V"}), @Definition(id = "guiGraphics", local = {@Local(type = GuiGraphicsExtractor.class, name = {"guiGraphics"}, argsOnly = true)})})
/*    */   @Expression({"guiGraphics.blitSprite(?,?,?,?,?,?,?)"})
/*    */   void render(GuiGraphicsExtractor instance, RenderPipeline renderPipeline, Identifier resourceLocation, int i, int j, int k, int l, float f, Operation<Void> original) {
/* 23 */     original.call(new Object[] { instance, renderPipeline, resourceLocation, Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(k), Integer.valueOf(l), Float.valueOf(LegacyRenderUtil.getHUDOpacity() * f) });
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\FourJBarMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */