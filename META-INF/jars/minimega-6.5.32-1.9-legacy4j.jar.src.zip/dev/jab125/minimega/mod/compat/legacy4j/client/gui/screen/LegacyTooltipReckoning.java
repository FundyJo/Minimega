/*    */ package dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen;
/*    */ 
/*    */ import java.util.function.BiFunction;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.components.MultiLineLabel;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.util.Util;
/*    */ import wily.legacy.util.client.LegacyFontUtil;
/*    */ 
/*    */ public class LegacyTooltipReckoning {
/*    */   static {
/* 12 */     labelsCache = Util.memoize((c, i) -> MultiLineLabel.create((Minecraft.getInstance()).font, c, i.intValue()));
/* 13 */     sdLabelsCache = Util.memoize((c, i) -> MultiLineLabel.create((Minecraft.getInstance()).font, (Component)c.copy().withStyle(c.getStyle().withFont(LegacyFontUtil.MOJANGLES_11_FONT)), i.intValue()));
/*    */   }
/*    */   
/*    */   public static final BiFunction<Component, Integer, MultiLineLabel> labelsCache;
/*    */   public static final BiFunction<Component, Integer, MultiLineLabel> sdLabelsCache;
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\gui\screen\LegacyTooltipReckoning.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */