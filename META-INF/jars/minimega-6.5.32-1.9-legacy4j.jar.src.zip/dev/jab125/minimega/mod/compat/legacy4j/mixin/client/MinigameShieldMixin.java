/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import com.llamalad7.mixinextras.expression.Definition;
/*    */ import com.llamalad7.mixinextras.expression.Expression;
/*    */ import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import dev.jab125.minimega.mod.client.gui.overlay.MinigameShield;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import wily.legacy.client.LegacyOptions;
/*    */ 
/*    */ @Mixin({MinigameShield.class})
/*    */ public class MinigameShieldMixin {
/*    */   @ModifyExpressionValue(method = {"render"}, at = {@At("MIXINEXTRAS:EXPRESSION")})
/*    */   @Definition(id = "intrinsicScale", local = {@Local(type = float.class, name = {"intrinsicScale"})})
/*    */   @Expression({"intrinsicScale = @(?)"})
/*    */   float render(float original) {
/* 18 */     return Math.max(1.0F, ((Integer)LegacyOptions.hudSize.get()).intValue() / 1.2F);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\MinigameShieldMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */