/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin;
/*    */ 
/*    */ import dev.jab125.minimega.mod.util.controller.MinigamesController;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin(value = {Player.class}, priority = 1500)
/*    */ public abstract class PlayerMixin {
/*    */   @Inject(method = {"@Minimega:InvInit"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void minimega$keepFallFlyingInGlide(CallbackInfo ci) {
/* 14 */     Player player = (Player)this;
/* 15 */     if (MinigamesController.getMinigameController(player.level()).glideActive())
/* 16 */       ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\PlayerMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */