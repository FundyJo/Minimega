/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.takeall;
/*    */ import com.llamalad7.mixinextras.expression.Definition;
/*    */ import com.llamalad7.mixinextras.expression.Definitions;
/*    */ import com.llamalad7.mixinextras.expression.Expression;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.util.Minigame;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.client.KeyMapping;
/*    */ import org.spongepowered.asm.mixin.Dynamic;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import wily.legacy.client.controller.LegacyKeyMapping;
/*    */ import wily.legacy.client.screen.ControlTooltip;
/*    */ 
/*    */ @Mixin({ControlTooltip.GuiManager.class})
/*    */ public class ControlTooltipGuiManagerMixin {
/*    */   @WrapOperation(method = {"applyGUIControlTooltips"}, at = {@At("MIXINEXTRAS:EXPRESSION")})
/*    */   @Dynamic
/*    */   @Definitions({@Definition(id = "keyCrafting", field = {"Lwily/legacy/Legacy4JClient;keyCrafting:Lnet/minecraft/client/KeyMapping;"}), @Definition(id = "add", method = {"Lwily/legacy/client/screen/ControlTooltip$Renderer;add(Lnet/minecraft/client/KeyMapping;)Lwily/legacy/client/screen/ControlTooltip$Renderer;"})})
/*    */   @Expression({"@(?.add(keyCrafting))"})
/*    */   private static ControlTooltip.Renderer setupdefaultcontainerscreen(ControlTooltip.Renderer renderer, KeyMapping crafting, Operation<ControlTooltip.Renderer> operation) {
/* 24 */     Objects.requireNonNull((LegacyKeyMapping)crafting); return renderer.add(() -> (MinimegaClient.getMinigame() == Minigame.BATTLE || MinimegaClient.getMinigame() == Minigame.TUMBLE) ? null : (ControlTooltip.Icon)ControlTooltip.getIconFromKeyMapping((LegacyKeyMapping)crafting), (LegacyKeyMapping)crafting::getDisplayName);
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\takeall\ControlTooltipGuiManagerMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */