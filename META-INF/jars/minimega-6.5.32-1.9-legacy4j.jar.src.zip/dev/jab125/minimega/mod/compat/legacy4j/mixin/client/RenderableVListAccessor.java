package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import wily.legacy.client.screen.RenderableVList;

@Mixin({RenderableVList.class})
public interface RenderableVListAccessor {
  @Accessor
  String getName();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\RenderableVListAccessor.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */