/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import dev.jab125.minimega.mod.Minimega;
/*    */ import dev.jab125.minimega.mod.client.gui.screen.MapTransitionScreen;
/*    */ import dev.jab125.minimega.mod.util.Minigame;
/*    */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import wily.factoryapi.base.client.UIAccessor;
/*    */ import wily.legacy.client.LegacyOptions;
/*    */ import wily.legacy.client.screen.LegacyLoading;
/*    */ import wily.legacy.util.LegacyComponents;
/*    */ 
/*    */ @Mixin({MapTransitionScreen.class})
/*    */ public class LegacyLoadingScreenMixin
/*    */   extends Screen
/*    */   implements LegacyLoading
/*    */ {
/*    */   protected LegacyLoadingScreenMixin(Component component) {
/* 25 */     super(component);
/*    */   }
/*    */   
/*    */   @Unique
/*    */   private Screen self() {
/* 30 */     return this;
/*    */   }
/*    */   
/*    */   @Inject(method = {"extractRenderState"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void extractRenderState(GuiGraphicsExtractor guiGraphicsExtractor, int i, int j, float f, CallbackInfo ci) {
/* 35 */     if (((Boolean)LegacyOptions.legacyLoadingAndConnecting.get()).booleanValue()) {
/* 36 */       ci.cancel();
/* 37 */       MapTransitionScreen loading = (MapTransitionScreen)self();
/*    */       
/* 39 */       Minigame<?> minigame = loading.mapInfo().minigame();
/* 40 */       UIAccessor accessor = (getLoadingRenderer()).accessor;
/* 41 */       int height = this.minecraft.getWindow().getGuiScaledHeight();
/* 42 */       int headerY = Math.round(accessor.getFloat("loadingHeader.y", height / 2.0F - 23.0F));
/* 43 */       int barY = accessor.getInteger("loadingBar.y", height / 2 + 15);
/* 44 */       int stageY = accessor.getInteger("loadingStage.y", barY - 10);
/* 45 */       boolean sd = LegacyOptions.getUIMode().isSD();
/* 46 */       int size = sd ? 32 : 48;
/* 47 */       int titleBottom = accessor.getBoolean("hasTitle", Boolean.valueOf(true)).booleanValue() ? (sd ? 44 : 99) : 0;
/* 48 */       int shift = Math.max(0, titleBottom + size + 10 - headerY);
/* 49 */       headerY += shift;
/* 50 */       accessor.putStaticElement("loadingHeader.y", Integer.valueOf(headerY));
/* 51 */       accessor.putStaticElement("loadingStage.y", Integer.valueOf(stageY + shift));
/* 52 */       accessor.putStaticElement("loadingBar.y", Integer.valueOf(barY + shift));
/* 53 */       accessor.putStaticElement("loadingIcon.sprite", Minimega.id(minigame.tId() + "/" + minigame.tId()));
/* 54 */       accessor.putStaticElement("loadingIcon.width", Integer.valueOf(size));
/*    */       
/* 56 */       Component lastLoadingHeader = null;
/* 57 */       Component lastLoadingStage = null;
/* 58 */       boolean genericLoading = false;
/* 59 */       float progress = 0.0F;
/* 60 */       lastLoadingHeader = loading.mapInfo().displayName();
/* 61 */       lastLoadingStage = LegacyComponents.LOADING_SPAWN_AREA;
/* 62 */       progress = loading.progress();
/* 63 */       getLoadingRenderer().prepareRender(this.minecraft, UIAccessor.of(this), lastLoadingHeader, lastLoadingStage, progress, genericLoading);
/* 64 */       getLoadingRenderer().extractRenderState(guiGraphicsExtractor, i, j, f);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\LegacyLoadingScreenMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */