/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.takeall;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.util.Minigame;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import wily.legacy.Legacy4JClient;
/*    */ import wily.legacy.client.ControlType;
/*    */ import wily.legacy.client.controller.LegacyKeyMapping;
/*    */ import wily.legacy.client.screen.ControlTooltip;
/*    */ import wily.legacy.client.screen.LegacyMenuAccess;
/*    */ import wily.legacy.util.LegacyComponents;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({ControlTooltip.class})
/*    */ public interface ControlTooltipMixin
/*    */ {
/*    */   @WrapMethod(method = {"setupDefaultContainerScreen"}, remap = false)
/*    */   private static ControlTooltip.Renderer setupdefaultcontainerscreen(ControlTooltip.Renderer par1, LegacyMenuAccess<?> a, Operation<ControlTooltip.Renderer> original) {
/* 28 */     ControlTooltip.Renderer call = (ControlTooltip.Renderer)original.call(new Object[] { par1, a });
/* 29 */     call.add(() -> ControlType.getActiveType().isKbm() ? ControlTooltip.getIconFromKeyMapping((LegacyKeyMapping)Legacy4JClient.keyCrafting) : ControlTooltip.getIconFromKeyMapping((LegacyKeyMapping)Legacy4JClient.keyCycleHeldLeft), () -> 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 35 */         (MinimegaClient.getMinigame() == Minigame.BATTLE && a instanceof net.minecraft.client.gui.screens.inventory.ContainerScreen) ? LegacyComponents.TAKE_ALL : null);
/* 36 */     return par1;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\takeall\ControlTooltipMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */