/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.smallinv;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.client.SmallInvConstants;
/*    */ import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
/*    */ import net.minecraft.client.gui.screens.inventory.ContainerScreen;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.world.entity.player.Inventory;
/*    */ import net.minecraft.world.inventory.AbstractContainerMenu;
/*    */ import net.minecraft.world.inventory.Slot;
/*    */ import org.spongepowered.asm.mixin.Dynamic;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import wily.legacy.client.LegacyOptions;
/*    */ import wily.legacy.inventory.LegacySlotDisplay;
/*    */ import wily.legacy.mixin.base.client.AbstractContainerScreenAccessor;
/*    */ 
/*    */ 
/*    */ @Mixin(value = {ContainerScreen.class}, priority = 1100)
/*    */ public abstract class LegacyContainerScreenMixin<T extends AbstractContainerMenu>
/*    */   extends AbstractContainerScreen<T>
/*    */ {
/*    */   public LegacyContainerScreenMixin(T abstractContainerMenu, Inventory inventory, Component component) {
/* 26 */     super((AbstractContainerMenu)abstractContainerMenu, inventory, component);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @WrapOperation(method = {"@Minimega:InvInit"}, at = {@At(value = "INVOKE", target = "wily/legacy/inventory/LegacySlotDisplay.override(Lnet/minecraft/world/inventory/Slot;IILwily/legacy/inventory/LegacySlotDisplay;)Lnet/minecraft/world/inventory/Slot;")})
/*    */   @Dynamic
/*    */   Slot a(Slot slot, int x, int y, LegacySlotDisplay lsd, Operation<Slot> original) {
/* 34 */     if (MinimegaClient.getController().isSmallInventory() && SmallInvConstants.supportsSmallInventory(this) && slot.container instanceof Inventory) {
/* 35 */       if (Inventory.isHotbarSlot(slot.getContainerSlot()))
/* 36 */         return (Slot)original.call(new Object[] { slot, Integer.valueOf(x), Integer.valueOf(y - (LegacyOptions.getUIMode().isSD() ? 45 : 70)), lsd }); 
/* 37 */       if (slot.getContainerSlot() >= 9 && slot.getContainerSlot() < 36)
/* 38 */         return (Slot)original.call(new Object[] { slot, Integer.valueOf(-9999), Integer.valueOf(-9999), lsd }); 
/*    */     } 
/* 40 */     return (Slot)original.call(new Object[] { slot, Integer.valueOf(x), Integer.valueOf(y), lsd });
/*    */   }
/*    */ 
/*    */   
/*    */   @WrapOperation(method = {"@Minimega:InvInit"}, at = {@At(value = "INVOKE", target = "Lwily/legacy/mixin/base/client/AbstractContainerScreenAccessor;legacy$setImageHeight(I)V")})
/*    */   @Dynamic
/*    */   void ih(AbstractContainerScreenAccessor o, int v, Operation<Void> original) {
/* 47 */     if (MinimegaClient.getController().isSmallInventory() && SmallInvConstants.supportsSmallInventory(this))
/* 48 */     { original.call(new Object[] { o, Integer.valueOf(v - (LegacyOptions.getUIMode().isSD() ? 45 : 70)) }); }
/* 49 */     else { original.call(new Object[] { o, Integer.valueOf(v) }); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\smallinv\LegacyContainerScreenMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */