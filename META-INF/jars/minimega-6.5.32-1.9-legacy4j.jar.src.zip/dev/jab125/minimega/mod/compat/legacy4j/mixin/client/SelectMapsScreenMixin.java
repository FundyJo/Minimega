/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import dev.jab125.minimega.mod.client.gui.screen.minigame.SelectMapsScreen;
/*    */ import dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen.LegacyMapSelectionScreen;
/*    */ import dev.jab125.minimega.mod.data.MapInfo;
/*    */ import dev.jab125.minimega.mod.util.Minigame;
/*    */ import dev.jab125.minimega.mod.util.Ref;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.resources.Identifier;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({SelectMapsScreen.class})
/*    */ public class SelectMapsScreenMixin
/*    */ {
/*    */   @Inject(method = {"createMapVotingScreen"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static void create(Minigame<?> minigame, @Nullable Screen parent, Ref<Identifier> selectedMap, List<Identifier> enabledMaps, List<MapInfo> mapInfos, CallbackInfoReturnable<Screen> cir) {
/* 22 */     cir.setReturnValue(new LegacyMapSelectionScreen(minigame, parent, selectedMap, enabledMaps, mapInfos));
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\SelectMapsScreenMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */