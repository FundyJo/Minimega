/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.glide;
/*    */ 
/*    */ import dev.jab125.minimega.mod.client.gui.overlay.GlideMedalHud;
/*    */ import dev.jab125.minimega.mod.client.gui.overlay.GlideProximityIndicatorHud;
/*    */ import dev.jab125.minimega.mod.client.gui.overlay.GlideScoreHud;
/*    */ import dev.jab125.minimega.mod.client.gui.overlay.GlideSpeedometerHud;
/*    */ import dev.jab125.minimega.mod.client.gui.overlay.GlideTimerHud;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import wily.legacy.util.client.LegacyRenderUtil;
/*    */ 
/*    */ @Mixin({GlideSpeedometerHud.class, GlideTimerHud.class, GlideProximityIndicatorHud.class, GlideMedalHud.class, GlideScoreHud.class})
/*    */ public class GlideHudVisibilityMixin {
/*    */   @Inject(method = {"render*"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static void cancelRenderingIfHudIsHidden(CallbackInfo ci) {
/* 18 */     if (!LegacyRenderUtil.canDisplayHUD()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\glide\GlideHudVisibilityMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */