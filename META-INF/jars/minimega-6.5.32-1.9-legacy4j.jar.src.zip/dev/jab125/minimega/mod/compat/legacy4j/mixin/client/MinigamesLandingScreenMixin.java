/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import dev.jab125.minimega.mod.client.gui.screen.minigame.MinigamesLandingScreen;
/*    */ import dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen.LegacyMinigamesScreen;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({MinigamesLandingScreen.class})
/*    */ public class MinigamesLandingScreenMixin {
/*    */   @Inject(method = {"createMinigamesLandingScreen"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static void create(Screen parent, CallbackInfoReturnable<Screen> cir) {
/* 15 */     cir.setReturnValue(new LegacyMinigamesScreen(parent));
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\MinigamesLandingScreenMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */