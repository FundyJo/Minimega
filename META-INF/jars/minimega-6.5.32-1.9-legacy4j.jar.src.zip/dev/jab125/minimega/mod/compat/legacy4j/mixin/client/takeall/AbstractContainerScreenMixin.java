/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.takeall;
/*    */ 
/*    */ import com.llamalad7.mixinextras.expression.Definition;
/*    */ import com.llamalad7.mixinextras.expression.Definitions;
/*    */ import com.llamalad7.mixinextras.expression.Expression;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import dev.jab125.minimega.mod.abstractions.networking.ClientNetworking;
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.networking.payload.C2STakeAllPayload;
/*    */ import net.minecraft.client.KeyMapping;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
/*    */ import net.minecraft.client.input.KeyEvent;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import wily.legacy.Legacy4JClient;
/*    */ import wily.legacy.client.ControlType;
/*    */ import wily.legacy.client.controller.LegacyKeyMapping;
/*    */ 
/*    */ @Mixin(value = {AbstractContainerScreen.class}, priority = 1500)
/*    */ public class AbstractContainerScreenMixin extends Screen {
/*    */   protected AbstractContainerScreenMixin(Component component) {
/* 27 */     super(component);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @WrapOperation(method = {"@Minimega:InvInit"}, at = {@At("MIXINEXTRAS:EXPRESSION")})
/*    */   @Definitions({@Definition(id = "keyCrafting", field = {"Lwily/legacy/Legacy4JClient;keyCrafting:Lnet/minecraft/client/KeyMapping;"}), @Definition(id = "matches", method = {"Lnet/minecraft/client/KeyMapping;matches(Lnet/minecraft/client/input/KeyEvent;)Z"}), @Definition(id = "keyEvent", local = {@Local(type = KeyEvent.class, argsOnly = true)})})
/*    */   @Expression({"keyCrafting.matches(keyEvent)"})
/*    */   boolean legacykeypressed(KeyMapping keyCrafting, KeyEvent keyEvent, Operation<Boolean> operation) {
/* 36 */     if (ControlType.getActiveType().isKbm()) {
/* 37 */       if (((Boolean)operation.call(new Object[] { keyCrafting, keyEvent })).booleanValue()) {
/* 38 */         if (this instanceof net.minecraft.client.gui.screens.inventory.ContainerScreen && (MinimegaClient.getMinigameController().minigameAbilities()).takeAll) {
/* 39 */           this.minecraft.getConnection().send(ClientNetworking.getInstance().play((CustomPacketPayload)new C2STakeAllPayload()));
/* 40 */           return false;
/*    */         } 
/* 42 */         return true;
/*    */       }
/*    */     
/* 45 */     } else if ((((LegacyKeyMapping)Legacy4JClient.keyCycleHeldLeft).getBinding()).bindingState.justPressed && this instanceof net.minecraft.client.gui.screens.inventory.ContainerScreen && (MinimegaClient.getMinigameController().minigameAbilities()).takeAll) {
/* 46 */       this.minecraft.getConnection().send(ClientNetworking.getInstance().play((CustomPacketPayload)new C2STakeAllPayload()));
/* 47 */       return false;
/*    */     } 
/*    */     
/* 50 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\takeall\AbstractContainerScreenMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */