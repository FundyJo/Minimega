/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.glide;
/*    */ 
/*    */ import com.llamalad7.mixinextras.expression.Definition;
/*    */ import com.llamalad7.mixinextras.expression.Expression;
/*    */ import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.networking.payload.S2CDisplayTextPayload;
/*    */ import java.util.function.Consumer;
/*    */ import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import wily.legacy.network.TopMessage;
/*    */ 
/*    */ @Mixin({MinimegaClient.class})
/*    */ public class MinimegaClientMixin
/*    */ {
/*    */   @ModifyExpressionValue(method = {"receiveS2CStatusPayload"}, at = {@At("MIXINEXTRAS:EXPRESSION")}, remap = false)
/*    */   @Definition(id = "handler", local = {@Local(type = Consumer.class, name = {"handler"})})
/*    */   @Expression({"handler = @(?)"})
/*    */   private static Consumer<Component> handler(Consumer<Component> original) {
/* 25 */     return component -> TopMessage.setSmall(new TopMessage(component, -1, 40, true, true, false));
/*    */   }
/*    */ 
/*    */   
/*    */   @ModifyExpressionValue(method = {"receiveS2CStatusPayload"}, at = {@At("MIXINEXTRAS:EXPRESSION")}, remap = false)
/*    */   @Definition(id = "pulsingHandler", local = {@Local(type = Consumer.class, name = {"pulsingHandler"})})
/*    */   @Expression({"pulsingHandler = @(?)"})
/*    */   private static Consumer<Component> pulsingHandler(Consumer<Component> original) {
/* 33 */     return component -> TopMessage.setSmall(new TopMessage(component, -1, 40, true, true, true));
/*    */   }
/*    */   
/*    */   @Inject(method = {"receiveS2CDisplayTextPayload"}, at = {@At("HEAD")}, cancellable = true, remap = false)
/*    */   private static void handler(S2CDisplayTextPayload payload, ClientPlayNetworking.Context context, CallbackInfo ci) {
/* 38 */     TopMessage.setSmall(new TopMessage(payload.component(), -1, 40, true, true, false));
/* 39 */     ci.cancel();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\glide\MinimegaClientMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */