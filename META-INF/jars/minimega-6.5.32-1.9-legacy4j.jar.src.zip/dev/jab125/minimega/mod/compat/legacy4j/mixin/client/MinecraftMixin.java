/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.util.Minigame;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin(value = {Minecraft.class}, priority = 1500)
/*    */ public class MinecraftMixin {
/*    */   @Inject(method = {"@Minimega:InvInit"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void handleDropKey(CallbackInfo ci) {
/* 15 */     Minigame<?> minigame = MinimegaClient.getMinigame();
/* 16 */     if (minigame == Minigame.LOBBY || minigame == Minigame.GLIDE) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\MinecraftMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */