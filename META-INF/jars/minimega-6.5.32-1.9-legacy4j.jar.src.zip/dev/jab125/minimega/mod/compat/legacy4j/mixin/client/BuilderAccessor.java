package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({Button.Builder.class})
public interface BuilderAccessor {
  @Accessor
  Component getMessage();
  
  @Accessor
  Button.OnPress getOnPress();
  
  @Accessor
  Tooltip getTooltip();
  
  @Accessor
  int getX();
  
  @Accessor
  int getY();
  
  @Accessor
  int getWidth();
  
  @Accessor
  int getHeight();
  
  @Accessor
  Button.CreateNarration getCreateNarration();
}


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\BuilderAccessor.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */