/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import com.llamalad7.mixinextras.expression.Definition;
/*    */ import com.llamalad7.mixinextras.expression.Expression;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ import wily.legacy.skins.skin.SkinFairness;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({SkinFairness.class})
/*    */ public class SkinFairnessMixin
/*    */ {
/*    */   @Inject(method = {"isRestrictedServer"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static void isRestrictedServer(Minecraft client, CallbackInfoReturnable<Boolean> cir) {
/*    */     // Byte code:
/*    */     //   0: invokestatic getMinigame : ()Ldev/jab125/minimega/mod/util/Minigame;
/*    */     //   3: getstatic dev/jab125/minimega/mod/util/Minigame.NONE : Ldev/jab125/minimega/mod/util/Minigame;
/*    */     //   6: if_acmpeq -> 81
/*    */     //   9: aload_1
/*    */     //   10: invokestatic getMinigameController : ()Ldev/jab125/minimega/mod/util/controller/AbstractMinigameController;
/*    */     //   13: invokevirtual getMinigameData : ()Ldev/jab125/minimega/mod/util/minigamedata/MinigameData;
/*    */     //   16: invokevirtual config : ()Ldev/jab125/minimega/mod/util/minigamedata/MinigameSpecificConfig;
/*    */     //   19: astore #4
/*    */     //   21: aload #4
/*    */     //   23: instanceof dev/jab125/minimega/mod/util/minigamedata/BattleConfig
/*    */     //   26: ifeq -> 53
/*    */     //   29: aload #4
/*    */     //   31: checkcast dev/jab125/minimega/mod/util/minigamedata/BattleConfig
/*    */     //   34: astore_2
/*    */     //   35: aload_2
/*    */     //   36: invokevirtual settings : ()Ldev/jab125/minimega/mod/util/minigamedata/battle/BattleConfigSettings;
/*    */     //   39: astore #5
/*    */     //   41: aload #5
/*    */     //   43: astore_3
/*    */     //   44: aload_3
/*    */     //   45: invokeinterface allowAllSkins : ()Z
/*    */     //   50: ifne -> 57
/*    */     //   53: iconst_1
/*    */     //   54: goto -> 58
/*    */     //   57: iconst_0
/*    */     //   58: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*    */     //   61: invokevirtual setReturnValue : (Ljava/lang/Object;)V
/*    */     //   64: goto -> 81
/*    */     //   67: astore_2
/*    */     //   68: new java/lang/MatchException
/*    */     //   71: dup
/*    */     //   72: aload_2
/*    */     //   73: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   76: aload_2
/*    */     //   77: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
/*    */     //   80: athrow
/*    */     //   81: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #22	-> 0
/*    */     //   #23	-> 81
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   44	9	3	settings	Ldev/jab125/minimega/mod/util/minigamedata/battle/BattleConfigSettings;
/*    */     //   57	1	3	settings	Ldev/jab125/minimega/mod/util/minigamedata/battle/BattleConfigSettings;
/*    */     //   0	82	0	client	Lnet/minecraft/client/Minecraft;
/*    */     //   0	82	1	cir	Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	82	1	cir	Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable<Ljava/lang/Boolean;>;
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   36	39	67	java/lang/Throwable
/*    */   }
/*    */   
/*    */   @WrapOperation(method = {"isRestrictedServer"}, at = {@At("MIXINEXTRAS:EXPRESSION")}, require = 0)
/*    */   @Definition(id = "hasModOnServer", method = {"Lwily/factoryapi/FactoryAPIClient;hasModOnServer(Ljava/lang/String;)Z"})
/*    */   @Expression({"hasModOnServer(?)"})
/*    */   private static boolean hasmodonserverminimega(String id, Operation<Boolean> original) {
/* 29 */     if ("minimega".equals(id)) return false; 
/* 30 */     return ((Boolean)original.call(new Object[] { id })).booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\SkinFairnessMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */