/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ import com.mojang.serialization.DynamicOps;
/*    */ import com.mojang.serialization.JsonOps;
/*    */ import dev.jab125.minimega.mod.Minimega;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.resources.Identifier;
/*    */ import net.minecraft.server.packs.resources.ResourceManager;
/*    */ import net.minecraft.util.GsonHelper;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import wily.legacy.client.screen.HowToPlayScreen;
/*    */ 
/*    */ @Mixin({HowToPlayScreen.Manager.class})
/*    */ public class HowToPlayScreenLoaderMixin {
/*    */   @Inject(method = {"onResourceManagerReload"}, at = {@At("RETURN")})
/*    */   void on(ResourceManager par1, CallbackInfo ci) {
/* 21 */     HowToPlayScreen.Section s = null;
/* 22 */     for (HowToPlayScreen.Section section : HowToPlayScreen.Section.list) {
/* 23 */       if (section.uiDefinitionLocation().equals(Identifier.parse("legacy:ui_definitions/how_to_play/hud.json"))) {
/* 24 */         s = section;
/*    */       }
/*    */     } 
/* 27 */     if (s != null) {
/*    */       
/* 29 */       String[] strs = { "{\n  \"title\": {\"translate\": \"minimega.legacyhowtoplay.battle\"},\n  \"ui_definition\": \"minimega:how_to_play/battle\"\n}", "{\n  \"title\": {\"translate\": \"minimega.legacyhowtoplay.glide\"},\n  \"ui_definition\": \"minimega:how_to_play/glide\"\n}" };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 39 */       List<HowToPlayScreen.Section> section = Arrays.<String>stream(strs).map(str -> { Objects.requireNonNull(Minimega.LOGGER); return HowToPlayScreen.Section.CODEC.parse((DynamicOps)JsonOps.INSTANCE, GsonHelper.parse(str)).resultOrPartial(Minimega.LOGGER::error).orElseThrow(); }).toList();
/* 40 */       HowToPlayScreen.Section.list.addAll(HowToPlayScreen.Section.list.indexOf(s) + 1, section);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\HowToPlayScreenLoaderMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */