/*     */ package dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen;
/*     */ 
/*     */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*     */ import dev.jab125.minimega.mod.client.gui.screen.minigame.MinigamesLandingScreen;
/*     */ import dev.jab125.minimega.mod.compat.legacy4j.client.gui.widget.CreationList;
/*     */ import dev.jab125.minimega.mod.util.Minigame;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*     */ import net.minecraft.client.gui.components.AbstractButton;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.Renderable;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.input.KeyEvent;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.util.Mth;
/*     */ import wily.legacy.client.ControlType;
/*     */ import wily.legacy.client.controller.BindingState;
/*     */ import wily.legacy.client.controller.ControllerBinding;
/*     */ import wily.legacy.client.screen.ControlTooltip;
/*     */ import wily.legacy.client.screen.LegacyTabButton;
/*     */ import wily.legacy.client.screen.Panel;
/*     */ import wily.legacy.client.screen.PanelVListScreen;
/*     */ import wily.legacy.client.screen.RenderableVList;
/*     */ import wily.legacy.client.screen.TabList;
/*     */ import wily.legacy.util.LegacySprites;
/*     */ import wily.legacy.util.client.LegacyRenderUtil;
/*     */ 
/*     */ public class LegacyMinigamesScreen
/*     */   extends PanelVListScreen implements ControlTooltip.Event, TabList.Access {
/*     */   public boolean isLoading = false;
/*  35 */   protected final TabList tabList = (new TabList(this.accessor)).add(LegacyTabButton.Type.LEFT, (Component)Component.translatable("legacy.menu.create"), b -> repositionElements()).add(LegacyTabButton.Type.MIDDLE, (Component)Component.translatable("legacy.menu.join"), b -> repositionElements())
/*     */ 
/*     */     
/*  38 */     .add(LegacyTabButton.Type.RIGHT, (Component)Component.translatable("minimega.friends"), b -> getTabList().resetSelectedTab());
/*  39 */   private final Map<Minigame<?>, List<Object>> o = new HashMap<>();
/*     */   private <T> T minigame(T t, Minigame<?> minigame) {
/*  41 */     ((List<T>)this.o.computeIfAbsent(minigame, a -> new ArrayList())).add(t);
/*  42 */     return t;
/*     */   }
/*  44 */   public final CreationList creationList = new CreationList(this.accessor, MinigamesLandingScreen.Type.CREATE, this::minigame);
/*  45 */   protected final CreationList serverRenderableList = new CreationList(this.accessor, MinigamesLandingScreen.Type.JOIN, this::minigame);
/*     */   
/*     */   protected final Panel panelRecess;
/*     */ 
/*     */   
/*     */   public void addControlTooltips(ControlTooltip.Renderer renderer) {
/*  51 */     super.addControlTooltips(renderer);
/*  52 */     renderer.add(() -> ControlType.getActiveType().isKbm() ? (ControlTooltip.Icon)ControlTooltip.getKeyIcon(79) : (ControlTooltip.Icon)((BindingState.Button)ControllerBinding.UP_BUTTON.bindingState).getIcon(), () -> ControlTooltip.getKeyMessage(79, (Screen)this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LegacyMinigamesScreen(Screen parent, int initialTab) {
/*  61 */     super(s -> Panel.createPanel((Screen)s, (), ()), (Component)Component.translatable("legacy.menu.play_game"));
/*  62 */     this.panelRecess = Panel.createPanel((Screen)this, p -> p.appearance(LegacySprites.PANEL_RECESS, this.panel.width - 18, this.panel.height - 18), p -> p.pos(this.panel.x + 9, this.panel.y + 9));
/*  63 */     this.parent = parent;
/*  64 */     this.tabList.setSelected(initialTab);
/*  65 */     this.renderableVLists.clear();
/*     */     
/*  67 */     this.renderableVLists.add(this.creationList);
/*  68 */     this.renderableVLists.add(this.serverRenderableList);
/*     */   }
/*     */   
/*     */   public boolean hasTabList() {
/*  72 */     return this.accessor.getBoolean("hasTabList", Boolean.valueOf(true)).booleanValue();
/*     */   }
/*     */   
/*     */   public LegacyMinigamesScreen(Screen parent) {
/*  76 */     this(parent, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabList getTabList() {
/*  86 */     return this.tabList;
/*     */   }
/*     */ 
/*     */   
/*     */   public void added() {
/*  91 */     super.added();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init() {
/*  98 */     if (hasTabList()) addWidget((GuiEventListener)this.tabList); 
/*  99 */     this.panel.init();
/* 100 */     this.panelRecess.init("panelRecess");
/* 101 */     renderableVListInit();
/* 102 */     if (hasTabList()) this.tabList.init(this.panel.x, this.panel.y - 25, this.panel.width, 31);
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderableVListInit() {
/* 108 */     getRenderableVList().init(this.panel.x + 15, this.panel.y + 15, this.panel.width - 30, this.panel.height - 30);
/* 109 */     if (!hasTabList()) {
/* 110 */       this.serverRenderableList.init("serverRenderableVList", this.panel.x + 15, this.panel.y + 15, this.panel.width - 30, this.panel.height - 30);
/*     */     }
/*     */   }
/*     */   
/*     */   public void initRenderableVListEntry(RenderableVList renderableVList, Renderable renderable) {
/* 115 */     if (renderable instanceof AbstractWidget) { AbstractWidget widget = (AbstractWidget)renderable;
/* 116 */       widget.setHeight(this.accessor.getInteger("buttonsHeight", 30)); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderDefaultBackground(GuiGraphicsExtractor guiGraphics, int i, int j, float f) {
/* 123 */     LegacyRenderUtil.renderDefaultBackground(this.accessor, guiGraphics, false);
/* 124 */     if (hasTabList()) this.tabList.extractRenderState(guiGraphics, i, j, f); 
/* 125 */     this.panel.extractRenderState(guiGraphics, i, j, f);
/* 126 */     this.tabList.renderSelected(guiGraphics, i, j, f);
/* 127 */     this.panelRecess.extractRenderState(guiGraphics, i, j, f);
/* 128 */     this.tabList.renderSelected(guiGraphics, i, j, f);
/* 129 */     if (this.isLoading) {
/* 130 */       LegacyRenderUtil.drawGenericLoading(guiGraphics, this.panel.x + 112, this.panel.y + 66);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void extractRenderState(GuiGraphicsExtractor guiGraphics, int i, int j, float f) {
/* 136 */     super.extractRenderState(guiGraphics, i, j, f);
/* 137 */     for (Map.Entry<Minigame<?>, List<Object>> entry : this.o.entrySet()) {
/* 138 */       for (Object object : entry.getValue()) {
/* 139 */         if (object instanceof AbstractButton) { AbstractButton button = (AbstractButton)object; if (children().contains(button) && button.visible) {
/* 140 */             int x = button.getX() + 1;
/* 141 */             int y = button.getY() + button.getHeight() - 2;
/* 142 */             int width = (int)Mth.lerp(((Minigame)entry.getKey()).getProgress(), 0.0F, (button.getWidth() - 2));
/* 143 */             int height = 1;
/* 144 */             guiGraphics.fill(x, y, x + width, y + height, ((Minigame)entry.getKey()).isPlayable() ? -16711936 : -256);
/*     */           }  }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public RenderableVList getRenderableVList() {
/* 152 */     return getRenderableVLists().get(hasTabList() ? this.tabList.getIndex() : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/* 157 */     super.tick();
/* 158 */     if (MinimegaClient.isOutdated()) onClose();
/*     */   
/*     */   }
/*     */   
/*     */   public boolean keyPressed(KeyEvent keyEvent) {
/* 163 */     if (hasTabList() && (this.tabList.controlTab(keyEvent.key()) || this.tabList.directionalControlTab(keyEvent.key())))
/* 164 */       return true; 
/* 165 */     if (super.keyPressed(keyEvent)) {
/* 166 */       return true;
/*     */     }
/* 168 */     if (keyEvent.key() == 294) {
/* 169 */       if (this.tabList.getIndex() != 0)
/*     */       {
/* 171 */         if (this.tabList.getIndex() == 2);
/*     */       }
/*     */ 
/*     */       
/* 175 */       rebuildWidgets();
/* 176 */       return true;
/*     */     } 
/* 178 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\gui\screen\LegacyMinigamesScreen.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */