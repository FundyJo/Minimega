/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.client.gui.screen.AccessScreen;
/*    */ import dev.jab125.minimega.mod.client.gui.screen.minigame.MinigamesLandingScreen;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.client.gui.components.Renderable;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.client.gui.screens.TitleScreen;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import org.spongepowered.asm.mixin.Dynamic;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import wily.legacy.client.screen.RenderableVList;
/*    */ 
/*    */ 
/*    */ @Mixin(value = {TitleScreen.class}, priority = 1100)
/*    */ public abstract class LegacyTitleScreenMixin
/*    */   extends Screen
/*    */ {
/*    */   protected LegacyTitleScreenMixin(Component component) {
/* 24 */     super(component);
/*    */   }
/*    */   
/*    */   @WrapOperation(method = {"@Minimega:InvInit"}, at = {@At(value = "INVOKE", target = "Lwily/legacy/client/screen/RenderableVList;addRenderable(Lnet/minecraft/client/gui/components/Renderable;)Lwily/legacy/client/screen/RenderableVList;", ordinal = 0)}, require = 0)
/*    */   @Dynamic
/*    */   private RenderableVList mm$legacyInit(RenderableVList list, Renderable renderable, Operation<RenderableVList> original) {
/*    */     // Byte code:
/*    */     //   0: aload_2
/*    */     //   1: instanceof net/minecraft/client/gui/components/Button
/*    */     //   4: ifeq -> 57
/*    */     //   7: aload_2
/*    */     //   8: checkcast net/minecraft/client/gui/components/Button
/*    */     //   11: astore #6
/*    */     //   13: aload #6
/*    */     //   15: invokevirtual getMessage : ()Lnet/minecraft/network/chat/Component;
/*    */     //   18: invokeinterface getContents : ()Lnet/minecraft/network/chat/ComponentContents;
/*    */     //   23: astore #7
/*    */     //   25: aload #7
/*    */     //   27: instanceof net/minecraft/network/chat/contents/TranslatableContents
/*    */     //   30: ifeq -> 57
/*    */     //   33: aload #7
/*    */     //   35: checkcast net/minecraft/network/chat/contents/TranslatableContents
/*    */     //   38: astore #5
/*    */     //   40: ldc 'legacy.menu.leaderboards'
/*    */     //   42: aload #5
/*    */     //   44: invokevirtual getKey : ()Ljava/lang/String;
/*    */     //   47: invokevirtual equals : (Ljava/lang/Object;)Z
/*    */     //   50: ifeq -> 57
/*    */     //   53: aload_1
/*    */     //   54: goto -> 78
/*    */     //   57: aload_3
/*    */     //   58: iconst_2
/*    */     //   59: anewarray java/lang/Object
/*    */     //   62: dup
/*    */     //   63: iconst_0
/*    */     //   64: aload_1
/*    */     //   65: aastore
/*    */     //   66: dup
/*    */     //   67: iconst_1
/*    */     //   68: aload_2
/*    */     //   69: aastore
/*    */     //   70: invokeinterface call : ([Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   75: checkcast wily/legacy/client/screen/RenderableVList
/*    */     //   78: astore #4
/*    */     //   80: ldc 'minimega.menu.minigames'
/*    */     //   82: invokestatic translatable : (Ljava/lang/String;)Lnet/minecraft/network/chat/MutableComponent;
/*    */     //   85: aload_0
/*    */     //   86: <illegal opcode> onPress : (Ldev/jab125/minimega/mod/compat/legacy4j/mixin/client/LegacyTitleScreenMixin;)Lnet/minecraft/client/gui/components/Button$OnPress;
/*    */     //   91: invokestatic builder : (Lnet/minecraft/network/chat/Component;Lnet/minecraft/client/gui/components/Button$OnPress;)Lnet/minecraft/client/gui/components/Button$Builder;
/*    */     //   94: invokevirtual build : ()Lnet/minecraft/client/gui/components/Button;
/*    */     //   97: astore #5
/*    */     //   99: aload #5
/*    */     //   101: invokestatic isOutdated : ()Z
/*    */     //   104: ifne -> 111
/*    */     //   107: iconst_1
/*    */     //   108: goto -> 112
/*    */     //   111: iconst_0
/*    */     //   112: putfield active : Z
/*    */     //   115: aload_3
/*    */     //   116: iconst_2
/*    */     //   117: anewarray java/lang/Object
/*    */     //   120: dup
/*    */     //   121: iconst_0
/*    */     //   122: aload_1
/*    */     //   123: aastore
/*    */     //   124: dup
/*    */     //   125: iconst_1
/*    */     //   126: aload #5
/*    */     //   128: aastore
/*    */     //   129: invokeinterface call : ([Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   134: pop
/*    */     //   135: ldc 'Feature Flags Invites Menu'
/*    */     //   137: iconst_0
/*    */     //   138: invokestatic hasFeatureOrDefault : (Ljava/lang/String;Z)Z
/*    */     //   141: ifeq -> 199
/*    */     //   144: ldc 'Access'
/*    */     //   146: invokestatic literal : (Ljava/lang/String;)Lnet/minecraft/network/chat/MutableComponent;
/*    */     //   149: aload_0
/*    */     //   150: <illegal opcode> onPress : (Ldev/jab125/minimega/mod/compat/legacy4j/mixin/client/LegacyTitleScreenMixin;)Lnet/minecraft/client/gui/components/Button$OnPress;
/*    */     //   155: invokestatic builder : (Lnet/minecraft/network/chat/Component;Lnet/minecraft/client/gui/components/Button$OnPress;)Lnet/minecraft/client/gui/components/Button$Builder;
/*    */     //   158: invokevirtual build : ()Lnet/minecraft/client/gui/components/Button;
/*    */     //   161: astore #5
/*    */     //   163: aload #5
/*    */     //   165: invokestatic isOutdated : ()Z
/*    */     //   168: ifne -> 175
/*    */     //   171: iconst_1
/*    */     //   172: goto -> 176
/*    */     //   175: iconst_0
/*    */     //   176: putfield active : Z
/*    */     //   179: aload_3
/*    */     //   180: iconst_2
/*    */     //   181: anewarray java/lang/Object
/*    */     //   184: dup
/*    */     //   185: iconst_0
/*    */     //   186: aload_1
/*    */     //   187: aastore
/*    */     //   188: dup
/*    */     //   189: iconst_1
/*    */     //   190: aload #5
/*    */     //   192: aastore
/*    */     //   193: invokeinterface call : ([Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   198: pop
/*    */     //   199: aload #4
/*    */     //   201: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #30	-> 0
/*    */     //   #32	-> 80
/*    */     //   #35	-> 94
/*    */     //   #36	-> 99
/*    */     //   #37	-> 115
/*    */     //   #39	-> 135
/*    */     //   #40	-> 144
/*    */     //   #43	-> 158
/*    */     //   #44	-> 163
/*    */     //   #45	-> 179
/*    */     //   #47	-> 199
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   40	17	5	contents	Lnet/minecraft/network/chat/contents/TranslatableContents;
/*    */     //   13	44	6	button	Lnet/minecraft/client/gui/components/Button;
/*    */     //   99	36	5	build	Lnet/minecraft/client/gui/components/Button;
/*    */     //   163	36	5	build	Lnet/minecraft/client/gui/components/Button;
/*    */     //   0	202	0	this	Ldev/jab125/minimega/mod/compat/legacy4j/mixin/client/LegacyTitleScreenMixin;
/*    */     //   0	202	1	list	Lwily/legacy/client/screen/RenderableVList;
/*    */     //   0	202	2	renderable	Lnet/minecraft/client/gui/components/Renderable;
/*    */     //   0	202	3	original	Lcom/llamalad7/mixinextras/injector/wrapoperation/Operation;
/*    */     //   80	122	4	call	Lwily/legacy/client/screen/RenderableVList;
/*    */     // Local variable type table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	202	3	original	Lcom/llamalad7/mixinextras/injector/wrapoperation/Operation<Lwily/legacy/client/screen/RenderableVList;>;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\LegacyTitleScreenMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */