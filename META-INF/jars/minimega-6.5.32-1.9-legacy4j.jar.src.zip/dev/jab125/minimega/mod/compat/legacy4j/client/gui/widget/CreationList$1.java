/*    */ package dev.jab125.minimega.mod.compat.legacy4j.client.gui.widget;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*    */ import net.minecraft.client.input.InputWithModifiers;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.resources.Identifier;
/*    */ import wily.factoryapi.base.client.FactoryGuiGraphics;
/*    */ import wily.legacy.client.screen.IconButton;
/*    */ import wily.legacy.client.screen.RenderableVList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends IconButton
/*    */ {
/*    */   null(RenderableVList arg0, int arg1, int arg2, int arg3, int arg4, Component arg5) {
/* 88 */     super(arg0, arg1, arg2, arg3, arg4, arg5);
/*    */   }
/*    */   public void renderIcon(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, int x, int y, int width, int height) {
/* 91 */     FactoryGuiGraphics.of(guiGraphics).blitSprite(iconSprite, getX() + x, getY() + y, width, height);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onPress(InputWithModifiers input) {
/* 96 */     onPress.accept(this);
/*    */   }
/*    */   
/*    */   public void renderIconHighlight(GuiGraphicsExtractor guiGraphics, int i, int i1, int i2, int i3, int i4, int i5) {}
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\gui\widget\CreationList$1.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */