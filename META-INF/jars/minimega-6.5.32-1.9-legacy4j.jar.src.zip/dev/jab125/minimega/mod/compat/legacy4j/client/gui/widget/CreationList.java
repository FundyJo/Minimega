/*     */ package dev.jab125.minimega.mod.compat.legacy4j.client.gui.widget;
/*     */ 
/*     */ import dev.jab125.minimega.mod.Minimega;
/*     */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*     */ import dev.jab125.minimega.mod.client.gui.screen.minigame.MinigamesLandingScreen;
/*     */ import dev.jab125.minimega.mod.client.gui.screen.minigame.NewDataScreen;
/*     */ import dev.jab125.minimega.mod.client.join.Joiner;
/*     */ import dev.jab125.minimega.mod.util.Minigame;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*     */ import net.minecraft.client.gui.components.AbstractButton;
/*     */ import net.minecraft.client.gui.components.Renderable;
/*     */ import net.minecraft.client.gui.components.Tooltip;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.input.InputWithModifiers;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.resources.Identifier;
/*     */ import org.apache.commons.lang3.function.TriFunction;
/*     */ import wily.factoryapi.base.client.FactoryGuiGraphics;
/*     */ import wily.factoryapi.base.client.UIAccessor;
/*     */ import wily.legacy.client.screen.IconButton;
/*     */ import wily.legacy.client.screen.RenderableVList;
/*     */ 
/*     */ public class CreationList
/*     */   extends RenderableVList {
/*     */   protected final Minecraft minecraft;
/*     */   private final MinigamesLandingScreen.Type state;
/*     */   
/*     */   public CreationList(UIAccessor accessor, MinigamesLandingScreen.Type type, BiConsumer<Object, Minigame<?>> consumer) {
/*  32 */     super(accessor);
/*  33 */     layoutSpacing(l -> Integer.valueOf(0));
/*  34 */     this.minecraft = Minecraft.getInstance();
/*  35 */     consumer.accept(addIconButton(this, Minimega.id("battle/battle"), (Component)Component.translatable("minimega.battle"), c -> battle()), Minigame.BATTLE);
/*     */     
/*  37 */     consumer.accept(addIconButton(this, Minimega.id("glide/glide"), (Component)Component.translatable("minimega.glide"), c -> glide()), Minigame.GLIDE);
/*  38 */     consumer.accept(addIconButton(this, Minimega.id("fistfight/fistfight"), (Component)Component.translatable("minimega.fistfight"), c -> fistfight()), Minigame.FISTFIGHT);
/*  39 */     this.state = type;
/*     */   }
/*     */   
/*     */   private void battle() {
/*  43 */     if (MinimegaClient.isOutdated())
/*  44 */       return;  if (this.state == MinigamesLandingScreen.Type.CREATE) {
/*  45 */       NewDataScreen.openCreateLobbyScreen(this.minecraft, getScreen(), Minigame.BATTLE, dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen.LegacyDataScreen::new);
/*  46 */     } else if (this.state == MinigamesLandingScreen.Type.JOIN) {
/*  47 */       MinimegaClient.joinPublic(Minigame.BATTLE);
/*  48 */       Joiner.joinMultiplayerWorld(this.minecraft);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tumble() {
/*  53 */     if (MinimegaClient.isOutdated())
/*  54 */       return;  if (this.state == MinigamesLandingScreen.Type.CREATE) {
/*  55 */       NewDataScreen.openCreateLobbyScreen(this.minecraft, getScreen(), Minigame.TUMBLE, dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen.LegacyDataScreen::new);
/*  56 */     } else if (this.state == MinigamesLandingScreen.Type.JOIN) {
/*  57 */       MinimegaClient.joinPublic(Minigame.TUMBLE);
/*  58 */       Joiner.joinMultiplayerWorld(this.minecraft);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void glide() {
/*  63 */     if (MinimegaClient.isOutdated())
/*  64 */       return;  if (this.state == MinigamesLandingScreen.Type.CREATE) {
/*  65 */       NewDataScreen.openCreateLobbyScreen(this.minecraft, getScreen(), Minigame.GLIDE, dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen.LegacyDataScreen::new);
/*  66 */     } else if (this.state == MinigamesLandingScreen.Type.JOIN) {
/*  67 */       MinimegaClient.joinPublic(Minigame.GLIDE);
/*  68 */       Joiner.joinMultiplayerWorld(this.minecraft);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fistfight() {
/*  73 */     if (MinimegaClient.isOutdated())
/*  74 */       return;  if (this.state == MinigamesLandingScreen.Type.CREATE) {
/*  75 */       NewDataScreen.openCreateLobbyScreen(this.minecraft, getScreen(), Minigame.FISTFIGHT, dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen.LegacyDataScreen::new);
/*  76 */     } else if (this.state == MinigamesLandingScreen.Type.JOIN) {
/*  77 */       MinimegaClient.joinPublic(Minigame.FISTFIGHT);
/*  78 */       Joiner.joinMultiplayerWorld(this.minecraft);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object addIconButton(RenderableVList list, Identifier iconSprite, Component message, Consumer<AbstractButton> onPress) {
/*  83 */     return addIconButton(list, iconSprite, message, onPress, (Tooltip)null);
/*     */   }
/*     */   
/*     */   public static Object addIconButton(RenderableVList list, final Identifier iconSprite, Component message, final Consumer<AbstractButton> onPress, Tooltip tooltip) {
/*     */     IconButton iconButton;
/*  88 */     list.addRenderable((Renderable)(iconButton = new IconButton(list, 0, 0, 270, 30, message)
/*     */         {
/*     */           public void renderIcon(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, int x, int y, int width, int height) {
/*  91 */             FactoryGuiGraphics.of(guiGraphics).blitSprite(iconSprite, getX() + x, getY() + y, width, height);
/*     */           }
/*     */ 
/*     */           
/*     */           public void onPress(InputWithModifiers input) {
/*  96 */             onPress.accept(this);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void renderIconHighlight(GuiGraphicsExtractor guiGraphics, int i, int i1, int i2, int i3, int i4, int i5) {}
/*     */         }));
/* 103 */     if (!iconSprite.equals(Minimega.id("glide/glide")) && !iconSprite.equals(Minimega.id("fistfight/fistfight")) && !iconSprite.equals(Minimega.id("battle/battle")) && (!iconSprite.equals(Minimega.id("tumble/tumble")) || !MinimegaClient.hasFeatureOrDefault("tumble", false)))
/* 104 */       ((AbstractButton)iconButton).active = false; 
/* 105 */     iconButton.setTooltip(tooltip);
/* 106 */     return iconButton;
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\gui\widget\CreationList.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */