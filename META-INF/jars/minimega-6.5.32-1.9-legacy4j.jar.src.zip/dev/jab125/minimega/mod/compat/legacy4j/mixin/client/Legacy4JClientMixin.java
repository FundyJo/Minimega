/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import dev.jab125.minimega.mod.abstractions.networking.ClientNetworking;
/*    */ import dev.jab125.minimega.mod.networking.payload.C2SRestartPayload;
/*    */ import dev.jab125.minimega.mod.util.Minigame;
/*    */ import dev.jab125.minimega.mod.util.controller.MinigamesController;
/*    */ import net.minecraft.client.KeyMapping;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.screens.inventory.InventoryScreen;
/*    */ import net.minecraft.client.multiplayer.ClientLevel;
/*    */ import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ import net.minecraft.world.level.Level;
/*    */ import org.spongepowered.asm.mixin.Dynamic;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import wily.legacy.Legacy4JClient;
/*    */ 
/*    */ @Mixin({Legacy4JClient.class})
/*    */ public class Legacy4JClientMixin {
/*    */   @WrapOperation(method = {"preTick"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/KeyMapping;consumeClick()Z")})
/*    */   @Dynamic
/*    */   private static boolean mm$preTick(KeyMapping instance, Operation<Boolean> original) {
/* 25 */     Minecraft minecraft = Minecraft.getInstance();
/* 26 */     ClientLevel level = minecraft.level;
/* 27 */     if (instance == Legacy4JClient.keyCrafting) {
/* 28 */       Minigame<?> activeMinigame = MinigamesController.getMinigameController((Level)level).getActiveMinigame();
/* 29 */       if (level != null) {
/* 30 */         if (activeMinigame == Minigame.LOBBY) {
/* 31 */           while (instance.consumeClick()) {
/* 32 */             if (minecraft.gameMode.isServerControlledInventory()) {
/* 33 */               minecraft.player.sendOpenInventory(); continue;
/*    */             } 
/* 35 */             minecraft.getTutorial().onOpenInventory();
/* 36 */             minecraft.setScreen((Screen)new InventoryScreen((Player)minecraft.player));
/*    */           } 
/*    */           
/* 39 */           return false;
/* 40 */         }  if (activeMinigame == Minigame.GLIDE) {
/* 41 */           while (instance.consumeClick()) {
/* 42 */             minecraft.player.connection.send(ClientNetworking.getInstance().play((CustomPacketPayload)new C2SRestartPayload(false)));
/*    */           }
/* 44 */           return false;
/* 45 */         }  if (activeMinigame == Minigame.FISTFIGHT || activeMinigame == Minigame.BATTLE) {
/* 46 */           while (instance.consumeClick());
/* 47 */           return false;
/* 48 */         }  return ((Boolean)original.call(new Object[] { instance })).booleanValue();
/* 49 */       }  return ((Boolean)original.call(new Object[] { instance })).booleanValue();
/* 50 */     }  return ((Boolean)original.call(new Object[] { instance })).booleanValue();
/*    */   }
/*    */   
/*    */   @Inject(method = {"postTick"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static void mm$postTick(Minecraft minecraft, CallbackInfo ci) {
/* 55 */     ClientLevel level = minecraft.level;
/* 56 */     if (level == null)
/* 57 */       return;  MinigamesController minigameController = MinigamesController.getMinigameController((Level)level);
/* 58 */     if (minigameController == null)
/* 59 */       return;  if (!minigameController.isActive())
/* 60 */       return;  ci.cancel();
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\Legacy4JClientMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */