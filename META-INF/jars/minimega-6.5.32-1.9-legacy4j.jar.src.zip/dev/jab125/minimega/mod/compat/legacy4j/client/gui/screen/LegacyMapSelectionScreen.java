/*     */ package dev.jab125.minimega.mod.compat.legacy4j.client.gui.screen;
/*     */ 
/*     */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*     */ import dev.jab125.minimega.mod.client.gui.widget.ISelectMapsScreen;
/*     */ import dev.jab125.minimega.mod.compat.legacy4j.client.gui.widget.MapList;
/*     */ import dev.jab125.minimega.mod.data.MapInfo;
/*     */ import dev.jab125.minimega.mod.util.Minigame;
/*     */ import dev.jab125.minimega.mod.util.Ref;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*     */ import net.minecraft.client.gui.TextAlignment;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.MultiLineLabel;
/*     */ import net.minecraft.client.gui.components.Renderable;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.input.KeyEvent;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import net.minecraft.resources.Identifier;
/*     */ import net.minecraft.sounds.SoundEvent;
/*     */ import net.minecraft.sounds.SoundEvents;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import wily.factoryapi.base.client.FactoryGuiGraphics;
/*     */ import wily.legacy.Legacy4JClient;
/*     */ import wily.legacy.client.CommonColor;
/*     */ import wily.legacy.client.LegacyOptions;
/*     */ import wily.legacy.client.controller.BindingState;
/*     */ import wily.legacy.client.screen.ControlTooltip;
/*     */ import wily.legacy.client.screen.LegacyScrollRenderer;
/*     */ import wily.legacy.client.screen.Panel;
/*     */ import wily.legacy.client.screen.PanelVListScreen;
/*     */ import wily.legacy.client.screen.RenderableVList;
/*     */ import wily.legacy.client.screen.ScrollableRenderer;
/*     */ import wily.legacy.util.LegacySprites;
/*     */ import wily.legacy.util.client.LegacyFontUtil;
/*     */ import wily.legacy.util.client.LegacyRenderUtil;
/*     */ import wily.legacy.util.client.LegacySoundUtil;
/*     */ 
/*     */ public class LegacyMapSelectionScreen
/*     */   extends PanelVListScreen implements ControlTooltip.Event, ISelectMapsScreen<LegacyMapSelectionScreen> {
/*     */   public boolean isLoading = false;
/*     */   public final MapList mapList;
/*     */   private final ArrayList<Identifier> selected;
/*     */   private final Ref<Identifier> selectedMap;
/*     */   @Nullable
/*     */   private final Minigame<?> minigame;
/*     */   private final List<Identifier> enabledMaps;
/*     */   private final boolean isVotingScreen;
/*  54 */   protected final Panel tooltipBox = Panel.tooltipBoxOf(this.panel, 190); private final List<MapInfo> mapInfos; boolean focusing; protected ScrollableRenderer scrollableRenderer;
/*     */   private final boolean hasTooltip = false;
/*     */   private static final int BIG = 195;
/*     */   
/*     */   public void addControlTooltips(ControlTooltip.Renderer renderer) {
/*  59 */     super.addControlTooltips(renderer);
/*  60 */     if (!isVotingScreen()) {
/*  61 */       renderer.add((Minecraft.getInstance()).options.keyInventory, () -> Component.translatable("minimega.selectAll"));
/*  62 */       renderer.add(Legacy4JClient.keyCrafting, () -> Component.translatable("minimega.deselectAll"));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public LegacyMapSelectionScreen(Screen parent, ArrayList<Identifier> selected, List<MapInfo> mapInfos)
/*     */   {
/*  69 */     super(s -> Panel.createPanel((Screen)s, (), (), (), ()), (Component)Component.translatable("minimega.selectMaps"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     this.focusing = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 283 */     this.scrollableRenderer = new ScrollableRenderer(new LegacyScrollRenderer());
/*     */     
/* 285 */     this.hasTooltip = false; this.parent = parent; this.selected = selected; this.selectedMap = null; this.enabledMaps = null; this.minigame = null; this.isVotingScreen = false; this.mapInfos = mapInfos; this.mapList = new MapList(this.accessor, this); this.renderableVLists.clear(); this.renderableVLists.add(this.mapList); } public boolean isPauseScreen() { return (!isVotingScreen() && super.isPauseScreen()); } public void added() { super.added(); } protected void init() { this.tooltipBox.init(); this.panel.height = Math.min(256, this.height - 52); this.panel.init(); renderableVListInit(); } public void renderableVListInit() { int a = 30; getRenderableVList().init("renderableVList", this.panel.x + 15, this.panel.y + a, this.panel.width - 30, this.panel.height - 15 - a); if (isVotingScreen()) { Identifier resourceLocation = (Identifier)selectedMap().get(); if (!this.focusing && resourceLocation != null) { Optional<Renderable> option = (getRenderableVList()).renderables.stream().filter(b -> { if (b instanceof MapList.ButtonTickBox) { MapList.ButtonTickBox buttonTickBox = (MapList.ButtonTickBox)b; if (buttonTickBox.mapInfo().id().equals(resourceLocation)); }  return false; }).findFirst(); this.focusing = true; option.ifPresent(renderable -> getRenderableVList().focusRenderable(renderable)); }  }  } public void renderDefaultBackground(GuiGraphicsExtractor guiGraphics, int i, int j, float f) { if (!isVotingScreen()) LegacyRenderUtil.renderDefaultBackground(this.accessor, guiGraphics, false);  renderTooltipBox(guiGraphics, (LayoutElement)this.panel); this.panel.extractRenderState(guiGraphics, i, j, f); FactoryGuiGraphics.of(guiGraphics).blitSprite(LegacySprites.PANEL_RECESS, this.accessor.getInteger("panelRecess.x", this.panel.x + 9), this.accessor.getInteger("panelRecess.y", this.panel.y + 9 + 15), this.accessor.getInteger("panelRecess.width", this.panel.width - 18), this.accessor.getInteger("panelRecess.height", this.panel.height - 18 - 15)); if (this.isLoading) LegacyRenderUtil.drawGenericLoading(guiGraphics, this.panel.x + 112, this.panel.y + 66);  LegacyFontUtil.applySDFont(b -> guiGraphics.text(this.font, (Component)Component.translatable(isVotingScreen() ? "minimega.selectMap" : "minimega.selectMaps"), this.panel.x + this.panel.width / 2 - this.font.width((FormattedText)Component.translatable(isVotingScreen() ? "minimega.selectMap" : "minimega.selectMaps")) / 2, this.panel.y + (b.booleanValue() ? 6 : 12), ((Integer)CommonColor.GRAY_TEXT.get()).intValue(), false)); } public void initRenderableVListEntry(RenderableVList renderableVList, Renderable renderable) { if (renderable instanceof AbstractWidget) { AbstractWidget widget = (AbstractWidget)renderable; widget.setHeight(this.accessor.getInteger("buttonsHeight", 30)); }  } public LegacyMapSelectionScreen(Minigame<?> minigame, @Nullable Screen parent, Ref<Identifier> selectedMap, List<Identifier> enabledMaps, List<MapInfo> mapInfos) { super(s -> Panel.createPanel((Screen)s, (), (), (), ()), (Component)Component.translatable("minimega.selectMap")); this.focusing = false; this.scrollableRenderer = new ScrollableRenderer(new LegacyScrollRenderer()); this.hasTooltip = false; this.parent = parent; this.selectedMap = selectedMap; this.selected = null; this.enabledMaps = enabledMaps; this.isVotingScreen = true; this.minigame = minigame; this.mapInfos = mapInfos; this.mapList = new MapList(this.accessor, this); this.renderableVLists.clear(); this.renderableVLists.add(this.mapList); }
/*     */   public RenderableVList getRenderableVList() { return (RenderableVList)this.mapList; }
/*     */   public void tick() { super.tick(); if (MinimegaClient.isOutdated()) onClose();  }
/*     */   public boolean keyPressed(KeyEvent event) { if (!isVotingScreen()) { if (this.minecraft.options.keyInventory.matches(event)) { this.mapList.selectAll(); LegacySoundUtil.playSimpleUISound((SoundEvent)SoundEvents.UI_BUTTON_CLICK.value(), 1.0F); return true; }  if (Legacy4JClient.keyCrafting.matches(event)) { this.mapList.deselectAll(); LegacySoundUtil.playSimpleUISound((SoundEvent)SoundEvents.UI_BUTTON_CLICK.value(), 1.0F); return true; }  }  return super.keyPressed(event); }
/* 289 */   public Minecraft getMinecraftClient() { return this.minecraft; } public ArrayList<Identifier> getSelectedMaps() { return this.selected; } @Nullable public Ref<Identifier> selectedMap() { return this.selectedMap; } private void renderTooltipBox(GuiGraphicsExtractor graphics, int x, int y, int width, int height) { LegacyRenderUtil.renderPointerPanel(graphics, x, y, width, height);
/* 290 */     Identifier background = getImage();
/* 291 */     boolean sd = LegacyOptions.getUIMode().isSD();
/*     */     
/* 293 */     int descriptionWidth = getDefaultWidth() - 16;
/* 294 */     int lineHeight = sd ? 8 : 12;
/* 295 */     int left = x + (sd ? 5 : 8);
/* 296 */     int descriptionFromBottom = getImageHeight() + 5;
/* 297 */     int visibleLines = 1337;
/* 298 */     MultiLineLabel label = (sd ? LegacyTooltipReckoning.sdLabelsCache : LegacyTooltipReckoning.labelsCache).apply(getComponents(), Integer.valueOf(descriptionWidth));
/* 299 */     Component text = getText();
/* 300 */     if (text != null)
/* 301 */       LegacyFontUtil.applySDFont(b -> LegacyRenderUtil.renderScrollingString(graphics, this.font, text, left, y + 8, x + descriptionWidth, y + 16, -1, true)); 
/* 302 */     this.scrollableRenderer.extractRenderState(graphics, left, y + 8 + lineHeight, descriptionWidth, visibleLines * lineHeight, () -> label.visitLines(TextAlignment.LEFT, left, y + 8 + lineHeight, lineHeight, graphics.textRenderer()));
/* 303 */     if (background != null)
/* 304 */       FactoryGuiGraphics.of(graphics).blit(background, left, y + height - descriptionFromBottom, 0.0F, 0.0F, getImageWidth(), getImageHeight(), getImageWidth(), getImageHeight());  } @Nullable public List<Identifier> enabledMaps() { return this.enabledMaps; } public boolean isVotingScreen() { return this.isVotingScreen; } public Minigame<?> getMinigame() { Screen screen = this.parent; LegacyDataScreen s = (LegacyDataScreen)screen; return isVotingScreen() ? this.minigame : ((screen instanceof LegacyDataScreen) ? s.getMinigame() : null); } public List<MapInfo> mapInfos() { return this.mapInfos; } private void renderTooltipBox(GuiGraphicsExtractor guiGraphics, LayoutElement panel) { renderTooltipBox(guiGraphics, panel, 0); } private void renderTooltipBox(GuiGraphicsExtractor guiGraphics, LayoutElement panel, int xOffset) { renderTooltipBox(guiGraphics, panel.getX() + panel.getWidth() - 2 + xOffset, panel.getY() + 5, getDefaultWidth() - 5, panel.getHeight() - 10); } private MultiLineLabel getLabel(GuiEventListener listener, int width) { if (listener == null) return MultiLineLabel.create(this.font, width, new Component[0]);  return MultiLineLabel.create(this.font, (Component)Component.literal("missingno"), width); }
/*     */   private MultiLineLabel getLabel(int width) { GuiEventListener focused = getFocused(); if (focused instanceof MapList.ButtonTickBox) { MapList.ButtonTickBox buttonTickBox = (MapList.ButtonTickBox)focused; return MultiLineLabel.create(this.font, buttonTickBox.mapInfo().description(), width); }  return getLabel(focused, width); }
/*     */   private Component getComponents(GuiEventListener listener) { if (listener == null) return (Component)Component.empty();  return (Component)Component.literal("missingno"); }
/*     */   private Component getComponents() { GuiEventListener focused = getFocused(); if (focused instanceof MapList.ButtonTickBox) { MapList.ButtonTickBox buttonTickBox = (MapList.ButtonTickBox)focused; return buttonTickBox.mapInfo().description(); }  return getComponents(focused); }
/*     */   private Identifier getImage() { GuiEventListener focused = getFocused(); if (focused instanceof MapList.ButtonTickBox) { MapList.ButtonTickBox buttonTickBox = (MapList.ButtonTickBox)focused; return buttonTickBox.mapInfo().id().withPrefix("textures/gui/" + getMinigame().tId() + "/maps/").withSuffix(".png"); }  return null; }
/*     */   private Component getText() { GuiEventListener focused = getFocused(); if (focused instanceof MapList.ButtonTickBox) { MapList.ButtonTickBox buttonTickBox = (MapList.ButtonTickBox)focused; return buttonTickBox.mapInfo().displayName(); }  return null; }
/* 310 */   public static int getDefaultWidth() { return LegacyOptions.getUIMode().isSD() ? 115 : 195; }
/*     */ 
/*     */   
/*     */   public static int getImageWidth() {
/* 314 */     return LegacyOptions.getUIMode().isSD() ? 100 : 174;
/*     */   }
/*     */   
/*     */   public static int getImageHeight() {
/* 318 */     return (int)(getImageWidth() / 2.013888888888889D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void bindingStateTick(BindingState bindingState) {
/* 323 */     super.bindingStateTick(bindingState);
/* 324 */     if (!isVotingScreen() && 
/* 325 */       bindingState.pressed && bindingState.canClick()) {
/* 326 */       if (bindingState.matches(this.minecraft.options.keyInventory)) {
/* 327 */         this.mapList.selectAll();
/* 328 */         LegacySoundUtil.playSimpleUISound((SoundEvent)SoundEvents.UI_BUTTON_CLICK.value(), 1.0F);
/*     */       } 
/* 330 */       if (bindingState.matches(Legacy4JClient.keyCrafting)) {
/* 331 */         this.mapList.deselectAll();
/* 332 */         LegacySoundUtil.playSimpleUISound((SoundEvent)SoundEvents.UI_BUTTON_CLICK.value(), 1.0F);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\gui\screen\LegacyMapSelectionScreen.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */