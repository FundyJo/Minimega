/*    */ package dev.jab125.minimega.mod.compat.legacy4j.client;
/*    */ 
/*    */ import dev.jab125.minimega.mod.util.controller.glide.GlideGameType;
/*    */ 


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\client\Legacy4JCompatClient$1.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */