/*    */ package dev.jab125.minimega.mod.compat.legacy4j;
/*    */ 
/*    */ import dev.jab125.minimega.mod.abstractions.modloader.ModLoader;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Legacy4JCompatMixinPlugin
/*    */   implements IMixinConfigPlugin
/*    */ {
/*    */   public void onLoad(String mixinPackage) {}
/*    */   
/*    */   public String getRefMapperConfig() {
/* 18 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
/* 23 */     return ModLoader.isLegacy4jInstalled();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getMixins() {
/* 33 */     return null;
/*    */   }
/*    */   
/*    */   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */   
/*    */   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\Legacy4JCompatMixinPlugin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */