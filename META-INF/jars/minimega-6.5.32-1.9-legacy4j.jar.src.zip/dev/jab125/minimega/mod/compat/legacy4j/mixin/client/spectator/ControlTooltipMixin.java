/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.spectator;
/*    */ import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
/*    */ import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
/*    */ import dev.jab125.minimega.mod.client.MinimegaClient;
/*    */ import dev.jab125.minimega.mod.util.controller.AbstractMinigameController;
/*    */ import dev.jab125.minimega.mod.util.controller.battle.BattleMinigameController;
/*    */ import dev.jab125.minimega.mod.util.minigamedata.BattleConfig;
/*    */ import dev.jab125.minimega.mod.util.minigamedata.MinigameSpecificConfig;
/*    */ import dev.jab125.minimega.mod.util.minigamedata.battle.BattleConfigSettings;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import wily.legacy.client.screen.ControlTooltip;
/*    */ 
/*    */ @Mixin({ControlTooltip.class})
/*    */ public interface ControlTooltipMixin {
/*    */   @WrapMethod(method = {"getAttackAction"}, remap = false)
/*    */   private static Component getAttackAction(Minecraft minecraft, Operation<Component> original) {
/* 20 */     if (attackShouldBeSqueak(minecraft)) return (Component)Component.literal("Squeak"); 
/* 21 */     return (Component)original.call(new Object[] { minecraft });
/*    */   }
/*    */   @Unique
/*    */   private static boolean attackShouldBeSqueak(Minecraft minecraft) {
/* 25 */     AbstractMinigameController abstractMinigameController = MinimegaClient.getMinigameController(); if (abstractMinigameController instanceof BattleMinigameController) { BattleMinigameController controller = (BattleMinigameController)abstractMinigameController; MinigameSpecificConfig minigameSpecificConfig = controller.getMinigameData().config(); if (minigameSpecificConfig instanceof BattleConfig) { BattleConfig battleConfig = (BattleConfig)minigameSpecificConfig; try { BattleConfigSettings battleConfigSettings1 = battleConfig.settings();
/* 26 */           BattleConfigSettings settings = battleConfigSettings1; if (settings.spectatorMode().canSqueak() && minecraft.player.isSpectator() && minecraft.getCameraEntity() == minecraft.player); return false; } catch (Throwable throwable) { throw new MatchException(throwable.toString(), throwable); }
/*    */          }
/*    */        }
/*    */     
/*    */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\spectator\ControlTooltipMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */