/*    */ package dev.jab125.minimega.mod.compat.legacy4j.mixin.client.glide;
/*    */ 
/*    */ import dev.jab125.minimega.mod.client.GlideHudHelpers;
/*    */ import dev.jab125.minimega.mod.compat.legacy4j.client.Legacy4JCompatClient;
/*    */ import dev.jab125.minimega.mod.party.GlideSlotsMetadata;
/*    */ import net.minecraft.client.DeltaTracker;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ import net.minecraft.client.gui.GuiGraphicsExtractor;
/*    */ import net.minecraft.world.entity.player.Player;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import wily.factoryapi.base.client.UIAccessor;
/*    */ import wily.factoryapi.util.FactoryGuiElement;
/*    */ 
/*    */ @Mixin({GlideHudHelpers.class})
/*    */ public class GlideHudHelpersMixin {
/*    */   @Inject(method = {"renderGlideHotbar"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private static void renderStart(Gui gui, Player player, GlideSlotsMetadata slotsMetadata, GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
/* 22 */     CallbackInfo ci2 = new CallbackInfo("lolwhocares", true);
/* 23 */     UIAccessor accessor = UIAccessor.of(gui);
/* 24 */     FactoryGuiElement.HOTBAR.prepareMixin(guiGraphics, accessor, ci2);
/* 25 */     if (ci2.isCancelled()) {
/* 26 */       ci.cancel();
/*    */       return;
/*    */     } 
/* 29 */     float x = guiGraphics.guiWidth() / 2.0F;
/* 30 */     float y = guiGraphics.guiHeight() - 5.0F;
/* 31 */     guiGraphics.pose().translate(x, y);
/* 32 */     guiGraphics.pose().scale(1.0F / FactoryGuiElement.HOTBAR.getScale("scaleX", accessor), 1.0F / FactoryGuiElement.HOTBAR.getScale("scaleY", accessor));
/* 33 */     guiGraphics.pose().translate(-x, -y);
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderGlideHotbar"}, at = {@At("TAIL")})
/*    */   private static void renderEnd(Gui gui, Player player, GlideSlotsMetadata slotsMetadata, GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
/* 38 */     FactoryGuiElement.HOTBAR.finalizeMixin(guiGraphics, UIAccessor.of(gui));
/*    */     
/* 40 */     if ((Minecraft.getInstance()).screen == null && (Minecraft.getInstance()).level != null)
/* 41 */       Legacy4JCompatClient.tooltips.setupControlTooltips(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\timos\Downloads\minimega-6.5.32.jar!\META-INF\jars\minimega-6.5.32-1.9-legacy4j.jar!\dev\jab125\minimega\mod\compat\legacy4j\mixin\client\glide\GlideHudHelpersMixin.class
 * Java compiler version: 25 (69.0)
 * JD-Core Version:       1.1.3
 */